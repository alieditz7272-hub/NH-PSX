# NH PSX Super Analysis

Fresh mobile-first GitHub Pages PWA for PSX analysis.

- Responsive bright/dark interface
- Company search and quick symbols
- Multi-timeframe analysis: 5m, 15m, 30m, 1H, 4H, 1D, 1W, 1M
- Candlestick chart with EMA 9/20/50/100/200
- Pivot, support and resistance levels
- Intraday, short-term and swing signal cards
- RSI, MACD and volume status
- BUY = green, SELL = red, NO TRADE = orange across signal boxes
- No Netlify, Firebase or Gemini dependency

GitHub Pages: Settings → Pages → Deploy from branch → main → /(root).
