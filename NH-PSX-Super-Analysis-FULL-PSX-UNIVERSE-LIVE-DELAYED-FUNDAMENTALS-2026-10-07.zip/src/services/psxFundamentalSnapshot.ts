export interface FundamentalSnapshot {
  symbol: string;
  companyName: string;
  currentEps: number | null;
  expectedEps: number | null;
  peRatio: number | null;
  sectorMedianPe: number | null;
  faceValue: number | null;
  currentBookValue: number | null;
  expectedBookValue: number | null;
  currentEnterpriseValue: number | null;
  expectedEnterpriseValue: number | null;
  latestCashDividend: number | null;
  expectedCashDividend: number | null;
  latestCashDividendExDate: string | null;
  currentYearProfitLoss: number | null;
  previousYearProfitLoss: number | null;
  source: string;
  fetchedAt: number;
}

const API = 'https://psxdata-api.fastapicloud.dev';
const n = (v: any) => {
  if (v === null || v === undefined || v === '') return null;
  const x = Number(String(v).replace(/,/g, '').replace(/%/g, '').trim());
  return Number.isFinite(x) ? x : null;
};
const first = (obj: any, keys: string[]) => {
  for (const key of keys) {
    if (obj && obj[key] !== undefined && obj[key] !== null && obj[key] !== '') return obj[key];
  }
  return null;
};
const cleanSymbol = (symbol: string) => symbol.replace(/\.PSX$|\.KA$/i, '').replace(/[^A-Z0-9&._-]/gi, '').toUpperCase();
const median = (values: number[]) => {
  if (!values.length) return null;
  const a = [...values].sort((x, y) => x - y);
  return a[Math.floor(a.length / 2)];
};

function parseCompanyPage(html: string) {
  const text = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/\s+/g, ' ')
    .trim();

  const labelled = (labels: string[]) => {
    for (const label of labels) {
      const re = new RegExp(`${label}\\s*[:|]?\\s*([-+]?\\d[\\d,]*(?:\\.\\d+)?)`, 'i');
      const m = re.exec(text);
      if (m) return n(m[1]);
    }
    return null;
  };
  const dateAfter = (labels: string[]) => {
    for (const label of labels) {
      const re = new RegExp(`${label}\\s*[:|]?\\s*(\\d{1,2}[-/]\\d{1,2}[-/]20\\d{2}|20\\d{2}[-/]\\d{1,2}[-/]\\d{1,2})`, 'i');
      const m = re.exec(text);
      if (m) return m[1];
    }
    return null;
  };

  return {
    faceValue: labelled(['Face Value']),
    bookValue: labelled(['Book Value Per Share', 'Book Value']),
    enterpriseValue: labelled(['Enterprise Value']),
    eps: labelled(['EPS', 'Earnings Per Share']),
    profit: labelled(['Profit After Tax', 'Profit / Loss', 'Profit Loss']),
    previousProfit: labelled(['Previous Year Profit', 'Previous Profit']),
    dividend: labelled(['Latest Cash Dividend', 'Latest Dividend', 'Cash Dividend']),
    exDate: dateAfter(['Ex Date', 'Ex-Date', 'Dividend Ex Date']),
  };
}

let screenerCache: { rows: any[]; fetchedAt: number } | null = null;
async function fetchScreener(): Promise<{ rows: any[]; fetchedAt: number }> {
  if (screenerCache && Date.now() - screenerCache.fetchedAt < 60_000 && screenerCache.rows.length > 100) return screenerCache;
  const res = await fetch(`${API}/screener?ts=${Date.now()}`, { cache: 'no-store' });
  if (!res.ok) throw new Error(`PSX screener HTTP ${res.status}`);
  const payload = await res.json();
  const rows = Array.isArray(payload) ? payload : payload?.data;
  if (!Array.isArray(rows) || rows.length < 100) throw new Error('PSX screener returned an incomplete universe');
  screenerCache = { rows, fetchedAt: Date.now() };
  return screenerCache;
}

export async function fetchFundamentalSnapshot(symbol: string): Promise<FundamentalSnapshot> {
  const clean = cleanSymbol(symbol);
  const { rows, fetchedAt } = await fetchScreener();
  const row = rows.find((r: any) => String(first(r, ['symbol', 'SYMBOL', 'ticker']) ?? '').replace(/\.PSX$/i, '').toUpperCase() === clean);
  if (!row) throw new Error(`${clean} not found in the current PSX screener universe`);

  const price = n(first(row, ['price', 'current', 'CURRENT', 'close', 'PRICE']));
  const pe = n(first(row, ['peRatio', 'pe', 'PE', 'p/e', 'P/E RATIO', 'PE RATIO']));
  const directEps = n(first(row, ['eps', 'EPS', 'ttmEps', 'TTM EPS', 'earningsPerShare']));
  const pb = n(first(row, ['pbRatio', 'priceToBook', 'priceBook', 'P/B', 'PB RATIO', 'PRICE TO BOOK']));
  const directBook = n(first(row, ['bookValue', 'bookValuePerShare', 'Book Value', 'BOOK VALUE', 'BVPS']));
  const marketCap = n(first(row, ['marketCap', 'market_cap', 'MARKET CAP']));
  const sector = String(first(row, ['sector', 'SECTOR']) ?? '');
  const sectorPes = rows
    .filter((r: any) => String(first(r, ['sector', 'SECTOR']) ?? '') === sector)
    .map((r: any) => n(first(r, ['peRatio', 'pe', 'PE', 'P/E RATIO', 'PE RATIO'])))
    .filter((v: number | null): v is number => v !== null && v > 0 && v < 100);

  let company = { faceValue: null as number|null, bookValue: null as number|null, enterpriseValue: null as number|null, eps: null as number|null, profit: null as number|null, previousProfit: null as number|null, dividend: null as number|null, exDate: null as string|null };
  try {
    const res = await fetch(`https://dps.psx.com.pk/company/${encodeURIComponent(clean)}?ts=${Date.now()}`, { cache: 'no-store' });
    if (res.ok) company = parseCompanyPage(await res.text());
  } catch {
    // Browser CORS/network can block the official profile; screener-derived fields remain usable.
  }

  const currentEps = company.eps ?? directEps ?? (price && pe && pe > 0 ? Number((price / pe).toFixed(4)) : null);
  const currentBookValue = company.bookValue ?? directBook ?? (price && pb && pb > 0 ? Number((price / pb).toFixed(4)) : null);
  const currentYearProfitLoss = company.profit ?? n(first(row, ['profitAfterTax', 'profit', 'PAT', 'netProfit']));
  const previousYearProfitLoss = company.previousProfit ?? n(first(row, ['previousProfit', 'previousYearProfit', 'priorYearProfit']));

  const growth = currentYearProfitLoss !== null && previousYearProfitLoss !== null && previousYearProfitLoss !== 0
    ? (currentYearProfitLoss / previousYearProfitLoss) - 1 : null;
  const boundedGrowth = growth === null ? null : Math.max(-0.20, Math.min(0.25, growth));
  const expectedEps = currentEps !== null && boundedGrowth !== null ? Number((currentEps * (1 + boundedGrowth)).toFixed(2)) : null;
  const expectedBookValue = currentBookValue !== null && boundedGrowth !== null ? Number((currentBookValue * (1 + boundedGrowth)).toFixed(2)) : null;

  return {
    symbol: clean,
    companyName: String(first(row, ['name', 'companyName', 'company', 'NAME']) ?? clean),
    currentEps,
    expectedEps,
    peRatio: pe,
    sectorMedianPe: median(sectorPes),
    faceValue: company.faceValue,
    currentBookValue,
    expectedBookValue,
    currentEnterpriseValue: company.enterpriseValue ?? n(first(row, ['enterpriseValue', 'enterprise_value', 'EV'])),
    expectedEnterpriseValue: null,
    latestCashDividend: company.dividend ?? n(first(row, ['latestDividend', 'dividend', 'cashDividend'])),
    expectedCashDividend: null,
    latestCashDividendExDate: company.exDate,
    currentYearProfitLoss,
    previousYearProfitLoss,
    source: company.faceValue || company.bookValue || company.enterpriseValue || company.dividend ? 'PSX Data Portal + PSX screener' : 'PSX screener (verified fields only)',
    fetchedAt,
  };
}
