import React from 'react';
import { Logo } from './Logo';
import { Lock, Download, RefreshCw } from 'lucide-react';

interface TopBrandingBarProps {
  onLockTerminal?: () => void;
  isUnlocked?: boolean;
}

export const TopBrandingBar: React.FC<TopBrandingBarProps> = ({ onLockTerminal, isUnlocked }) => {
  const [canInstall, setCanInstall] = React.useState(false);
  const [standalone, setStandalone] = React.useState(false);
  React.useEffect(() => {
    const check = () => {
      const isApp = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true;
      setStandalone(Boolean(isApp));
      setCanInstall(Boolean((window as any).__nhInstallPrompt));
    };
    check();
    window.addEventListener('nh-pwa-install-ready', check);
    window.addEventListener('nh-pwa-installed', check);
    return () => {
      window.removeEventListener('nh-pwa-install-ready', check);
      window.removeEventListener('nh-pwa-installed', check);
    };
  }, []);
  const updateKnowledge = async () => {
    try {
      await fetch(`./data/superbrain_injected_wisdom.json?ts=${Date.now()}`, { cache: 'no-store' });
      window.dispatchEvent(new Event('nh-knowledge-update'));
      alert('Knowledge updated successfully.');
    } catch {
      alert('Knowledge update unavailable right now.');
    }
  };

  const install = async () => {
    const prompt = (window as any).__nhInstallPrompt;
    if (prompt) {
      try { await prompt.prompt(); await prompt.userChoice; } catch {}
      (window as any).__nhInstallPrompt = null;
      setCanInstall(false);
      return;
    }
    alert('Android Chrome: browser menu ⋮ → Install app / Add to Home screen.');
  };
  return (
    <div id="section-go-to-top" className="sticky top-0 z-50 w-full bg-[#05070e]/95 backdrop-blur-md border-b border-white/[0.08] shadow-[0_4px_24px_rgba(0,0,0,0.85)] font-mono select-none px-2 sm:px-4 py-2">
      <div className="w-full max-w-xl mx-auto flex flex-col items-center gap-2">
        {/* Full Mobile Screen Width Horizontal NH Logo */}
        <div className="w-full flex items-center justify-between gap-2">
          <div className="flex-1 flex items-center justify-center">
            <Logo size="full" className="w-full" />
          </div>
          {isUnlocked && onLockTerminal && (
            <button
              type="button"
              onClick={onLockTerminal}
              title="Lock Terminal (Sign Out)"
              className="px-2.5 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/60 hover:border-rose-500/50 text-slate-400 hover:text-rose-400 text-[10px] font-mono font-bold flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden xs:inline">Lock</span>
            </button>
          )}
        </div>

        {!standalone && (
          <button type="button" onClick={install} className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 font-mono font-extrabold text-xs rounded-xl border border-emerald-400/30 shadow transition-all active:scale-[0.99]" title="Install NH PSX Super Analysis">
            <Download className="w-4 h-4" />
            <span>{canInstall ? 'INSTALL PWA' : 'INSTALL / ADD TO HOME SCREEN'}</span>
          </button>
        )}

        <button type="button" onClick={updateKnowledge} className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 font-mono font-extrabold text-xs rounded-xl border border-cyan-400/30 shadow transition-all active:scale-[0.99]" title="Update Knowledge">
          <RefreshCw className="w-4 h-4" />
          <span>UPDATE KNOWLEDGE</span>
        </button>

        {/* Full Mobile Screen Width WhatsApp Number Button (Identical Width to Logo) */}
        <div className="w-full">
          <a
            href="https://wa.me/923009412177"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-2 px-4 py-2 sm:py-2.5 bg-[#080e18] hover:bg-[#0c1524] text-emerald-400 hover:text-emerald-300 font-mono font-semibold text-xs xs:text-sm sm:text-base rounded-xl border border-slate-700/70 hover:border-slate-600 shadow-[0_2px_10px_rgba(0,0,0,0.6)] transition-all transform active:scale-[0.99] text-center tracking-wide"
            title="Contact Nadeem Hassan on WhatsApp: 03009412177"
          >
            <svg className="w-4.5 h-4.5 xs:w-5 xs:h-5 fill-current shrink-0" viewBox="0 0 24 24">
              <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" />
            </svg>
            <span>WhatsApp: 03009412177</span>
          </a>
        </div>
      </div>
    </div>
  );
};
