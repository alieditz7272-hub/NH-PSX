import json,re,time,concurrent.futures
from datetime import datetime,timezone
from urllib.request import Request,urlopen

BASE='https://dps.psx.com.pk'
HEADERS={'User-Agent':'Mozilla/5.0 (compatible; NH-PSX-Super-Analysis/1.0)','Accept':'text/html,application/xhtml+xml'}

def get(url):
    req=Request(url,headers=HEADERS)
    with urlopen(req,timeout=30) as r:return r.read().decode('utf-8','replace')

def clean(s):
    s=re.sub(r'<script[\s\S]*?</script>|<style[\s\S]*?</style>',' ',s,flags=re.I)
    s=re.sub(r'<[^>]+>',' ',s); s=re.sub(r'&nbsp;',' ',s,flags=re.I); s=re.sub(r'&amp;','&',s,flags=re.I)
    return re.sub(r'\s+',' ',s).strip()

def num(v):
    try:
        x=str(v).replace(',','').replace('%','').replace('Rs','').replace('(','-').replace(')','').strip()
        return float(x) if x not in ('','-','—','N/A','n/a') else None
    except:return None

def table_rows(html):
    out=[]
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>',html,re.I|re.S):
        cells=[clean(c) for c in re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>',tr,re.I|re.S)]
        if cells: out.append(cells)
    return out

def labelled(rows,label):
    label=label.lower()
    for r in rows:
        if r and label in r[0].lower(): return [num(x) for x in r[1:]]
    return []

def parse_symbol(sym):
    try: html=get(f'{BASE}/company/{sym}')
    except Exception:return None
    rows=table_rows(html); text=clean(html)
    eps=labelled(rows,'EPS')
    profits=labelled(rows,'Profit after Taxation')
    dividends=labelled(rows,'Cash Dividend') or labelled(rows,'Dividend')
    # PSX company pages publish the annual financial block in descending year order.
    # Use the first reported annual values; do not invent missing fields.
    current_eps=eps[0] if eps else None
    prev_eps=eps[1] if len(eps)>1 else None
    current_profit=profits[0] if profits else None
    prev_profit=profits[1] if len(profits)>1 else None
    latest_div=next((x for x in dividends if x is not None),None)
    expected_eps=None
    if current_eps is not None and current_profit is not None and prev_profit not in (None,0):
        growth=current_profit/prev_profit-1
        growth=max(-0.20,min(0.25,growth))
        expected_eps=round(current_eps*(1+growth),2)
    expected_div=latest_div
    # Explicit face/par value only. No guessed defaults.
    mf=re.search(r'(?:Face Value|Par Value)\s*(?:Rs\.?\s*)?([\d,.]+)',text,re.I)
    face=num(mf.group(1)) if mf else None
    # Market cap and shares are published on the PSX company page. EV/BV require balance-sheet
    # data not exposed consistently on this page, so leave them null rather than fabricating them.
    fetched=int(time.time()*1000)
    return {'symbol':sym,'companyName':sym,'currentEps':current_eps,'expectedEps':expected_eps,
            'currentBookValue':None,'expectedBookValue':None,'currentEnterpriseValue':None,'expectedEnterpriseValue':None,
            'latestCashDividend':latest_div,'expectedCashDividend':expected_div,'latestCashDividendExDate':None,
            'currentYearProfitLoss':current_profit,'previousYearProfitLoss':prev_profit,'faceValue':face,
            'source':'PSX Data Portal — official company financials','fetchedAt':fetched}

def symbols():
    try:
        with open('public/data/market.json',encoding='utf-8') as f: payload=json.load(f)
        syms=[]
        for r in payload.get('data',[]):
            s=str(r.get('symbol','')).replace('.PSX','').replace('.KA','').upper()
            if re.fullmatch(r'[A-Z0-9&._-]{1,20}',s) and s not in {'KSE100','KSE100PR','ALLSHR','KSE30','KMI30','KMIALLSHR'} and s not in syms:
                syms.append(s)
        return syms
    except Exception:
        return []

syms=symbols(); print('symbols',len(syms))
results={}
def one(s):
    try:return s,parse_symbol(s)
    except Exception:return s,None
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
    for s,r in ex.map(one,syms):
        if r and any(r.get(k) is not None for k in ('currentEps','currentYearProfitLoss','latestCashDividend')): results[s]=r
        if len(results)%25==0 and results: print('parsed',len(results))

payload={'fetchedAt':datetime.now(timezone.utc).isoformat(),'source':'PSX Data Portal — official company financials','data':results}
with open('public/data/fundamentals.json','w',encoding='utf-8') as f:json.dump(payload,f,separators=(',',':'))
print('wrote',len(results))
if len(results)<20: raise RuntimeError(f'PSX fundamentals parser returned only {len(results)} companies')
