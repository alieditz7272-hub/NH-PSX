import json, re, time
from datetime import datetime, timezone
from urllib.request import Request, urlopen

BASE='https://dps.psx.com.pk'
HEADERS={'User-Agent':'Mozilla/5.0 (compatible; NH-PSX-Super-Analysis/1.0)','Accept':'text/html,application/xhtml+xml,application/json','X-Requested-With':'XMLHttpRequest'}

def get(url):
    req=Request(url,headers=HEADERS)
    with urlopen(req,timeout=30) as r:
        return r.read().decode('utf-8','replace')

def num(v):
    try: return float(str(v).replace(',','').replace('%','').strip())
    except: return 0

def parse_market(html):
    rows=[]
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>', html, re.I|re.S):
        fields={}
        for cell in re.findall(r'<t[dh][^>]*>.*?</t[dh]>', tr, re.I|re.S):
            name=re.search(r'data-name=["\']([^"\']+)',cell,re.I)
            if not name: continue
            order=re.search(r'data-order=["\']([^"\']+)',cell,re.I)
            text=re.sub(r'<[^>]+>',' ',cell)
            text=re.sub(r'&nbsp;',' ',text,flags=re.I)
            text=re.sub(r'&amp;','&',text,flags=re.I)
            text=re.sub(r'\s+',' ',text).strip()
            fields[name.group(1).lower().replace(' ','')]=order.group(1) if order else text
        sym=str(fields.get('symbol','')).replace('.PSX','').replace('.KA','').strip().upper()
        if not re.fullmatch(r'[A-Z0-9&._-]{1,20}',sym) or sym in ('SYMBOL','SNO','SR.NO'): continue
        ldcp=num(fields.get('ldcp')); op=num(fields.get('open')); hi=num(fields.get('high')); lo=num(fields.get('low'))
        cur=num(fields.get('close') or fields.get('current')); ch=num(fields.get('change')); pct=num(fields.get('percentchange') or fields.get('changepercent') or fields.get('percent_change')); vol=num(fields.get('volume'))
        if cur>0:
            rows.append({'symbol':sym,'name':sym,'price':cur,'change':ch,'changePercent':pct,'open':op or cur,'high':hi or cur,'low':lo or cur,'previousClose':ldcp,'volume':vol})
    return list({r['symbol']:r for r in rows}.values())

def parse_kse(html):
    text=re.sub(r'<[^>]+>',' ',html)
    text=re.sub(r'&nbsp;',' ',text,flags=re.I)
    text=re.sub(r'\s+',' ',text).strip()
    m=re.search(r'KSE100\s+([\d,]+(?:\.\d+)?)\s+([+-]?[\d,]+(?:\.\d+)?)\s*\(([+-]?[\d.]+)%\)',text,re.I)
    if not m: return None
    cur=num(m.group(1)); ch=num(m.group(2)); pct=num(m.group(3))
    if cur<=0:return None
    return {'symbol':'KSE100','name':'KSE-100 Index','price':cur,'change':ch,'changePercent':pct,'open':cur-ch,'high':cur,'low':cur,'previousClose':cur-ch,'volume':0}

now=datetime.now(timezone.utc).isoformat()
market_html=get(BASE+'/market-watch')
rows=parse_market(market_html)
if len(rows)<20:
    raise RuntimeError(f'PSX market-watch parser returned only {len(rows)} rows')
try:
    idx_html=get(BASE+'/indices')
    kse=parse_kse(idx_html)
    if kse: rows.insert(0,kse)
except Exception:
    pass
# The GitHub runner timestamp is the exact time this official PSX snapshot was fetched.
# Keep it separate from the app's local clock so the UI never labels local time as PSX source time.
payload={'fetchedAt':now,'sourceTime':now,'source':'PSX Data Portal — official market-watch snapshot','delay':'PSX delayed/public snapshot','data':rows}
with open('public/data/market.json','w',encoding='utf-8') as f: json.dump(payload,f,separators=(',',':'))
print(f'Wrote {len(rows)} quotes at {now}')
