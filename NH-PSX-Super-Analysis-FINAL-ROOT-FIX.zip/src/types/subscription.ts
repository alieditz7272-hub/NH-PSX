export type SubscriptionPlanType = 'MONTHLY' | 'YEARLY';

export type PaymentMethodType = 'EASYPAISA' | 'BANK_TRANSFER';

export type PaymentStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'EXPIRED' | 'CANCELLED';

export type SubscriptionStatus = 'ACTIVE' | 'EXPIRED' | 'PENDING' | 'CANCELLED' | 'NONE';

export type UserAccountState = 
  | 'NEW_USER'
  | 'PAYMENT_REQUIRED'
  | 'PAYMENT_PENDING'
  | 'PAYMENT_APPROVED'
  | 'ACTIVE_SUBSCRIBER'
  | 'SUBSCRIPTION_EXPIRING'
  | 'SUBSCRIPTION_EXPIRED'
  | 'EXPIRED'
  | 'PAYMENT_REJECTED';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  username?: string;
  role: 'USER' | 'ADMIN';
  accountState: UserAccountState;
  subscriptionStatus: SubscriptionStatus;
  plan?: SubscriptionPlanType;
  activeSubscriptionId?: string;
  createdAt: number;
  isGuest?: boolean;
  guestNotes?: string;
  plainPasswordHint?: string;
}

export interface GuestUserRecord {
  id: string;
  name: string;
  username: string;
  email: string;
  password: string;
  phone?: string;
  role: 'USER' | 'ADMIN';
  accountState: UserAccountState;
  subscriptionStatus: SubscriptionStatus;
  plan: SubscriptionPlanType;
  subscriptionId?: string;
  startDate: number;
  expiryDate: number;
  daysRemaining: number;
  isExpiringSoon: boolean;
  createdAt: number;
  notes?: string;
  relationTag?: 'Family Member' | 'Close Friend' | 'VIP Colleague' | 'VIP Trader' | 'General Guest';
  createdByAdmin: string;
  isActive: boolean;
}

export interface SubscriptionRecord {
  subscriptionId: string;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  plan: SubscriptionPlanType;
  status: SubscriptionStatus;
  startDate: number; // timestamp
  expiryDate: number; // timestamp
  paymentId: string;
  daysRemaining: number;
  isExpiringSoon: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface PaymentRecord {
  paymentId: string;
  id?: string;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  plan: SubscriptionPlanType;
  amount: number;
  currency: 'PKR';
  paymentMethod: PaymentMethodType;
  transactionId: string;
  paymentDate: string;
  screenshotData?: string; // base64 or safe data URL
  screenshotName?: string;
  notes?: string;
  status: PaymentStatus;
  submittedAt: number;
  reviewedAt?: number;
  reviewedBy?: string;
  adminNotes?: string;
  rejectionReason?: string;
  expiryDate?: number;
  activationDate?: number;
}

export interface AdminMetrics {
  totalUsers: number;
  activeSubscribers: number;
  pendingPayments: number;
  expiredSubscriptions: number;
  monthlySubscribers: number;
  yearlySubscribers: number;
  totalApprovedPayments: number;
  totalRevenue: number; // PKR (Approved only)
  pendingRevenue: number; // PKR
  rejectedPayments: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
}

export interface SubscriberDetail {
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  role: 'USER' | 'ADMIN';
  accountState: UserAccountState;
  subscriptionStatus: SubscriptionStatus;
  plan?: SubscriptionPlanType;
  subscriptionId?: string;
  startDate?: number;
  expiryDate?: number;
  daysRemaining: number;
  isExpiringSoon: boolean;
  lastPayment?: {
    paymentId: string;
    amount: number;
    paymentMethod: PaymentMethodType;
    transactionId: string;
    paymentDate: string;
    submittedAt: number;
    status: PaymentStatus;
  };
}

export interface RevenueBreakdown {
  totalApprovedRevenue: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
  approvedEasypaisaRevenue: number;
  approvedBankTransferRevenue: number;
  pendingAmount: number;
  rejectedAmount: number;
}

export interface AuditLog {
  id: string;
  timestamp: number;
  action: string;
  details: string;
  performedBy: string;
  userId?: string;
  paymentId?: string;
  previousStatus?: string;
  newStatus?: string;
  adminNote?: string;
}

export const PLAN_CONFIGS = {
  MONTHLY: {
    id: 'MONTHLY' as SubscriptionPlanType,
    name: 'NH Stock Trading Pro (Monthly)',
    tagline: 'Standard 1-Month Full Pro Access',
    price: 5000,
    priceFormatted: '5,000',
    billingCycle: '/ month',
    durationDays: 30,
    durationMonths: 1,
    savingsText: null,
    equivalentMonthly: '5,000 / month'
  },
  YEARLY: {
    id: 'YEARLY' as SubscriptionPlanType,
    name: 'NH Stock Trading Pro (Yearly)',
    tagline: 'Best Value • 12-Month Pro Trading Terminal',
    price: 48000,
    priceFormatted: '48,000',
    billingCycle: '/ year',
    durationDays: 365,
    durationMonths: 12,
    savingsText: 'Save 12,000 for Yearly Subscription',
    equivalentMonthly: '4,000 / month'
  }
};

export const PAYMENT_METHODS = {
  EASYPAISA: {
    id: 'EASYPAISA' as PaymentMethodType,
    title: 'Easypaisa',
    accountName: 'Nadeem Hassan',
    accountTitle: 'Nadeem Hassan',
    accountNumber: '03009412177',
    tag: 'Easypaisa Transfer'
  },
  BANK_TRANSFER: {
    id: 'BANK_TRANSFER' as PaymentMethodType,
    title: 'Faysal Bank',
    bankName: 'Faysal Bank',
    accountTitle: 'Nadeem Hassan',
    accountNumber: '3426708000003272',
    iban: 'PK32FAYS3426708000003272',
    tag: 'Bank Transfer / IBFT'
  }
};
