export type AnalyticsEventType =
  | 'app_open'
  | 'landing_page_view'
  | 'subscription_page_view'
  | 'monthly_plan_view'
  | 'yearly_plan_view'
  | 'plan_selected'
  | 'payment_method_view'
  | 'easypaisa_selected'
  | 'bank_transfer_selected'
  | 'payment_form_started'
  | 'payment_form_completed'
  | 'payment_submitted'
  | 'payment_pending'
  | 'payment_approved'
  | 'payment_rejected'
  | 'subscription_activated'
  | 'subscription_expired'
  | 'subscription_renewal_started'
  | 'subscription_renewed'
  | 'session_started'
  | 'session_ended'
  | 'heartbeat';

export type DeviceCategory = 'Android' | 'iPhone/iOS' | 'Desktop' | 'Tablet' | 'Unknown';
export type BrowserCategory = 'Chrome' | 'Safari' | 'Edge' | 'Firefox' | 'Other';
export type TrafficSourceCategory = 'Direct' | 'Google/Search' | 'Facebook' | 'Instagram' | 'Other Referral' | 'Unknown';

export interface AnalyticsEvent {
  eventId: string;
  eventType: AnalyticsEventType;
  sessionId: string;
  visitorId: string;
  userId?: string;
  userName?: string;
  userEmail?: string;
  timestamp: number;
  plan?: 'MONTHLY' | 'YEARLY';
  paymentMethod?: 'EASYPAISA' | 'BANK_TRANSFER';
  amount?: number;
  page?: string;
  deviceCategory: DeviceCategory;
  browser: BrowserCategory;
  trafficSource: TrafficSourceCategory;
  meta?: Record<string, any>;
}

export type DateFilterRange = 
  | 'TODAY'
  | 'YESTERDAY'
  | 'LAST_7_DAYS'
  | 'LAST_30_DAYS'
  | 'THIS_MONTH'
  | 'LAST_MONTH'
  | 'THIS_YEAR'
  | 'ALL_TIME'
  | 'CUSTOM';

export interface FunnelStage {
  stageId: string;
  stageName: string;
  stageDescription?: string;
  usersCount: number;
  percentOfTotalVisitors: number;
  conversionFromPrevPercent: number;
  dropOffPercent: number;
  dropOffCount: number;
}

export interface UserDropOffItem {
  stageName: string;
  dropOffCount: number;
  dropOffPercent: number;
  reasonDescription: string;
  nextStepName: string;
}

export interface PaymentAbandonmentStats {
  paymentPageVisitors: number;
  paymentStarted: number;
  paymentSubmitted: number;
  paymentAbandoned: number;
  paymentConversionRate: number;
  paymentAbandonmentRate: number;
  highIntentUsersCount: number;
}

export interface PaymentMethodMetrics {
  views: number;
  selected: number;
  submitted: number;
  approved: number;
  conversionRate: number;
}

export interface PlanMetrics {
  views: number;
  selected: number;
  paymentStarted: number;
  submitted: number;
  approved: number;
  conversionRate: number;
}

export interface RealTimeVisitorCounters {
  totalVisitors: number;
  activeNow: number; // Active in last 5 minutes
  todayVisitors: number;
  thisWeekVisitors: number;
  thisMonthVisitors: number;
  totalSessions: number;
}

export interface TodayOverviewMetrics {
  uniqueVisitors: number;
  totalSessions: number;
  subscriptionPageViews: number;
  planSelections: number;
  paymentMethodViews: number;
  paymentFormStarts: number;
  paymentSubmissions: number;
  approvedPayments: number;
  rejectedPayments: number;
  newSubscribers: number;
  revenue: number;
}

export interface TrafficSourceBreakdown {
  direct: number;
  google: number;
  facebook: number;
  instagram: number;
  otherReferral: number;
  unknown: number;
}

export interface DeviceBreakdown {
  android: number;
  ios: number;
  desktop: number;
  tablet: number;
  unknown: number;
  mobilePercent: number;
  desktopPercent: number;
}

export interface BrowserBreakdown {
  chrome: number;
  safari: number;
  edge: number;
  firefox: number;
  other: number;
}

export interface UserJourneyStep {
  step: string;
  timestamp: number;
  timeFormatted: string;
  meta?: any;
}

export interface UserJourneyItem {
  journeyId: string;
  sessionId: string;
  visitorId: string;
  userId?: string;
  userName?: string;
  userEmail?: string;
  isRegistered: boolean;
  deviceCategory: DeviceCategory;
  browser: BrowserCategory;
  trafficSource: TrafficSourceCategory;
  startTime: number;
  lastActiveTime: number;
  steps: UserJourneyStep[];
  outcome: 'APPROVED_SUBSCRIBER' | 'PENDING_VERIFICATION' | 'ABANDONED_PAYMENT' | 'HIGH_INTENT' | 'BOUNCED' | 'BROWSING';
  totalDurationSeconds: number;
}

export interface HourlyTrendPoint {
  hour: number;
  hourLabel: string;
  visitors: number;
  subscriptionViews: number;
  paymentStarts: number;
  paymentSubmissions: number;
  approvedPayments: number;
}

export interface DailyTrendPoint {
  date: string;
  dateLabel: string;
  visitors: number;
  paymentStarts: number;
  paymentSubmissions: number;
  approvals: number;
  revenue: number;
}

export interface AdminAlertNotification {
  id: string;
  type: 'PAYMENT_SUBMITTED' | 'PAYMENT_APPROVED' | 'PAYMENT_REJECTED' | 'PAYMENT_STARTED' | 'HIGH_INTENT' | 'SUBSCRIBER_ACTIVATED' | 'PAYMENT_PAGE_REACHED';
  title: string;
  message: string;
  timestamp: number;
  read: boolean;
  sessionId?: string;
  userId?: string;
  amount?: number;
  plan?: string;
}

export interface LiveActivityEvent {
  id: string;
  eventType: AnalyticsEventType;
  description: string;
  timestamp: number;
  timeAgo: string;
  badgeType: 'info' | 'success' | 'warning' | 'purple' | 'amber';
  userName?: string;
  isRegistered: boolean;
  device: string;
}

export interface ComprehensiveAnalyticsData {
  timeframe: DateFilterRange;
  customStartDate?: string;
  customEndDate?: string;
  lastUpdated: number;
  
  // 1. Real-time User Counters
  counters: RealTimeVisitorCounters;
  
  // 2. 10 Primary Admin Analytics Cards
  cards: {
    totalVisitors: number;
    activeNow: number;
    subscriptionPageVisitors: number;
    paymentPageVisitors: number;
    paymentStarted: number;
    paymentSubmitted: number;
    pendingPayments: number;
    approvedPayments: number;
    paymentAbandonment: number;
    activeSubscribers: number;
  };
  
  // 3. Complete User Funnel (9 Steps)
  funnel: FunnelStage[];
  
  // 4. Drop-off Analysis
  dropOffReport: {
    stages: UserDropOffItem[];
    totalLostBetweenOpenAndSub: number;
    highestDropOffStage: string;
  };
  
  // 5. Payment Page Abandonment
  abandonmentStats: PaymentAbandonmentStats;
  
  // 6. Payment Method Analytics (Easypaisa vs Faysal Bank)
  paymentMethods: {
    easypaisa: PaymentMethodMetrics;
    faysalBank: PaymentMethodMetrics;
  };
  
  // 7. Plan Analytics (Monthly vs Yearly)
  plans: {
    monthly: PlanMetrics;
    yearly: PlanMetrics;
  };
  
  // 8. Today's Snapshot
  todayMetrics: TodayOverviewMetrics;
  
  // 9. Traffic, Device, Browser
  trafficSources: TrafficSourceBreakdown;
  devices: DeviceBreakdown;
  browsers: BrowserBreakdown;
  
  // 10. Hourly & Daily Trends
  hourlyTrends: HourlyTrendPoint[];
  dailyTrends: DailyTrendPoint[];
  
  // 11. User Journeys (Recent 50)
  userJourneys: UserJourneyItem[];
  
  // 12. Live Activity Feed (Recent 30)
  liveFeed: LiveActivityEvent[];
  
  // 13. High-Intent Users List
  highIntentUsers: {
    sessionId: string;
    visitorId: string;
    userName?: string;
    email?: string;
    plan?: string;
    paymentMethod?: string;
    startedAt: number;
    lastActive: number;
    status: string;
  }[];
  
  // 14. Real-Time Admin Alerts
  notifications: AdminAlertNotification[];
}
