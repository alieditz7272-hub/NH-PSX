import { isPsxIndex } from './symbol';

export function getCurrencySymbol(_asset?: { symbol?: string; exchange?: string; countryFlag?: string } | string | null): string {
  return '';
}

/**
 * Mandatory Whole Application Rule:
 * 1. Whenever displaying any Index value, always round it (e.g. 115240)
 * 2. Whenever displaying any stock price, always display 2 digits after the point (e.g. 135.20)
 * 3. Never write 'Rs.' or 'Points'
 */
export function formatPrice(
  price: number | undefined | null,
  asset?: { symbol?: string; exchange?: string; countryFlag?: string; assetClass?: string; name?: string } | string | boolean | null,
  _decimals?: number
): string {
  if (price === undefined || price === null || typeof price !== 'number' || isNaN(price)) return 'N/A';
  
  // Rule: Whenever displaying any Index value, always round it (no decimals)
  const isIdx = asset === true || isPsxIndex(asset) || (price > 10000 && !asset);
  if (isIdx) {
    return Math.round(price).toString();
  }

  // Rule: Whenever displaying any stock price, always display exactly 2 digits after the decimal point
  return price.toFixed(2).replace(/,/g, '');
}

/**
 * Formats a value strictly as a clean pure number without 'Rs.' or 'Points'
 */
export function formatValueWithUnit(
  price: number | undefined | null,
  asset?: { symbol?: string; exchange?: string; countryFlag?: string; assetClass?: string; name?: string } | string | boolean | null,
  _decimals?: number
): string {
  return formatPrice(price, asset, _decimals);
}
