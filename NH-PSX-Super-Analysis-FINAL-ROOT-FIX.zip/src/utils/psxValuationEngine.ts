// ============================================================================
// PSX TRIANGULATED VALUATION ENGINE (EXACT AUTHENTIC FORMULATION)
// ============================================================================
// Multi-Ratio Discretionary Valuation Model for Pakistan Stock Exchange:
// 1. Normalized P/E multiple (45% weight on Normalized EPS × Sector Fair P/E)
// 2. Graham-Dodd Intrinsic Formula (35% weight: √(Fair P/E × Fair P/B × EPS × BVPS))
// 3. Net Asset Value Floor (20% weight: Book Value × Sector Fair P/B)
// 4. Sector-Adaptive Multiples (Tech, Banks, Cement, E&P, Fertilizer, etc.)
// 5. Penny Turnaround Recovery Model for low-priced counters (< 25 PKR)
// 6. Macroeconomic Index Expansion Model for KSE-100 / KSE-30 / KMI-30
// ============================================================================

import { getPsxSector } from './psxSectors';

export interface PSXValuationInput {
  symbol: string;
  currentPrice?: number;
  currentEps?: number;
  historical25YearAvgEps?: number;
  peRatio?: number;
  bookValue?: number;
  sector?: string;
  isIndex?: boolean;
}

export interface PSXProjectedValuationResult {
  symbol: string;
  currentPrice: number;
  currentEps: number;
  historical25YearAvgEps: number;
  peRatio: number;
  bookValue: number;
  projectedFairPrice: number;
  projectedFairPriceDisplay: string;
  valuationStatusEnglish: string;
  valuationStatusUrdu: string;
  formulaBaseEnglish: string;
  formulaBaseUrdu: string;
  upsideDownsidePct: number;
  isIndex: boolean;
}

export function getSectorFairMultiples(sector?: string): { fairPe: number; fairPb: number } {
  const s = (sector || '').toUpperCase();
  if (s.includes('TECH') || s.includes('SOFTWARE')) {
    return { fairPe: 16.5, fairPb: 4.2 };
  }
  if (s.includes('PHARMA') || s.includes('HEALTH')) {
    return { fairPe: 11.5, fairPb: 2.4 };
  }
  if (s.includes('FOOD') || s.includes('PERSONAL CARE')) {
    return { fairPe: 12.0, fairPb: 3.0 };
  }
  if (s.includes('AUTO') || s.includes('MOTOR')) {
    return { fairPe: 8.5, fairPb: 1.8 };
  }
  if (s.includes('FERTILIZER')) {
    return { fairPe: 7.2, fairPb: 2.2 };
  }
  if (s.includes('CEMENT') || s.includes('CONSTRUCTION')) {
    return { fairPe: 7.8, fairPb: 1.4 };
  }
  if (s.includes('EXPLORATION') || s.includes('OIL & GAS EXPLORATION') || s.includes('E&P')) {
    return { fairPe: 5.2, fairPb: 0.88 };
  }
  if (s.includes('BANK') || s.includes('FINANCIAL')) {
    return { fairPe: 4.8, fairPb: 0.95 };
  }
  if (s.includes('POWER') || s.includes('ENERGY') || s.includes('ELECTRIC')) {
    return { fairPe: 4.2, fairPb: 0.85 };
  }
  if (s.includes('REFINERY') || s.includes('MARKETING') || s.includes('OMC')) {
    return { fairPe: 5.4, fairPb: 0.78 };
  }
  if (s.includes('STEEL') || s.includes('ENGINEERING')) {
    return { fairPe: 7.0, fairPb: 1.1 };
  }
  if (s.includes('TEXTILE')) {
    return { fairPe: 6.2, fairPb: 0.75 };
  }
  if (s.includes('CHEMICAL')) {
    return { fairPe: 7.5, fairPb: 1.5 };
  }
  return { fairPe: 6.5, fairPb: 1.15 };
}

export function calculatePSXProjectedValuation(input: PSXValuationInput): PSXProjectedValuationResult {
  const cleanSym = (input.symbol || '').toUpperCase().replace('.PSX', '').replace('.KA', '').trim();
  const normSym = cleanSym.replace(/[-\s]/g, '');

  const isIndex = Boolean(
    input.isIndex ||
    normSym.startsWith('KSE100') ||
    normSym.startsWith('KSE30') ||
    normSym.startsWith('KMI30') ||
    normSym === 'KSE' ||
    normSym === 'ALLSHR' ||
    (input.sector || '').toLowerCase().includes('index')
  );

  // 1. Benchmark Indices (KSE-100, KSE-30, KMI-30) Macroeconomic Valuation Target
  if (isIndex) {
    const rawIndexPrice = (input.currentPrice && input.currentPrice > 1000)
      ? input.currentPrice
      : (normSym.includes('30') ? (normSym.startsWith('KMI') ? 68500 : 35200) : 110500);

    // KSE-100 / PSX historical mean P/E expansion target from 4.8x to historical median 5.8x
    const expansionRatio = 5.8 / 4.8;
    const projectedTargetNum = Math.round(rawIndexPrice * expansionRatio);
    const projectedDisplay = projectedTargetNum.toString();
    const upsidePct = Number((((projectedTargetNum - rawIndexPrice) / rawIndexPrice) * 100).toFixed(2));

    return {
      symbol: cleanSym,
      currentPrice: Math.round(rawIndexPrice),
      currentEps: 0,
      historical25YearAvgEps: 0,
      peRatio: 4.8,
      bookValue: 0,
      projectedFairPrice: projectedTargetNum,
      projectedFairPriceDisplay: projectedDisplay,
      valuationStatusEnglish: 'Trading at Historical Macroeconomic Valuation Discount',
      valuationStatusUrdu: 'Index tareekhi macroeconomic valuation discount par trade kar raha hai',
      formulaBaseEnglish: 'Macroeconomic Index Model: Aggregate P/E Expansion Target 5.8x (Current 4.8x)',
      formulaBaseUrdu: 'Macroeconomic Index Model: Aggregate P/E Expansion Target 5.8x (Current 4.8x)',
      upsideDownsidePct: upsidePct,
      isIndex: true
    };
  }

  // 2. Individual PSX Equities Triangulation
  const rawPrice = (input.currentPrice && input.currentPrice > 0) ? input.currentPrice : 45;
  const isPenny = rawPrice < 25;
  const resolvedSector = input.sector || getPsxSector(cleanSym) || '';
  const { fairPe, fairPb } = getSectorFairMultiples(resolvedSector);

  let curEps = (input.currentEps !== undefined && input.currentEps !== null) ? input.currentEps : 0;
  let histAvgEps = (input.historical25YearAvgEps !== undefined && input.historical25YearAvgEps !== null) ? input.historical25YearAvgEps : 0;
  let pe = (input.peRatio !== undefined && input.peRatio !== null) ? input.peRatio : 0;
  let bv = (input.bookValue !== undefined && input.bookValue !== null) ? input.bookValue : 0;

  // Infer missing fundamentals from market price & sector benchmarks
  if (curEps === 0 && pe === 0) {
    pe = fairPe;
    curEps = Number((rawPrice / Math.max(1, fairPe)).toFixed(2));
    histAvgEps = Number((curEps * 0.58).toFixed(2));
    bv = Number((curEps * 4.8).toFixed(2));
  } else if (pe === 0 && curEps > 0) {
    pe = Number((rawPrice / curEps).toFixed(1));
  }

  // Tech / Software high-growth dynamic weighting
  const isTechGrowth = resolvedSector.toUpperCase().includes('TECH') && curEps > histAvgEps;

  // Multi-decade normalized cycle earnings
  let normEps = curEps;
  if (!isTechGrowth && curEps > 0 && histAvgEps > 0) {
    normEps = (0.65 * curEps) + (0.35 * histAvgEps);
  } else if (curEps <= 0) {
    normEps = Math.max(0.10, bv > 0 ? (bv * 0.07) : (rawPrice / (fairPe * 2)));
  }

  // Pillar 1: Earnings Power Valuation (EPS × Fair Sector P/E)
  const vEarnings = normEps * fairPe;

  // Pillar 2: Benjamin Graham Intrinsic Formula (√(Fair P/E × Fair P/B × EPS × Book Value))
  const grahamMultiplier = fairPe * fairPb;
  let vGraham = vEarnings;
  if (curEps > 0 && bv > 0) {
    const rawGraham = Math.sqrt(grahamMultiplier * curEps * bv);
    vGraham = Math.min(rawGraham, Math.max(vEarnings * 1.30, rawPrice * 1.65));
  }

  // Pillar 3: Net Asset Value Floor (Book Value × Sector Fair P/B)
  const vAsset = bv > 0 ? (bv * fairPb) : (rawPrice * 0.85);

  let rawFairPrice = 0;

  if (isPenny) {
    // Penny & Turnaround Stock Model
    if (bv > 0) {
      const assetFloor = bv * 0.55;
      const earningsComponent = Math.max(0, curEps * fairPe * 0.70);
      const modeledPennyFair = (0.60 * assetFloor) + (0.40 * (earningsComponent > 0 ? earningsComponent : rawPrice * 1.25));
      rawFairPrice = Math.max(rawPrice * 1.12, Math.min(rawPrice * 1.75, modeledPennyFair));
    } else {
      rawFairPrice = rawPrice * 1.25;
    }
  } else if (isTechGrowth) {
    // High-growth Tech Formulation (70% Earnings Power + 30% Graham Intrinsic)
    rawFairPrice = (0.70 * vEarnings) + (0.30 * vGraham);
  } else {
    // Authentic Triangulated Multi-Ratio Model (45% Earnings + 35% Graham-Dodd + 20% Net Asset Book Value)
    rawFairPrice = (0.45 * vEarnings) + (0.35 * vGraham) + (0.20 * vAsset);
    rawFairPrice = Math.max(rawPrice * 0.75, Math.min(rawPrice * 1.90, rawFairPrice));
  }

  const finalProjectedFairPrice = Number(rawFairPrice.toFixed(2));
  const finalDisplay = finalProjectedFairPrice.toFixed(2);
  const upsidePct = Number((((finalProjectedFairPrice - rawPrice) / rawPrice) * 100).toFixed(2));

  let statusEn = 'Trading Near Projected Price (Fairly Valued)';
  let statusUr = 'Stock Projected Price ke qareeb trade kar raha hai (Fair Valuation)';

  if (rawPrice < finalProjectedFairPrice * 0.92) {
    statusEn = 'Trading Below Projected Price (Undervalued)';
    statusUr = 'Stock Projected Price se neechay discount par trade kar raha hai (Undervalued)';
  } else if (rawPrice > finalProjectedFairPrice * 1.08) {
    statusEn = 'Trading Above Projected Price (Premium / Overvalued)';
    statusUr = 'Stock Projected Price se ooper premium par trade kar raha hai (Overvalued)';
  }

  const formulaEn = isPenny
    ? 'Turnaround Recovery Model: 60% Tangible Asset Floor + 40% Recovery Earnings Multiple'
    : 'Multi-Ratio Model: 45% Normalized EPS Multiples + 35% Graham-Dodd Value + 20% Net Asset Book Value';

  const formulaUr = isPenny
    ? 'Turnaround Recovery Formula: 60% Tangible Asset Floor + 40% Recovery Earnings Multiple'
    : 'Multi-Ratio Formula: 45% Normalized EPS + 35% Graham-Dodd Model + 20% Net Asset Book Value';

  return {
    symbol: cleanSym,
    currentPrice: Number(rawPrice.toFixed(2)),
    currentEps: Number(curEps.toFixed(2)),
    historical25YearAvgEps: Number(histAvgEps.toFixed(2)),
    peRatio: Number(pe.toFixed(1)),
    bookValue: Number(bv.toFixed(2)),
    projectedFairPrice: finalProjectedFairPrice,
    projectedFairPriceDisplay: finalDisplay,
    valuationStatusEnglish: statusEn,
    valuationStatusUrdu: statusUr,
    formulaBaseEnglish: formulaEn,
    formulaBaseUrdu: formulaUr,
    upsideDownsidePct: upsidePct,
    isIndex: false
  };
}
