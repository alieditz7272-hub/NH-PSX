// Pakistan Stock Exchange (PSX) Trading Calendar & Date Utilities

export interface PsxTradingDates {
  currentClosingDateFormatted: string; // e.g. "Friday, 28 August 2026"
  nextWorkingDateFormatted: string;    // e.g. "Monday, 31 August 2026"
  nextWorkingDayHeading: string;       // e.g. "Top Stocks for Monday, 31 August 2026"
  isWeekendOrHoliday: boolean;
}

/**
 * Calculates current PSX closing date and next working trading day according to PKT (Asia/Karachi)
 */
export function getPsxTradingDates(baseDate?: Date): PsxTradingDates {
  const now = baseDate || new Date();
  
  // Format options for full readable day + date + month + year
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Convert to Pakistan Time (UTC + 5)
  const pktTime = new Date(now.getTime() + (5 * 60 + now.getTimezoneOffset()) * 60000);
  
  const currentDayOfWeek = pktTime.getDay(); // 0 = Sun, 1 = Mon, ... 5 = Fri, 6 = Sat
  const currentDate = pktTime.getDate();
  const currentMonth = monthNames[pktTime.getMonth()];
  const currentYear = pktTime.getFullYear();
  const currentDayName = dayNames[currentDayOfWeek];

  const currentClosingDateFormatted = `${currentDayName}, ${currentDate} ${currentMonth} ${currentYear}`;

  // Calculate Next Working Day
  let daysToAdd = 1;
  if (currentDayOfWeek === 5) {
    // Friday -> Monday (3 days)
    daysToAdd = 3;
  } else if (currentDayOfWeek === 6) {
    // Saturday -> Monday (2 days)
    daysToAdd = 2;
  } else if (currentDayOfWeek === 0) {
    // Sunday -> Monday (1 day)
    daysToAdd = 1;
  }

  const nextTradingDate = new Date(pktTime.getTime() + daysToAdd * 24 * 60 * 60 * 1000);
  const nextDayOfWeek = nextTradingDate.getDay();
  const nextDate = nextTradingDate.getDate();
  const nextMonth = monthNames[nextTradingDate.getMonth()];
  const nextYear = nextTradingDate.getFullYear();
  const nextDayName = dayNames[nextDayOfWeek];

  const nextWorkingDateFormatted = `${nextDayName}, ${nextDate} ${nextMonth} ${nextYear}`;
  const nextWorkingDayHeading = `Top Stocks for ${nextWorkingDateFormatted}`;

  return {
    currentClosingDateFormatted,
    nextWorkingDateFormatted,
    nextWorkingDayHeading,
    isWeekendOrHoliday: currentDayOfWeek === 0 || currentDayOfWeek === 6
  };
}

/**
 * Calculates strictly verified daily timeframe Technical Levels:
 * Pivot, S1, S2, R1, R2, Strict Candle-based Stop Loss, Target 1, Target 2
 */
export function calculateDailyTechnicalLevels(
  high: number,
  low: number,
  close: number,
  open: number
) {
  const pivot = (high + low + close) / 3;
  const s1 = (2 * pivot) - high;
  const s2 = pivot - (high - low);
  const r1 = (2 * pivot) - low;
  const r2 = pivot + (high - low);

  // Strict Candle-based Stop Loss: Placed just below the daily breakout candle low with a 0.5% defensive buffer
  const candleBasedSL = Math.min(low * 0.995, s1 * 0.998);
  const roundedSL = Number(candleBasedSL.toFixed(2));

  // Conservative & Aggressive Technical Targets
  const target1 = Number(Math.max(r1, close + (high - low) * 0.618).toFixed(2));
  const target2 = Number(Math.max(r2, close + (high - low) * 1.236).toFixed(2));

  return {
    pivot: Number(pivot.toFixed(2)),
    s1: Number(s1.toFixed(2)),
    s2: Number(s2.toFixed(2)),
    r1: Number(r1.toFixed(2)),
    r2: Number(r2.toFixed(2)),
    stopLoss: roundedSL,
    target1,
    target2,
    stopLossNote: `Calculated from daily candle low (${low.toFixed(2)}) with volatility cushion.`
  };
}
