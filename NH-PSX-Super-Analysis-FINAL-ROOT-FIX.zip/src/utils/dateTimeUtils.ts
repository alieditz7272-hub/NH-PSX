import { getPakistanTimeInfo } from './psxMarketCalendar';

export interface AppDateTimeInfo {
  dateString: string;       // e.g. "Monday, 21 Sep 2026"
  shortDateString: string;  // e.g. "21 Sep 2026"
  timeString: string;       // e.g. "03:30 PM"
  timeWithSeconds: string;  // e.g. "03:30:15 PM"
  timeWithTz: string;       // e.g. "03:30 PM PKT"
  fullDateTimeStr: string;  // e.g. "Monday, 21 Sep 2026 • 03:30 PM PKT"
  canvasDateTimeStr: string;// e.g. "21 Sep 2026 | 03:30 PM PKT"
  dateSlug: string;         // e.g. "21_Sep_2026"
  // Convenient aliases for UI sections
  uiDateTimeStr: string;    // Alias for fullDateTimeStr
  dateStr: string;          // Alias for shortDateString
  timeStr: string;          // Alias for timeString
  dateFormatted: string;    // Alias for shortDateString
}

/**
 * Returns standardized real-time date and time formatted in English according to Pakistan Standard Time (PKT).
 * Guarantees that both current date and current time are always available together.
 */
export function getAppCurrentDateTime(date: Date = new Date()): AppDateTimeInfo {
  const pkt = getPakistanTimeInfo(date);

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const pktDateObj = new Date(pkt.isoDate);
  const mIdx = !isNaN(pktDateObj.getMonth()) ? pktDateObj.getMonth() : new Date().getMonth();
  const dNum = pkt.isoDate.split('-')[2] || String(new Date().getDate()).padStart(2, '0');
  const yNum = pkt.isoDate.split('-')[0] || String(new Date().getFullYear());

  const shortDateString = `${dNum} ${months[mIdx] || 'Sep'} ${yNum}`;
  const dateString = `${pkt.dayName}, ${shortDateString}`;

  // Time formatting (12-hour AM/PM)
  const timeRaw = pkt.timeString; // e.g. "03:30:15 PM"
  const parts = timeRaw.split(' ');
  const hm = parts[0].split(':');
  const period = parts[1] || 'PM';
  const time12 = `${hm[0]}:${hm[1]} ${period}`;
  const timeWithTz = `${time12} PKT`;

  return {
    dateString,
    shortDateString,
    timeString: time12,
    timeWithSeconds: timeRaw,
    timeWithTz,
    fullDateTimeStr: `${dateString} • ${timeWithTz}`,
    canvasDateTimeStr: `${shortDateString} | ${timeWithTz}`,
    dateSlug: shortDateString.replace(/\s+/g, '_'),
    uiDateTimeStr: `${dateString} • ${timeWithTz}`,
    dateStr: shortDateString,
    timeStr: time12,
    dateFormatted: shortDateString,
  };
}
