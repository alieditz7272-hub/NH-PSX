import { Candle, TickerQuote } from '../types';

export type MarketStructureDirection = 'Going Up' | 'Going Down' | 'Range Bound';
export type MarketStructureStatus = string;

export interface MarketStructureResult {
  status: string; // e.g. "OGDC Going Up", "KSE100 Going Up", "OGDC Range Bound"
  direction: MarketStructureDirection;
  assetName: string;
  technicalAnalysisRomanUrdu: string;
  technicalAnalysisEnglish: string;
  swingSequenceSummary: string; // e.g. "HH → HL → HH → HL"
  recentHighs: number[];
  recentLows: number[];
  currentPrice: number;
}

interface SwingPoint {
  index: number;
  type: 'HIGH' | 'LOW';
  price: number;
  timeLabel?: string;
}

/**
 * Evaluates pure price action swing structure (HH, HL, LH, LL) for the selected stock or index.
 * Strictly outputs one of 3 dynamic statuses:
 *  - "[Stock or Index Name] Going Up"
 *  - "[Stock or Index Name] Going Down"
 *  - "[Stock or Index Name] Range Bound"
 */
export function evaluateMarketStructure(
  ticker?: TickerQuote,
  candles?: Candle[]
): MarketStructureResult {
  const currentPrice = ticker?.price ?? (candles && candles.length > 0 ? candles[candles.length - 1].close : 100);
  const assetName = ticker?.symbol ? ticker.symbol.replace('.PSX', '').trim() : 'Stock';

  // Fallback if insufficient candles
  if (!candles || candles.length < 6) {
    // Evaluate based on price vs previous close and open if available
    const changePct = ticker?.changePercent ?? 0;
    if (changePct > 1.8 && ticker?.price && ticker?.open && ticker.price > ticker.open) {
      return {
        status: `${assetName} Going Up`,
        direction: 'Going Up',
        assetName,
        technicalAnalysisRomanUrdu: 'HH aur HL ki consistent sequence bullish structure ko confirm kar rahi hai.',
        technicalAnalysisEnglish: 'Consistent sequence of HH and HL confirms bullish structure.',
        swingSequenceSummary: 'HH → HL → HH',
        recentHighs: [ticker.high || currentPrice],
        recentLows: [ticker.low || currentPrice * 0.98],
        currentPrice,
      };
    } else if (changePct < -1.8 && ticker?.price && ticker?.open && ticker.price < ticker.open) {
      return {
        status: `${assetName} Going Down`,
        direction: 'Going Down',
        assetName,
        technicalAnalysisRomanUrdu: 'LH aur LL ki consistent sequence bearish structure ko confirm kar rahi hai.',
        technicalAnalysisEnglish: 'Consistent sequence of LH and LL confirms bearish structure.',
        swingSequenceSummary: 'LH → LL → LH',
        recentHighs: [ticker.high || currentPrice * 1.02],
        recentLows: [ticker.low || currentPrice],
        currentPrice,
      };
    } else {
      return {
        status: `${assetName} Range Bound`,
        direction: 'Range Bound',
        assetName,
        technicalAnalysisRomanUrdu: 'Price defined area mein move kar rahi hai aur clear directional structure establish nahi hua.',
        technicalAnalysisEnglish: 'Price is moving within a defined area and clear directional structure is not established.',
        swingSequenceSummary: 'High → Low → High (Range)',
        recentHighs: [currentPrice * 1.01],
        recentLows: [currentPrice * 0.99],
        currentPrice,
      };
    }
  }

  // 1. Detect Swing Highs and Swing Lows using fractal pivot checks
  const swings: SwingPoint[] = [];
  const lookback = 2; // 2 bars on each side

  for (let i = lookback; i < candles.length - lookback; i++) {
    const c = candles[i];
    const isHigh =
      c.high >= candles[i - 1].high &&
      c.high > candles[i - 2].high &&
      c.high >= candles[i + 1].high &&
      c.high > candles[i + 2].high;

    const isLow =
      c.low <= candles[i - 1].low &&
      c.low < candles[i - 2].low &&
      c.low <= candles[i + 1].low &&
      c.low < candles[i + 2].low;

    if (isHigh && !isLow) {
      // Don't add duplicate consecutive highs without a low in between
      if (swings.length === 0 || swings[swings.length - 1].type !== 'HIGH') {
        swings.push({ index: i, type: 'HIGH', price: c.high, timeLabel: c.timeLabel });
      } else if (c.high > swings[swings.length - 1].price) {
        swings[swings.length - 1] = { index: i, type: 'HIGH', price: c.high, timeLabel: c.timeLabel };
      }
    } else if (isLow && !isHigh) {
      if (swings.length === 0 || swings[swings.length - 1].type !== 'LOW') {
        swings.push({ index: i, type: 'LOW', price: c.low, timeLabel: c.timeLabel });
      } else if (c.low < swings[swings.length - 1].price) {
        swings[swings.length - 1] = { index: i, type: 'LOW', price: c.low, timeLabel: c.timeLabel };
      }
    }
  }

  // Separate into highs and lows
  const swingHighs = swings.filter((s) => s.type === 'HIGH').map((s) => s.price);
  const swingLows = swings.filter((s) => s.type === 'LOW').map((s) => s.price);

  // If fewer than 2 highs or lows, fallback to broader comparison
  if (swingHighs.length < 2 || swingLows.length < 2) {
    const firstHalf = candles.slice(0, Math.floor(candles.length / 2));
    const secondHalf = candles.slice(Math.floor(candles.length / 2));

    const h1 = Math.max(...firstHalf.map((c) => c.high));
    const l1 = Math.min(...firstHalf.map((c) => c.low));
    const h2 = Math.max(...secondHalf.map((c) => c.high));
    const l2 = Math.min(...secondHalf.map((c) => c.low));

    if (h2 > h1 && l2 > l1 && currentPrice >= l2) {
      return {
        status: `${assetName} Going Up`,
        direction: 'Going Up',
        assetName,
        technicalAnalysisRomanUrdu: 'HH aur HL ki consistent sequence bullish structure ko confirm kar rahi hai.',
        technicalAnalysisEnglish: 'Consistent sequence of HH and HL confirms bullish structure.',
        swingSequenceSummary: 'HH → HL → HH',
        recentHighs: [h1, h2],
        recentLows: [l1, l2],
        currentPrice,
      };
    } else if (h2 < h1 && l2 < l1 && currentPrice <= h2) {
      return {
        status: `${assetName} Going Down`,
        direction: 'Going Down',
        assetName,
        technicalAnalysisRomanUrdu: 'LH aur LL ki consistent sequence bearish structure ko confirm kar rahi hai.',
        technicalAnalysisEnglish: 'Consistent sequence of LH and LL confirms bearish structure.',
        swingSequenceSummary: 'LH → LL → LH',
        recentHighs: [h1, h2],
        recentLows: [l1, l2],
        currentPrice,
      };
    } else {
      return {
        status: `${assetName} Range Bound`,
        direction: 'Range Bound',
        assetName,
        technicalAnalysisRomanUrdu: 'Price defined area mein move kar rahi hai aur clear directional structure establish nahi hua.',
        technicalAnalysisEnglish: 'Price is moving within a defined area and clear directional structure is not established.',
        swingSequenceSummary: 'High → Low → High (Range Bound)',
        recentHighs: [h1, h2],
        recentLows: [l1, l2],
        currentPrice,
      };
    }
  }

  // Look at the last 3-4 swing highs and lows
  const lastHighs = swingHighs.slice(-3);
  const lastLows = swingLows.slice(-3);

  const nH = lastHighs.length;
  const nL = lastLows.length;

  const latestH = lastHighs[nH - 1];
  const prevH = lastHighs[nH - 2];
  const prevPrevH = nH >= 3 ? lastHighs[nH - 3] : prevH;

  const latestL = lastLows[nL - 1];
  const prevL = lastLows[nL - 2];
  const prevPrevL = nL >= 3 ? lastLows[nL - 3] : prevL;

  // Bullish Conditions:
  // Sustained HH + HL sequence, previous swing highs break ho rahe hon aur pullbacks higher lows maintain kar rahe hon.
  const isHigherHighs = latestH > prevH && (nH < 3 || prevH >= prevPrevH * 0.998);
  const isHigherLows = latestL > prevL && (nL < 3 || prevL >= prevPrevL * 0.998);
  const priceHoldingAboveHigherLow = currentPrice >= prevL;

  // Bearish Conditions:
  // Sustained LH + LL sequence, previous swing lows break ho rahe hon aur rebounds lower highs maintain kar rahe hon.
  const isLowerHighs = latestH < prevH && (nH < 3 || prevH <= prevPrevH * 1.002);
  const isLowerLows = latestL < prevL && (nL < 3 || prevL <= prevPrevL * 1.002);
  const priceHoldingBelowLowerHigh = currentPrice <= prevH;

  // Strict Rule Checks:
  // • Single candle ya single swing par status change na karo.
  // • Temporary pullback ko trend reversal na samjho.
  // • False/failed breakout ko confirmed structure break na mano.
  // • Jab directional structure clearly established na ho, sirf Market Range Bound select karo.
  if (isHigherHighs && isHigherLows && priceHoldingAboveHigherLow) {
    return {
      status: `${assetName} Going Up`,
      direction: 'Going Up',
      assetName,
      technicalAnalysisRomanUrdu: 'HH aur HL ki consistent sequence bullish structure ko confirm kar rahi hai.',
      technicalAnalysisEnglish: 'Consistent sequence of HH and HL confirms bullish structure.',
      swingSequenceSummary: 'HH → HL → HH → HL',
      recentHighs: lastHighs,
      recentLows: lastLows,
      currentPrice,
    };
  }

  if (isLowerHighs && isLowerLows && priceHoldingBelowLowerHigh) {
    return {
      status: `${assetName} Going Down`,
      direction: 'Going Down',
      assetName,
      technicalAnalysisRomanUrdu: 'LH aur LL ki consistent sequence bearish structure ko confirm kar rahi hai.',
      technicalAnalysisEnglish: 'Consistent sequence of LH and LL confirms bearish structure.',
      swingSequenceSummary: 'LH → LL → LH → LL',
      recentHighs: lastHighs,
      recentLows: lastLows,
      currentPrice,
    };
  }

  // If directional structure is not clearly established, strictly select Range Bound
  return {
    status: `${assetName} Range Bound`,
    direction: 'Range Bound',
    assetName,
    technicalAnalysisRomanUrdu: 'Price defined area mein move kar rahi hai aur clear directional structure establish nahi hua.',
    technicalAnalysisEnglish: 'Price is moving within a defined area and clear directional structure is not established.',
    swingSequenceSummary: 'High → Low → High → Low within same area',
    recentHighs: lastHighs,
    recentLows: lastLows,
    currentPrice,
  };
}
