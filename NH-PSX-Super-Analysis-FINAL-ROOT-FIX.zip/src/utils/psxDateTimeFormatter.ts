/**
 * PSX Standardized Date & Time Formatter
 * 
 * Strict Application Standard:
 * Date Format: "Monday, 1 Sep 2026" (Weekday, Day-of-month unpadded, Short Month, Year)
 * Time Format: "09:09 PM (Pakistan Standard Time)" (12-hour hh:mm AM/PM + (Pakistan Standard Time))
 */

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * Formats a Date object or timestamp into "Monday, 1 Sep 2026"
 */
const MONTH_MAP: Record<string, string> = {
  january: 'Jan', jan: 'Jan',
  february: 'Feb', feb: 'Feb',
  march: 'Mar', mar: 'Mar',
  april: 'Apr', apr: 'Apr',
  may: 'May',
  june: 'Jun', jun: 'Jun',
  july: 'Jul', jul: 'Jul',
  august: 'Aug', aug: 'Aug',
  september: 'Sep', sep: 'Sep',
  october: 'Oct', oct: 'Oct',
  november: 'Nov', nov: 'Nov',
  december: 'Dec', dec: 'Dec'
};

export function formatPSXDate(input?: Date | number | string): string {
  // If no input is provided, ALWAYS format the current real date dynamically!
  if (!input) {
    return formatDateObject(new Date());
  }

  // Handle pre-formatted or string inputs like "Monday, 26 January 2026" or "15 August 2025"
  if (typeof input === 'string') {
    const trimmed = input.trim();
    // Check if string matches "Weekday, Day Month Year"
    const matchWithWeekday = trimmed.match(/^([A-Za-z]+),\s*(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/);
    if (matchWithWeekday) {
      const weekday = matchWithWeekday[1];
      const day = parseInt(matchWithWeekday[2], 10);
      const rawMonth = matchWithWeekday[3].toLowerCase();
      const year = matchWithWeekday[4];
      const shortMonth = MONTH_MAP[rawMonth] || matchWithWeekday[3].slice(0, 3);
      return `${weekday}, ${day} ${shortMonth} ${year}`;
    }

    const matchNoWeekday = trimmed.match(/^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/);
    if (matchNoWeekday) {
      const day = parseInt(matchNoWeekday[1], 10);
      const rawMonth = matchNoWeekday[2].toLowerCase();
      const year = matchNoWeekday[3];
      const shortMonth = MONTH_MAP[rawMonth] || matchNoWeekday[2].slice(0, 3);
      // Try to determine weekday from date
      const testD = new Date(`${shortMonth} ${day}, ${year}`);
      const weekday = !isNaN(testD.getTime()) ? DAYS[testD.getDay()] : 'Monday';
      return `${weekday}, ${day} ${shortMonth} ${year}`;
    }

    const parsedD = new Date(input);
    if (!isNaN(parsedD.getTime())) {
      return formatDateObject(parsedD);
    }
  }

  const d = typeof input === 'number' ? new Date(input) : (input instanceof Date ? input : new Date());
  return formatDateObject(isNaN(d.getTime()) ? new Date() : d);
}

function formatDateObject(d: Date): string {
  try {
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Karachi',
      weekday: 'long',
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
    const parts = formatter.formatToParts(d);
    const weekday = parts.find(p => p.type === 'weekday')?.value || DAYS[d.getDay()];
    const day = parts.find(p => p.type === 'day')?.value || d.getDate().toString();
    const month = parts.find(p => p.type === 'month')?.value || MONTHS[d.getMonth()];
    const year = parts.find(p => p.type === 'year')?.value || d.getFullYear().toString();

    return `${weekday}, ${day} ${month} ${year}`;
  } catch {
    // Fallback if Intl fails
    const weekday = DAYS[d.getDay()];
    const day = d.getDate().toString();
    const month = MONTHS[d.getMonth()];
    const year = d.getFullYear().toString();
    return `${weekday}, ${day} ${month} ${year}`;
  }
}

/**
 * Formats a Date object or timestamp into "09:09 PM (Pakistan Standard Time)"
 */
export function formatPSXTime(input?: Date | number | string): string {
  const d = input ? (typeof input === 'string' || typeof input === 'number' ? new Date(input) : input) : new Date();
  const validD = isNaN(d.getTime()) ? new Date() : d;

  try {
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Karachi',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
    const formatted = formatter.format(validD); // e.g. "09:09 PM"
    return `${formatted} (Pakistan Standard Time)`;
  } catch {
    // Fallback 12-hour time calculation
    let hours = validD.getHours();
    const minutes = validD.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // 0 becomes 12
    const hoursStr = hours.toString().padStart(2, '0');
    return `${hoursStr}:${minutes} ${ampm} (Pakistan Standard Time)`;
  }
}

/**
 * Formats combined date and time:
 * "Monday, 1 Sep 2026 • 09:09 PM (Pakistan Standard Time)"
 */
export function formatPSXDateTime(input?: Date | number | string): string {
  return `${formatPSXDate(input)} • ${formatPSXTime(input)}`;
}
