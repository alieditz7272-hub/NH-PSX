export function formatDisplaySymbol(symbol?: string | null): string {
  if (!symbol) return '';
  return symbol.replace(/\.PSX$/i, '');
}

export function formatDisplayName(ticker?: { symbol?: string; name?: string } | null): string {
  if (!ticker) return '';
  let name = ticker.name || 'Company Name Unavailable';
  name = name.replace(/\s*\((PSX|Pakistan)\)/gi, '').trim();
  return name;
}

// PSX Defaulter Counter Identification (Official PSX Regulation 5.11 Segment)
const PSX_DEFAULTER_SYMBOLS = new Set([
  'HASCOL', 'PACE', 'DSFL', 'DINT', 'SLYT', 'QUICE', 'ADMM', 'ALQT', 'CLOV', 
  'FDIBL', 'SPL', 'BAPL', 'HIRAT', 'DADX', 'DCL', 'FCSC', 'PEL', 'FLYNG', 
  'DSIL', 'DMTM', 'SFL', 'SGABL', 'SGF', 'STML', 'DFML', 
  'DEWA', 'EMCO', 'GTYR', 'KASBM', 'PPLM', 'SPLC', 'SNAI', 'KASB', 'SARC', 
  'RUBY', 'SERF', 'TPLP', 'DOL', 'HSM', 'GLOT', 'MFFL', 'MSCL', 'PABC'
]);

// PSX Index Recognition Helper (KSE100, KSE30, ALLSHR, KMI30, KSE100PR, etc.)
const KNOWN_PSX_INDICES = new Set([
  'KSE100', 'KSE-100', 'KSE 100', 
  'KSE30', 'KSE-30', 'KSE 30', 
  'ALLSHR', 'ALL-SHR', 'ALL SHR', 
  'KMI30', 'KMI-30', 'KMI 30', 
  'KMIALLSHR', 'KSE100PR', 'BKTI', 'OGTI', 'NITPGI', 'NBPPGI', 'UPP9', 'MZNINDEX'
]);

export function isPsxIndex(tickerOrSymbol?: any): boolean {
  if (!tickerOrSymbol) return false;
  if (typeof tickerOrSymbol === 'object') {
    if (tickerOrSymbol.assetClass === 'Index') return true;
    if (typeof tickerOrSymbol.name === 'string' && tickerOrSymbol.name.toLowerCase().includes('index')) return true;
    if (typeof tickerOrSymbol.sector === 'string' && tickerOrSymbol.sector.toLowerCase().includes('index')) return true;
  }
  const raw = typeof tickerOrSymbol === 'string' ? tickerOrSymbol : tickerOrSymbol.symbol || '';
  const clean = raw.toUpperCase().replace(/\.PSX$/i, '').replace(/\.KA$/i, '').replace(/[-_ ]/g, '').trim();
  
  if (KNOWN_PSX_INDICES.has(clean) || KNOWN_PSX_INDICES.has(raw.toUpperCase().replace(/\.PSX$/i, '').trim())) {
    return true;
  }
  if (clean.startsWith('KSE') || clean.startsWith('KMI') || clean.includes('INDEX') || clean === 'ALLSHR') {
    return true;
  }
  return false;
}

export function isPsxDefaulter(tickerOrSymbol?: any, extraTicker?: any): boolean {
  if (!tickerOrSymbol && !extraTicker) return false;
  const target = extraTicker || (typeof tickerOrSymbol === 'object' ? tickerOrSymbol : null);
  if (target) {
    if (
      target.isDefaulter ||
      target.is_defaulter ||
      target.defaulter ||
      target.defaulterSegment ||
      (typeof target.segment === 'string' && target.segment.toLowerCase().includes('defaulter')) ||
      (typeof target.market === 'string' && target.market.toLowerCase().includes('defaulter')) ||
      (typeof target.category === 'string' && target.category.toLowerCase().includes('defaulter'))
    ) {
      return true;
    }
  }
  const raw = typeof tickerOrSymbol === 'string' ? tickerOrSymbol : (target?.symbol || '');
  const clean = raw.toUpperCase().replace(/\.PSX$/i, '').replace(/\.KA$/i, '').replace(/[-_ ]/g, '').trim();
  return PSX_DEFAULTER_SYMBOLS.has(clean) || PSX_DEFAULTER_SYMBOLS.has(raw.toUpperCase().replace(/\.PSX$/i, '').trim());
}

export function getPriceUnit(_tickerOrSymbol?: any): { prefix: string; suffix: string; label: string } {
  return {
    prefix: '',
    suffix: '',
    label: ''
  };
}

export function formatValueWithUnit(value: number | string | undefined | null, tickerOrSymbol?: any, _decimals: number = 2): string {
  if (value === undefined || value === null || value === '' || isNaN(Number(value))) return '-';
  const num = Number(value);
  const isIdx = tickerOrSymbol === true || isPsxIndex(tickerOrSymbol) || (num > 10000 && !tickerOrSymbol);
  if (isIdx) {
    return Math.round(num).toString();
  }
  const formattedNum = num.toFixed(2).replace(/,/g, '');
  return formattedNum;
}

export function formatPriceWithUnit(value: number | string | undefined | null, tickerOrSymbol?: any, decimals: number = 2): string {
  return formatValueWithUnit(value, tickerOrSymbol, decimals);
}
