export interface PakistanTimeInfo {
  timeString: string;       // "10:42:31 PM"
  timeWithTz: string;       // "10:42:31 PM PKT"
  dateString: string;       // "08 August 2026"
  dayOfWeek: number;        // 0 = Sun, 1 = Mon, ..., 6 = Sat
  dayName: string;          // "Saturday", "Sunday", etc.
  hours: number;            // 0-23
  minutes: number;          // 0-59
  seconds: number;          // 0-59
  isoDate: string;          // "2026-08-08"
  monthDayStr: string;      // "08-08" (MM-DD)
}

export type MarketState = 'OPEN' | 'CLOSED' | 'PRE_MARKET' | 'POST_MARKET' | 'HOLIDAY';

export interface PSXMarketStatus {
  state: MarketState;
  statusLabel: string;      // "PSX MARKET OPEN", "PSX MARKET CLOSED", "PRE-MARKET", "POST-MARKET", "MARKET HOLIDAY"
  reason?: string;          // "Weekend", "PSX Holiday - Independence Day", "Friday Prayer Break", "After Hours"
  badgeColorClass: string;  // Tailwind styles for badge
  dotColorClass: string;    // Tailwind color for status indicator light
  sessionName: string;      // "Continuous Session", "Friday Morning Session", etc.
}

// PSX Official Fixed & Lunar Market Holidays Mapping
const PSX_FIXED_HOLIDAYS: Record<string, string> = {
  '02-05': 'Kashmir Day',
  '03-23': 'Pakistan Day',
  '05-01': 'Labour Day',
  '08-14': 'Independence Day',
  '09-06': 'Defence Day',
  '11-09': 'Iqbal Day',
  '12-25': 'Quaid-e-Azam Day / Christmas',
};

// PSX Lunar / Floating Holidays (YYYY-MM-DD)
const PSX_LUNAR_HOLIDAYS: Record<string, string> = {
  // 2024
  '2024-04-10': 'Eid-ul-Fitr (Day 1)',
  '2024-04-11': 'Eid-ul-Fitr (Day 2)',
  '2024-04-12': 'Eid-ul-Fitr (Day 3)',
  '2024-06-17': 'Eid-ul-Adha (Day 1)',
  '2024-06-18': 'Eid-ul-Adha (Day 2)',
  '2024-06-19': 'Eid-ul-Adha (Day 3)',
  '2024-07-16': 'Ashura (9th Muharram)',
  '2024-07-17': 'Ashura (10th Muharram)',
  '2024-09-16': 'Eid Milad-un-Nabi',

  // 2025
  '2025-03-31': 'Eid-ul-Fitr (Day 1)',
  '2025-04-01': 'Eid-ul-Fitr (Day 2)',
  '2025-04-02': 'Eid-ul-Fitr (Day 3)',
  '2025-06-06': 'Eid-ul-Adha (Day 1)',
  '2025-06-07': 'Eid-ul-Adha (Day 2)',
  '2025-06-08': 'Eid-ul-Adha (Day 3)',
  '2025-07-05': 'Ashura (9th Muharram)',
  '2025-07-06': 'Ashura (10th Muharram)',
  '2025-09-05': 'Eid Milad-un-Nabi',

  // 2026
  '2026-03-20': 'Eid-ul-Fitr (Day 1)',
  '2026-03-21': 'Eid-ul-Fitr (Day 2)',
  '2026-03-22': 'Eid-ul-Fitr (Day 3)',
  '2026-05-27': 'Eid-ul-Adha (Day 1)',
  '2026-05-28': 'Eid-ul-Adha (Day 2)',
  '2026-05-29': 'Eid-ul-Adha (Day 3)',
  '2026-06-25': 'Ashura (9th Muharram)',
  '2026-06-26': 'Ashura (10th Muharram)',
  '2026-08-25': 'Eid Milad-un-Nabi',

  // 2027
  '2027-03-10': 'Eid-ul-Fitr (Day 1)',
  '2027-03-11': 'Eid-ul-Fitr (Day 2)',
  '2027-03-12': 'Eid-ul-Fitr (Day 3)',
  '2027-05-17': 'Eid-ul-Adha (Day 1)',
  '2027-05-18': 'Eid-ul-Adha (Day 2)',
  '2027-05-19': 'Eid-ul-Adha (Day 3)',
  '2027-06-15': 'Ashura (9th Muharram)',
  '2027-06-16': 'Ashura (10th Muharram)',
  '2027-08-15': 'Eid Milad-un-Nabi',
};

/**
  Retrieves exact Pakistan Standard Time (Asia/Karachi)
 */
export function getPakistanTimeInfo(dateObj: Date = new Date()): PakistanTimeInfo {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Karachi',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const parts = formatter.formatToParts(dateObj);
  let year = '2026', month = '01', day = '01', hour = '12', minute = '00', second = '00', dayPeriod = 'AM';

  for (const p of parts) {
    if (p.type === 'year') year = p.value;
    if (p.type === 'month') month = p.value;
    if (p.type === 'day') day = p.value;
    if (p.type === 'hour') hour = p.value;
    if (p.type === 'minute') minute = p.value;
    if (p.type === 'second') second = p.value;
    if (p.type === 'dayPeriod') dayPeriod = p.value;
  }

  let h24 = parseInt(hour, 10);
  const dpUpper = (dayPeriod || 'AM').toUpperCase();
  if (dpUpper === 'PM' && h24 < 12) h24 += 12;
  if (dpUpper === 'AM' && h24 === 12) h24 = 0;

  const shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const monthIdx = Math.max(0, parseInt(month, 10) - 1);
  const dayOfMonth = parseInt(day, 10);

  // Get day of week in Asia/Karachi offset (+05:00)
  const pktUtcDate = new Date(`${year}-${month}-${day}T${String(h24).padStart(2, '0')}:${minute}:${second}+05:00`);
  const dayOfWeek = pktUtcDate.getUTCDay();
  const dayName = dayNames[dayOfWeek];

  const dateString = `${dayName}, ${dayOfMonth} ${shortMonths[monthIdx]} ${year}`;
  const timeString = `${hour.padStart(2, '0')}:${minute.padStart(2, '0')}:${second.padStart(2, '0')} ${dpUpper}`;
  const timeWithTz = `${hour.padStart(2, '0')}:${minute.padStart(2, '0')} ${dpUpper} (Pakistan Standard Time)`;
  const isoDate = `${year}-${month}-${day}`;
  const monthDayStr = `${month}-${day}`;

  return {
    timeString,
    timeWithTz,
    dateString,
    dayOfWeek,
    dayName,
    hours: h24,
    minutes: parseInt(minute, 10),
    seconds: parseInt(second, 10),
    isoDate,
    monthDayStr,
  };
}

/**
  Evaluates current PSX Market Status based on Pakistan Standard Time
 */
export function getPSXMarketStatus(now: Date = new Date()): PSXMarketStatus {
  const pkt = getPakistanTimeInfo(now);

  // 1. Check Weekend (Saturday = 6, Sunday = 0)
  if (pkt.dayOfWeek === 0 || pkt.dayOfWeek === 6) {
    return {
      state: 'CLOSED',
      statusLabel: '🔴 PSX MARKET CLOSED',
      reason: 'Weekend',
      badgeColorClass: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
      dotColorClass: 'bg-rose-500',
      sessionName: 'Weekend Market Closure',
    };
  }

  // 2. Check PSX Official Holidays
  const holidayName = PSX_LUNAR_HOLIDAYS[pkt.isoDate] || PSX_FIXED_HOLIDAYS[pkt.monthDayStr];
  if (holidayName) {
    return {
      state: 'HOLIDAY',
      statusLabel: '⚪ MARKET HOLIDAY',
      reason: `PSX Holiday — ${holidayName}`,
      badgeColorClass: 'bg-slate-500/10 text-slate-300 border-slate-500/30',
      dotColorClass: 'bg-slate-300',
      sessionName: `Official Holiday: ${holidayName}`,
    };
  }

  const timeInMin = pkt.hours * 60 + pkt.minutes;

  // 3. Friday Trading Schedule (Session 1 & Session 2)
  if (pkt.dayOfWeek === 5) {
    // Pre-Market: 09:00 AM (540) to 09:15 AM (555)
    if (timeInMin >= 540 && timeInMin < 555) {
      return {
        state: 'PRE_MARKET',
        statusLabel: '🟡 PRE-MARKET',
        reason: 'Pre-Open Order Entry (09:00 AM - 09:15 AM)',
        badgeColorClass: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
        dotColorClass: 'bg-amber-400',
        sessionName: 'Pre-Open Session',
      };
    }

    // Session 1: 09:15 AM (555) to 12:00 PM (720)
    if (timeInMin >= 555 && timeInMin <= 720) {
      return {
        state: 'OPEN',
        statusLabel: '🟢 PSX MARKET OPEN',
        reason: 'Friday Morning Session',
        badgeColorClass: 'bg-[#00FFA3]/10 text-[#00FFA3] border-[#00FFA3]/30',
        dotColorClass: 'bg-[#00FFA3]',
        sessionName: 'Session 1 (09:15 AM - 12:00 PM)',
      };
    }

    // Friday Prayer / Jummah Break: 12:00 PM (720) to 02:30 PM (870)
    if (timeInMin > 720 && timeInMin < 870) {
      return {
        state: 'CLOSED',
        statusLabel: '🔴 PSX MARKET CLOSED',
        reason: 'Friday Prayer Break (12:00 PM - 02:30 PM)',
        badgeColorClass: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
        dotColorClass: 'bg-rose-500',
        sessionName: 'Jummah Prayer Break',
      };
    }

    // Session 2: 02:30 PM (870) to 04:30 PM (990)
    if (timeInMin >= 870 && timeInMin <= 990) {
      return {
        state: 'OPEN',
        statusLabel: '🟢 PSX MARKET OPEN',
        reason: 'Friday Afternoon Session',
        badgeColorClass: 'bg-[#00FFA3]/10 text-[#00FFA3] border-[#00FFA3]/30',
        dotColorClass: 'bg-[#00FFA3]',
        sessionName: 'Session 2 (02:30 PM - 04:30 PM)',
      };
    }

    // Post-Market / Closing Session: 04:30 PM (990) to 05:00 PM (1020)
    if (timeInMin > 990 && timeInMin <= 1020) {
      return {
        state: 'POST_MARKET',
        statusLabel: '🟡 POST-MARKET',
        reason: 'Closing Session & Order Matching (04:30 PM - 05:00 PM)',
        badgeColorClass: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
        dotColorClass: 'bg-amber-400',
        sessionName: 'Closing Session',
      };
    }

    // Outside Trading Hours
    return {
      state: 'CLOSED',
      statusLabel: '🔴 PSX MARKET CLOSED',
      reason: 'After Hours',
      badgeColorClass: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
      dotColorClass: 'bg-rose-500',
      sessionName: 'After Hours',
    };
  }

  // 4. Monday to Thursday Schedule
  // Pre-Market: 09:00 AM (540) to 09:15 AM (555)
  if (timeInMin >= 540 && timeInMin < 555) {
    return {
      state: 'PRE_MARKET',
      statusLabel: '🟡 PRE-MARKET',
      reason: 'Pre-Open Order Entry (09:00 AM - 09:15 AM)',
      badgeColorClass: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
      dotColorClass: 'bg-amber-400',
      sessionName: 'Pre-Open Session',
    };
  }

  // Continuous Trading: 09:15 AM (555) to 03:30 PM (930)
  if (timeInMin >= 555 && timeInMin <= 930) {
    return {
      state: 'OPEN',
      statusLabel: '🟢 PSX MARKET OPEN',
      reason: 'Continuous Trading Session',
      badgeColorClass: 'bg-[#00FFA3]/10 text-[#00FFA3] border-[#00FFA3]/30',
      dotColorClass: 'bg-[#00FFA3]',
      sessionName: 'Continuous Session (09:15 AM - 03:30 PM)',
    };
  }

  // Post-Market / Closing Session: 03:30 PM (930) to 04:00 PM (960)
  if (timeInMin > 930 && timeInMin <= 960) {
    return {
      state: 'POST_MARKET',
      statusLabel: '🟡 POST-MARKET',
      reason: 'Closing Session & Order Matching (03:30 PM - 04:00 PM)',
      badgeColorClass: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
      dotColorClass: 'bg-amber-400',
      sessionName: 'Closing Session',
    };
  }

  // Outside Trading Hours
  return {
    state: 'CLOSED',
    statusLabel: '🔴 PSX MARKET CLOSED',
    reason: 'After Hours',
    badgeColorClass: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    dotColorClass: 'bg-rose-500',
    sessionName: 'After Hours',
  };
}
