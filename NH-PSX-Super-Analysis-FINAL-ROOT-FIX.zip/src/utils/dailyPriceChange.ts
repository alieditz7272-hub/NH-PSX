import { TickerQuote, Candle } from '../types';
import { formatPrice } from './currency';
import { isPsxIndex } from './symbol';

export interface DailyChangeResult {
  currentPrice: number | undefined;
  prevClose: number | undefined;
  change: number | undefined;
  changePercent: number | undefined;
  isUp: boolean;
  isDown: boolean;
  isUnchanged: boolean;
  isAvailable: boolean;
  isIndex: boolean;
  prefix: string;
  formattedCurrentPrice: string;
  formattedChangeText: string;
  formattedChangePctText: string;
  arrowSymbol: string; // '▲', '▼', or ''
  colorClass: string;
  badgeBgClass: string;
  displayStatusText: string;
}

/**
 * Validates and calculates daily price change from verified PSX candle series or quote.
 */
export function calculateDailyPriceChange(
  ticker: TickerQuote,
  candles?: Candle[]
): DailyChangeResult {
  const isIndex = isPsxIndex(ticker);
  const prefix = '';

  // Determine latest close and previous trading day close from verified daily candles
  let currentPrice: number | undefined = undefined;
  let prevClose: number | undefined = undefined;

  if (candles && candles.length > 0) {
    const validCandles = candles.filter(
      (c) => c && typeof c.close === 'number' && !isNaN(c.close) && c.close > 0
    );
    if (validCandles.length > 0) {
      currentPrice = validCandles[validCandles.length - 1].close;
      if (validCandles.length >= 2) {
        prevClose = validCandles[validCandles.length - 2].close;
      }
    }
  }

  // Fallback to ticker fields if candles array didn't yield both prices
  if (currentPrice === undefined && typeof ticker.price === 'number' && !isNaN(ticker.price) && ticker.price > 0) {
    currentPrice = ticker.price;
  }

  if (prevClose === undefined) {
    if (typeof ticker.previousClose === 'number' && !isNaN(ticker.previousClose) && ticker.previousClose > 0) {
      prevClose = ticker.previousClose;
    } else if (
      typeof ticker.change === 'number' &&
      !isNaN(ticker.change) &&
      currentPrice !== undefined
    ) {
      const calculatedPrev = currentPrice - ticker.change;
      if (calculatedPrev > 0) {
        prevClose = calculatedPrev;
      }
    }
  }

  // Validate data availability
  const isAvailable =
    currentPrice !== undefined &&
    prevClose !== undefined &&
    !isNaN(currentPrice) &&
    !isNaN(prevClose) &&
    prevClose > 0;

  if (!isAvailable) {
    return {
      currentPrice,
      prevClose,
      change: undefined,
      changePercent: undefined,
      isUp: false,
      isDown: false,
      isUnchanged: false,
      isAvailable: false,
      isIndex,
      prefix,
      formattedCurrentPrice: currentPrice !== undefined ? `${formatPrice(currentPrice, ticker)}` : 'N/A',
      formattedChangeText: 'DATA UNAVAILABLE',
      formattedChangePctText: '',
      arrowSymbol: '',
      colorClass: 'text-amber-400/80',
      badgeBgClass: 'bg-amber-500/10 border-amber-500/20 text-amber-300',
      displayStatusText: 'CHANGE: DATA UNAVAILABLE',
    };
  }

  const change = currentPrice - prevClose;
  const changePercent = (change / prevClose) * 100;

  // Precision formatting rules
  const absChange = Math.abs(change);
  const changeDecimals = absChange < 0.1 ? 4 : 2;
  const absChangeFormatted = isIndex ? Math.round(absChange).toString() : absChange.toFixed(changeDecimals);

  const isUp = change > 0.000001;
  const isDown = change < -0.000001;
  const isUnchanged = !isUp && !isDown;

  let arrowSymbol = '';
  let colorClass = 'text-white/70';
  let badgeBgClass = 'bg-white/5 border-white/10 text-white/70';
  let formattedChangeText = isIndex ? '0' : '0.00';
  let formattedChangePctText = '0.00%';

  if (isUp) {
    arrowSymbol = '▲';
    colorClass = 'text-[#10b981]';
    badgeBgClass = 'bg-emerald-500/15 border-emerald-500/30 text-[#10b981]';
    formattedChangeText = `▲ +${absChangeFormatted}`;
    formattedChangePctText = `+${changePercent.toFixed(2)}%`;
  } else if (isDown) {
    arrowSymbol = '▼';
    colorClass = 'text-[#ef4444]';
    badgeBgClass = 'bg-red-500/15 border-red-500/30 text-[#ef4444]';
    formattedChangeText = `▼ -${absChangeFormatted}`;
    formattedChangePctText = `${changePercent.toFixed(2)}%`;
  } else {
    arrowSymbol = '';
    colorClass = 'text-white/70';
    badgeBgClass = 'bg-white/5 border-white/10 text-white/70';
    formattedChangeText = isIndex ? '0' : '0.00';
    formattedChangePctText = '0.00%';
  }

  const formattedCurrentPrice = `${formatPrice(currentPrice, ticker)}`;
  const displayStatusText = `${formattedChangeText} (${formattedChangePctText})`;

  return {
    currentPrice,
    prevClose,
    change,
    changePercent,
    isUp,
    isDown,
    isUnchanged,
    isAvailable: true,
    isIndex,
    prefix,
    formattedCurrentPrice,
    formattedChangeText,
    formattedChangePctText,
    arrowSymbol,
    colorClass,
    badgeBgClass,
    displayStatusText,
  };
}
