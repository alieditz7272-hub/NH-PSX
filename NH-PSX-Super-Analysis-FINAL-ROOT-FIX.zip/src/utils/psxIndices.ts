// PSX Official Indices & Constituents Mapping Engine
// Strictly English Only

export interface PSXIndexInfo {
  id: string;
  name: string;
  shortName: string;
  description: string;
  badgeColor: string;
}

export const PSX_INDEX_DEFINITIONS: PSXIndexInfo[] = [
  {
    id: 'ALL',
    name: 'All PSX Equities (Whole Market)',
    shortName: 'All PSX',
    description: 'Scans all listed equities across all sectors on the Pakistan Stock Exchange',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
  },
  {
    id: 'KSE100',
    name: 'KSE-100 Benchmark Index',
    shortName: 'KSE-100',
    description: 'Top 100 benchmark liquid equities representing over 85% of market capitalization',
    badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
  },
  {
    id: 'KSE30',
    name: 'KSE-30 Large-Cap Bluechips',
    shortName: 'KSE-30',
    description: 'Top 30 liquid large-cap bluechip stocks filtered by free-float market cap',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/40'
  },
  {
    id: 'KMI30',
    name: 'KMI-30 Islamic Shariah Index',
    shortName: 'KMI-30',
    description: '30 screened Shariah-compliant high-liquidity stocks audited by Meezan Bank / PSX',
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/40'
  },
  {
    id: 'ALLSHR',
    name: 'All Shares Index',
    shortName: 'All Shares',
    description: 'Complete broad-market composite index covering all trading active counters',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40'
  }
];

// Official PSX KSE-100 Constituents Symbols (Clean tickers without .PSX suffix)
export const KSE100_CONSTITUENTS = new Set([
  'OGDC', 'PPL', 'MARI', 'POL', 'SYS', 'TRG', 'AIRLINK', 'NETSOL', 'AVN', 'OCTOPUS', 'PTC', 'WTL', 'TELE',
  'MEBL', 'MCB', 'UBL', 'HBL', 'AKBL', 'BAHL', 'FABL', 'NBP', 'BOP', 'BIPL', 'JSBL', 'ABL', 'BOK',
  'ENGRO', 'FFC', 'EFERT', 'FATIMA', 'FFBL',
  'LUCK', 'FCCL', 'MLCF', 'CHCC', 'DGKC', 'KOHC', 'ACPL', 'PIOC', 'FLYNG', 'POWER',
  'PSO', 'SHEL', 'APL', 'SNGP', 'SSGC', 'HASCOL', 'PRL', 'NRL', 'ATRL', 'BYCO', 'CNERGY',
  'HUBC', 'KAPCO', 'KEL', 'NCPL', 'NPL', 'SPWL', 'PKGP',
  'SEARL', 'AGP', 'FEROZ', 'CPHL', 'GLAXO', 'HINOON', 'IBFL', 'ABOT', 'OTSU',
  'INDU', 'HCAR', 'PSMC', 'MTL', 'GHNI', 'GHNL', 'ATLH', 'AGTL', 'SAZEW',
  'ILP', 'NCL', 'GADT', 'KTML', 'CRTM', 'FML', 'ANL',
  'UNITY', 'NATF', 'MUGHAL', 'ASTL', 'ISL', 'INIL', 'TGL', 'PAEL', 'LOTCHEM', 'EPCL',
  'HUMNL', 'TREET', 'PSEL', 'COLG', 'NESTLE', 'SITC', 'SRVI'
]);

// Official PSX KSE-30 Constituents Symbols (Top 30 liquid heavyweights)
export const KSE30_CONSTITUENTS = new Set([
  'OGDC', 'PPL', 'MARI', 'POL', 'SYS', 'TRG',
  'MEBL', 'MCB', 'UBL', 'HBL', 'BAHL', 'FABL', 'NBP',
  'ENGRO', 'FFC', 'EFERT', 'FFBL',
  'LUCK', 'FCCL', 'MLCF', 'DGKC', 'CHCC',
  'PSO', 'HUBC', 'SNGP',
  'SEARL', 'INDU', 'MTL', 'ILP', 'EPCL'
]);

// Official PSX KMI-30 Shariah Compliant Constituents Symbols
export const KMI30_CONSTITUENTS = new Set([
  'OGDC', 'PPL', 'MARI', 'POL', 'SYS', 'AIRLINK', 'NETSOL',
  'MEBL',
  'ENGRO', 'FFC', 'EFERT', 'FATIMA', 'FFBL',
  'LUCK', 'FCCL', 'MLCF', 'CHCC', 'DGKC', 'KOHC', 'ACPL',
  'PSO', 'HUBC', 'PRL', 'ATRL',
  'SEARL', 'AGP', 'FEROZ', 'CPHL', 'HINOON',
  'INDU', 'MTL', 'SAZEW', 'GHNI', 'ILP', 'NCL', 'GADT',
  'UNITY', 'MUGHAL', 'INIL', 'TGL', 'PAEL', 'LOTCHEM', 'EPCL'
]);

/**
 * Checks whether a given stock symbol belongs to the specified index
 */
export function isStockInIndex(rawSymbol: string, indexId: string): boolean {
  if (!rawSymbol) return false;
  if (!indexId || indexId === 'ALL' || indexId === 'ALLSHR') return true;

  const clean = rawSymbol.toUpperCase().replace('.PSX', '').replace('.KA', '').trim();

  if (indexId === 'KSE100') {
    return KSE100_CONSTITUENTS.has(clean);
  }
  if (indexId === 'KSE30') {
    return KSE30_CONSTITUENTS.has(clean);
  }
  if (indexId === 'KMI30') {
    return KMI30_CONSTITUENTS.has(clean);
  }
  return true;
}

/**
 * Filters an array of tickers by PSX Index membership
 */
export function filterTickersByIndex<T extends { symbol: string }>(tickers: T[], indexId: string): T[] {
  if (!Array.isArray(tickers)) return [];
  if (!indexId || indexId === 'ALL' || indexId === 'ALLSHR') return tickers;
  return tickers.filter(t => isStockInIndex(t.symbol, indexId));
}
