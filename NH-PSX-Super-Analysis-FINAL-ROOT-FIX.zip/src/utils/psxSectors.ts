// Official PSX Sectors Verification Mapping

const PSX_SYMBOL_SECTORS: Record<string, string> = {
  // Benchmark Indices
  'KSE100': 'PSX Benchmark Index',
  'KSE30': 'PSX Benchmark Index',
  'ALLSHR': 'PSX Broad Market Index',
  'KMI30': 'PSX Islamic Benchmark Index',
  'KSE100PR': 'PSX Total Return Index',

  // Technology & Communication
  'SYS': 'Technology & Communication',
  'TRG': 'Technology & Communication',
  'AIRLINK': 'Technology & Communication',
  'NETSOL': 'Technology & Communication',
  'AVN': 'Technology & Communication',
  'OCTOPUS': 'Technology & Communication',
  'PTC': 'Technology & Communication',
  'WTL': 'Technology & Communication',
  'TELE': 'Technology & Communication',

  // Oil & Gas Exploration
  'OGDC': 'Oil & Gas Exploration Companies',
  'PPL': 'Oil & Gas Exploration Companies',
  'MARI': 'Oil & Gas Exploration Companies',
  'POL': 'Oil & Gas Exploration Companies',
  'SPSL': 'Oil & Gas Exploration Companies',
  'PIL': 'Chemicals & Lubricants',
  'AHCL': 'Investment Banking & Conglomerate',

  // Oil & Gas Marketing
  'PSO': 'Oil & Gas Marketing Companies',
  'SHEL': 'Oil & Gas Marketing Companies',
  'APL': 'Oil & Gas Marketing Companies',
  'SNGP': 'Oil & Gas Marketing Companies',
  'SSGC': 'Oil & Gas Marketing Companies',
  'HASCOL': 'Oil & Gas Marketing Companies',

  // Commercial Banks
  'MEBL': 'Commercial Banks',
  'MCB': 'Commercial Banks',
  'UBL': 'Commercial Banks',
  'HBL': 'Commercial Banks',
  'AKBL': 'Commercial Banks',
  'BAHL': 'Commercial Banks',
  'FABL': 'Commercial Banks',
  'NBP': 'Commercial Banks',
  'BOP': 'Commercial Banks',
  'BIPL': 'Commercial Banks',
  'JSBL': 'Commercial Banks',
  'ABL': 'Commercial Banks',
  'BOK': 'Commercial Banks',

  // Fertilizer
  'ENGRO': 'Fertilizer',
  'FFC': 'Fertilizer',
  'EFERT': 'Fertilizer',
  'FATIMA': 'Fertilizer',

  // Cement
  'LUCK': 'Cement',
  'FCCL': 'Cement',
  'MLCF': 'Cement',
  'DGKC': 'Cement',
  'CHCC': 'Cement',
  'PIOC': 'Cement',
  'ACPL': 'Cement',
  'BWCL': 'Cement',

  // Power Generation & Distribution
  'HUBC': 'Power Generation & Distribution',
  'KEL': 'Power Generation & Distribution',
  'KAPCO': 'Power Generation & Distribution',
  'NCPL': 'Power Generation & Distribution',
  'SPWL': 'Power Generation & Distribution',

  // Automobile Assembler
  'SAZEW': 'Automobile Assembler',
  'INDU': 'Automobile Assembler',
  'HCAR': 'Automobile Assembler',
  'PSMC': 'Automobile Assembler',
  'MTL': 'Automobile Assembler',

  // Pharmaceuticals
  'SEARL': 'Pharmaceuticals',
  'ABOT': 'Pharmaceuticals',
  'GLAXO': 'Pharmaceuticals',
  'FEROZ': 'Pharmaceuticals',
  'HINOON': 'Pharmaceuticals',

  // Refinery
  'ATRL': 'Refinery',
  'NRL': 'Refinery',
  'PRL': 'Refinery',
  'CNERGY': 'Refinery',
  'BYCO': 'Refinery',

  // Textile Composite
  'NML': 'Textile Composite',
  'GATI': 'Textile Composite',
  'KTML': 'Textile Composite',
  'ILP': 'Textile Composite',

  // Chemicals
  'EPCL': 'Chemicals',
  'LOTCHEM': 'Chemicals',
  'COLG': 'Chemicals',
  'ICI': 'Chemicals',

  // Engineering & Steel
  'INIL': 'Engineering',
  'ISL': 'Engineering',
  'MUGHAL': 'Engineering',
  'ASTL': 'Engineering',

  // Food & Personal Care
  'NESTLE': 'Food & Personal Care Products',
  'UNITY': 'Food & Personal Care Products',
  'NATF': 'Food & Personal Care Products',
  'SHEZAN': 'Food & Personal Care Products',
};

export function getPsxSector(symbol: string, name?: string): string {
  const cleanSym = (symbol || '').toUpperCase().replace('.PSX', '').trim();
  if (PSX_SYMBOL_SECTORS[cleanSym]) {
    return PSX_SYMBOL_SECTORS[cleanSym];
  }

  const cleanName = (name || '').toLowerCase();
  if (cleanName.includes('bank') || cleanName.includes('meezan') || cleanName.includes('mcb') || cleanName.includes('ubl') || cleanName.includes('hbl')) {
    return 'Commercial Banks';
  }
  if (cleanName.includes('cement')) {
    return 'Cement';
  }
  if (cleanName.includes('fertilizer') || cleanName.includes('engro') || cleanName.includes('fauji')) {
    return 'Fertilizer';
  }
  if (cleanName.includes('oil') || cleanName.includes('gas') || cleanName.includes('petroleum')) {
    return 'Oil & Gas Exploration Companies';
  }
  if (cleanName.includes('power') || cleanName.includes('electric') || cleanName.includes('energy')) {
    return 'Power Generation & Distribution';
  }
  if (cleanName.includes('tech') || cleanName.includes('software') || cleanName.includes('systems') || cleanName.includes('telecom')) {
    return 'Technology & Communication';
  }
  if (cleanName.includes('auto') || cleanName.includes('motor') || cleanName.includes('car')) {
    return 'Automobile Assembler';
  }
  if (cleanName.includes('pharma') || cleanName.includes('lab') || cleanName.includes('health')) {
    return 'Pharmaceuticals';
  }
  if (cleanName.includes('refinery')) {
    return 'Refinery';
  }
  if (cleanName.includes('textile')) {
    return 'Textile Composite';
  }
  if (cleanName.includes('chemical')) {
    return 'Chemicals';
  }
  if (cleanName.includes('food') || cleanName.includes('milk') || cleanName.includes('dair')) {
    return 'Food & Personal Care Products';
  }

  return 'PSX Equity';
}
