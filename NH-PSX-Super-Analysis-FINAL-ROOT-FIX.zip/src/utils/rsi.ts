/**
 * Audited & Verified Wilder's RSI(14) Indicator Engine
 * Calculates true 14-period Wilder RSI from daily CLOSE prices in chronological order.
 */

/**
 * Calculates Wilder's RSI(14) array for a given series of close prices.
 * @param closes Chronological close prices array (oldest at index 0, newest at last index).
 * @param period RSI period, default is 14.
 * @returns Array of RSI values (full precision float or undefined if insufficient data).
 */
export function calculateWilderRsiSeries(closes: number[], period: number = 14): (number | undefined)[] {
  // Data integrity check: filter out non-numeric or non-positive values
  if (!Array.isArray(closes)) return [];
  
  const rsiSeries: (number | undefined)[] = new Array(closes.length).fill(undefined);

  // Validate we have at least period + 1 valid chronological close prices (e.g. 15 for RSI 14)
  const validCount = closes.filter(c => typeof c === 'number' && !isNaN(c) && c > 0).length;
  if (validCount < period + 1 || closes.length < period + 1) {
    return rsiSeries;
  }

  let avgGain = 0;
  let avgLoss = 0;

  // Step 1: First period (index 1 to period) - calculate initial SMA of gains and losses
  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change > 0) {
      avgGain += change;
    } else {
      avgLoss += Math.abs(change);
    }
  }

  avgGain /= period;
  avgLoss /= period;

  // Calculate RSI at index = period (14th change, 15th candle)
  if (avgLoss === 0) {
    rsiSeries[period] = avgGain === 0 ? 50 : 100;
  } else if (avgGain === 0) {
    rsiSeries[period] = 0;
  } else {
    const rs = avgGain / avgLoss;
    rsiSeries[period] = 100 - (100 / (1 + rs));
  }

  // Step 2: Subsequent periods - use Wilder's exponential smoothing:
  // AvgGain = (prevAvgGain * 13 + currentGain) / 14
  // AvgLoss = (prevAvgLoss * 13 + currentLoss) / 14
  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;

    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;

    if (avgLoss === 0) {
      rsiSeries[i] = avgGain === 0 ? 50 : 100;
    } else if (avgGain === 0) {
      rsiSeries[i] = 0;
    } else {
      const rs = avgGain / avgLoss;
      rsiSeries[i] = 100 - (100 / (1 + rs));
    }
  }

  return rsiSeries;
}

/**
 * Independent Method B Calculation for Verification / Audit (Tolerance check <= 0.01)
 */
export function calculateWilderRsiMethodB(closes: number[], period: number = 14): number | undefined {
  if (!closes || closes.length < period + 1) return undefined;

  let gainSum = 0;
  let lossSum = 0;

  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff > 0) gainSum += diff;
    else lossSum += Math.abs(diff);
  }

  let emaGain = gainSum / period;
  let emaLoss = lossSum / period;

  const alpha = 1 / period;

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    const g = diff > 0 ? diff : 0;
    const l = diff < 0 ? Math.abs(diff) : 0;

    emaGain = alpha * g + (1 - alpha) * emaGain;
    emaLoss = alpha * l + (1 - alpha) * emaLoss;
  }

  if (emaLoss === 0) return emaGain === 0 ? 50 : 100;
  if (emaGain === 0) return 0;

  const rs = emaGain / emaLoss;
  return 100 - (100 / (1 + rs));
}

/**
 * Evaluates RSI Alert details according to permanent RSI pane rules:
 * 70–100: SELL / Profit Book / Avoid Buy
 * 60–70:  HOLD / Buy on Pullback
 * 50–60:  BUY / HOLD
 * 40–50:  WAIT / HOLD
 * 30–40:  SELL / Avoid Buy
 * 0–30:   BUY on Confirmation Candle
 */
export function evaluateRsiAlert(rsi: number | undefined) {
  if (rsi === undefined || rsi === null || isNaN(rsi)) {
    return {
      rsiText: 'N/A',
      rsiValue: undefined,
      alertLabel: 'INSUFFICIENT DATA FOR RSI(14)',
      alertColor: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
      status: 'WAIT' as const,
      ruleText: 'WAIT / HOLD',
      actionText: 'WAIT / HOLD',
      tradingGuideline: 'Insufficient historical data for RSI calculation'
    };
  }

  const roundedRsi = parseFloat(rsi.toFixed(2));
  const rsiText = roundedRsi.toFixed(2);

  // 70–100: SELL / Profit Book / Avoid Buy
  if (rsi >= 70) {
    return {
      rsiText,
      rsiValue: roundedRsi,
      alertLabel: `SELL / Profit Book / Avoid Buy [RSI ${rsiText}]`,
      alertColor: 'bg-rose-500/25 text-rose-300 border-rose-500/60 shadow-[0_0_15px_rgba(244,63,94,0.3)]',
      status: 'SELL' as const,
      ruleText: 'SELL / Profit Book / Avoid Buy',
      actionText: 'SELL / Profit Book / Avoid Buy',
      tradingGuideline: '70–100: SELL / Profit Book / Avoid Buy'
    };
  } 
  // 60–70: HOLD / Buy on Pullback
  else if (rsi >= 60) {
    return {
      rsiText,
      rsiValue: roundedRsi,
      alertLabel: `HOLD / Buy on Pullback [RSI ${rsiText}]`,
      alertColor: 'bg-sky-500/25 text-sky-300 border-sky-500/60 shadow-[0_0_15px_rgba(56,189,248,0.25)]',
      status: 'HOLD' as const,
      ruleText: 'HOLD / Buy on Pullback',
      actionText: 'HOLD / Buy on Pullback',
      tradingGuideline: '60–70: HOLD / Buy on Pullback'
    };
  } 
  // 50–60: BUY / HOLD
  else if (rsi >= 50) {
    return {
      rsiText,
      rsiValue: roundedRsi,
      alertLabel: `BUY / HOLD [RSI ${rsiText}]`,
      alertColor: 'bg-emerald-500/25 text-[#00FFA3] border-emerald-500/60 shadow-[0_0_15px_rgba(0,255,163,0.3)]',
      status: 'BUY' as const,
      ruleText: 'BUY / HOLD',
      actionText: 'BUY / HOLD',
      tradingGuideline: '50–60: BUY / HOLD'
    };
  } 
  // 40–50: WAIT / HOLD
  else if (rsi >= 40) {
    return {
      rsiText,
      rsiValue: roundedRsi,
      alertLabel: `WAIT / HOLD [RSI ${rsiText}]`,
      alertColor: 'bg-amber-500/25 text-amber-300 border-amber-500/60 shadow-[0_0_15px_rgba(245,158,11,0.25)]',
      status: 'WAIT' as const,
      ruleText: 'WAIT / HOLD',
      actionText: 'WAIT / HOLD',
      tradingGuideline: '40–50: WAIT / HOLD'
    };
  } 
  // 30–40: SELL / Avoid Buy
  else if (rsi >= 30) {
    return {
      rsiText,
      rsiValue: roundedRsi,
      alertLabel: `SELL / Avoid Buy [RSI ${rsiText}]`,
      alertColor: 'bg-orange-500/25 text-orange-300 border-orange-500/60 shadow-[0_0_15px_rgba(249,115,22,0.25)]',
      status: 'SELL' as const,
      ruleText: 'SELL / Avoid Buy',
      actionText: 'SELL / Avoid Buy',
      tradingGuideline: '30–40: SELL / Avoid Buy'
    };
  } 
  // 0–30: BUY on Confirmation Candle
  else {
    return {
      rsiText,
      rsiValue: roundedRsi,
      alertLabel: `BUY on Confirmation Candle [RSI ${rsiText}]`,
      alertColor: 'bg-emerald-500/25 text-emerald-300 border-emerald-500/70 shadow-[0_0_20px_rgba(16,185,129,0.35)]',
      status: 'BUY' as const,
      ruleText: 'BUY on Confirmation Candle',
      actionText: 'BUY on Confirmation Candle',
      tradingGuideline: '0–30: BUY on Confirmation Candle'
    };
  }
}
