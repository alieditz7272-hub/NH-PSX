import { TickerQuote } from '../types';

type CellMap = Record<string, string>;

const clean = (value: string) => value
  .replace(/\u00a0/g, ' ')
  .replace(/\s+/g, ' ')
  .trim();

const numberValue = (value?: string) => {
  const n = Number(String(value ?? '').replace(/,/g, '').replace(/%/g, '').trim());
  return Number.isFinite(n) ? n : 0;
};

const keyName = (value: string) => value.toLowerCase().replace(/[^a-z0-9]/g, '');

function cellValue(cell: HTMLTableCellElement) {
  const order = cell.getAttribute('data-order');
  return order && order.trim() !== '' ? order : clean(cell.textContent || '');
}

function makeQuote(named: CellMap, positional: string[]): TickerQuote | null {
  const symbol = clean(named.symbol || positional[0] || '').replace(/\s+/g, '').toUpperCase();
  if (!/^[A-Z0-9&._-]{1,20}$/.test(symbol) || symbol === 'SYMBOL') return null;

  const previousClose = numberValue(named.ldcp || named.previousclose || positional[1]);
  const open = numberValue(named.open || positional[2]);
  const high = numberValue(named.high || positional[3]);
  const low = numberValue(named.low || positional[4]);
  const price = numberValue(named.current || named.close || positional[5]);
  const change = numberValue(named.change || positional[6]);
  const changePercent = numberValue(named.percentchange || named.changepercent || named.changepercentage || positional[7]);
  const volume = numberValue(named.volume || positional[8]);

  if (price <= 0) return null;

  return {
    symbol: `${symbol}.PSX`,
    name: clean(named.name || symbol),
    price,
    change,
    changePercent,
    open: open || price,
    high: high || price,
    low: low || price,
    previousClose,
    volume,
    avgVolume: volume,
    marketCap: 0,
    sector: 'PSX',
    assetClass: 'Stock',
    exchange: 'PSX (Pakistan)',
    countryFlag: '🇵🇰',
    lastTickTime: Date.now(),
    bid: 0,
    ask: 0,
    bidSize: 0,
    askSize: 0,
    vwap: 0,
    rsi: 50,
    macd: { macd: 0, signal: 0, histogram: 0 },
    sma20: 0,
    sma50: 0,
    sma200: 0,
    aiScore: 0,
    aiSignal: 'Neutral',
    isVerified: true,
    source: 'PSX Official Market Watch — 5-minute delayed data',
    receivedAt: Date.now(),
  };
}


function parseOfficialIndexHtml(html: string, cleanCode: string): TickerQuote | null {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const text = (doc.body?.innerText || '').replace(/\u00a0/g, ' ').replace(/[ \t]+/g, ' ').trim();
  const marker = new RegExp(`${cleanCode}\\s+([\\d,]+(?:\\.\\d+)?)\\s+([+-]?[\\d,]+(?:\\.\\d+)?)\\s*\\(([+-]?[\\d.]+)%\\)`, 'i').exec(text);
  if (!marker) return null;

  const current = numberValue(marker[1]);
  const change = numberValue(marker[2]);
  const changePercent = numberValue(marker[3]);
  if (current <= 0) return null;

  let high = current;
  let low = current;
  const tableMarker = new RegExp(`${cleanCode}\\s*\\|\\s*High\\s*\\|\\s*Low\\s*\\|\\s*Current`, 'i');
  const idx = text.search(tableMarker);
  if (idx >= 0) {
    const tail = text.slice(idx, idx + 700);
    const nums = tail.match(/[\d,]+(?:\.\d+)?/g) || [];
    if (nums.length >= 2) {
      high = numberValue(nums[0]);
      low = numberValue(nums[1]);
    }
  }

  return {
    symbol: `${cleanCode}.PSX`,
    name: cleanCode === 'KSE100' ? 'KSE-100 Index' : cleanCode,
    price: current,
    change,
    changePercent,
    open: current,
    high: high > 0 ? high : current,
    low: low > 0 ? low : current,
    previousClose: current - change,
    volume: 0,
    avgVolume: 0,
    marketCap: 0,
    sector: 'Pakistan Benchmark Index',
    assetClass: 'Index' as const,
    exchange: 'PSX (Pakistan)',
    countryFlag: '🇵🇰',
    lastTickTime: Date.now(),
    bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0,
    rsi: 50, macd: { macd: 0, signal: 0, histogram: 0 }, sma20: 0, sma50: 0, sma200: 0,
    aiScore: 0, aiSignal: 'Neutral', isVerified: true,
    source: 'PSX Data Portal — official index snapshot',
    receivedAt: Date.now(),
  };
}

async function fetchOfficialIndexQuote(code: string): Promise<TickerQuote | null> {
  const cleanCode = code.replace(/[^A-Z0-9]/g, '').toUpperCase();

  // Primary: official PSX index snapshot. It is the exchange's own
  // published current value and remains valid after the trading session closes.
  for (const endpoint of [
    `https://dps.psx.com.pk/indices?ts=${Date.now()}`,
    `https://dps.psx.com.pk/indices/${cleanCode}?ts=${Date.now()}`,
  ]) {
    try {
      const res = await fetch(endpoint, {
        cache: 'no-store',
        headers: { 'Accept': 'text/html,application/xhtml+xml' },
      });
      if (res.ok) {
        const quote = parseOfficialIndexHtml(await res.text(), cleanCode);
        if (quote) return quote;
      }
    } catch {
      // Try the next official endpoint, then the JSON timeseries fallback.
    }
  }

  // Secondary: official PSX JSON timeseries. PSX returns newest tick first.
  try {
    const [intradayRes, eodRes] = await Promise.all([
      fetch(`https://dps.psx.com.pk/timeseries/int/${cleanCode}?ts=${Date.now()}`, { cache: 'no-store' }),
      fetch(`https://dps.psx.com.pk/timeseries/eod/${cleanCode}?ts=${Date.now()}`, { cache: 'no-store' })
    ]);
    if (!intradayRes.ok) return null;
    const intraday = await intradayRes.json();
    const eod = eodRes.ok ? await eodRes.json() : null;
    const ticks = Array.isArray(intraday?.data) ? intraday.data : [];
    if (!ticks.length) return null;

    const last = ticks[0];
    const prices = ticks.map((r: any[]) => Number(r?.[1])).filter((n: number) => Number.isFinite(n) && n > 0);
    const current = Number(last?.[1]);
    if (!Number.isFinite(current) || current <= 0) return null;

    const previousClose = Number(Array.isArray(eod?.data) && eod.data.length ? eod.data[0]?.[1] : 0);
    const change = previousClose > 0 ? current - previousClose : 0;
    const changePercent = previousClose > 0 ? (change / previousClose) * 100 : 0;
    const timestamp = Number(last?.[0]) * 1000;

    return {
      symbol: `${cleanCode}.PSX`,
      name: cleanCode === 'KSE100' ? 'KSE-100 Index' : cleanCode,
      price: current,
      change,
      changePercent,
      open: prices[prices.length - 1] || current,
      high: Math.max(...prices),
      low: Math.min(...prices),
      previousClose,
      volume: Number(last?.[2] || 0),
      avgVolume: 0,
      marketCap: 0,
      sector: 'Pakistan Benchmark Index',
      assetClass: 'Index' as const,
      exchange: 'PSX (Pakistan)',
      countryFlag: '🇵🇰',
      lastTickTime: Number.isFinite(timestamp) ? timestamp : Date.now(),
      bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0,
      rsi: 50, macd: { macd: 0, signal: 0, histogram: 0 }, sma20: 0, sma50: 0, sma200: 0,
      aiScore: 0, aiSignal: 'Neutral', isVerified: true,
      source: 'PSX Data Portal — official index timeseries',
      receivedAt: Date.now(),
    };
  } catch {
    return null;
  }
}

async function fetchStaticSnapshot(): Promise<{ data: TickerQuote[]; fetchedAt: number; sourceTime: string }> {
  const res = await fetch(`./data/market.json?ts=${Date.now()}`, { cache: 'no-store' });
  if (!res.ok) throw new Error(`Static PSX snapshot HTTP ${res.status}`);
  const payload = await res.json();
  const raw = Array.isArray(payload?.data) ? payload.data : [];
  if (raw.length < 20) throw new Error('Static PSX snapshot has insufficient rows');
  const data: TickerQuote[] = raw.map((q: any): TickerQuote => ({
    symbol: `${String(q.symbol || '').replace(/\.PSX$|\.KA$/i, '').toUpperCase()}.PSX`,
    name: String(q.name || q.symbol || ''),
    price: numberValue(String(q.price ?? 0)), change: numberValue(String(q.change ?? 0)),
    changePercent: numberValue(String(q.changePercent ?? 0)), open: numberValue(String(q.open ?? q.price ?? 0)),
    high: numberValue(String(q.high ?? q.price ?? 0)), low: numberValue(String(q.low ?? q.price ?? 0)),
    previousClose: numberValue(String(q.previousClose ?? 0)), volume: numberValue(String(q.volume ?? 0)),
    avgVolume: numberValue(String(q.volume ?? 0)), marketCap: 0, sector: 'PSX', assetClass: q.symbol === 'KSE100' ? 'Index' as const : 'Stock' as const,
    exchange: 'PSX (Pakistan)', countryFlag: '🇵🇰', lastTickTime: payload?.fetchedAt ? Date.parse(payload.fetchedAt) : Date.now(),
    bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0, rsi: 50,
    macd: { macd: 0, signal: 0, histogram: 0 }, sma20: 0, sma50: 0, sma200: 0,
    aiScore: 0, aiSignal: 'Neutral', isVerified: true,
    source: String(payload?.source || 'PSX Data Portal — official delayed snapshot'), receivedAt: Date.now(),
  })).filter((q: TickerQuote) => q.price > 0 && q.symbol.length > 5);
  return { data, fetchedAt: payload?.fetchedAt ? Date.parse(payload.fetchedAt) : Date.now(), sourceTime: payload?.sourceTime || payload?.fetchedAt || 'PSX SNAPSHOT' };
}

export async function fetchPSXDelayedQuotes(force = false): Promise<{ data: TickerQuote[]; fetchedAt: number; sourceTime: string }> {
  const cacheKey = '__NH_PSX_DELAYED_CACHE__';
  if (!force) {
    const cached = (globalThis as any)[cacheKey];
    if (cached && Date.now() - cached.fetchedAt < 4 * 60 * 1000 && cached.data.length > 20) return cached;
  }
  try {
    const result = await fetchStaticSnapshot();
    (globalThis as any)[cacheKey] = result;
    return result;
  } catch (staticErr) {
    const configured = (import.meta as any).env?.VITE_PSX_DATA_URL as string | undefined;
    const url = configured || 'https://psxdata-api.fastapicloud.dev/screener';
    const response = await fetch(`${url}${url.includes('?') ? '&' : '?'}ts=${Date.now()}`, { cache: 'no-store' });
    if (!response.ok) throw staticErr;
    const payload = await response.json();
    const raw = Array.isArray(payload) ? payload : payload?.data;
    if (!Array.isArray(raw) || raw.length < 20) throw staticErr;
    const data: TickerQuote[] = raw.map((q: any): TickerQuote => ({
      symbol: `${String(q.symbol || '').replace(/\.PSX$|\.KA$/i, '').toUpperCase()}.PSX`, name: String(q.name || q.symbol || ''),
      price: numberValue(String(q.price ?? q.current ?? 0)), change: numberValue(String(q.change ?? 0)), changePercent: numberValue(String(q.changePercent ?? 0)),
      open: numberValue(String(q.open ?? q.price ?? 0)), high: numberValue(String(q.high ?? q.price ?? 0)), low: numberValue(String(q.low ?? q.price ?? 0)), previousClose: numberValue(String(q.previousClose ?? q.ldcp ?? 0)), volume: numberValue(String(q.volume ?? 0)), avgVolume: numberValue(String(q.volume ?? 0)), marketCap: 0, sector: 'PSX', assetClass: 'Stock', exchange: 'PSX (Pakistan)', countryFlag: '🇵🇰', lastTickTime: Date.now(), bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0, rsi: 50, macd: { macd: 0, signal: 0, histogram: 0 }, sma20: 0, sma50: 0, sma200: 0, aiScore: 0, aiSignal: 'Neutral', isVerified: true, source: String(payload?.source || 'PSX delayed fallback'), receivedAt: Date.now(),
    })).filter((q: TickerQuote) => q.price > 0 && q.symbol.length > 5);
    if (data.length < 20) throw staticErr;
    const result = { data, fetchedAt: payload?.fetchedAt ? Date.parse(payload.fetchedAt) : Date.now(), sourceTime: payload?.fetchedAt || new Date().toISOString() };
    (globalThis as any)[cacheKey] = result;
    return result;
  }
}
