import { 
  UserProfile, 
  SubscriptionRecord, 
  PaymentRecord, 
  AdminMetrics, 
  SubscriberDetail,
  RevenueBreakdown,
  AuditLog, 
  GuestUserRecord,
  SubscriptionPlanType, 
  PaymentMethodType 
} from '../types/subscription';
import { safeStorage } from '../utils/safeStorage';

const TOKEN_STORAGE_KEY = 'nh_trading_auth_token_v1';
const ADMIN_KEY_STORAGE = 'nh_admin_secret_key_v1';

export function getAuthHeaders(): HeadersInit {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  const token = safeStorage.getItem(TOKEN_STORAGE_KEY);
  const adminKey = safeStorage.getItem(ADMIN_KEY_STORAGE);
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  if (adminKey) {
    headers['x-admin-key'] = adminKey;
  }
  return headers;
}

export async function authFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const newInit: RequestInit = { ...(init || {}) };
  const headers = new Headers(newInit.headers || {});
  const token = safeStorage.getItem(TOKEN_STORAGE_KEY);
  const adminKey = safeStorage.getItem(ADMIN_KEY_STORAGE) || 'nhpro2026';
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  if (!headers.has('x-admin-key') && adminKey) {
    headers.set('x-admin-key', adminKey);
  }
  newInit.headers = headers;
  return fetch(input, newInit);
}

class SubscriptionClient {
  private token: string | null = null;
  private adminKey: string | null = null;

  constructor() {
    this.token = safeStorage.getItem(TOKEN_STORAGE_KEY);
    this.adminKey = safeStorage.getItem(ADMIN_KEY_STORAGE);
  }

  public setToken(token: string | null) {
    this.token = token;
    if (token) {
      safeStorage.setItem(TOKEN_STORAGE_KEY, token);
    } else {
      safeStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  }

  public getToken(): string | null {
    return this.token;
  }

  public setAdminKey(key: string | null) {
    this.adminKey = key;
    if (key) {
      safeStorage.setItem(ADMIN_KEY_STORAGE, key);
    } else {
      safeStorage.removeItem(ADMIN_KEY_STORAGE);
    }
  }

  public getAdminKey(): string | null {
    return this.adminKey;
  }

  private getHeaders(): HeadersInit {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json'
    };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    const adminKey = this.adminKey || safeStorage.getItem(ADMIN_KEY_STORAGE) || 'nhpro2026';
    if (adminKey) {
      headers['x-admin-key'] = adminKey;
    }
    return headers;
  }

  // Register
  public async register(params: { name: string; email: string; phone: string; password: string }): Promise<{ user: UserProfile; token: string }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(params)
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Registration failed');
    }
    this.setToken(data.token);
    return data;
  }

  // Login
  public async login(params: { emailOrPhone: string; password: string }): Promise<{ user: UserProfile; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(params)
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Login failed');
    }
    this.setToken(data.token);
    return data;
  }

  // Check current session & subscription status from server
  public async checkAuth(): Promise<{ user: UserProfile | null; subscription: SubscriptionRecord | null }> {
    if (!this.token) {
      return { user: null, subscription: null };
    }
    try {
      const res = await fetch('/api/auth/me', {
        headers: this.getHeaders()
      });
      const data = await res.json();
      if (data.status === 'ok' && data.user) {
        return { user: data.user, subscription: data.subscription };
      }
      return { user: null, subscription: null };
    } catch (e) {
      return { user: null, subscription: null };
    }
  }

  // Logout
  public async logout(): Promise<void> {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: this.getHeaders()
      });
    } catch (e) {}
    this.setToken(null);
  }

  // Submit manual payment verification
  public async submitPayment(params: {
    plan: SubscriptionPlanType;
    paymentMethod: PaymentMethodType;
    amount: number;
    transactionId: string;
    paymentDate: string;
    screenshotData?: string;
    screenshotName?: string;
    notes?: string;
    fullName?: string;
    email?: string;
    phone?: string;
    password?: string;
  }): Promise<{ payment: PaymentRecord; user: UserProfile; message: string }> {
    const res = await fetch('/api/payments/submit', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(params)
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to submit payment');
    }
    return data;
  }

  // Get My Payments
  public async getMyPayments(): Promise<PaymentRecord[]> {
    const res = await fetch('/api/payments/my-payments', {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to fetch payments');
    }
    return data.payments || [];
  }

  // Get My Subscription
  public async getMySubscription(): Promise<{ subscription: SubscriptionRecord | null; user: UserProfile }> {
    const res = await fetch('/api/subscription/my-subscription', {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to fetch subscription');
    }
    return data;
  }

  // Admin: Fetch Metrics
  public async getAdminMetrics(): Promise<AdminMetrics> {
    const res = await fetch('/api/admin/metrics', {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Admin authentication required');
    }
    return data.metrics;
  }

  // Admin: Fetch Payments with filter & search
  public async getAdminPayments(filters: { status?: string; plan?: string; method?: string; search?: string }): Promise<PaymentRecord[]> {
    const params = new URLSearchParams();
    if (filters.status) params.append('status', filters.status);
    if (filters.plan) params.append('plan', filters.plan);
    if (filters.method) params.append('method', filters.method);
    if (filters.search) params.append('search', filters.search);

    const res = await fetch(`/api/admin/payments?${params.toString()}`, {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Admin authentication required');
    }
    return data.payments || [];
  }

  // Admin: Approve
  public async approvePayment(paymentId: string, adminNotes?: string): Promise<{ payment: PaymentRecord; subscription: SubscriptionRecord }> {
    const res = await fetch(`/api/admin/payments/${paymentId}/approve`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ adminNotes })
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to approve payment');
    }
    return data;
  }

  // Admin: Reject
  public async rejectPayment(paymentId: string, reason: string, adminNotes?: string): Promise<PaymentRecord> {
    const res = await fetch(`/api/admin/payments/${paymentId}/reject`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ reason, adminNotes })
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to reject payment');
    }
    return data.payment;
  }

  // Admin: Update Notes
  public async updateAdminNotes(paymentId: string, notes: string): Promise<PaymentRecord> {
    const res = await fetch(`/api/admin/payments/${paymentId}/notes`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ notes })
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to update notes');
    }
    return data.payment;
  }

  // Admin: Audit Logs
  public async getAuditLogs(): Promise<AuditLog[]> {
    const res = await fetch('/api/admin/audit-logs', {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to fetch audit logs');
    }
    return data.logs || [];
  }

  // Admin: Subscribers List
  public async getSubscribers(): Promise<SubscriberDetail[]> {
    const res = await fetch('/api/admin/subscribers', {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to fetch subscribers');
    }
    return data.subscribers || [];
  }

  // Admin: Extend Subscriber Subscription
  public async extendSubscriberSubscription(userId: string, days: number, adminNotes?: string): Promise<SubscriptionRecord> {
    const res = await fetch(`/api/admin/subscribers/${userId}/extend`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ days, adminNotes })
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to extend subscription');
    }
    return data.subscription;
  }

  // Admin: Suspend Subscriber Subscription
  public async suspendSubscriberSubscription(userId: string, reason?: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`/api/admin/subscribers/${userId}/suspend`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ reason })
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to suspend subscription');
    }
    return data;
  }

  // Admin: Reactivate Subscriber Subscription
  public async reactivateSubscriberSubscription(userId: string, adminNotes?: string): Promise<SubscriptionRecord> {
    const res = await fetch(`/api/admin/subscribers/${userId}/reactivate`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ adminNotes })
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to reactivate subscription');
    }
    return data.subscription;
  }

  // Admin: Detailed Revenue Breakdown
  public async getDetailedRevenue(): Promise<RevenueBreakdown> {
    const res = await fetch('/api/admin/revenue', {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to fetch revenue');
    }
    return data.revenue;
  }

  // Admin: Real-Time Comprehensive Analytics Summary
  public async getAnalyticsSummary(params: {
    range?: string;
    startDate?: string;
    endDate?: string;
  } = {}): Promise<any> {
    const query = new URLSearchParams();
    if (params.range) query.append('range', params.range);
    if (params.startDate) query.append('startDate', params.startDate);
    if (params.endDate) query.append('endDate', params.endDate);

    const res = await fetch(`/api/admin/analytics/summary?${query.toString()}`, {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to fetch analytics summary');
    }
    return data.analytics;
  }

  // Admin: Mark Notification Read
  public async markNotificationRead(id: string): Promise<boolean> {
    const res = await fetch(`/api/admin/analytics/notifications/${id}/read`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    const data = await res.json();
    return data.status === 'ok';
  }

  // Admin: Mark All Notifications Read
  public async markAllNotificationsRead(): Promise<boolean> {
    const res = await fetch(`/api/admin/analytics/notifications/read-all`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    const data = await res.json();
    return data.status === 'ok';
  }

  // Admin: Get Export CSV URL
  public getExportCsvUrl(range: string = 'TODAY', startDate?: string, endDate?: string): string {
    const query = new URLSearchParams();
    query.append('range', range);
    if (startDate) query.append('startDate', startDate);
    if (endDate) query.append('endDate', endDate);
    if (this.adminKey) query.append('adminKey', this.adminKey);
    return `/api/admin/analytics/export-csv?${query.toString()}`;
  }

  // =========================================================================
  // ADMIN GUEST USER MANAGEMENT METHODS
  // =========================================================================

  // Admin: Get all guest users
  public async getGuestUsers(): Promise<GuestUserRecord[]> {
    const res = await fetch('/api/admin/guest-users', {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to fetch guest accounts');
    }
    return data.guests || [];
  }

  // Admin: Create a new guest user
  public async createGuestUser(params: {
    name: string;
    username: string;
    password: string;
    phone?: string;
    notes?: string;
    relationTag?: 'Family Member' | 'Close Friend' | 'VIP Colleague' | 'VIP Trader' | 'General Guest';
    durationDays?: number;
  }): Promise<{ guest: GuestUserRecord; message: string }> {
    const res = await fetch('/api/admin/guest-users', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(params)
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to create guest user');
    }
    return data;
  }

  // Admin: Delete a guest user
  public async deleteGuestUser(userId: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`/api/admin/guest-users/${userId}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to delete guest user');
    }
    return data;
  }

  // Admin: Update guest user
  public async updateGuestUser(userId: string, params: {
    name?: string;
    password?: string;
    notes?: string;
    relationTag?: 'Family Member' | 'Close Friend' | 'VIP Colleague' | 'VIP Trader' | 'General Guest';
    durationDays?: number;
  }): Promise<{ guest: GuestUserRecord; message: string }> {
    const res = await fetch(`/api/admin/guest-users/${userId}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(params)
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to update guest user');
    }
    return data;
  }

  // Admin: Toggle guest active status
  public async toggleGuestUser(userId: string, active: boolean): Promise<{ guest: GuestUserRecord; message: string }> {
    const res = await fetch(`/api/admin/guest-users/${userId}/toggle`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ active })
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to update guest status');
    }
    return data;
  }

  // Admin: Get all managed users (members & guest passes)
  public async getManagedUsers(): Promise<any[]> {
    const res = await fetch('/api/admin/managed-users', {
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to fetch users');
    }
    return data.users || [];
  }

  // Admin: Create managed user or guest pass
  public async createManagedUser(params: {
    name: string;
    username: string;
    password: string;
    phone?: string;
    isGuest?: boolean;
    durationDays?: number;
    notes?: string;
  }): Promise<{ user: any; message: string }> {
    const res = await fetch('/api/admin/managed-users', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(params)
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to create user');
    }
    return data;
  }

  // Admin: Update managed user
  public async updateManagedUser(userId: string, params: {
    name?: string;
    password?: string;
    durationDays?: number;
    notes?: string;
    isActive?: boolean;
  }): Promise<{ user: any; message: string }> {
    const res = await fetch(`/api/admin/managed-users/${userId}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(params)
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to update user');
    }
    return data;
  }

  // Admin: Delete managed user
  public async deleteManagedUser(userId: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`/api/admin/managed-users/${userId}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    const data = await res.json();
    if (data.status !== 'ok') {
      throw new Error(data.message || 'Failed to delete user');
    }
    return data;
  }
}

export const subscriptionClient = new SubscriptionClient();
