/**
 * ============================================================================
 * PSX CORPORATE BUSINESS EXPANSION & TURNAROUND INTELLIGENCE DATABASE
 * ============================================================================
 * Disclosures from corporate annual audited accounts, corporate analyst
 * briefings, board resolutions, regulatory filings with PSX and SECP,
 * and verified commercial licenses (e.g. OMC licenses, EV ventures, Capex).
 *
 * Enforces user rules:
 * - Strictly English only for default technical and analytical text.
 * - Roman Urdu support for the language toggle.
 * - Zero info source/website citations.
 * - Clear, simple, easy-to-understand language.
 * ============================================================================
 */

export interface PSXExpansionInfo {
  symbol: string;
  hasExpansion: boolean;
  status: 'ACTIVE_EXPANSION' | 'NEW_LICENSE_VENTURE' | 'TURNAROUND_CATALYST' | 'PLANT_CAPEX_UPGRADE' | 'ACTIVE_CAPEX' | 'NOT_APPLICABLE';
  statusBadgeEnglish: string;
  statusBadgeUrdu: string;
  headlineEnglish: string;
  headlineUrdu: string;
  detailsEnglish: string;
  detailsUrdu: string;
  catalystEnglish: string;
  catalystUrdu: string;
  disclosedHorizon: string;
  regulatorySourceType: string;
}

export const PSX_EXPANSION_DATABASE: Record<string, PSXExpansionInfo> = {
  // 🌟 SPSL (Standard Petroleum Services Limited - User's Explicit Focus Case)
  SPSL: {
    symbol: 'SPSL',
    hasExpansion: true,
    status: 'NEW_LICENSE_VENTURE',
    statusBadgeEnglish: 'New License Venture • OMC Retail Expansion',
    statusBadgeUrdu: 'New License Venture • OMC Retail Petrol Pump Network',
    headlineEnglish: 'OGRA Oil Marketing Company (OMC) License Application & Retail Fuel Station Network Rollout',
    headlineUrdu: 'OGRA OMC License Application aur Retail Petrol Pump Network Rollout',
    detailsEnglish: 'SPSL is pursuing an Oil Marketing Company (OMC) license from OGRA, alongside establishing oil storage infrastructure in Punjab and Sindh to transform into a full-scale petroleum marketing enterprise.',
    detailsUrdu: 'SPSL ne OGRA se Oil Marketing Company (OMC) license hasil karne ki application di hai aur storage depots establish kar ke retail petrol pump network rollout karne ki turnaround strategy par kaam shuru kia hai.',
    catalystEnglish: 'Transforming from oilfield logistics into a nationwide retail petroleum distribution OMC acts as an immense turnaround story for SPSL, unlocking multi-fold top-line revenue expansion and higher valuation multiples.',
    catalystUrdu: 'Oilfield logistics se nationwide retail petroleum OMC distribution mein shift hona SPSL ke lye ek zabardast turnaround story hai jo revenues aur cash flows ko multi-fold barhaye gi.',
    disclosedHorizon: 'Regulatory Approval & Storage Commissioning Phase (FY2025-2026)',
    regulatorySourceType: 'Board Resolutions & Regulatory Licensing Filings'
  },

  // 🌟 PRL (Pakistan Refinery Limited)
  PRL: {
    symbol: 'PRL',
    hasExpansion: true,
    status: 'PLANT_CAPEX_UPGRADE',
    statusBadgeEnglish: 'Active Mega Capex • Refinery Modernization',
    statusBadgeUrdu: 'Active Mega Capex • Refinery Upgrade aur Doubling',
    headlineEnglish: 'Refinery Expansion & Upgrade Project (REUP) - Doubling Capacity to 100000 bpd',
    headlineUrdu: 'Refinery Expansion & Upgrade Project (REUP) - 100000 bpd Capacity Doubling',
    detailsEnglish: 'PRL is executing its landmark Refinery Expansion and Upgrade Project under the Government Brownfield Refining Policy to double processing capacity to 100000 bpd and transition from low-value furnace oil to Euro-V compliant petrol and high-speed diesel.',
    detailsUrdu: 'PRL Brownfield Refining Policy ke tehat REUP project execute kar rahi hai jis se refining capacity double ho kar 100000 bpd ho jaye gi aur furnace oil ki bajaye Euro-V petrol aur diesel manufacture hon ge.',
    catalystEnglish: 'Eliminating loss-making furnace oil production in favor of premium Euro-V fuels structurally transforms refinery gross margins and long-term dividend distribution power.',
    catalystUrdu: 'Furnace oil khatam kar ke pure Euro-V fuels produce karna company ke refining margins aur profits ko mustaqil bunyadon par zabardast boost de ga.',
    disclosedHorizon: 'EPC Contracting & Project Commissioning Horizon (FY2025-2028)',
    regulatorySourceType: 'Annual Audited Accounts & Statutory Corporate Disclosures'
  },

  // 🌟 CNERGY (Cnergyico PK Limited)
  CNERGY: {
    symbol: 'CNERGY',
    hasExpansion: true,
    status: 'TURNAROUND_CATALYST',
    statusBadgeEnglish: 'Turnaround Catalyst • SPM Upgrade & Debt Rescheduling',
    statusBadgeUrdu: 'Turnaround Catalyst • SPM Terminal aur Debt Restructuring',
    headlineEnglish: 'Single Point Mooring (SPM) Crude Terminal Upgrade & Comprehensive Debt Restructuring',
    headlineUrdu: 'SPM Deep-Sea Terminal Modernization aur Debt Restructuring Plan',
    detailsEnglish: 'CNERGY is optimizing its offshore Single Point Mooring (SPM) crude handling terminal to reduce crude import freight costs, while negotiating formal debt restructuring with commercial banks to restore working capital lines and Euro-V production.',
    detailsUrdu: 'CNERGY apne offshore Single Point Mooring (SPM) crude terminal ko optimize kar rahi hai taake freight kharche bach sakein, aur banks ke sath debt restructuring complete kar ke Euro-V fuel supply barhane ki koshish mein hai.',
    catalystEnglish: 'Successful bank debt reprofiling combined with unimpeded crude imports via SPM provides the operational catalyst to return the refinery to full capacity utilization and operating profitability.',
    catalystUrdu: 'Bank debt rescheduling aur SPM crude terminal ki bahali se refinery full capacity par chal sakti hai jo share value ke lye zabardast turnaround catalyst hai.',
    disclosedHorizon: 'Creditor Restructuring & Plant Debottlenecking (FY2025-2026)',
    regulatorySourceType: 'Statutory Filings & Corporate Analyst Briefings'
  },

  // 🌟 HUBC (The Hub Power Company)
  HUBC: {
    symbol: 'HUBC',
    hasExpansion: true,
    status: 'NEW_LICENSE_VENTURE',
    statusBadgeEnglish: 'New Strategic Venture • Electric Vehicles & Mining',
    statusBadgeUrdu: 'New Strategic Venture • BYD Electric Vehicles Assembly',
    headlineEnglish: 'BYD Electric Vehicle Assembly Plant (Mega Motor Co) & Thar Coal Pipeline Conversion',
    headlineUrdu: 'BYD Electric Vehicles Assembly Plant aur Thar Coal Rail Conversion',
    detailsEnglish: 'HUBC has partnered with BYD through its subsidiary Mega Motor Co to set up Pakistan first state-of-the-art electric vehicle assembly plant and nationwide EV charging infrastructure, alongside converting its Hub plant boilers to Thar coal.',
    detailsUrdu: 'HUBC ne Mega Motor Co ke zariye BYD ke sath mil kar Pakistan mein electric passenger cars assembly plant aur EV supercharger network lagane ka muahida kia hai, sath hi Thar coal conversion par kaam jari hai.',
    catalystEnglish: 'Entering the high-growth green mobility sector and replacing expensive imported coal with local Thar coal hedges cash flows against IPP contract renegotiations and unlocks fresh industrial growth.',
    catalystUrdu: 'BYD EV assembly venture aur local Thar coal conversion se company ki future cash flows aur dividend capacity mein zabardast izafa mutawaqqe hai.',
    disclosedHorizon: 'Commercial EV Assembly Launch (FY2025-2026)',
    regulatorySourceType: 'Corporate Statutory Disclosures & Material Information Notices'
  },

  // 🌟 SYS (Systems Limited)
  SYS: {
    symbol: 'SYS',
    hasExpansion: true,
    status: 'ACTIVE_EXPANSION',
    statusBadgeEnglish: 'Active Expansion • GCC & Enterprise AI Scale-Up',
    statusBadgeUrdu: 'Active Expansion • Saudi Arabia aur Enterprise AI Growth',
    headlineEnglish: 'Aggressive Saudi Arabia / GCC Digital Banking Footprint & Enterprise AI Export Expansion',
    headlineUrdu: 'Saudi Arabia aur GCC Digital Banking aur Enterprise AI Footprint Expansion',
    detailsEnglish: 'SYS is aggressively expanding delivery operations across Riyadh and Dubai, securing high-ticket digital banking transformation, cloud modernization, and enterprise generative AI solutions for tier-1 regional banks and government entities.',
    detailsUrdu: 'SYS Saudi Arabia (Riyadh) aur UAE mein apne offices expand kar rahi hai jahan bare banks aur government bodies ko digital banking, cloud migration aur enterprise AI solutions deliver kiye ja rahe hain.',
    catalystEnglish: 'Dollar-denominated export revenues from Saudi Arabia Vision 2030 initiatives protect margins and drive long-term compound earnings growth.',
    catalystUrdu: 'Saudi Arabia aur GCC se USD export revenues company ke margins ko currency depreciation ke khilaf mazboot rakhte hain aur zabardast growth dete hain.',
    disclosedHorizon: 'Ongoing Regional Footprint Expansion (FY2025-2027)',
    regulatorySourceType: 'Annual Audited Accounts & Investor Presentations'
  },

  // 🌟 LUCK (Lucky Cement Limited)
  LUCK: {
    symbol: 'LUCK',
    hasExpansion: true,
    status: 'ACTIVE_EXPANSION',
    statusBadgeEnglish: 'Active Expansion • Captive Hybrid Green Energy & Mining',
    statusBadgeUrdu: 'Active Expansion • Captive Solar-Wind Power aur Mining',
    headlineEnglish: 'Captive Solar-Wind Hybrid Power Installations & International Clinker Grinding Expansion',
    headlineUrdu: 'Captive Solar aur Wind Hybrid Plants aur International Clinker Expansion',
    detailsEnglish: 'LUCK is expanding captive solar and wind renewable generation across Pezu and Karachi plants to significantly lower power costs, while growing international grinding facilities in Iraq and pursuing international mineral exploration.',
    detailsUrdu: 'LUCK apne Pezu aur Karachi cement plants par multi-megawatt captive solar aur wind hybrid systems laga rahi hai taake bijli ke kharche kam hon, aur Iraq aur Africa mein cement operations expand kar rahi hai.',
    catalystEnglish: 'Substantial energy cost savings through captive renewables safeguard industry-leading gross margins even during periods of sluggish domestic construction demand.',
    catalystUrdu: 'Apni solar/wind power se cement banane ka kharcha kam hota hai jis se domestic demand slow hone ke bawajood company ka profit high rehta hai.',
    disclosedHorizon: 'Phase-Wise Commissioning (FY2025-2026)',
    regulatorySourceType: 'Annual Audited Reports & Corporate Briefings'
  },

  // 🌟 MEBL (Meezan Bank Limited)
  MEBL: {
    symbol: 'MEBL',
    hasExpansion: true,
    status: 'ACTIVE_EXPANSION',
    statusBadgeEnglish: 'Active Expansion • 100+ Branches Annually',
    statusBadgeUrdu: 'Active Expansion • Saalana 100+ Naye Islamic Branches',
    headlineEnglish: 'Nationwide Islamic Branch Rollout Exceeding 1050+ Branches & Digital Banking Leadership',
    headlineUrdu: '1050+ Islamic Branches se Tajawaz aur Mobile Digital Banking Expansion',
    detailsEnglish: 'MEBL is opening 100+ new commercial Islamic branches annually across all provinces, capturing massive low-cost zero-return Islamic current account deposits and underwriting national Sovereign Sukuks.',
    detailsUrdu: 'MEBL har saal 100 se ziada naye branches khol rahi hai jis se zero-cost Islamic current account deposits mein zabardast izafa ho raha hai aur branch footprint 1050+ cross kar chuka hai.',
    catalystEnglish: 'Industry-leading Islamic CASA ratio (near 50% zero-cost current accounts) creates unmatched net interest margins and resilient profitability in any interest-rate regime.',
    catalystUrdu: 'Zero-cost current account deposits ki waja se Meezan Bank ke munafa ke margins pure banking sector mein sab se mazboot aur mustahkam hain.',
    disclosedHorizon: 'Continuous Annual Branch Expansion (FY2025-2026)',
    regulatorySourceType: 'Annual Financial Reports & SBP Approvals'
  },

  // 🌟 FFC (Fauji Fertilizer Company)
  FFC: {
    symbol: 'FFC',
    hasExpansion: true,
    status: 'ACTIVE_EXPANSION',
    statusBadgeEnglish: 'Active Expansion • Agritech Acquisition & Energy Savings',
    statusBadgeUrdu: 'Active Expansion • Agritech Acquisition aur Energy Upgrades',
    headlineEnglish: 'Consolidation of Agritech Limited & Greenfield Hybrid Energy Integration',
    headlineUrdu: 'Agritech Limited ki Acquisition aur Plant Energy Optimization',
    detailsEnglish: 'FFC is completing the acquisition of a controlling stake in Agritech Limited to consolidate urea market dominance, alongside deploying energy-efficiency Capex across Goth Machhi production lines.',
    detailsUrdu: 'FFC Agritech Limited ka controlling stake acquire kar ke mulki urea market mein apna share mazeed mazboot bana rahi hai aur Goth Machhi plants par energy saving Capex kar rahi hai.',
    catalystEnglish: 'Consolidating Agritech adds immediate production capacity without greenfield execution risk, enhancing pricing power and national distribution efficiency.',
    catalystUrdu: 'Agritech ki acquisition se FFC ki urea capacity foran barh jati hai aur market share mazeed dominate ho jata hai.',
    disclosedHorizon: 'Regulatory Integration & Closure (FY2025-2026)',
    regulatorySourceType: 'PSX Statutory Material Information Filings'
  },

  // 🌟 ENGRO (Engro Corporation)
  ENGRO: {
    symbol: 'ENGRO',
    hasExpansion: true,
    status: 'ACTIVE_EXPANSION',
    statusBadgeEnglish: 'Active Expansion • Infrastructure & Chemical Terminal',
    statusBadgeUrdu: 'Active Expansion • International Chemical Terminals',
    headlineEnglish: 'Capital Reallocation into International Chemical Terminals & Telecom Infrastructure',
    headlineUrdu: 'International Chemical Terminals aur Telecom Tower Infrastructure Expansion',
    detailsEnglish: 'ENGRO is reallocating capital into high-margin regional infrastructure and chemical terminal storage assets, while scaling its Enfrashare telecom tower infrastructure across Pakistan.',
    detailsUrdu: 'ENGRO apne capital ko international chemical storage terminals aur Enfrashare telecom towers network mein invest kar rahi hai taake stable foreign currency cash flows generate hon.',
    catalystEnglish: 'Transitioning capital toward dollar-denominated storage assets shields the balance sheet from rupee volatility and strengthens dividend payout stability.',
    catalystUrdu: 'Foreign currency storage aur telecom tower business se rupee depreciation ka asar kam hota hai aur dividend regular rehta hai.',
    disclosedHorizon: 'Portfolio Execution & Deployment (FY2025-2027)',
    regulatorySourceType: 'Corporate Analyst Briefings & Annual Reports'
  },

  // 🌟 PAEL (Pak Elektron Limited)
  PAEL: {
    symbol: 'PAEL',
    hasExpansion: true,
    status: 'ACTIVE_CAPEX',
    statusBadgeEnglish: 'Active Capex • Smart AMI Meters & Solar Inverters',
    statusBadgeUrdu: 'Active Capex • Smart AMI Meters aur Solar Inverters Assembly',
    headlineEnglish: 'Advanced AMI Smart Electricity Meter Production Lines & Solar Hybrid Inverter Assembly',
    headlineUrdu: 'Automated AMI Smart Meters Manufacturing aur Solar Inverters Setup',
    detailsEnglish: 'PAEL is expanding automated mass manufacturing lines for smart Advanced Metering Infrastructure (AMI) electricity meters to fulfill government DISCO modernization contracts, alongside rolling out residential solar hybrid inverters.',
    detailsUrdu: 'PAEL smart electricity meters (AMI) ki automated production lines laga rahi hai taake sarkari bijli distribution companies (DISCOs) ke contracts deliver kar sake, sath hi solar hybrid inverters launch kiye hain.',
    catalystEnglish: 'Smart meter contracts for power sector anti-theft automation create stable, multi-billion rupee non-cyclical revenue streams independent of seasonal appliance demand.',
    catalystUrdu: 'Smart meters ke multi-billion rupee sarkari contracts se company ko saal bhar steady orders milte hain jo appliance demand ke seasonal utaar charhao ko balance karte hain.',
    disclosedHorizon: 'Production Scaling & Supply Execution (FY2025-2026)',
    regulatorySourceType: 'Annual Audited Accounts & Management Disclosures'
  },

  // 🌟 AIRLINK (Air Link Communication)
  AIRLINK: {
    symbol: 'AIRLINK',
    hasExpansion: true,
    status: 'ACTIVE_EXPANSION',
    statusBadgeEnglish: 'Active Expansion • Smartphone & Smart TV Assembly',
    statusBadgeUrdu: 'Active Expansion • Smartphone aur Smart TV Assembly Lines',
    headlineEnglish: 'Smartphone Assembly Expansion for Xiaomi/TECNO & Nationwide Retail Franchises',
    headlineUrdu: 'Xiaomi aur TECNO Smartphone Assembly aur Retail Franchise Store Network',
    detailsEnglish: 'AIRLINK is expanding mobile phone assembly lines for global brands including Xiaomi and TECNO, while inaugurating smart TV and laptop assembly lines alongside nationwide retail experience stores.',
    detailsUrdu: 'AIRLINK Xiaomi aur TECNO ke sath mil kar mobile assembly lines barha rahi hai aur smart TVs aur laptops manufacture karne ke sath nationwide retail outlets open kar rahi hai.',
    catalystEnglish: 'Local assembly tariff incentives combined with rapid retail expansion deliver robust cash collection velocity and expanding operating margins.',
    catalystUrdu: 'Local mobile assembly par duty incentives aur direct retail selling se cash collection tez hoti hai aur munafa barhta hai.',
    disclosedHorizon: 'Ongoing Commercial Scaling (FY2025-2026)',
    regulatorySourceType: 'Corporate Filings & Press Disclosures'
  },

  // 🌟 SEARL (The Searle Company)
  SEARL: {
    symbol: 'SEARL',
    hasExpansion: true,
    status: 'ACTIVE_CAPEX',
    statusBadgeEnglish: 'Active Capex • Bio-Tech Intravenous Plant & GCC Exports',
    statusBadgeUrdu: 'Active Capex • Bio-Tech Injectables Plant aur GCC Exports',
    headlineEnglish: 'Sterile Intravenous Injectable Plant Commissioning & GCC Regulatory Registrations',
    headlineUrdu: 'Sterile Injectable Plant Setup aur GCC Markets Export Registrations',
    detailsEnglish: 'SEARL is commissioning a modern sterile intravenous injectable and bio-tech manufacturing facility, while securing export registrations across the UAE, Saudi Arabia, and Southeast Asia.',
    detailsUrdu: 'SEARL Lahore mein modern sterile intravenous injectable plant commission kar rahi hai aur Gulf/GCC countries mein apni medicines ki export registrations complete kar rahi hai.',
    catalystEnglish: 'Expanding into sterile injectables and dollar-denominated export sales mitigates domestic drug price regulatory caps and expands operating EBITDA margins.',
    catalystUrdu: 'Sterile injectables aur foreign exports se dawaon ki qeematon ke sarkari controls ka asar kam hota hai aur munafa barhta hai.',
    disclosedHorizon: 'Commercial Validation & Product Launch (FY2025-2026)',
    regulatorySourceType: 'Annual Audited Accounts & Corporate Notices'
  },

  // 🌟 OGDC (Oil & Gas Development Company)
  OGDC: {
    symbol: 'OGDC',
    hasExpansion: true,
    status: 'NEW_LICENSE_VENTURE',
    statusBadgeEnglish: 'Strategic Mega Venture • Reko Diq Mining & Tight Gas',
    statusBadgeUrdu: 'Strategic Mega Venture • Reko Diq Mining aur Tight Gas Exploration',
    headlineEnglish: 'Equity Participation in Reko Diq Copper-Gold Project & Tight Gas Pilot Drilling',
    headlineUrdu: 'Reko Diq Copper-Gold Mega Project mein Equity aur Tight Gas Drilling',
    detailsEnglish: 'OGDC is investing sovereign consortium equity into the world-class Reko Diq copper-gold mining mega-project in Balochistan, while scaling tight gas pilot horizontal drilling across southern Sindh blocks.',
    detailsUrdu: 'OGDC Reko Diq copper-gold project mein consortium ke zariye equity invest kar rahi hai aur Sindh mein tight gas reserves nikalne ke lye modern drilling technologies deploy kar rahi hai.',
    catalystEnglish: 'Entering the multi-decade Reko Diq gold/copper mining asset diversifies OGDC away from depleting hydrocarbon basins into tier-1 global commodities.',
    catalystUrdu: 'Reko Diq gold aur copper mining se OGDC ko mustaqil multi-decade foreign currency cash flows milengi jo gas fields ki kami ko cover karengi.',
    disclosedHorizon: 'Project Feasibility & Mining Infrastructure (FY2025-2028)',
    regulatorySourceType: 'Statutory PSX Material Information Filings'
  },

  // 🌟 PPL (Pakistan Petroleum Limited)
  PPL: {
    symbol: 'PPL',
    hasExpansion: true,
    status: 'NEW_LICENSE_VENTURE',
    statusBadgeEnglish: 'Strategic Mega Venture • Reko Diq & Frontier Drilling',
    statusBadgeUrdu: 'Strategic Mega Venture • Reko Diq Mining aur Tight Gas',
    headlineEnglish: 'Reko Diq Mining Equity Stake & Gambat South Deep Exploration Concessions',
    headlineUrdu: 'Reko Diq Mining Consortium aur Gambat South Deep Gas Drilling',
    detailsEnglish: 'PPL holds key equity participation in the Reko Diq mining joint venture alongside Barrick Gold, while deploying modern hydraulic fracturing for deep gas exploration in Gambat South and Sui field life extension.',
    detailsUrdu: 'PPL Barrick Gold ke sath Reko Diq mining project mein equity share rakhti hai aur Gambat South aur Sui field mein modern extraction techniques se gas production barhane par kaam kar rahi hai.',
    catalystEnglish: 'Reko Diq mining upside combined with tight gas incentive pricing policy provides substantial long-term reserve replacement and cash flow protection.',
    catalystUrdu: 'Reko Diq copper-gold mining aur tight gas ki behtar sarkari qeematein company ki future valuation ko zabardast support deti hain.',
    disclosedHorizon: 'Mining Development & Exploration Phase (FY2025-2028)',
    regulatorySourceType: 'Statutory Corporate Filings & Annual Accounts'
  },

  // 🌟 TELE (Telecard Limited)
  TELE: {
    symbol: 'TELE',
    hasExpansion: true,
    status: 'TURNAROUND_CATALYST',
    statusBadgeEnglish: 'Turnaround Catalyst • Enterprise Cloud & Supernet Tech',
    statusBadgeUrdu: 'Turnaround Catalyst • Enterprise Cloud aur Debt Restructuring',
    headlineEnglish: 'Corporate Debt Restructuring & Asset-Light Enterprise Cloud Solutions Pivot',
    headlineUrdu: 'Corporate Debt Restructuring aur Enterprise Cloud Services Pivot',
    detailsEnglish: 'TELE is restructuring historical balance sheet debt while pivoting into asset-light enterprise cloud infrastructure, satellite connectivity, and cybersecurity services via its Supernet group entities.',
    detailsUrdu: 'TELE purana bank debt settle kar rahi hai aur purani fixed line telephony ki bajaye Supernet ke zariye enterprise cloud, cybersecurity aur satellite connectivity par shift ho rahi hai.',
    catalystEnglish: 'Clearing legacy bank liabilities and transitioning to high-margin recurring enterprise software and cloud connectivity represents the core turnaround driver.',
    catalystUrdu: 'Purane bank liabilities khatam hona aur high-margin cloud contracts par shift hona share ke lye positive turnaround story hai.',
    disclosedHorizon: 'Corporate Debt Resolution (FY2025-2026)',
    regulatorySourceType: 'Statutory Filings & Corporate Disclosures'
  },

  // 🌟 SILK (Silkbank Limited)
  SILK: {
    symbol: 'SILK',
    hasExpansion: true,
    status: 'TURNAROUND_CATALYST',
    statusBadgeEnglish: 'Turnaround Catalyst • SBP Recapitalization & Merger Talks',
    statusBadgeUrdu: 'Turnaround Catalyst • SBP Guided Recapitalization aur Merger',
    headlineEnglish: 'State Bank Recapitalization Framework & Strategic Bank Amalgamation Negotiations',
    headlineUrdu: 'State Bank Framework ke tehat Recapitalization aur Bank Merger Talks',
    detailsEnglish: 'SILK is in ongoing discussions with interested commercial financial institutions and strategic sponsor consortiums to execute capital injection or statutory merger under State Bank of Pakistan minimum capital directives.',
    detailsUrdu: 'SILK State Bank of Pakistan ki nigrani mein interested financial institutions aur sponsor groups ke sath capital injection aur statutory merger ki talks mein hai taake capital adequacy poori ho sake.',
    catalystEnglish: 'A successful strategic capital injection or bank merger solves regulatory capital deficiency, turning around the franchise and unlocking trapped asset value.',
    catalystUrdu: 'Strategic capital injection ya merger se bank ka capital issue hal ho sakta hai jo share holders ke lye key turnaround catalyst hai.',
    disclosedHorizon: 'Regulatory Recapitalization Window (FY2025-2026)',
    regulatorySourceType: 'Statutory PSX Material Disclosures & SBP Directives'
  },

  // 🌟 HASCOL (Hascol Petroleum Limited)
  HASCOL: {
    symbol: 'HASCOL',
    hasExpansion: true,
    status: 'TURNAROUND_CATALYST',
    statusBadgeEnglish: 'Turnaround Catalyst • High Court Debt Scheme & Pump Revival',
    statusBadgeUrdu: 'Turnaround Catalyst • High Court Debt Scheme aur Retail Pumps Revival',
    headlineEnglish: 'High Court Sanctioned Debt Restructuring Scheme & Taj Gasoline Sponsor Alignment',
    headlineUrdu: 'High Court Debt Restructuring Scheme aur Taj Gasoline Strategic Alignment',
    detailsEnglish: 'HASCOL is pursuing formal High Court approval for a comprehensive debt restructuring scheme with creditor banks, while coordinating with prospective strategic partner Taj Gasoline to revive product supplies across its 600+ retail fuel stations.',
    detailsUrdu: 'HASCOL banks ke sath High Court ke zariye debt restructuring scheme par kaam kar rahi hai aur Taj Gasoline ke sath alignment kar rahi hai taake 600+ petrol pumps par oil supply dobara shuru ho sake.',
    catalystEnglish: 'Bank debt restructuring and fuel supply resumption to its nationwide pump infrastructure could trigger a dramatic operational turnaround from historical losses.',
    catalystUrdu: 'Debt restructure hone aur petrol supply bahal hone se 600 pumps ka network dobara cash generate kare ga jo sab se bara turnaround driver ho ga.',
    disclosedHorizon: 'Court Sanction & Creditor Settlement (FY2025-2026)',
    regulatorySourceType: 'Court Filings & PSX Material Disclosures'
  },

  // 🌟 HUMNL (Hum Network Limited)
  HUMNL: {
    symbol: 'HUMNL',
    hasExpansion: true,
    status: 'ACTIVE_EXPANSION',
    statusBadgeEnglish: 'Active Expansion • Digital OTT Streaming & Global Syndication',
    statusBadgeUrdu: 'Active Expansion • Digital OTT Streaming aur Global Drama Syndication',
    headlineEnglish: 'Digital Streaming OTT Platform Rollout & Global YouTube Drama Monetization',
    headlineUrdu: 'Digital Streaming OTT Platform aur International Drama Syndication',
    detailsEnglish: 'HUMNL is scaling direct-to-consumer digital OTT streaming platforms, monetizing international syndication rights with global streaming giants, and expanding high-margin digital media content creation.',
    detailsUrdu: 'HUMNL direct digital OTT mobile streaming platforms launch kar rahi hai aur international broadcast platforms ko Pakistani dramas syndicate kar ke foreign currency income generate kar rahi hai.',
    catalystEnglish: 'High-margin digital and international streaming revenues reduce reliance on domestic linear television advertising cycles.',
    catalystUrdu: 'Digital aur foreign currency streaming income se local TV advertising market ke utaar charhao ka khatra kam ho jata hai.',
    disclosedHorizon: 'Platform Rollout & Scaling (FY2025-2026)',
    regulatorySourceType: 'Annual Audited Accounts & Management Briefings'
  },

  // 🌟 WAVES (Waves Corporation)
  WAVES: {
    symbol: 'WAVES',
    hasExpansion: true,
    status: 'TURNAROUND_CATALYST',
    statusBadgeEnglish: 'Turnaround Catalyst • Appliances Demerger & Retail Outlets',
    statusBadgeUrdu: 'Turnaround Catalyst • Home Appliances Demerger aur Retail Network',
    headlineEnglish: 'Corporate Demerger of Waves Home Appliances & Secondary-City Retail Network Expansion',
    headlineUrdu: 'Waves Home Appliances ka Demerger aur Retail Outlets Network Rollout',
    detailsEnglish: 'WAVES executed the demerger of its appliances manufacturing business into a dedicated listed entity while expanding company-owned retail appliance showrooms in tier-2 and tier-3 industrial cities.',
    detailsUrdu: 'WAVES ne apne manufacturing karobar ko alag listed entity mein demerge kia hai aur chote shehron mein direct retail showrooms ka network expand kar rahi hai.',
    catalystEnglish: 'Corporate demerger unlocks transparent asset valuation and direct retail sales improve working capital turnover.',
    catalystUrdu: 'Corporate demerger aur direct retail showrooms se cash flows clear hoti hain aur karobar mein behtari aati hai.',
    disclosedHorizon: 'Retail Rollout & Distribution Optimization (FY2025-2026)',
    regulatorySourceType: 'Annual Audited Accounts & Scheme of Arrangement'
  },

  // 🌟 FLYNG (Flying Cement / Flying Paper)
  FLYNG: {
    symbol: 'FLYNG',
    hasExpansion: true,
    status: 'ACTIVE_CAPEX',
    statusBadgeEnglish: 'Active Capex • Waste Heat Recovery & Line Modernization',
    statusBadgeUrdu: 'Active Capex • Waste Heat Recovery aur Plant Upgrade',
    headlineEnglish: 'Waste Heat Recovery Captive Power Installation & Production Throughput Modernization',
    headlineUrdu: 'Waste Heat Recovery Power Plant aur Production Capacity Upgrade',
    detailsEnglish: 'FLYNG is installing waste heat recovery (WHR) captive power systems to generate zero-fuel electricity from kiln exhaust gases, while upgrading clinker throughput lines.',
    detailsUrdu: 'FLYNG waste heat recovery system laga rahi hai taake factory ki dhuen se sasti bijli banayi ja sake aur cement banane ki overall cost kam ho sake.',
    catalystEnglish: 'Self-generated zero-fuel electricity significantly lowers cost per ton, restoring operating gross margins.',
    catalystUrdu: 'Zero-fuel electricity se per-bag cost kam hoti hai jis se mushkil market mein bi munafa barhta hai.',
    disclosedHorizon: 'Installation & Commissioning Phase (FY2025-2026)',
    regulatorySourceType: 'Annual Audited Accounts & Corporate Notices'
  },

  // 🌟 DFML (Dewan Farooque Motors)
  DFML: {
    symbol: 'DFML',
    hasExpansion: true,
    status: 'TURNAROUND_CATALYST',
    statusBadgeEnglish: 'Turnaround Catalyst • Sujawal Assembly Plant Revival & EVs',
    statusBadgeUrdu: 'Turnaround Catalyst • Sujawal Plant Bahali aur Commercial EVs',
    headlineEnglish: 'Reactivation of Sujawal Vehicle Assembly Plant for Commercial EVs & Farm Equipment',
    headlineUrdu: 'Sujawal Car Assembly Plant ki Bahali aur Commercial Electric Vehicles Setup',
    detailsEnglish: 'DFML is reviving its manufacturing facility in Sujawal under the Auto Industry Development and Export Policy (AIDEP) to assemble commercial electric vehicles and specialized automotive products.',
    detailsUrdu: 'DFML apna Sujawal assembly plant dobara chala rahi hai jahan commercial electric vehicles aur automotive machinery assemble karne ke arrangements kiye gaye hain.',
    catalystEnglish: 'Reactivating idle production lines transforms a distressed closed asset into an active commercial assembler.',
    catalystUrdu: 'Band factory ka dobara chalu hona aur commercial EVs banana DFML ke lye ek bari turnaround opportunity hai.',
    disclosedHorizon: 'Commercial Assembly Operations (FY2025-2026)',
    regulatorySourceType: 'Statutory Filings & Corporate Notices'
  },

  // 🌟 PIOC (Pioneer Cement)
  PIOC: {
    symbol: 'PIOC',
    hasExpansion: true,
    status: 'ACTIVE_CAPEX',
    statusBadgeEnglish: 'Active Capex • Solar Power Expansion',
    statusBadgeUrdu: 'Active Capex • 12MW Solar Power Installation',
    headlineEnglish: '12MW Captive Solar Array Installation at Chenki Plant',
    headlineUrdu: 'Chenki Factory mein 12MW Captive Solar Power Plant Setup',
    detailsEnglish: 'PIOC is commissioning a 12MW captive solar power installation at its Chenki plant to hedge against rising grid tariffs and stabilize clinker manufacturing costs.',
    detailsUrdu: 'PIOC Chenki factory mein 12MW solar plant laga rahi hai taake sarkari bijli ke barhte hue rates se bach sake aur cement production cost control mein rahe.',
    catalystEnglish: 'Lower cost per kilowatt hour directly protects cement operating margins during seasonal demand cycles.',
    catalystUrdu: 'Sasti solar bijli se cement production ka kharcha kam rehta hai aur margins safe rehte hain.',
    disclosedHorizon: 'Commissioning Phase (FY2025-2026)',
    regulatorySourceType: 'Annual Audited Reports'
  },

  // 🌟 AST (Amreli Steels)
  AST: {
    symbol: 'AST',
    hasExpansion: true,
    status: 'PLANT_CAPEX_UPGRADE',
    statusBadgeEnglish: 'Plant Modernization • Energy Efficiency & Specialty Re-bars',
    statusBadgeUrdu: 'Plant Upgrade • Energy Efficiency aur High-Strength Steel',
    headlineEnglish: 'Dhabeji Rolling Mill Energy Optimization & High-Strength Seismic Re-bar Rollout',
    headlineUrdu: 'Dhabeji Rolling Mill Optimization aur Seismic Resistant Re-bars',
    detailsEnglish: 'AST is optimizing its Dhabeji automated re-bar rolling mill with energy-efficiency upgrades and expanding distribution of high-strength earthquake-resistant steel re-bars.',
    detailsUrdu: 'AST Dhabeji factory mein automated rolling mill ki energy efficiency barha rahi hai aur zalzala-resistant high-strength steel re-bars market mein supply kar rahi hai.',
    catalystEnglish: 'Energy-efficient steel melting lowers unit conversion costs, positioning the firm for recovery in national infrastructure tenders.',
    catalystUrdu: 'Bijli aur gas ka kharcha kam hone se steel bananey ki cost kam hoti hai jis se infrastructure projects mein munafa barhta hai.',
    disclosedHorizon: 'Operational Upgrades (FY2025-2026)',
    regulatorySourceType: 'Annual Audited Accounts'
  },

  // 🌟 DAWH (Dawood Hercules)
  DAWH: {
    symbol: 'DAWH',
    hasExpansion: true,
    status: 'ACTIVE_EXPANSION',
    statusBadgeEnglish: 'Corporate Restructuring • Energy Transition Investments',
    statusBadgeUrdu: 'Corporate Restructuring • Green Energy Transition Capital',
    headlineEnglish: 'Strategic Amalgamation with DH Partners & Capital Deployment into Green Energy',
    headlineUrdu: 'Corporate Amalgamation aur Green Energy Ventures mein Capital Deployment',
    detailsEnglish: 'DAWH is restructuring into a streamlined investment holding entity to deploy capital into international green transition, renewable energy, and regional technology ventures.',
    detailsUrdu: 'DAWH apne corporate structure ko streamline kar ke international renewable energy aur green transition projects mein fresh capital invest kar rahi hai.',
    catalystEnglish: 'Deploying capital into defensive yield-generating energy transition assets provides long-term dividend growth.',
    catalystUrdu: 'Green energy aur high-yield assets mein investment se long-term dividend regular aur mazboot rehta hai.',
    disclosedHorizon: 'Restructuring Execution (FY2025-2026)',
    regulatorySourceType: 'Statutory Scheme of Arrangement & PSX Notices'
  }
};

/**
 * Returns comprehensive business expansion & turnaround intelligence for any PSX symbol.
 * If the company has no reported expansion plans or operates in steady-state, returns NOT_APPLICABLE.
 */
export function getPSXExpansionIntelligence(symbol: string, sector?: string): PSXExpansionInfo {
  const clean = (symbol || '').toUpperCase().replace('.PSX', '').replace('.KA', '').trim();
  const norm = clean.replace(/[-\s]/g, '');

  if (PSX_EXPANSION_DATABASE[clean]) {
    return PSX_EXPANSION_DATABASE[clean];
  }
  if (PSX_EXPANSION_DATABASE[norm]) {
    return PSX_EXPANSION_DATABASE[norm];
  }

  const isIndex = norm.startsWith('KSE') || norm.startsWith('KMI') || (sector || '').toLowerCase().includes('index');
  if (isIndex) {
    return {
      symbol: clean,
      hasExpansion: false,
      status: 'NOT_APPLICABLE',
      statusBadgeEnglish: 'Not Applicable • Benchmark Macro Index',
      statusBadgeUrdu: 'Not Applicable • Benchmark Macroeconomic Index',
      headlineEnglish: 'Not Applicable • Benchmark Macroeconomic Index',
      headlineUrdu: 'Not Applicable • Benchmark Macroeconomic Index',
      detailsEnglish: 'As a market capitalization-weighted benchmark index, KSE-100 tracks overall market performance across 35 sectors rather than conducting physical corporate Capex or business expansion.',
      detailsUrdu: 'KSE-100 ek benchmark index hai jo overall market ki car-kardagi track karta hai, is lye physical business expansion ya Capex is par lagu nahi hota.',
      catalystEnglish: 'Reflects collective economic earnings growth of constituent equities rather than single-firm expansion.',
      catalystUrdu: 'Index constituent companies ki collective growth ko zahir karta hai.',
      disclosedHorizon: 'Not Applicable',
      regulatorySourceType: 'PSX Index Governance'
    };
  }

  // Sensible default for uncataloged companies operating in steady-state mode
  return {
    symbol: clean,
    hasExpansion: false,
    status: 'NOT_APPLICABLE',
    statusBadgeEnglish: 'Not Applicable • Steady-State Operations',
    statusBadgeUrdu: 'Not Applicable • Routine Steady-State Operations',
    headlineEnglish: 'Not Applicable • Steady-State Operational Maintenance',
    headlineUrdu: 'Not Applicable • Routine Maintenance Mode',
    detailsEnglish: 'Company has not disclosed new capacity expansion, major Capex, or license applications in recent annual reports or statutory filings. Operations are conducted in steady-state maintenance mode.',
    detailsUrdu: 'Company ki janib se kisi nayi capacity expansion, bare Capex ya new license ka elaan ya disclosure samnay nahi aaya; karobar routine maintenance mode mein chal raha hai.',
    catalystEnglish: 'Focus remains on sustaining current production runs, managing regular working capital cycles, and routine plant upkeep.',
    catalystUrdu: 'Company ka focus mojooda production aur routine operations chalane par hai, koi nai expansion plan reported nahi hai.',
    disclosedHorizon: 'Not Applicable (Steady-State Operations)',
    regulatorySourceType: 'Audited Annual Reports & Statutory Filings'
  };
}
