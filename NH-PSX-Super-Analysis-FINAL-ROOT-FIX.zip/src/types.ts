export type TimeFrame = '15M' | '30M' | '1H' | '4H' | '1D' | '1W' | '1MO';

export type AssetClass = 'Stock' | 'Crypto' | 'Index' | 'Forex' | 'Commodity';

export interface TickerQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  open: number;
  high: number;
  low: number;
  previousClose: number;
  volume: number;
  avgVolume: number;
  marketCap: number;
  peRatio?: number;
  week52High?: number;
  week52HighDate?: string;
  week52Low?: number;
  week52LowDate?: string;
  yearHigh?: number;
  yearLow?: number;
  everHigh?: number;
  everHighDate?: string;
  everLow?: number;
  everLowDate?: string;
  allTimeHigh?: number;
  allTimeLow?: number;
  sector: string;
  assetClass: AssetClass;
  exchange?: string;
  countryFlag?: string;
  lastTickTime: number;
  bid: number;
  ask: number;
  bidSize: number;
  askSize: number;
  vwap: number;
  rsi: number;
  macd: {
    macd: number;
    signal: number;
    histogram: number;
  };
  sma20: number;
  sma50: number;
  sma200: number;
  aiScore: number; // 0 to 100
  aiSignal: 'Strong Buy' | 'Buy' | 'Neutral' | 'Sell' | 'Strong Sell';
  isVerified?: boolean;
  source?: string;
  receivedAt?: number;
}

export interface Candle {
  time: number; // timestamp in seconds or millis
  timeLabel: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  isVerified?: boolean;
  sma20?: number;
  sma50?: number;
  ema9?: number;
  ema21?: number;
  ema20?: number;
  ema50?: number;
  ema200?: number;
  supertrend?: { value: number; trend: 'BUY' | 'SELL' };
  rsi?: number;
  upperBB?: number;
  lowerBB?: number;
  middleBB?: number;
  vwap?: number;
}

export interface TechnicalIndicators {
  rsi: number;
  macd: { macd: number; signal: number; histogram: number };
  sma20: number;
  sma50: number;
  sma200: number;
  ema9: number;
  ema21: number;
  ema20: number;
  bollingerBands: { upper: number; middle: number; lower: number };
  vwap: number;
  atr: number;
}

export type StrategyType = 
  | 'EMA_9_21_CROSS'
  | 'MA_CROSSOVER' 
  | 'RSI_REVERSAL' 
  | 'MEAN_REVERSION' 
  | 'MOMENTUM_BREAKOUT' 
  | 'EMA_50_200_CROSS'
  | 'CUSTOM_AI';

export interface BacktestParams {
  symbol: string;
  strategy: StrategyType;
  timeframe: TimeFrame;
  initialCapital: number;
  positionSizePercent: number;
  stopLossPercent: number;
  takeProfitPercent: number;
  shortEnabled: boolean;
  fastPeriod: number;
  slowPeriod: number;
  rsiOversold: number;
  rsiOverbought: number;
  customRules?: string;
}

export interface Trade {
  id: string;
  type: 'BUY' | 'SELL' | 'SHORT' | 'COVER';
  entryTime: string;
  entryPrice: number;
  exitTime?: string;
  exitPrice?: number;
  quantity: number;
  pnl?: number;
  pnlPercent?: number;
  status: 'OPEN' | 'CLOSED';
  reason: string;
}

export interface EquityPoint {
  time: string;
  portfolioValue: number;
  benchmarkValue: number; // SPY benchmark normalized
  drawdownPercent: number;
}

export interface BacktestResult {
  params: BacktestParams;
  totalReturnPercent: number;
  totalProfit: number;
  benchmarkReturnPercent: number;
  annualizedReturnPercent: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdownPercent: number;
  winRatePercent: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  profitFactor: number;
  avgTradePnlPercent: number;
  trades: Trade[];
  equityCurve: EquityPoint[];
}

export interface AIResearchReport {
  symbol: string;
  timestamp: string;
  overallScore: number; // 0-100
  conviction: 'Strong Buy' | 'Buy' | 'Neutral' | 'Sell' | 'Strong Sell';
  executiveSummary: string;
  technicalAnalysis: {
    trendSummary: string;
    keySupport: number[];
    keyResistance: number[];
    detectedPatterns: string[];
    indicatorBreakdown: { name: string; signal: 'Bullish' | 'Bearish' | 'Neutral'; details: string }[];
  };
  algorithmicSetup: {
    recommendedStrategy: string;
    idealEntry: number;
    stopLoss: number;
    targetPrice1: number;
    targetPrice2: number;
    riskRewardRatio: number;
  };
  catalystsAndRisks: {
    bullishCatalysts: string[];
    keyRisks: string[];
    sentimentScore: number; // -1 to +1
  };
  quantSnippet?: {
    language: string;
    code: string;
  };
  groundingSources?: { title: string; url: string }[];
}

export interface TechnicalLevels {
  pivot: number;
  s1: number;
  s2: number;
  r1: number;
  r2: number;
  stopLoss: number;
  target1: number;
  target2: number;
  stopLossNote?: string;
}



