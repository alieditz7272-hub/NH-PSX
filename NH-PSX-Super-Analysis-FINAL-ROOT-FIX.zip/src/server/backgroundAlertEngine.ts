import fs from 'fs';
import path from 'path';
import { TickerQuote } from '../types';
import { calculate14IndicatorsConfluence, IndicatorScoreResult } from '../utils/psx14IndicatorAlertEvaluator';
import { isStockInIndex, PSX_INDEX_DEFINITIONS } from '../utils/psxIndices';
import { isPsxIndex } from '../utils/symbol';
import { ntfyNotifier, DEFAULT_NTFY_TOPIC, ADMIN_NAME } from './ntfyNotifier';

export interface ServerPriceAlert {
  id: string;
  symbol: string;
  name: string;
  type: 'PRICE_ABOVE' | 'PRICE_BELOW' | 'VOLUME_SPIKE' | 'TARGET_HIT' | 'STOP_LOSS_HIT';
  threshold: number;
  initialPrice: number;
  initialVolume: number;
  isActive: boolean;
  createdAt: number;
  triggeredAt?: number;
  spokenMessage: string;
  createdBy?: string;
  isIndex?: boolean;
}

export interface Scanner80PctSignal {
  id: string;
  symbol: string;
  name: string;
  score: number;
  bullishCount: number;
  totalIndicators: number;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  timestamp: number;
  formattedPktTime: string;
  logics: string[];
  entryZone: string;
  targetPrice: number;
  stopLossPrice: number;
  ntfyDispatched: boolean;
  indexFiltered?: string;
}

export interface AlertEngineSettings {
  isMasterActive: boolean;
  is80PctScannerActive: boolean;
  selectedIndex: string; // 'ALL' | 'KSE100' | 'KSE30' | 'KMI30'
  minScoreThreshold: number;
}

interface AlertStoreData {
  settings: AlertEngineSettings;
  alerts: ServerPriceAlert[];
  triggeredHistory: {
    id: string;
    alertId: string;
    symbol: string;
    name: string;
    message: string;
    price: number;
    timestamp: number;
    formattedPktTime: string;
    ntfyDispatched: boolean;
  }[];
  scannerSignals: Scanner80PctSignal[];
}

const DATA_DIR = path.join(process.cwd(), 'data');
const ALERTS_DB_FILE = path.join(DATA_DIR, 'psx_alerts_store.json');

export class BackgroundAlertEngine {
  private static instance: BackgroundAlertEngine;
  private lastHourlyCloseHour: number = -1;
  private db: AlertStoreData = {
    settings: {
      isMasterActive: true,
      is80PctScannerActive: true,
      selectedIndex: 'ALL',
      minScoreThreshold: 80
    },
    alerts: [],
    triggeredHistory: [],
    scannerSignals: []
  };

  private constructor() {
    this.ensureDataDir();
    this.load();
    this.seedDefaultAlertsIfEmpty();
  }

  public static getInstance(): BackgroundAlertEngine {
    if (!BackgroundAlertEngine.instance) {
      BackgroundAlertEngine.instance = new BackgroundAlertEngine();
    }
    return BackgroundAlertEngine.instance;
  }

  private ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
      try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      } catch (e) {
        console.error('Failed to create data dir for alerts:', e);
      }
    }
  }

  private load() {
    try {
      if (fs.existsSync(ALERTS_DB_FILE)) {
        const raw = fs.readFileSync(ALERTS_DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        this.db = {
          settings: {
            isMasterActive: parsed.settings?.isMasterActive ?? true,
            is80PctScannerActive: parsed.settings?.is80PctScannerActive ?? true,
            selectedIndex: parsed.settings?.selectedIndex || 'ALL',
            minScoreThreshold: parsed.settings?.minScoreThreshold || 80
          },
          alerts: parsed.alerts || [],
          triggeredHistory: parsed.triggeredHistory || [],
          scannerSignals: parsed.scannerSignals || []
        };
      }
    } catch (e) {
      console.warn('Failed to parse alerts DB, initializing empty store:', e);
      this.db = {
        settings: {
          isMasterActive: true,
          is80PctScannerActive: true,
          selectedIndex: 'ALL',
          minScoreThreshold: 80
        },
        alerts: [],
        triggeredHistory: [],
        scannerSignals: []
      };
    }
  }

  public save() {
    try {
      this.ensureDataDir();
      fs.writeFileSync(ALERTS_DB_FILE, JSON.stringify(this.db, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to save alerts store to disk:', e);
    }
  }

  private seedDefaultAlertsIfEmpty() {
    if (!this.db.alerts || this.db.alerts.length === 0) {
      this.db.alerts = [
        {
          id: 'alt-srv-kse100',
          symbol: 'KSE100.PSX',
          name: 'KSE-100 Index',
          type: 'PRICE_ABOVE',
          threshold: 125000,
          initialPrice: 120000,
          initialVolume: 450000000,
          isActive: true,
          createdAt: Date.now() - 3600000,
          spokenMessage: 'KSE-100 Index milestone breakout alert above 125,000 points!',
          createdBy: 'admin_nadeem',
          isIndex: true
        },
        {
          id: 'alt-srv-ogdc',
          symbol: 'OGDC.PSX',
          name: 'Oil & Gas Dev Co',
          type: 'PRICE_ABOVE',
          threshold: 165.0,
          initialPrice: 158.5,
          initialVolume: 4500000,
          isActive: true,
          createdAt: Date.now() - 7200000,
          spokenMessage: 'OGDC price crossed above 165 Rupees resistance breakout!',
          createdBy: 'admin_nadeem',
          isIndex: false
        }
      ];
      this.save();
    }
  }

  // =========================================================================
  // SETTINGS MANAGEMENT
  // =========================================================================

  public getSettings(): AlertEngineSettings {
    return { ...this.db.settings };
  }

  public updateSettings(newSettings: Partial<AlertEngineSettings>): AlertEngineSettings {
    this.db.settings = {
      ...this.db.settings,
      ...newSettings
    };
    this.save();
    console.log(`[ALERT ENGINE] Updated settings: MasterActive=${this.db.settings.isMasterActive}, 80PctScannerActive=${this.db.settings.is80PctScannerActive}, Index=${this.db.settings.selectedIndex}`);
    return this.db.settings;
  }

  public setMasterActive(active: boolean): boolean {
    this.db.settings.isMasterActive = active;
    this.save();
    return this.db.settings.isMasterActive;
  }

  public set80PctScannerActive(active: boolean): boolean {
    this.db.settings.is80PctScannerActive = active;
    this.save();
    return this.db.settings.is80PctScannerActive;
  }

  public setSelectedIndex(indexCode: string): string {
    this.db.settings.selectedIndex = indexCode || 'ALL';
    this.save();
    return this.db.settings.selectedIndex;
  }

  // =========================================================================
  // ALERT CRUD
  // =========================================================================

  public getAlerts(): ServerPriceAlert[] {
    return this.db.alerts || [];
  }

  public getTriggeredHistory() {
    return this.db.triggeredHistory || [];
  }

  public getScannerSignals(): Scanner80PctSignal[] {
    return this.db.scannerSignals || [];
  }

  public addAlert(alert: Omit<ServerPriceAlert, 'id' | 'createdAt'>): ServerPriceAlert {
    const isIndex = alert.symbol.startsWith('KSE') || alert.symbol.startsWith('ALLSHR') || alert.symbol.startsWith('KMI');
    const newAlert: ServerPriceAlert = {
      ...alert,
      id: `alt_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
      isActive: true,
      isIndex
    };

    if (!this.db.alerts) this.db.alerts = [];
    this.db.alerts.unshift(newAlert);
    this.save();

    console.log(`[ALERT ENGINE] Registered 24/7 background alert for ${newAlert.symbol} (${newAlert.type} @ ${newAlert.threshold})`);
    return newAlert;
  }

  public deleteAlert(alertId: string): boolean {
    if (!this.db.alerts) return false;
    const initialLen = this.db.alerts.length;
    this.db.alerts = this.db.alerts.filter(a => a.id !== alertId);
    if (this.db.alerts.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  public toggleAlert(alertId: string): ServerPriceAlert | null {
    if (!this.db.alerts) return null;
    const target = this.db.alerts.find(a => a.id === alertId);
    if (target) {
      target.isActive = !target.isActive;
      this.save();
      return target;
    }
    return null;
  }

  public syncBulkAlerts(clientAlerts: ServerPriceAlert[]) {
    if (!Array.isArray(clientAlerts)) return;
    const existingMap = new Map((this.db.alerts || []).map(a => [a.id, a]));
    
    clientAlerts.forEach(ca => {
      if (existingMap.has(ca.id)) {
        const curr = existingMap.get(ca.id)!;
        curr.isActive = ca.isActive;
        curr.threshold = ca.threshold;
        curr.spokenMessage = ca.spokenMessage || curr.spokenMessage;
      } else {
        const isIndex = ca.symbol.startsWith('KSE') || ca.symbol.startsWith('ALLSHR') || ca.symbol.startsWith('KMI');
        this.db.alerts.unshift({
          ...ca,
          isIndex
        });
      }
    });
    this.save();
  }

  // =========================================================================
  // 24/7 BACKGROUND TICK EVALUATOR
  // =========================================================================

  public async evaluateLiveQuotes(quotes: TickerQuote[]) {
    if (!quotes || quotes.length === 0) return;

    // Check master switch
    if (!this.db.settings.isMasterActive) {
      return;
    }

    try {
      // 1. Evaluate User/Admin Price & Volume Alerts (Stocks + Indices)
      await this.evaluateCustomPriceAlerts(quotes);

      // 2. Evaluate 80%+ High-Probability Scanner Confluence across Selected Index Equities
      if (this.db.settings.is80PctScannerActive) {
        await this.evaluate80PctScannerConfluence(quotes);
      }

      // 3. Evaluate Volume Above 20 Days Moving Average for Stocks & Indices
      await this.evaluate20DayVolumeSurges(quotes);

      // 4. Evaluate Outstanding Breakouts (Stocks breaking multi-week resistance or hitting confirmed high momentum)
      await this.evaluateOutstandingBreakouts(quotes);

      // 5. Evaluate Bearish Reversal Candlestick Formations
      await this.evaluateBearishCandles(quotes);

      // 6. Evaluate Hourly KSE-100 Closing Alert during market hours
      await this.evaluateHourlyKse100Close(quotes);

      // 7. Evaluate Day Closing Summary & Top 5 Volume Leaders (Post 16:00 PKT)
      await this.evaluateMarketCloseSummaryAndTop5(quotes);
    } catch (e) {
      console.error('[BACKGROUND ALERT ENGINE] Error during live quote evaluation:', e);
    }
  }

  // 1. Evaluate Custom Price Alerts
  private async evaluateCustomPriceAlerts(quotes: TickerQuote[]) {
    if (!this.db.alerts || this.db.alerts.length === 0) return;

    const now = Date.now();
    const activeAlerts = this.db.alerts.filter(a => a.isActive);

    for (const alt of activeAlerts) {
      const cleanAltSym = alt.symbol.toUpperCase().replace('.PSX', '').replace('.KA', '').trim();
      const quote = quotes.find(q => {
        const qSym = q.symbol.toUpperCase().replace('.PSX', '').replace('.KA', '').trim();
        return qSym === cleanAltSym || q.symbol.toUpperCase() === alt.symbol.toUpperCase();
      });

      if (!quote || typeof quote.price !== 'number' || quote.price <= 0) continue;

      let triggered = false;
      let hitReason = '';

      const isIdx = isPsxIndex(alt.symbol) || isPsxIndex(quote);
      if ((alt.type === 'PRICE_ABOVE' || alt.type === 'TARGET_HIT') && quote.price >= alt.threshold) {
        triggered = true;
        hitReason = `Price reached ${quote.price.toFixed(2)} (Crossed Target / Resistance: ${alt.threshold.toFixed(2)})`;
      } else if ((alt.type === 'PRICE_BELOW' || alt.type === 'STOP_LOSS_HIT') && quote.price <= alt.threshold) {
        triggered = true;
        hitReason = `Price dropped to ${quote.price.toFixed(2)} (Crossed Support / Stop Loss: ${alt.threshold.toFixed(2)})`;
      } else if (alt.type === 'VOLUME_SPIKE') {
        const avgVol = Math.max(100000, alt.initialVolume || quote.avgVolume || 100000);
        const currentVol = quote.volume || 0;
        const volumeSurgePct = (currentVol / avgVol) * 100;
        if (volumeSurgePct >= alt.threshold && currentVol > 50000) {
          triggered = true;
          hitReason = `Volume surged to ${currentVol.toFixed(2).replace(/,/g, '')} shares (${volumeSurgePct.toFixed(2).replace(/,/g, '')}% of baseline avg)`;
        }
      }

      if (triggered) {
        alt.isActive = false;
        alt.triggeredAt = now;

        const dateStr = new Intl.DateTimeFormat('en-PK', {
          timeZone: 'Asia/Karachi',
          dateStyle: 'medium',
          timeStyle: 'medium'
        }).format(new Date(now));

        // Save in history
        if (!this.db.triggeredHistory) this.db.triggeredHistory = [];
        this.db.triggeredHistory.unshift({
          id: `trig_${now.toString(36)}`,
          alertId: alt.id,
          symbol: alt.symbol,
          name: alt.name || quote.name || alt.symbol,
          message: hitReason,
          price: quote.price,
          timestamp: now,
          formattedPktTime: dateStr,
          ntfyDispatched: true
        });
        if (this.db.triggeredHistory.length > 200) {
          this.db.triggeredHistory = this.db.triggeredHistory.slice(0, 200);
        }

        this.save();

        console.log(`[ALERT TRIGGERED] ${alt.symbol} -> ${hitReason}. Dispatching ntfy push to Admin ${ADMIN_NAME} (${DEFAULT_NTFY_TOPIC})...`);

        // Dispatch instant ntfy push alert
        try {
          await ntfyNotifier.sendPriceAlarmAlert({
            symbol: alt.symbol,
            name: alt.name || quote.name || alt.symbol,
            type: alt.type,
            threshold: alt.threshold,
            currentPrice: quote.price,
            change: quote.change || 0,
            changePercent: quote.changePercent || 0,
            reason: hitReason,
            spokenMessage: alt.spokenMessage,
            isIndex: alt.isIndex
          });
        } catch (err: any) {
          console.log(`[ALERT DISPATCH] Price alert logged for ${alt.symbol}: ${err?.message || err}`);
        }
      }
    }
  }

  // 2. Evaluate 80%+ Confluence Scanner filtered by Selected Index
  private async evaluate80PctScannerConfluence(quotes: TickerQuote[]) {
    const now = Date.now();
    const selectedIndex = this.db.settings.selectedIndex || 'ALL';
    const minThreshold = this.db.settings.minScoreThreshold || 80;

    // Filter out market indices, empty quotes, and filter by selected index membership
    const eligibleEquities = quotes.filter(q => 
      q && q.symbol && 
      q.assetClass !== 'Index' && 
      !q.symbol.startsWith('KSE') && 
      !q.symbol.startsWith('ALLSHR') && 
      !q.symbol.startsWith('KMI') &&
      typeof q.price === 'number' && q.price > 0 &&
      isStockInIndex(q.symbol, selectedIndex)
    );

    const indexDef = PSX_INDEX_DEFINITIONS.find(i => i.id === selectedIndex);
    const indexLabel = indexDef ? indexDef.shortName : selectedIndex;

    for (const stock of eligibleEquities) {
      const evalResult: IndicatorScoreResult = calculate14IndicatorsConfluence(stock);

      // Score threshold condition
      if (evalResult.score >= minThreshold) {
        const cleanSym = stock.symbol.toUpperCase().trim();

        const dateStr = new Intl.DateTimeFormat('en-PK', {
          timeZone: 'Asia/Karachi',
          dateStyle: 'medium',
          timeStyle: 'medium'
        }).format(new Date(now));

        // Extract key bullish indicator logics
        const bullishLogics = evalResult.indicatorDetails
          .filter(ind => ind.isBullish)
          .map(ind => `✅ ${ind.name}: ${ind.status} (${ind.valueText})`);

        const cmp = stock.price;
        const stopLoss = parseFloat((cmp * 0.965).toFixed(2));
        const targetPrice = parseFloat((cmp * 1.085).toFixed(2));
        const isIdx = isPsxIndex(stock);
        const entryZone = `${(cmp * 0.995).toFixed(2)} – ${(cmp * 1.01).toFixed(2)}`;

        const signal: Scanner80PctSignal = {
          id: `scan80_${cleanSym}_${now.toString(36)}`,
          symbol: stock.symbol,
          name: stock.name || cleanSym.replace('.PSX', ''),
          score: evalResult.score,
          bullishCount: evalResult.bullishIndicatorsCount,
          totalIndicators: evalResult.totalIndicators,
          price: cmp,
          change: stock.change || 0,
          changePercent: stock.changePercent || 0,
          volume: stock.volume || 0,
          timestamp: now,
          formattedPktTime: dateStr,
          logics: bullishLogics,
          entryZone,
          targetPrice,
          stopLossPrice: stopLoss,
          ntfyDispatched: true,
          indexFiltered: indexLabel
        };

        if (!this.db.scannerSignals) this.db.scannerSignals = [];
        this.db.scannerSignals.unshift(signal);
        if (this.db.scannerSignals.length > 100) {
          this.db.scannerSignals = this.db.scannerSignals.slice(0, 100);
        }
        this.save();

        console.log(`[80% SCANNER HIT] ${stock.symbol} (Index: ${indexLabel}) achieved ${evalResult.score}% Confluence. Dispatching ntfy push to Admin ${ADMIN_NAME}...`);

        // Dispatch comprehensive ntfy notification with deduplication
        try {
          await ntfyNotifier.sendScanRadarAlert({
            symbol: stock.symbol,
            name: stock.name || cleanSym.replace('.PSX', ''),
            score: evalResult.score,
            price: cmp,
            change: stock.change || 0,
            changePercent: stock.changePercent || 0,
            volume: stock.volume || 0,
            signal: 'STRONG BUY (80%+ Confluence)',
            logics: bullishLogics,
            entryZone,
            targetPrice,
            stopLossPrice: stopLoss,
            indexName: indexLabel
          });
        } catch (err: any) {
          console.log(`[ALERT DISPATCH] Scanner alert logged for ${stock.symbol}: ${err?.message || err}`);
        }
      }
    }
  }

  // 3. Evaluate Volume Above 20-Day Average across Equities and Indices
  private async evaluate20DayVolumeSurges(quotes: TickerQuote[]) {
    for (const q of quotes) {
      if (!q || !q.symbol) continue;
      const currentVol = q.volume || 0;
      const avg20d = q.avgVolume || 0;

      // Check if current volume is strictly greater than 20-day moving average volume
      if (currentVol > 0 && avg20d > 0 && currentVol > avg20d) {
        const surgePct = ((currentVol - avg20d) / avg20d) * 100;
        
        // Dispatch volume above 20-day average alert (deduplicated per day per symbol inside notifier)
        try {
          await ntfyNotifier.sendVolume20dAvgAlert({
            symbol: q.symbol,
            name: q.name,
            currentPrice: q.price,
            currentVolume: currentVol,
            avgVolume20d: avg20d,
            surgePercent: surgePct,
            sector: q.sector
          });
        } catch (err: any) {
          console.log(`[ALERT DISPATCH] Volume 20D alert logged for ${q.symbol}: ${err?.message || err}`);
        }
      }
    }
  }

  // 4. Evaluate Outstanding Breakouts (Stocks breaking key resistance with high momentum & volume)
  private async evaluateOutstandingBreakouts(quotes: TickerQuote[]) {
    for (const q of quotes) {
      if (!q || !q.symbol || q.symbol.toUpperCase().startsWith('KSE') || q.symbol.toUpperCase().startsWith('KMI')) continue;
      
      const currentPrice = q.price || 0;
      const openPrice = q.open || currentPrice;
      const lastClose = q.previousClose || openPrice;
      const high = q.high || currentPrice;
      const changePct = q.changePercent || 0;
      const volume = q.volume || 0;
      const avgVol = q.avgVolume || 1;

      // Breakout criteria: price up > 2.5%, trading near or above 52-week or 20-day high, volume surge > 1.2x
      const breakoutLevel = q.sma20 ? Math.max(q.sma20 * 1.03, lastClose * 1.025) : lastClose * 1.025;
      const isBreakout = (currentPrice > breakoutLevel) && (changePct >= 2.5) && (volume >= avgVol * 1.2);

      if (isBreakout) {
        try {
          await ntfyNotifier.sendOutstandingBreakoutAlert({
            symbol: q.symbol,
            name: q.name,
            sector: q.sector,
            openPrice,
            lastClosePrice: lastClose,
            breakoutPrice: breakoutLevel,
            currentPrice
          });
        } catch (err: any) {
          console.log(`[ALERT DISPATCH] Breakout alert error for ${q.symbol}: ${err?.message || err}`);
        }
      }
    }
  }

  // 5. Evaluate Critical Bearish Candlestick Patterns
  private async evaluateBearishCandles(quotes: TickerQuote[]) {
    for (const q of quotes) {
      if (!q || !q.symbol || q.symbol.toUpperCase().startsWith('KSE') || q.symbol.toUpperCase().startsWith('KMI')) continue;

      const currentPrice = q.price || 0;
      const openPrice = q.open || currentPrice;
      const high = q.high || currentPrice;
      const low = q.low || currentPrice;
      const changePct = q.changePercent || 0;
      const rsi = q.rsi || 50;

      // Identify major bearish candlestick patterns:
      // 1. Bearish Engulfing: Gap up open above previous close, severe reversal down with large red body
      // 2. Shooting Star / Gravestone: Long upper shadow (> 2x body), closing near low after uptrend
      // 3. Dark Cloud Cover: Opens above high, closes below 50% of body
      let patternName = '';
      let patternSummary = '';

      const bodySize = Math.abs(currentPrice - openPrice);
      const upperWick = high - Math.max(openPrice, currentPrice);
      const lowerWick = Math.min(openPrice, currentPrice) - low;

      if (changePct <= -2.5 && currentPrice < openPrice && (rsi > 60 || currentPrice < (q.sma20 || currentPrice))) {
        patternName = 'Bearish Engulfing';
        patternSummary = 'Heavy institutional distribution breaking below opening demand zone.';
      } else if (upperWick >= 2 * Math.max(bodySize, 0.5) && currentPrice <= openPrice && high > (q.previousClose || openPrice) * 1.015) {
        patternName = 'Shooting Star / Bearish Rejection';
        patternSummary = 'Severe supply rejection at intraday highs with bulls losing control.';
      } else if (changePct <= -3.5) {
        patternName = 'Severe Downside Breakdown';
        patternSummary = 'High-velocity selloff breaking structural intraday supports.';
      }

      if (patternName) {
        try {
          await ntfyNotifier.sendBearishCandleAlert({
            symbol: q.symbol,
            name: q.name,
            sector: q.sector,
            currentPrice,
            patternName,
            patternSummary
          });
        } catch (err: any) {
          console.log(`[ALERT DISPATCH] Bearish candle alert error for ${q.symbol}: ${err?.message || err}`);
        }
      }
    }
  }

  // 6. Evaluate KSE-100 Hourly Closing Alert
  private async evaluateHourlyKse100Close(quotes: TickerQuote[]) {
    const kseQuote = quotes.find(q => q.symbol && q.symbol.toUpperCase().startsWith('KSE100'));
    if (!kseQuote || typeof kseQuote.price !== 'number' || kseQuote.price <= 0) return;

    // Determine current hour in Pakistan Standard Time (PKT, UTC+5)
    const now = new Date();
    const pktHourStr = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Karachi',
      hour: 'numeric',
      hour12: false
    }).format(now);
    const pktMinuteStr = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Karachi',
      minute: 'numeric'
    }).format(now);

    const pktHour = parseInt(pktHourStr, 10);
    const pktMinute = parseInt(pktMinuteStr, 10);

    // Active market evaluation window: 09:00 to 17:00 PKT
    if (pktHour >= 9 && pktHour <= 17) {
      // Fire at top of hour (minutes 0-5) once per hour
      if (pktMinute <= 5 && this.lastHourlyCloseHour !== pktHour) {
        this.lastHourlyCloseHour = pktHour;
        try {
          await ntfyNotifier.sendHourlyIndexCloseAlert({
            indexValue: kseQuote.price,
            changePoints: kseQuote.change || 0
          });
        } catch (err: any) {
          console.log(`[ALERT DISPATCH] Hourly index close alert error: ${err?.message || err}`);
        }
      }
    }
  }

  // 7. Evaluate Day Closing Summary & Top 5 Volume Leaders (Post 16:00 PKT)
  private async evaluateMarketCloseSummaryAndTop5(quotes: TickerQuote[]) {
    const now = new Date();
    const pktHourStr = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Karachi',
      hour: 'numeric',
      hour12: false
    }).format(now);
    const pktHour = parseInt(pktHourStr, 10);

    // Market closes around 15:30 - 16:00 PKT. Trigger daily summary after 16:00 PKT
    if (pktHour >= 16) {
      const kseQuote = quotes.find(q => q.symbol && q.symbol.toUpperCase().startsWith('KSE100'));
      if (kseQuote && typeof kseQuote.price === 'number' && kseQuote.price > 0) {
        try {
          await ntfyNotifier.sendDayClosingSummaryAlert({
            indexPoints: kseQuote.price,
            changePoints: kseQuote.change || 0,
            changePercent: kseQuote.changePercent || 0
          });
        } catch (e: any) {
          console.log(`[ALERT DISPATCH] Day closing summary alert error: ${e?.message || e}`);
        }
      }

      // Sort by volume descending for equities only
      const equities = quotes.filter(q => q && q.symbol && !q.symbol.toUpperCase().startsWith('KSE') && !q.symbol.toUpperCase().startsWith('KMI'));
      equities.sort((a, b) => (b.volume || 0) - (a.volume || 0));
      const top5 = equities.slice(0, 5).map(q => ({
        symbol: q.symbol,
        volume: q.volume || 0,
        price: q.price || 0
      }));

      if (top5.length > 0) {
        try {
          await ntfyNotifier.sendTop5VolumeLeadersAlert(top5);
        } catch (e: any) {
          console.log(`[ALERT DISPATCH] Top 5 volume leaders alert error: ${e?.message || e}`);
        }
      }
    }
  }

  // Trigger a direct test price alert dispatch
  public async dispatchTestPriceAlert(): Promise<any> {
    const record = await ntfyNotifier.sendPriceAlarmAlert({
      symbol: 'OGDC.PSX',
      name: 'Oil & Gas Development Company',
      type: 'PRICE_ABOVE',
      threshold: 165.0,
      currentPrice: 166.5,
      change: 3.5,
      changePercent: 2.15,
      reason: 'Price reached 166.50 (Crossed Target / Resistance: 165.00)',
      spokenMessage: 'Attention! OGDC has broken out above 165 with heavy institutional accumulation.'
    });
    return record;
  }

  // Trigger a direct test 80% scanner signal dispatch
  public async dispatchTest80PctScannerAlert(symbol: string = 'HUBC.PSX'): Promise<any> {
    const selectedIndex = this.db.settings.selectedIndex || 'ALL';
    const indexDef = PSX_INDEX_DEFINITIONS.find(i => i.id === selectedIndex);

    const record = await ntfyNotifier.sendScanRadarAlert({
      symbol,
      name: symbol === 'HUBC.PSX' ? 'Hub Power Company' : symbol.replace('.PSX', ''),
      score: 87,
      price: 134.5,
      change: 4.25,
      changePercent: 3.26,
      volume: 8500000,
      signal: 'STRONG BUY (80%+ Confluence)',
      indexName: indexDef ? indexDef.shortName : 'All PSX',
      logics: [
        '✅ Supertrend Confluence: Green Supertrend Buy Multi-Timeframe',
        '✅ 200 EMA Long-Term Trend: 134.50 >= 118.0 (Strong Structural Uptrend)',
        '✅ Institutional Volume Surge: 8.50M shares traded (> 1.8x 20-Day Average)',
        '✅ Wilder RSI (14) Momentum: RSI 62.4 in optimal bullish expansion zone',
        '✅ MACD Signal Cross: MACD Line 2.45 >= Signal 1.80 (Histogram Expanding +0.65)',
        '✅ VWAP Institutional Anchor: Price 134.50 >= Daily VWAP 132.80',
        '✅ Japanese Candlestick Action: Green solid breakout engulfing bar'
      ],
      entryZone: '133.50 – 135.00',
      targetPrice: 146.0,
      stopLossPrice: 129.5
    });
    return record;
  }

  // Trigger a test 20-day volume surge alert
  public async dispatchTestVolumeSurgeAlert(symbol: string = 'OGDC.PSX'): Promise<any> {
    const record = await ntfyNotifier.sendVolume20dAvgAlert({
      symbol,
      name: 'Oil & Gas Development Company',
      currentVolume: 15420000,
      avgVolume20d: 8120000,
      surgePercent: 89.9,
      sector: 'Oil & Gas Exploration'
    });
    return record;
  }

  // Trigger a test KSE-100 hourly close alert
  public async dispatchTestHourlyIndexAlert(): Promise<any> {
    const record = await ntfyNotifier.sendHourlyIndexCloseAlert({
      indexValue: 114350.25,
      changePoints: 345.50
    });
    return record;
  }

  // Trigger a test outstanding breakout alert
  public async dispatchTestBreakoutAlert(): Promise<any> {
    return ntfyNotifier.dispatchTestAlert('BREAKOUT');
  }

  // Trigger a test bearish candle alert
  public async dispatchTestBearishCandleAlert(): Promise<any> {
    return ntfyNotifier.dispatchTestAlert('BEARISH_CANDLE');
  }

  // Trigger a test day close summary alert
  public async dispatchTestDayCloseSummaryAlert(): Promise<any> {
    return ntfyNotifier.dispatchTestAlert('DAY_CLOSE');
  }

  // Trigger a test top 5 volume leaders alert
  public async dispatchTestTop5VolumeAlert(): Promise<any> {
    return ntfyNotifier.dispatchTestAlert('TOP_5_VOL');
  }
}

export const backgroundAlertEngine = BackgroundAlertEngine.getInstance();
