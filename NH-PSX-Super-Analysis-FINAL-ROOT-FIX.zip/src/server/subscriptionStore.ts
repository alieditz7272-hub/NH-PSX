import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { 
  UserProfile, 
  SubscriptionRecord, 
  PaymentRecord, 
  AuditLog, 
  AdminMetrics, 
  SubscriberDetail,
  RevenueBreakdown,
  GuestUserRecord,
  SubscriptionPlanType, 
  PaymentMethodType, 
  PaymentStatus,
  SubscriptionStatus,
  PLAN_CONFIGS
} from '../types/subscription';
import { ntfyNotifier } from './ntfyNotifier';

// Cryptographic Password Hashing & Timing-Safe Verification
export function hashPassword(password: string, salt?: string): string {
  const userSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, userSalt, 10000, 64, 'sha256').toString('hex');
  return `pbkdf2$${userSalt}$${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash || typeof storedHash !== 'string') return false;
  if (storedHash.startsWith('pbkdf2$')) {
    const parts = storedHash.split('$');
    if (parts.length === 3) {
      const salt = parts[1];
      const expectedHash = parts[2];
      const testHash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha256').toString('hex');
      try {
        const testBuf = Buffer.from(testHash, 'hex');
        const expBuf = Buffer.from(expectedHash, 'hex');
        if (testBuf.length !== expBuf.length) return false;
        return crypto.timingSafeEqual(testBuf, expBuf);
      } catch {
        return false;
      }
    }
  }
  // Legacy plaintext fallback
  return storedHash === password;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'subscription_store.json');

interface DatabaseSchema {
  users: Record<string, UserProfile & { passwordHash: string }>;
  subscriptions: Record<string, SubscriptionRecord>;
  payments: Record<string, PaymentRecord>;
  auditLogs: AuditLog[];
  sessions: Record<string, { userId: string; createdAt: number; expiresAt: number }>;
}

class SubscriptionStore {
  private db: DatabaseSchema = {
    users: {},
    subscriptions: {},
    payments: {},
    auditLogs: [],
    sessions: {}
  };

  constructor() {
    this.init();
  }

  private init() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.db = JSON.parse(raw);
        // Automatic security migration: upgrade any legacy plaintext password to salted PBKDF2
        let upgraded = false;
        if (this.db.users) {
          for (const u of Object.values(this.db.users)) {
            if (u.passwordHash && !u.passwordHash.startsWith('pbkdf2$')) {
              u.passwordHash = hashPassword(u.passwordHash);
              upgraded = true;
            }
          }
        }
        if (upgraded) {
          this.save();
        }
      } else {
        this.seedDefaultAdmin();
        this.save();
      }
    } catch (e) {
      console.warn('Could not load subscription store from disk, initializing fresh in-memory db', e);
      this.seedDefaultAdmin();
    }
  }

  private save() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(this.db, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to save subscription store to disk', e);
    }
  }

  private seedDefaultAdmin() {
    const adminId = 'user_admin_nadeem';
    if (!this.db.users[adminId]) {
      this.db.users[adminId] = {
        id: adminId,
        name: 'Nadeem Hassan (Admin)',
        email: 'nadeemhassan@nhtrading.pk',
        phone: '03009412177',
        role: 'ADMIN',
        accountState: 'ACTIVE_SUBSCRIBER',
        subscriptionStatus: 'ACTIVE',
        plan: 'YEARLY',
        createdAt: Date.now(),
        passwordHash: hashPassword('nhpro2026') // Salted PBKDF2 hash
      };

      // Admin has permanent master active subscription
      const subId = 'sub_admin_master';
      const now = Date.now();
      const tenYearsLater = now + 10 * 365 * 24 * 60 * 60 * 1000;
      this.db.subscriptions[subId] = {
        subscriptionId: subId,
        userId: adminId,
        userName: 'Nadeem Hassan (Admin)',
        userEmail: 'nadeemhassan@nhtrading.pk',
        userPhone: '03009412177',
        plan: 'YEARLY',
        status: 'ACTIVE',
        startDate: now,
        expiryDate: tenYearsLater,
        paymentId: 'pay_master_init',
        daysRemaining: 3650,
        isExpiringSoon: false,
        createdAt: now,
        updatedAt: now
      };
      this.db.users[adminId].activeSubscriptionId = subId;

      this.logAudit('SYSTEM_INIT', 'Default Admin and NH Trading Master records initialized', 'SYSTEM');
    }
  }

  public logAudit(
    action: string, 
    details: string, 
    performedBy: string, 
    userId?: string, 
    paymentId?: string,
    previousStatus?: string,
    newStatus?: string,
    adminNote?: string
  ) {
    const log: AuditLog = {
      id: 'log_' + Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
      action,
      details,
      performedBy,
      userId,
      paymentId,
      previousStatus,
      newStatus,
      adminNote
    };
    this.db.auditLogs.unshift(log);
    // Keep last 500 audit logs
    if (this.db.auditLogs.length > 500) {
      this.db.auditLogs = this.db.auditLogs.slice(0, 500);
    }
    this.save();
  }

  // Register a new user
  public registerUser(name: string, email: string, phone: string, password: string): { user: UserProfile; token: string } {
    const cleanEmail = email.trim().toLowerCase();
    const existing = Object.values(this.db.users).find(u => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      throw new Error('An account with this email address already exists. Please login.');
    }

    const userId = 'usr_' + crypto.randomBytes(16).toString('hex');
    const user: UserProfile & { passwordHash: string } = {
      id: userId,
      name: name.trim(),
      email: cleanEmail,
      phone: phone.trim(),
      role: 'USER',
      accountState: 'PAYMENT_REQUIRED',
      subscriptionStatus: 'NONE',
      createdAt: Date.now(),
      passwordHash: hashPassword(password)
    };

    this.db.users[userId] = user;
    const token = this.createSession(userId);
    this.logAudit('USER_REGISTERED', `New user registered: ${user.name} (${user.email})`, user.name, userId);
    this.save();

    const { passwordHash, ...profile } = user;
    return { user: profile, token };
  }

  // Login user (supports Email, Username, or Phone)
  public loginUser(emailOrPhoneOrUsername: string, password: string): { user: UserProfile; token: string } {
    const cleanInput = emailOrPhoneOrUsername.trim().toLowerCase();
    const user = Object.values(this.db.users).find(
      u => u.email.toLowerCase() === cleanInput || 
           u.phone.trim() === emailOrPhoneOrUsername.trim() ||
           (u.username && u.username.toLowerCase() === cleanInput) ||
           (u.role === 'ADMIN' && (
             cleanInput === 'admin' || 
             cleanInput === 'nadeemhassan' || 
             cleanInput === 'mnadeemhassan@gmail.com'
           ))
    );

    if (!user || !verifyPassword(password, user.passwordHash)) {
      throw new Error('Invalid username/email, phone number, or password.');
    }

    // Transparent security upgrade: upgrade legacy plaintext passwords to salted PBKDF2
    if (!user.passwordHash.startsWith('pbkdf2$')) {
      user.passwordHash = hashPassword(password);
    }

    // Refresh user state
    this.syncUserSubscriptionState(user.id);
    const refreshed = this.db.users[user.id];
    const token = this.createSession(user.id);

    this.logAudit('USER_LOGIN', `User logged in: ${user.name}`, user.name, user.id);
    this.save();

    // Trigger instant ntfy push alert to Admin Nadeem Hassan
    try {
      ntfyNotifier.sendUserLoginAlert(refreshed);
    } catch (ntfyErr) {
      console.warn('Failed to dispatch ntfy login alert:', ntfyErr);
    }

    const { passwordHash, ...profile } = refreshed;
    return { user: profile, token };
  }

  // Session handling with 256-bit cryptographic entropy
  public createSession(userId: string): string {
    const token = 'sess_' + crypto.randomBytes(32).toString('hex');
    const now = Date.now();
    this.db.sessions[token] = {
      userId,
      createdAt: now,
      expiresAt: now + 30 * 24 * 60 * 60 * 1000 // 30 days valid
    };
    this.save();
    return token;
  }

  public getUserByToken(token: string): UserProfile | null {
    if (!token) return null;
    const session = this.db.sessions[token];
    if (!session || Date.now() > session.expiresAt) {
      return null;
    }
    const user = this.db.users[session.userId];
    if (!user) return null;

    this.syncUserSubscriptionState(user.id);
    const refreshed = this.db.users[user.id];
    const { passwordHash, ...profile } = refreshed;
    return profile;
  }

  public getUserById(userId: string): UserProfile | null {
    if (!userId) return null;
    const user = this.db.users[userId];
    if (!user) return null;
    this.syncUserSubscriptionState(user.id);
    const refreshed = this.db.users[user.id];
    const { passwordHash, ...profile } = refreshed;
    return profile;
  }

  public logout(token: string): { user?: UserProfile } {
    if (token && this.db.sessions[token]) {
      const session = this.db.sessions[token];
      const user = this.db.users[session.userId];
      delete this.db.sessions[token];

      if (user) {
        this.logAudit('USER_LOGOUT', `User logged out: ${user.name} (${user.username || user.email})`, user.name, user.id);
        
        // Trigger instant ntfy push alert to Admin Nadeem Hassan
        try {
          const { passwordHash, ...cleanProfile } = user;
          ntfyNotifier.sendUserLogoutAlert(cleanProfile);
        } catch (ntfyErr) {
          console.warn('Failed to dispatch ntfy logout alert:', ntfyErr);
        }
      }

      this.save();
      return { user: user ? { ...user } : undefined };
    }
    return {};
  }

  // Sync user state and evaluate active/expired subscriptions
  public syncUserSubscriptionState(userId: string): void {
    const user = this.db.users[userId];
    if (!user) return;

    if (user.role === 'ADMIN') {
      user.subscriptionStatus = 'ACTIVE';
      user.accountState = 'ACTIVE_SUBSCRIBER';
      return;
    }

    // Find all user subscriptions
    const userSubs = Object.values(this.db.subscriptions)
      .filter(s => s.userId === userId)
      .sort((a, b) => b.expiryDate - a.expiryDate);

    const now = Date.now();
    const activeSub = userSubs.find(s => s.status === 'ACTIVE' && s.expiryDate > now);

    if (activeSub) {
      const daysRemaining = Math.max(0, Math.ceil((activeSub.expiryDate - now) / (1000 * 60 * 60 * 24)));
      activeSub.daysRemaining = daysRemaining;
      activeSub.isExpiringSoon = daysRemaining <= 7;
      user.subscriptionStatus = 'ACTIVE';
      user.plan = activeSub.plan;
      user.activeSubscriptionId = activeSub.subscriptionId;
      user.accountState = daysRemaining <= 7 ? 'SUBSCRIPTION_EXPIRING' : 'ACTIVE_SUBSCRIBER';
      return;
    }

    // Check if there is an expired subscription
    const expiredSub = userSubs.find(s => s.status === 'ACTIVE' && s.expiryDate <= now);
    if (expiredSub) {
      expiredSub.status = 'EXPIRED';
      expiredSub.daysRemaining = 0;
      expiredSub.isExpiringSoon = false;
      user.subscriptionStatus = 'EXPIRED';
      user.accountState = 'SUBSCRIPTION_EXPIRED';
      return;
    }

    // Check if user has any pending payments
    const userPayments = Object.values(this.db.payments).filter(p => p.userId === userId);
    const hasPending = userPayments.some(p => p.status === 'PENDING');
    if (hasPending) {
      user.subscriptionStatus = 'PENDING';
      user.accountState = 'PAYMENT_PENDING';
      return;
    }

    const hasRejected = userPayments.some(p => p.status === 'REJECTED');
    if (hasRejected) {
      user.subscriptionStatus = 'NONE';
      user.accountState = 'PAYMENT_REJECTED';
      return;
    }

    user.subscriptionStatus = 'NONE';
    user.accountState = 'PAYMENT_REQUIRED';
  }

  // Submit a new manual payment
  public submitPayment(
    userId: string,
    params: {
      plan: SubscriptionPlanType;
      paymentMethod: PaymentMethodType;
      amount: number;
      transactionId: string;
      paymentDate: string;
      screenshotData?: string;
      screenshotName?: string;
      notes?: string;
      fullName?: string;
      email?: string;
      phone?: string;
    }
  ): PaymentRecord {
    const user = this.db.users[userId];
    if (!user) {
      throw new Error('User not found. Please log in.');
    }

    // 1. Strict Plan Amount Validation
    const expectedAmount = PLAN_CONFIGS[params.plan].price;
    if (Number(params.amount) !== expectedAmount) {
      throw new Error(`Payment amount does not match the selected plan. (Selected plan ${params.plan} requires exact ${expectedAmount.toFixed(2).replace(/,/g, '')})`);
    }

    // 2. Duplicate Transaction ID check
    const cleanTxId = params.transactionId.trim();
    if (!cleanTxId) {
      throw new Error('Transaction ID / Reference Number is required.');
    }

    const duplicateTx = Object.values(this.db.payments).find(
      p => p.transactionId.toLowerCase() === cleanTxId.toLowerCase() && p.status !== 'REJECTED'
    );
    if (duplicateTx) {
      throw new Error(`Transaction ID "${cleanTxId}" has already been submitted. Please check your payment history or contact support.`);
    }

    const paymentId = 'pay_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
    const payment: PaymentRecord = {
      paymentId,
      userId: user.id,
      userName: params.fullName || user.name,
      userEmail: params.email || user.email,
      userPhone: params.phone || user.phone,
      plan: params.plan,
      amount: expectedAmount,
      currency: 'PKR',
      paymentMethod: params.paymentMethod,
      transactionId: cleanTxId,
      paymentDate: params.paymentDate || new Date().toISOString().split('T')[0],
      screenshotData: params.screenshotData,
      screenshotName: params.screenshotName,
      notes: params.notes?.trim() || '',
      status: 'PENDING',
      submittedAt: Date.now()
    };

    this.db.payments[paymentId] = payment;
    this.syncUserSubscriptionState(userId);
    this.logAudit('PAYMENT_SUBMITTED', `Payment submitted: ${payment.plan} (${Number(payment.amount).toFixed(2).replace(/,/g, '')}) via ${payment.paymentMethod} (Tx: ${payment.transactionId})`, user.name, user.id, paymentId);
    this.save();

    return payment;
  }

  // Admin: Get all payments with filtering & search
  public getAdminPayments(filters: {
    status?: string;
    plan?: string;
    method?: string;
    search?: string;
  }): PaymentRecord[] {
    let list = Object.values(this.db.payments);

    if (filters.status && filters.status !== 'ALL') {
      list = list.filter(p => p.status === filters.status);
    }
    if (filters.plan && filters.plan !== 'ALL') {
      list = list.filter(p => p.plan === filters.plan);
    }
    if (filters.method && filters.method !== 'ALL') {
      list = list.filter(p => p.paymentMethod === filters.method);
    }
    if (filters.search) {
      const q = filters.search.toLowerCase().trim();
      list = list.filter(p => 
        p.userName.toLowerCase().includes(q) ||
        p.userEmail.toLowerCase().includes(q) ||
        p.userPhone.toLowerCase().includes(q) ||
        p.transactionId.toLowerCase().includes(q) ||
        p.paymentId.toLowerCase().includes(q)
      );
    }

    return list.sort((a, b) => b.submittedAt - a.submittedAt);
  }

  // Admin: Approve a payment and activate/extend subscription
  public approvePayment(paymentId: string, adminUserId: string, adminNotes?: string): { payment: PaymentRecord; subscription: SubscriptionRecord } {
    const payment = this.db.payments[paymentId];
    if (!payment) {
      throw new Error('Payment record not found.');
    }
    if (payment.status === 'APPROVED') {
      throw new Error('This payment is already approved.');
    }

    const user = this.db.users[payment.userId];
    if (!user) {
      throw new Error('User associated with this payment not found.');
    }

    const admin = this.db.users[adminUserId];
    const adminName = admin ? admin.name : 'Admin';

    const now = Date.now();
    payment.status = 'APPROVED';
    payment.reviewedAt = now;
    payment.reviewedBy = adminName;
    if (adminNotes) {
      payment.adminNotes = adminNotes;
    }

    // Dynamic Expiry Calculation:
    // Monthly = 1 month (approx 30 days or exact next month)
    // Yearly = 12 months (365 days)
    const isMonthly = payment.plan === 'MONTHLY';
    const durationMs = isMonthly ? 30 * 24 * 60 * 60 * 1000 : 365 * 24 * 60 * 60 * 1000;

    // Check for early renewal (if user already has an active subscription)
    const existingSub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
    let startDate = now;
    let expiryDate = now + durationMs;

    if (existingSub && existingSub.status === 'ACTIVE' && existingSub.expiryDate > now) {
      // Extend existing expiry date
      startDate = existingSub.startDate;
      expiryDate = existingSub.expiryDate + durationMs;
      existingSub.expiryDate = expiryDate;
      existingSub.updatedAt = now;
      existingSub.paymentId = payment.paymentId;
      existingSub.plan = payment.plan;
      this.db.subscriptions[existingSub.subscriptionId] = existingSub;
    } else {
      const subId = 'sub_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
      const newSub: SubscriptionRecord = {
        subscriptionId: subId,
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        userPhone: user.phone,
        plan: payment.plan,
        status: 'ACTIVE',
        startDate,
        expiryDate,
        paymentId: payment.paymentId,
        daysRemaining: Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24)),
        isExpiringSoon: false,
        createdAt: now,
        updatedAt: now
      };
      this.db.subscriptions[subId] = newSub;
      user.activeSubscriptionId = subId;
    }

    payment.activationDate = startDate;
    payment.expiryDate = expiryDate;

    this.syncUserSubscriptionState(user.id);
    this.logAudit(
      'PAYMENT_APPROVED', 
      `Approved payment ${payment.paymentId} for ${user.name} (${payment.plan} - ${Number(payment.amount).toFixed(2).replace(/,/g, '')}). Subscription active until ${new Date(expiryDate).toLocaleDateString()}`, 
      adminName, 
      user.id, 
      payment.paymentId
    );
    this.save();

    const activeSub = this.db.subscriptions[user.activeSubscriptionId!];
    return { payment, subscription: activeSub };
  }

  // Admin: Reject payment
  public rejectPayment(paymentId: string, adminUserId: string, reason: string, adminNotes?: string): PaymentRecord {
    const payment = this.db.payments[paymentId];
    if (!payment) {
      throw new Error('Payment record not found.');
    }

    const admin = this.db.users[adminUserId];
    const adminName = admin ? admin.name : 'Admin';

    payment.status = 'REJECTED';
    payment.reviewedAt = Date.now();
    payment.reviewedBy = adminName;
    payment.rejectionReason = reason || 'Payment verify nahi ho saki. Please check transaction ID or contact support.';
    if (adminNotes) {
      payment.adminNotes = adminNotes;
    }

    this.syncUserSubscriptionState(payment.userId);
    this.logAudit('PAYMENT_REJECTED', `Rejected payment ${paymentId} for ${payment.userName}. Reason: ${payment.rejectionReason}`, adminName, payment.userId, paymentId);
    this.save();

    return payment;
  }

  // Admin: Save internal notes
  public updateAdminNotes(paymentId: string, notes: string): PaymentRecord {
    const payment = this.db.payments[paymentId];
    if (!payment) {
      throw new Error('Payment not found');
    }
    payment.adminNotes = notes;
    this.save();
    return payment;
  }

  // Admin Metrics Calculation (Strictly APPROVED payments for Revenue)
  public getAdminMetrics(): AdminMetrics {
    const users = Object.values(this.db.users);
    const payments = Object.values(this.db.payments);
    const subscriptions = Object.values(this.db.subscriptions);

    const totalUsers = users.length;
    const now = Date.now();

    const activeSubscribers = subscriptions.filter(s => s.status === 'ACTIVE' && s.expiryDate > now).length;
    const expiredSubscriptions = subscriptions.filter(s => s.status === 'EXPIRED' || (s.status === 'ACTIVE' && s.expiryDate <= now)).length;

    const pendingPaymentsList = payments.filter(p => p.status === 'PENDING');
    const pendingPayments = pendingPaymentsList.length;
    const pendingRevenue = pendingPaymentsList.reduce((acc, p) => acc + p.amount, 0);

    const approvedPaymentsList = payments.filter(p => p.status === 'APPROVED');
    const totalApprovedPayments = approvedPaymentsList.length;
    const rejectedPayments = payments.filter(p => p.status === 'REJECTED').length;

    // Monthly vs Yearly subscribers
    const monthlySubscribers = subscriptions.filter(s => s.status === 'ACTIVE' && s.expiryDate > now && s.plan === 'MONTHLY').length;
    const yearlySubscribers = subscriptions.filter(s => s.status === 'ACTIVE' && s.expiryDate > now && s.plan === 'YEARLY').length;

    // Revenue calculations (APPROVED ONLY)
    const monthlyRevenue = approvedPaymentsList.filter(p => p.plan === 'MONTHLY').reduce((acc, p) => acc + p.amount, 0);
    const yearlyRevenue = approvedPaymentsList.filter(p => p.plan === 'YEARLY').reduce((acc, p) => acc + p.amount, 0);
    const totalRevenue = monthlyRevenue + yearlyRevenue;

    return {
      totalUsers,
      activeSubscribers,
      pendingPayments,
      expiredSubscriptions,
      monthlySubscribers,
      yearlySubscribers,
      totalApprovedPayments,
      totalRevenue,
      pendingRevenue,
      rejectedPayments,
      monthlyRevenue,
      yearlyRevenue
    };
  }

  // Get detailed subscribers list for Admin
  public getSubscribersList(): SubscriberDetail[] {
    const users = Object.values(this.db.users);
    const now = Date.now();

    return users.map(user => {
      this.syncUserSubscriptionState(user.id);
      const sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
      const userPayments = Object.values(this.db.payments)
        .filter(p => p.userId === user.id)
        .sort((a, b) => b.submittedAt - a.submittedAt);
      
      const lastPayment = userPayments[0] ? {
        paymentId: userPayments[0].paymentId,
        amount: userPayments[0].amount,
        paymentMethod: userPayments[0].paymentMethod,
        transactionId: userPayments[0].transactionId,
        paymentDate: userPayments[0].paymentDate,
        submittedAt: userPayments[0].submittedAt,
        status: userPayments[0].status
      } : undefined;

      const daysRemaining = sub && sub.status === 'ACTIVE' && sub.expiryDate > now
        ? Math.ceil((sub.expiryDate - now) / (1000 * 60 * 60 * 24))
        : 0;

      return {
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        userPhone: user.phone,
        role: user.role,
        accountState: user.accountState,
        subscriptionStatus: user.subscriptionStatus,
        plan: sub?.plan || user.plan,
        subscriptionId: sub?.subscriptionId,
        startDate: sub?.startDate,
        expiryDate: sub?.expiryDate,
        daysRemaining,
        isExpiringSoon: daysRemaining > 0 && daysRemaining <= 7,
        lastPayment
      };
    }).sort((a, b) => {
      // Sort admins and active subscribers first
      if (a.role === 'ADMIN') return -1;
      if (b.role === 'ADMIN') return 1;
      if (a.subscriptionStatus === 'ACTIVE' && b.subscriptionStatus !== 'ACTIVE') return -1;
      if (b.subscriptionStatus === 'ACTIVE' && a.subscriptionStatus !== 'ACTIVE') return 1;
      return (b.expiryDate || 0) - (a.expiryDate || 0);
    });
  }

  // Admin: Manually extend subscription
  public extendSubscription(userId: string, additionalDays: number, adminName: string, adminNotes?: string): SubscriptionRecord {
    const user = this.db.users[userId];
    if (!user) {
      throw new Error('User not found.');
    }

    const now = Date.now();
    const durationMs = additionalDays * 24 * 60 * 60 * 1000;
    let sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;

    const prevStatus = sub ? sub.status : 'NONE';

    if (sub && sub.expiryDate > now) {
      // Extend current active subscription
      sub.expiryDate += durationMs;
      sub.status = 'ACTIVE';
      sub.updatedAt = now;
      sub.daysRemaining = Math.ceil((sub.expiryDate - now) / (1000 * 60 * 60 * 24));
    } else if (sub) {
      // Re-activate existing expired subscription starting now
      sub.startDate = now;
      sub.expiryDate = now + durationMs;
      sub.status = 'ACTIVE';
      sub.updatedAt = now;
      sub.daysRemaining = additionalDays;
    } else {
      // Create new subscription record
      const subId = 'sub_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
      sub = {
        subscriptionId: subId,
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        userPhone: user.phone,
        plan: user.plan || 'MONTHLY',
        status: 'ACTIVE',
        startDate: now,
        expiryDate: now + durationMs,
        paymentId: 'manual_admin_grant',
        daysRemaining: additionalDays,
        isExpiringSoon: false,
        createdAt: now,
        updatedAt: now
      };
      this.db.subscriptions[subId] = sub;
      user.activeSubscriptionId = subId;
    }

    this.syncUserSubscriptionState(userId);
    this.logAudit(
      'SUBSCRIPTION_EXTENDED',
      `Extended subscription for ${user.name} by +${additionalDays} days. New expiry: ${new Date(sub.expiryDate).toLocaleDateString()}`,
      adminName,
      userId,
      undefined,
      prevStatus,
      'ACTIVE',
      adminNotes
    );
    this.save();

    return sub;
  }

  // Admin: Suspend subscription
  public suspendSubscription(userId: string, adminName: string, reason?: string): { success: boolean; message: string } {
    const user = this.db.users[userId];
    if (!user) {
      throw new Error('User not found.');
    }
    if (user.role === 'ADMIN') {
      throw new Error('Master Admin account cannot be suspended.');
    }

    const sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
    const prevStatus = sub ? sub.status : 'NONE';
    if (sub) {
      sub.status = 'CANCELLED';
      sub.updatedAt = Date.now();
    }
    user.subscriptionStatus = 'CANCELLED';
    user.accountState = 'PAYMENT_REQUIRED';

    this.logAudit(
      'SUBSCRIPTION_SUSPENDED',
      `Suspended subscription for ${user.name}. Reason: ${reason || 'Admin action'}`,
      adminName,
      userId,
      undefined,
      prevStatus,
      'CANCELLED',
      reason
    );
    this.save();

    return { success: true, message: `Subscription for ${user.name} has been suspended.` };
  }

  // Admin: Reactivate subscription
  public reactivateSubscription(userId: string, adminName: string, adminNotes?: string): SubscriptionRecord {
    const user = this.db.users[userId];
    if (!user) {
      throw new Error('User not found.');
    }

    const now = Date.now();
    let sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
    const prevStatus = sub ? sub.status : 'NONE';

    if (sub) {
      sub.status = 'ACTIVE';
      if (sub.expiryDate <= now) {
        sub.expiryDate = now + 30 * 24 * 60 * 60 * 1000; // default 30 days
      }
      sub.updatedAt = now;
      sub.daysRemaining = Math.ceil((sub.expiryDate - now) / (1000 * 60 * 60 * 24));
    } else {
      const subId = 'sub_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
      sub = {
        subscriptionId: subId,
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        userPhone: user.phone,
        plan: 'MONTHLY',
        status: 'ACTIVE',
        startDate: now,
        expiryDate: now + 30 * 24 * 60 * 60 * 1000,
        paymentId: 'manual_reactivation',
        daysRemaining: 30,
        isExpiringSoon: false,
        createdAt: now,
        updatedAt: now
      };
      this.db.subscriptions[subId] = sub;
      user.activeSubscriptionId = subId;
    }

    this.syncUserSubscriptionState(userId);
    this.logAudit(
      'SUBSCRIPTION_REACTIVATED',
      `Reactivated subscription for ${user.name}. Expiry date: ${new Date(sub.expiryDate).toLocaleDateString()}`,
      adminName,
      userId,
      undefined,
      prevStatus,
      'ACTIVE',
      adminNotes
    );
    this.save();

    return sub;
  }

  // Admin: Get Detailed Revenue Breakdown
  public getDetailedRevenue(): RevenueBreakdown {
    const payments = Object.values(this.db.payments);

    const approvedList = payments.filter(p => p.status === 'APPROVED');
    const pendingList = payments.filter(p => p.status === 'PENDING');
    const rejectedList = payments.filter(p => p.status === 'REJECTED');

    const totalApprovedRevenue = approvedList.reduce((acc, p) => acc + p.amount, 0);
    const monthlyRevenue = approvedList.filter(p => p.plan === 'MONTHLY').reduce((acc, p) => acc + p.amount, 0);
    const yearlyRevenue = approvedList.filter(p => p.plan === 'YEARLY').reduce((acc, p) => acc + p.amount, 0);

    const approvedEasypaisaRevenue = approvedList.filter(p => p.paymentMethod === 'EASYPAISA').reduce((acc, p) => acc + p.amount, 0);
    const approvedBankTransferRevenue = approvedList.filter(p => p.paymentMethod === 'BANK_TRANSFER').reduce((acc, p) => acc + p.amount, 0);

    const pendingAmount = pendingList.reduce((acc, p) => acc + p.amount, 0);
    const rejectedAmount = rejectedList.reduce((acc, p) => acc + p.amount, 0);

    return {
      totalApprovedRevenue,
      monthlyRevenue,
      yearlyRevenue,
      approvedEasypaisaRevenue,
      approvedBankTransferRevenue,
      pendingAmount,
      rejectedAmount
    };
  }

  public getUserPayments(userId: string): PaymentRecord[] {
    return Object.values(this.db.payments)
      .filter(p => p.userId === userId)
      .sort((a, b) => b.submittedAt - a.submittedAt);
  }

  public getUserSubscription(userId: string): SubscriptionRecord | null {
    this.syncUserSubscriptionState(userId);
    const user = this.db.users[userId];
    if (!user || !user.activeSubscriptionId) return null;
    return this.db.subscriptions[user.activeSubscriptionId] || null;
  }

  public getAuditLogs(): AuditLog[] {
    return this.db.auditLogs.slice(0, 150);
  }

  // =========================================================================
  // GUEST USERNAME & PASSWORD MANAGEMENT (Easy Create, Delete, VIP Free Access)
  // =========================================================================

  // Admin: Get all Guest Users
  public getGuestUsers(): GuestUserRecord[] {
    const users = Object.values(this.db.users).filter(u => u.isGuest);
    const now = Date.now();

    return users.map(user => {
      this.syncUserSubscriptionState(user.id);
      const sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
      const daysRemaining = sub && sub.status === 'ACTIVE' && sub.expiryDate > now
        ? Math.ceil((sub.expiryDate - now) / (1000 * 60 * 60 * 24))
        : 0;

      return {
        id: user.id,
        name: user.name,
        username: user.username || user.email,
        email: user.email,
        password: user.plainPasswordHint || user.passwordHash || '',
        phone: user.phone,
        role: user.role,
        accountState: user.accountState,
        subscriptionStatus: user.subscriptionStatus,
        plan: sub?.plan || user.plan || 'YEARLY',
        subscriptionId: sub?.subscriptionId,
        startDate: sub?.startDate || user.createdAt,
        expiryDate: sub?.expiryDate || (user.createdAt + 10 * 365 * 24 * 60 * 60 * 1000),
        daysRemaining: daysRemaining || 3650,
        isExpiringSoon: false,
        createdAt: user.createdAt,
        notes: user.guestNotes || '',
        relationTag: (user as any).relationTag || 'Family Member',
        createdByAdmin: (user as any).createdByAdmin || 'Nadeem Hassan (Admin)',
        isActive: user.subscriptionStatus === 'ACTIVE'
      };
    }).sort((a, b) => b.createdAt - a.createdAt);
  }

  // Admin: Create a new Guest Account with instant free access (No Payment Required)
  public createGuestUser(params: {
    name: string;
    username: string;
    password: string;
    phone?: string;
    notes?: string;
    relationTag?: 'Family Member' | 'Close Friend' | 'VIP Colleague' | 'VIP Trader' | 'General Guest';
    durationDays?: number; // default 3650 days (10 years / permanent)
    adminName: string;
  }): GuestUserRecord {
    const cleanUsername = params.username.trim().toLowerCase().replace(/\s+/g, '_');
    const cleanName = params.name.trim();
    const cleanPassword = params.password.trim();

    if (!cleanUsername || cleanUsername.length < 3) {
      throw new Error('Username must be at least 3 characters long.');
    }
    if (!cleanPassword || cleanPassword.length < 4) {
      throw new Error('Password must be at least 4 characters long.');
    }

    // Check if username or email already taken
    const existing = Object.values(this.db.users).find(
      u => (u.username && u.username.toLowerCase() === cleanUsername) ||
           u.email.toLowerCase() === cleanUsername ||
           u.email.toLowerCase() === `${cleanUsername}@guest.nhtrading.pk`
    );
    if (existing) {
      throw new Error(`Username "${cleanUsername}" is already in use. Please choose another username.`);
    }

    const userId = 'usr_guest_' + crypto.randomBytes(12).toString('hex');
    const now = Date.now();
    const durationDays = params.durationDays && params.durationDays > 0 ? params.durationDays : 3650; // Default 10 years
    const expiryDate = now + durationDays * 24 * 60 * 60 * 1000;

    const email = cleanUsername.includes('@') ? cleanUsername : `${cleanUsername}@guest.nhtrading.pk`;

    const user: UserProfile & { passwordHash: string; relationTag?: string; createdByAdmin?: string } = {
      id: userId,
      name: cleanName,
      username: cleanUsername,
      email,
      phone: params.phone?.trim() || '03000000000',
      role: 'USER',
      accountState: 'ACTIVE_SUBSCRIBER',
      subscriptionStatus: 'ACTIVE',
      plan: 'YEARLY',
      createdAt: now,
      passwordHash: hashPassword(cleanPassword),
      isGuest: true,
      guestNotes: params.notes?.trim() || '',
      plainPasswordHint: cleanPassword,
      relationTag: params.relationTag || 'Family Member',
      createdByAdmin: params.adminName || 'Nadeem Hassan (Admin)'
    };

    // Create immediate active VIP guest subscription
    const subId = 'sub_guest_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
    const subscription: SubscriptionRecord = {
      subscriptionId: subId,
      userId,
      userName: cleanName,
      userEmail: email,
      userPhone: user.phone,
      plan: 'YEARLY',
      status: 'ACTIVE',
      startDate: now,
      expiryDate,
      paymentId: 'guest_admin_grant',
      daysRemaining: durationDays,
      isExpiringSoon: false,
      createdAt: now,
      updatedAt: now
    };

    user.activeSubscriptionId = subId;
    this.db.users[userId] = user;
    this.db.subscriptions[subId] = subscription;

    this.logAudit(
      'GUEST_USER_CREATED',
      `Created free VIP Guest access for "${cleanName}" (Username: ${cleanUsername}). Granted ${durationDays} days active access.`,
      params.adminName || 'Admin',
      userId,
      subId,
      'NONE',
      'ACTIVE',
      params.notes
    );
    this.save();

    return {
      id: user.id,
      name: user.name,
      username: cleanUsername,
      email: user.email,
      password: cleanPassword,
      phone: user.phone,
      role: user.role,
      accountState: user.accountState,
      subscriptionStatus: user.subscriptionStatus,
      plan: 'YEARLY',
      subscriptionId: subId,
      startDate: now,
      expiryDate,
      daysRemaining: durationDays,
      isExpiringSoon: false,
      createdAt: now,
      notes: user.guestNotes,
      relationTag: params.relationTag || 'Family Member',
      createdByAdmin: params.adminName,
      isActive: true
    };
  }

  // Admin: Delete a Guest User (Revokes access and deletes user & subscriptions immediately)
  public deleteGuestUser(userId: string, adminName: string): { success: boolean; message: string } {
    const user = this.db.users[userId];
    if (!user) {
      throw new Error('Guest user not found or already deleted.');
    }
    if (user.role === 'ADMIN') {
      throw new Error('Master Admin account cannot be deleted.');
    }

    const userName = user.name;
    const username = user.username || user.email;

    // 1. Invalidate and delete all active sessions for this user
    for (const [token, sess] of Object.entries(this.db.sessions)) {
      if (sess.userId === userId) {
        delete this.db.sessions[token];
      }
    }

    // 2. Remove all user subscriptions
    for (const [subId, sub] of Object.entries(this.db.subscriptions)) {
      if (sub.userId === userId) {
        delete this.db.subscriptions[subId];
      }
    }

    // 3. Remove user record
    delete this.db.users[userId];

    this.logAudit(
      'GUEST_USER_DELETED',
      `Deleted guest user "${userName}" (Username: ${username}). Access revoked and user purged.`,
      adminName || 'Admin',
      userId,
      undefined,
      'ACTIVE',
      'DELETED'
    );
    this.save();

    return { 
      success: true, 
      message: `Guest user "${userName}" (${username}) has been permanently deleted and their access has been revoked.` 
    };
  }

  // Admin: Update Guest User credentials or details
  public updateGuestUser(userId: string, updates: {
    name?: string;
    password?: string;
    notes?: string;
    relationTag?: 'Family Member' | 'Close Friend' | 'VIP Colleague' | 'VIP Trader' | 'General Guest';
    durationDays?: number;
  }, adminName: string): GuestUserRecord {
    const user = this.db.users[userId];
    if (!user) {
      throw new Error('Guest user not found.');
    }

    if (updates.name && updates.name.trim()) {
      user.name = updates.name.trim();
    }
    if (updates.password && updates.password.trim()) {
      user.passwordHash = hashPassword(updates.password.trim());
      user.plainPasswordHint = updates.password.trim();
    }
    if (updates.notes !== undefined) {
      user.guestNotes = updates.notes.trim();
    }
    if (updates.relationTag) {
      (user as any).relationTag = updates.relationTag;
    }

    if (updates.durationDays && updates.durationDays > 0) {
      const now = Date.now();
      const sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
      if (sub) {
        sub.expiryDate = now + updates.durationDays * 24 * 60 * 60 * 1000;
        sub.daysRemaining = updates.durationDays;
        sub.status = 'ACTIVE';
        sub.updatedAt = now;
      }
      user.subscriptionStatus = 'ACTIVE';
      user.accountState = 'ACTIVE_SUBSCRIBER';
    }

    this.logAudit(
      'GUEST_USER_UPDATED',
      `Updated guest credentials/settings for "${user.name}" (${user.username || user.email}).`,
      adminName || 'Admin',
      userId
    );
    this.save();

    const sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
    const now = Date.now();
    const daysRemaining = sub && sub.status === 'ACTIVE' && sub.expiryDate > now
      ? Math.ceil((sub.expiryDate - now) / (1000 * 60 * 60 * 24))
      : 0;

    return {
      id: user.id,
      name: user.name,
      username: user.username || user.email,
      email: user.email,
      password: user.plainPasswordHint || user.passwordHash || '',
      phone: user.phone,
      role: user.role,
      accountState: user.accountState,
      subscriptionStatus: user.subscriptionStatus,
      plan: sub?.plan || 'YEARLY',
      subscriptionId: sub?.subscriptionId,
      startDate: sub?.startDate || user.createdAt,
      expiryDate: sub?.expiryDate || (user.createdAt + 10 * 365 * 24 * 60 * 60 * 1000),
      daysRemaining: daysRemaining || 3650,
      isExpiringSoon: false,
      createdAt: user.createdAt,
      notes: user.guestNotes || '',
      relationTag: (user as any).relationTag || 'Family Member',
      createdByAdmin: (user as any).createdByAdmin || 'Nadeem Hassan (Admin)',
      isActive: user.subscriptionStatus === 'ACTIVE'
    };
  }

  // Admin: Toggle Guest User active state (pause / resume access)
  public toggleGuestUser(userId: string, active: boolean, adminName: string): GuestUserRecord {
    const user = this.db.users[userId];
    if (!user) {
      throw new Error('Guest user not found.');
    }

    const sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
    const now = Date.now();

    if (active) {
      user.subscriptionStatus = 'ACTIVE';
      user.accountState = 'ACTIVE_SUBSCRIBER';
      if (sub) {
        sub.status = 'ACTIVE';
        if (sub.expiryDate <= now) {
          sub.expiryDate = now + 3650 * 24 * 60 * 60 * 1000;
        }
        sub.updatedAt = now;
      }
    } else {
      user.subscriptionStatus = 'CANCELLED';
      user.accountState = 'PAYMENT_REQUIRED';
      if (sub) {
        sub.status = 'CANCELLED';
        sub.updatedAt = now;
      }
      // Clear sessions
      for (const [token, sess] of Object.entries(this.db.sessions)) {
        if (sess.userId === userId) {
          delete this.db.sessions[token];
        }
      }
    }

    this.logAudit(
      'GUEST_USER_STATUS_TOGGLED',
      `Toggled guest user "${user.name}" status to ${active ? 'ACTIVE (Unlocked)' : 'PAUSED (Locked)'}.`,
      adminName || 'Admin',
      userId,
      undefined,
      active ? 'CANCELLED' : 'ACTIVE',
      active ? 'ACTIVE' : 'CANCELLED'
    );
    this.save();

    const daysRemaining = sub && sub.status === 'ACTIVE' && sub.expiryDate > now
      ? Math.ceil((sub.expiryDate - now) / (1000 * 60 * 60 * 24))
      : 0;

    return {
      id: user.id,
      name: user.name,
      username: user.username || user.email,
      email: user.email,
      password: user.plainPasswordHint || user.passwordHash || '',
      phone: user.phone,
      role: user.role,
      accountState: user.accountState,
      subscriptionStatus: user.subscriptionStatus,
      plan: sub?.plan || 'YEARLY',
      subscriptionId: sub?.subscriptionId,
      startDate: sub?.startDate || user.createdAt,
      expiryDate: sub?.expiryDate || (user.createdAt + 10 * 365 * 24 * 60 * 60 * 1000),
      daysRemaining: daysRemaining,
      isExpiringSoon: false,
      createdAt: user.createdAt,
      notes: user.guestNotes || '',
      relationTag: (user as any).relationTag || 'Family Member',
      createdByAdmin: (user as any).createdByAdmin || 'Nadeem Hassan (Admin)',
      isActive: user.subscriptionStatus === 'ACTIVE'
    };
  }

  // Admin: Get all users & guests in a compact unified list
  public getAllManagedUsers(): any[] {
    const now = Date.now();
    return Object.values(this.db.users).map(user => {
      const sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
      let daysRemaining = 0;
      if (sub && sub.status === 'ACTIVE' && sub.expiryDate > now) {
        daysRemaining = Math.ceil((sub.expiryDate - now) / (1000 * 60 * 60 * 24));
      } else if (user.role === 'ADMIN') {
        daysRemaining = 3650;
      }
      return {
        id: user.id,
        name: user.name,
        username: user.username || user.email,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isGuest: Boolean(user.isGuest),
        accountState: user.accountState,
        subscriptionStatus: user.subscriptionStatus,
        plan: sub?.plan || user.plan || 'MEMBER',
        startDate: sub?.startDate || user.createdAt,
        expiryDate: sub?.expiryDate,
        daysRemaining: daysRemaining,
        passwordHint: (user as any).plainPasswordHint || '',
        notes: (user as any).guestNotes || '',
        createdAt: user.createdAt,
        isActive: user.subscriptionStatus === 'ACTIVE' || user.role === 'ADMIN'
      };
    });
  }

  // Admin: Create Managed User or Guest Pass (1 Day, 1 Week, 1 Month, Forever)
  public createManagedUser(params: {
    name: string;
    username: string;
    password: string;
    phone?: string;
    isGuest?: boolean;
    durationDays?: number;
    notes?: string;
    adminName?: string;
  }): any {
    const cleanUsername = params.username.trim().toLowerCase().replace(/\s+/g, '_');
    const cleanName = params.name.trim();
    const cleanPassword = params.password.trim();

    if (!cleanUsername || cleanUsername.length < 3) {
      throw new Error('Username must be at least 3 characters long.');
    }
    if (!cleanPassword || cleanPassword.length < 4) {
      throw new Error('Password must be at least 4 characters long.');
    }

    // If marked as guest, utilize createGuestUser
    if (params.isGuest) {
      return this.createGuestUser({
        name: cleanName,
        username: cleanUsername,
        password: cleanPassword,
        phone: params.phone,
        notes: params.notes,
        durationDays: params.durationDays || 36500,
        adminName: params.adminName || 'Nadeem Hassan (Admin)'
      });
    }

    // Otherwise create active Standard Member
    const existing = Object.values(this.db.users).find(
      u => (u.username && u.username.toLowerCase() === cleanUsername) ||
           u.email.toLowerCase() === cleanUsername ||
           u.email.toLowerCase() === `${cleanUsername}@nhtrading.pk`
    );
    if (existing) {
      throw new Error(`Username "${cleanUsername}" already exists.`);
    }

    const userId = 'usr_' + crypto.randomBytes(12).toString('hex');
    const now = Date.now();
    const durationDays = params.durationDays && params.durationDays > 0 ? params.durationDays : 36500;
    const expiryDate = now + durationDays * 24 * 60 * 60 * 1000;
    const email = cleanUsername.includes('@') ? cleanUsername : `${cleanUsername}@nhtrading.pk`;

    const user: UserProfile & { passwordHash: string; plainPasswordHint?: string; guestNotes?: string } = {
      id: userId,
      name: cleanName,
      username: cleanUsername,
      email,
      phone: params.phone?.trim() || '03000000000',
      role: 'USER',
      accountState: 'ACTIVE_SUBSCRIBER',
      subscriptionStatus: 'ACTIVE',
      plan: 'YEARLY',
      createdAt: now,
      passwordHash: hashPassword(cleanPassword),
      plainPasswordHint: cleanPassword,
      guestNotes: params.notes?.trim() || ''
    };

    const subId = 'sub_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
    const subscription: SubscriptionRecord = {
      subscriptionId: subId,
      userId,
      userName: cleanName,
      userEmail: email,
      userPhone: user.phone,
      plan: 'YEARLY',
      status: 'ACTIVE',
      startDate: now,
      expiryDate,
      paymentId: 'admin_direct_grant',
      daysRemaining: durationDays,
      isExpiringSoon: false,
      createdAt: now,
      updatedAt: now
    };

    user.activeSubscriptionId = subId;
    this.db.users[userId] = user;
    this.db.subscriptions[subId] = subscription;

    this.logAudit(
      'MEMBER_USER_CREATED',
      `Admin created new active member "${cleanName}" (${cleanUsername}) with ${durationDays} days access.`,
      params.adminName || 'Admin',
      userId,
      subId
    );
    this.save();

    return {
      id: user.id,
      name: user.name,
      username: cleanUsername,
      email: user.email,
      password: cleanPassword,
      phone: user.phone,
      role: user.role,
      accountState: user.accountState,
      subscriptionStatus: user.subscriptionStatus,
      plan: 'YEARLY',
      startDate: now,
      expiryDate,
      daysRemaining: durationDays,
      notes: user.guestNotes,
      isActive: true
    };
  }

  // Admin: Update any user (name, password, duration, notes)
  public updateManagedUser(userId: string, updates: {
    name?: string;
    password?: string;
    durationDays?: number;
    notes?: string;
    isActive?: boolean;
  }, adminName: string): any {
    const user = this.db.users[userId];
    if (!user) {
      throw new Error('User not found.');
    }
    if (user.role === 'ADMIN' && updates.isActive === false) {
      throw new Error('Cannot deactivate Master Admin account.');
    }

    if (updates.name && updates.name.trim()) {
      user.name = updates.name.trim();
    }
    if (updates.password && updates.password.trim()) {
      user.passwordHash = hashPassword(updates.password.trim());
      (user as any).plainPasswordHint = updates.password.trim();
    }
    if (updates.notes !== undefined) {
      (user as any).guestNotes = updates.notes.trim();
    }

    const sub = user.activeSubscriptionId ? this.db.subscriptions[user.activeSubscriptionId] : null;
    const now = Date.now();

    if (updates.durationDays && updates.durationDays > 0) {
      if (sub) {
        sub.expiryDate = now + updates.durationDays * 24 * 60 * 60 * 1000;
        sub.daysRemaining = updates.durationDays;
        sub.status = 'ACTIVE';
        sub.updatedAt = now;
      }
      user.subscriptionStatus = 'ACTIVE';
      user.accountState = 'ACTIVE_SUBSCRIBER';
    }

    if (updates.isActive !== undefined) {
      if (updates.isActive) {
        user.subscriptionStatus = 'ACTIVE';
        user.accountState = 'ACTIVE_SUBSCRIBER';
        if (sub) {
          sub.status = 'ACTIVE';
          sub.updatedAt = now;
        }
      } else {
        user.subscriptionStatus = 'CANCELLED';
        user.accountState = 'PAYMENT_REQUIRED';
        if (sub) {
          sub.status = 'CANCELLED';
          sub.updatedAt = now;
        }
        // Invalidate sessions
        for (const [token, sess] of Object.entries(this.db.sessions)) {
          if (sess.userId === userId) {
            delete this.db.sessions[token];
          }
        }
      }
    }

    this.logAudit('USER_MANAGED_UPDATE', `Admin updated user "${user.name}" (${user.username || user.email})`, adminName, userId);
    this.save();

    let daysRemaining = 0;
    if (sub && sub.status === 'ACTIVE' && sub.expiryDate > now) {
      daysRemaining = Math.ceil((sub.expiryDate - now) / (1000 * 60 * 60 * 24));
    }

    return {
      id: user.id,
      name: user.name,
      username: user.username || user.email,
      email: user.email,
      phone: user.phone,
      role: user.role,
      isGuest: Boolean(user.isGuest),
      subscriptionStatus: user.subscriptionStatus,
      daysRemaining,
      notes: (user as any).guestNotes || '',
      passwordHint: (user as any).plainPasswordHint || '',
      isActive: user.subscriptionStatus === 'ACTIVE' || user.role === 'ADMIN'
    };
  }

  // Admin: Delete any user or guest
  public deleteManagedUser(userId: string, adminName: string): { success: boolean; message: string } {
    return this.deleteGuestUser(userId, adminName);
  }
}

export const subscriptionStore = new SubscriptionStore();
