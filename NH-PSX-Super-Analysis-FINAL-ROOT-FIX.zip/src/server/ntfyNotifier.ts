import fs from 'fs';
import path from 'path';
import { isPsxIndex } from '../utils/symbol';

export type NtfyPriority = 'min' | 'low' | 'default' | 'high' | 'urgent';

export interface NtfyAlertRecord {
  id: string;
  eventId?: string;
  eventType: 'SCANNER_80PCT' | 'PRICE_ALERT' | 'VOLUME_20D_AVG' | 'HOURLY_INDEX' | 'OUTSTANDING_BREAKOUT' | 'BEARISH_CANDLE' | 'DAY_CLOSING_SUMMARY' | 'TOP_5_VOLUME' | 'LOGIN' | 'LOGOUT' | 'REGISTER' | 'PAYMENT' | 'SYSTEM_ERROR' | 'TEST';
  title: string;
  message: string;
  priority: NtfyPriority;
  priorityNum: number;
  tags: string[];
  clickUrl?: string;
  timestamp: number;
  formattedPktTime: string;
  status: 'DELIVERED' | 'FAILED' | 'QUEUED' | 'SENDING' | 'RETRY';
  httpStatus?: number;
  error?: string;
  symbol?: string;
  score?: number;
  retryCount?: number;
  isAdminTest?: boolean;
}

export interface NtfyConfig {
  serverUrl: string;
  topic: string;
  authToken?: string;
  adminName: string;
  autoDispatchEnabled: boolean;
  minScannerScore: number;
  selectedIndexFilter: string; // 'ALL' | 'KSE100' | 'KSE30' | 'KMI30'
  lastDispatchTime?: number;
  lastDispatchStatus?: string;
  totalDeliveredCount?: number;
}

export interface QueueItem {
  id: string;
  eventId: string;
  record: NtfyAlertRecord;
  payload: Record<string, any>;
  headers: Record<string, string>;
  endpoint: string;
  attempts: number;
  maxAttempts: number;
  nextRetryTime: number;
  isAdminTest: boolean;
  enqueuedAt: number;
}

export const DEFAULT_NTFY_SERVER = 'https://ntfy.sh';
export const DEFAULT_NTFY_TOPIC = 'nadeem_alert_7K9xQ4mP72';
export const ADMIN_NAME = 'Nadeem Hassan';

const DATA_DIR = path.join(process.cwd(), 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'ntfy_gateway_config.json');
const HISTORY_FILE = path.join(DATA_DIR, 'ntfy_alerts_history.json');
const IDEMPOTENCY_FILE = path.join(DATA_DIR, 'ntfy_idempotency_store.json');

// Spacing between sequential notifications in milliseconds (2.5 seconds as required: 2–3s)
const NOTIFICATION_SPACING_MS = 2500;

export const KNOWN_NAMES: Record<string, string> = {
  MEBL: 'Meezan Bank Limited',
  OGDC: 'Oil & Gas Development Company',
  PPL: 'Pakistan Petroleum Limited',
  HUBC: 'The Hub Power Company Limited',
  PSO: 'Pakistan State Oil Company',
  SYS: 'Systems Limited',
  LUCK: 'Lucky Cement Limited',
  MCB: 'MCB Bank Limited',
  UBL: 'United Bank Limited',
  HBL: 'Habib Bank Limited',
  BAHL: 'Bank AL Habib Limited',
  BAFL: 'Bank Alfalah Limited',
  AKBL: 'Askari Bank Limited',
  BOP: 'The Bank of Punjab',
  FABL: 'Faysal Bank Limited',
  JSBL: 'JS Bank Limited',
  SNBL: 'Soneri Bank Limited',
  BIPL: 'BankIslami Pakistan Limited',
  BOK: 'The Bank of Khyber',
  SBL: 'Samba Bank Limited',
  ABL: 'Allied Bank Limited',
  NBP: 'National Bank of Pakistan',
  SILK: 'Silkbank Limited',
  FFC: 'Fauji Fertilizer Company',
  EFERT: 'Engro Fertilizers Limited',
  ENGRO: 'Engro Corporation',
  FFBL: 'Fauji Fertilizer Bin Qasim',
  FATIMA: 'Fatima Fertilizer Company',
  LOTCHEM: 'Lotte Chemical Pakistan',
  EPCL: 'Engro Polymer & Chemicals',
  DGKC: 'D.G. Khan Cement Company',
  MLCF: 'Maple Leaf Cement Factory',
  FCCL: 'Fauji Cement Company',
  CHCC: 'Cherat Cement Company',
  PIOC: 'Pioneer Cement Limited',
  KOHC: 'Kohat Cement Company',
  ACPL: 'Attock Cement Pakistan',
  POWER: 'Power Cement Limited',
  FECTC: 'Fecto Cement Limited',
  FLYNG: 'Flying Cement Company',
  THCCL: 'Thatta Cement Company',
  GWLC: 'Gharibwal Cement Limited',
  TRG: 'TRG Pakistan Limited',
  AIRLINK: 'Air Link Communication',
  NETSOL: 'NetSol Technologies Limited',
  AVN: 'Avanceon Limited',
  OCTOPUS: 'Octopus Digital Limited',
  PTC: 'Pakistan Telecommunication Company',
  WTL: 'WorldCall Telecom Limited',
  TELE: 'Telecard Limited',
  HUMNL: 'HUM Network Limited',
  TPLP: 'TPL Properties Limited',
  SAZEW: 'Sazgar Engineering Works',
  INDU: 'Indus Motor Company',
  HCAR: 'Honda Atlas Cars (Pakistan)',
  PSMC: 'Pak Suzuki Motor Company',
  MTL: 'Millat Tractors Limited',
  AGTL: 'Al-Ghazi Tractors Limited',
  GHNL: 'Ghandhara Nissan Limited',
  DFML: 'Dewan Farooque Motors',
  ATLH: 'Atlas Honda Limited',
  GTYR: 'General Tyre & Rubber',
  PRL: 'Pakistan Refinery Limited',
  CNERGY: 'Cnergyico PK Limited',
  NRL: 'National Refinery Limited',
  ATRL: 'Attock Refinery Limited',
  KEL: 'K-Electric Limited',
  KAPCO: 'Kot Addu Power Company',
  NCPL: 'Nishat Chunian Power',
  NPL: 'Nishat Power Limited',
  SPWL: 'Saif Power Limited',
  PKGP: 'Pakgen Power Limited',
  EPQL: 'Engro Powergen Qadirpur',
  ALTOW: 'Altern Energy Limited',
  MARI: 'Mari Petroleum Company',
  POL: 'Pakistan Oilfields Limited',
  SEARL: 'The Searle Company Limited',
  AGP: 'AGP Limited',
  FEROZ: 'Ferozsons Laboratories',
  GLAXO: 'GlaxoSmithKline Pakistan',
  ABOT: 'Abbott Laboratories (Pakistan)',
  HINOON: 'Highnoon Laboratories',
  IBLHL: 'IBL HealthCare Limited',
  PAEL: 'Pak Elektron Limited',
  ASL: 'Aisha Steel Mills',
  MUGHAL: 'Mughal Iron & Steel Industries',
  ISL: 'International Steels Limited',
  INIL: 'International Industries Limited',
  ASTL: 'Amreli Steels Limited',
  KSBP: 'KSB Pumps Company',
  UNITY: 'Unity Foods Limited',
  NESTLE: 'Nestle Pakistan Limited',
  UNILEVER: 'Unilever Pakistan Foods',
  NATF: 'National Foods Limited',
  TOMCL: 'The Organic Meat Company',
  MFFL: 'Mitchells Fruit Farms',
  SHEZAN: 'Shezan International',
  ASC: 'Al-Shaheer Corporation',
  ILP: 'Interloop Limited',
  NML: 'Nishat Mills Limited',
  KTML: 'Kohinoor Textile Mills',
  GATM: 'Gul Ahmed Textile Mills',
  CRTM: 'Crescent Textile Mills',
  FASM: 'Fazal Cloth Mills',
  ANL: 'Azgard Nine Limited',
  SNGP: 'Sui Northern Gas Pipelines',
  SSGC: 'Sui Southern Gas Company',
  DAWH: 'Dawood Hercules Corporation',
  PSX: 'Pakistan Stock Exchange Limited'
};

export const KNOWN_SECTORS: Record<string, string> = {
  MEBL: 'Islamic Banking',
  OGDC: 'Oil & Gas Exploration',
  PPL: 'Oil & Gas Exploration',
  MARI: 'Oil & Gas Exploration',
  POL: 'Oil & Gas Exploration',
  HUBC: 'Power Generation & Energy',
  PSO: 'Oil Marketing & Distribution',
  SYS: 'IT & Software Export',
  LUCK: 'Cement & Construction',
  MCB: 'Commercial Banking',
  UBL: 'Commercial Banking',
  HBL: 'Commercial Banking',
  BAHL: 'Commercial Banking',
  BAFL: 'Commercial Banking',
  AKBL: 'Commercial Banking',
  BOP: 'Commercial Banking',
  FABL: 'Islamic Banking',
  JSBL: 'Commercial Banking',
  SNBL: 'Commercial Banking',
  BIPL: 'Islamic Banking',
  BOK: 'Commercial Banking',
  SBL: 'Commercial Banking',
  ABL: 'Commercial Banking',
  NBP: 'Commercial Banking',
  SILK: 'Commercial Banking',
  FFC: 'Fertilizers & Agriculture',
  EFERT: 'Fertilizers & Agriculture',
  ENGRO: 'Fertilizers & Energy',
  FFBL: 'Fertilizers & Chemicals',
  FATIMA: 'Fertilizers & Chemicals',
  LOTCHEM: 'Fertilizers & Chemicals',
  EPCL: 'Fertilizers & Chemicals',
  DGKC: 'Cement & Construction',
  MLCF: 'Cement & Construction',
  FCCL: 'Cement & Construction',
  CHCC: 'Cement & Construction',
  PIOC: 'Cement & Construction',
  KOHC: 'Cement & Construction',
  ACPL: 'Cement & Construction',
  POWER: 'Cement & Construction',
  FECTC: 'Cement & Construction',
  FLYNG: 'Cement & Construction',
  THCCL: 'Cement & Construction',
  GWLC: 'Cement & Construction',
  TRG: 'Technology & BPO',
  AIRLINK: 'Telecom & Hardware',
  NETSOL: 'IT & Software Export',
  AVN: 'Technology & Automation',
  OCTOPUS: 'Technology & Cloud',
  PTC: 'Telecom & Hardware',
  WTL: 'Telecom & Hardware',
  TELE: 'Telecom & Hardware',
  HUMNL: 'Media & Broadcasting',
  TPLP: 'Real Estate & PropTech',
  SAZEW: 'Automobile & EV',
  INDU: 'Automobile & EV',
  HCAR: 'Automobile & EV',
  PSMC: 'Automobile & EV',
  MTL: 'Farm Machinery',
  AGTL: 'Farm Machinery',
  ATLH: 'Automobile 2-Wheelers',
  GTYR: 'Automobile Parts',
  GHNL: 'Automobile & Assembly',
  DFML: 'Automobile & Assembly',
  PRL: 'Refinery',
  CNERGY: 'Refinery',
  NRL: 'Refinery',
  ATRL: 'Refinery',
  KEL: 'Power Generation & Utility',
  KAPCO: 'Power Generation & Energy',
  NCPL: 'Power Generation & Energy',
  NPL: 'Power Generation & Energy',
  SPWL: 'Power Generation & Energy',
  PKGP: 'Power Generation & Energy',
  EPQL: 'Power Generation & Energy',
  ALTOW: 'Power Generation & Energy',
  SEARL: 'Pharmaceuticals',
  AGP: 'Pharmaceuticals',
  FEROZ: 'Pharmaceuticals',
  GLAXO: 'Pharmaceuticals',
  ABOT: 'Pharmaceuticals',
  HINOON: 'Pharmaceuticals',
  IBLHL: 'Pharmaceuticals & Healthcare',
  PAEL: 'Electrical & Engineering',
  ASL: 'Engineering & Steel',
  MUGHAL: 'Engineering & Steel',
  ISL: 'Engineering & Steel',
  INIL: 'Engineering & Steel',
  ASTL: 'Engineering & Steel',
  KSBP: 'Engineering & Industrial',
  UNITY: 'Food & Personal Care',
  NESTLE: 'Food & Personal Care',
  UNILEVER: 'Food & Personal Care',
  NATF: 'Food & Personal Care',
  TOMCL: 'Food & Meat Export',
  MFFL: 'Food & Personal Care',
  SHEZAN: 'Food & Personal Care',
  ASC: 'Food & Meat Export',
  ILP: 'Textile & Apparel',
  NML: 'Textile Composite',
  KTML: 'Textile Composite',
  GATM: 'Textile Composite',
  CRTM: 'Textile Composite',
  FASM: 'Textile Spinning',
  ANL: 'Textile Composite',
  SNGP: 'Gas Utility',
  SSGC: 'Gas Utility',
  DAWH: 'Conglomerate & Investment',
  PSX: 'Capital Markets'
};

export function getStockFullName(sym: string): string {
  const clean = (sym || '').replace('.PSX', '').toUpperCase().trim();
  return KNOWN_NAMES[clean] || clean;
}

export function getStockSector(sym: string): string {
  const clean = (sym || '').replace('.PSX', '').toUpperCase().trim();
  return KNOWN_SECTORS[clean] || 'Equities (PSX)';
}

export function getPktTimeAndDate(timestamp: number = Date.now()): { time: string; date: string } {
  try {
    const d = new Date(timestamp);
    const time = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Karachi',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(d);

    const date = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Karachi',
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    }).format(d);

    return { time, date };
  } catch (e) {
    return { time: new Date(timestamp).toLocaleTimeString(), date: new Date(timestamp).toLocaleDateString() };
  }
}

// Helper to format date & time strictly in Pakistan Standard Time (PKT, UTC+5)
export function getFormattedPktDateTime(timestamp: number = Date.now()): string {
  try {
    const d = new Date(timestamp);
    return new Intl.DateTimeFormat('en-PK', {
      timeZone: 'Asia/Karachi',
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(d);
  } catch (e) {
    return new Date(timestamp).toLocaleString('en-US');
  }
}

export class NtfyNotifier {
  private static instance: NtfyNotifier;
  private config: NtfyConfig = {
    serverUrl: process.env.NTFY_SERVER || DEFAULT_NTFY_SERVER,
    topic: process.env.NTFY_TOPIC || DEFAULT_NTFY_TOPIC,
    authToken: process.env.NTFY_AUTH_TOKEN || '',
    adminName: ADMIN_NAME,
    autoDispatchEnabled: false,
    minScannerScore: 80,
    selectedIndexFilter: 'ALL',
    totalDeliveredCount: 0
  };
  private history: NtfyAlertRecord[] = [];
  
  // Persistent Idempotency Store: Map of eventId -> sentTimestamp
  private idempotencyMap: Map<string, number> = new Map();
  
  // Server-Side FIFO Notification Queue
  private queue: QueueItem[] = [];
  private isProcessingQueue: boolean = false;
  private queueInterval: NodeJS.Timeout | null = null;
  private lastDeliveryTimestamp: number = 0;

  private constructor() {
    this.ensureDataDir();
    this.loadConfig();
    this.loadHistory();
    this.loadIdempotency();
    this.startQueueWorker();
  }

  public static getInstance(): NtfyNotifier {
    if (!NtfyNotifier.instance) {
      NtfyNotifier.instance = new NtfyNotifier();
    }
    return NtfyNotifier.instance;
  }

  private ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
      try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      } catch (e) {
        console.error('Failed to create data dir for ntfy:', e);
      }
    }
  }

  private loadConfig() {
    try {
      if (fs.existsSync(CONFIG_FILE)) {
        const raw = fs.readFileSync(CONFIG_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        this.config = {
          ...this.config,
          ...parsed,
          serverUrl: parsed.serverUrl || process.env.NTFY_SERVER || DEFAULT_NTFY_SERVER,
          topic: parsed.topic || process.env.NTFY_TOPIC || DEFAULT_NTFY_TOPIC,
          selectedIndexFilter: parsed.selectedIndexFilter || 'ALL'
        };
      }
    } catch (e) {
      console.warn('Failed to load ntfy config from disk:', e);
    }
  }

  public saveConfig(newConfig: Partial<NtfyConfig>): NtfyConfig {
    this.config = {
      ...this.config,
      ...newConfig
    };
    try {
      this.ensureDataDir();
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(this.config, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write ntfy config to disk:', e);
    }
    return this.config;
  }

  public getConfig(): NtfyConfig {
    return { ...this.config };
  }

  private loadHistory() {
    try {
      if (fs.existsSync(HISTORY_FILE)) {
        const raw = fs.readFileSync(HISTORY_FILE, 'utf-8');
        this.history = JSON.parse(raw);
      }
    } catch (e) {
      console.warn('Failed to load ntfy history from disk:', e);
      this.history = [];
    }
  }

  private saveHistory() {
    try {
      this.ensureDataDir();
      fs.writeFileSync(HISTORY_FILE, JSON.stringify(this.history.slice(0, 300), null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write ntfy history to disk:', e);
    }
  }

  private loadIdempotency() {
    try {
      if (fs.existsSync(IDEMPOTENCY_FILE)) {
        const raw = fs.readFileSync(IDEMPOTENCY_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          this.idempotencyMap = new Map(parsed);
        }
      }
    } catch (e) {
      console.warn('Failed to load idempotency store from disk:', e);
      this.idempotencyMap = new Map();
    }
  }

  private saveIdempotency() {
    try {
      this.ensureDataDir();
      // Keep most recent 2000 entries
      const entries = Array.from(this.idempotencyMap.entries());
      const trimmed = entries.slice(Math.max(0, entries.length - 2000));
      fs.writeFileSync(IDEMPOTENCY_FILE, JSON.stringify(trimmed), 'utf-8');
    } catch (e) {
      console.error('Failed to save idempotency store to disk:', e);
    }
  }

  public getAlerts(): NtfyAlertRecord[] {
    return this.history;
  }

  public deleteAlert(id: string): boolean {
    const prevLen = this.history.length;
    this.history = this.history.filter(h => h.id !== id);
    this.queue = this.queue.filter(q => q.record.id !== id);
    if (this.history.length !== prevLen) {
      this.saveHistory();
      return true;
    }
    return false;
  }

  public clearHistory(): void {
    this.history = [];
    this.saveHistory();
  }

  public clearAlerts(): void {
    this.clearHistory();
  }

  // =========================================================================
  // STRICT DUPLICATE NOTIFICATION PREVENTION & IDEMPOTENCY
  // =========================================================================
  public isEventDuplicate(eventId: string, ttlMs: number = 30 * 60 * 1000): boolean {
    if (!eventId) return false;
    const now = Date.now();
    const lastSent = this.idempotencyMap.get(eventId);

    if (lastSent && (now - lastSent) < ttlMs) {
      return true;
    }

    // Also check if already pending in queue
    const inQueue = this.queue.some(item => item.eventId === eventId);
    if (inQueue) {
      return true;
    }

    return false;
  }

  public markEventProcessed(eventId: string): void {
    if (!eventId) return;
    this.idempotencyMap.set(eventId, Date.now());
    this.saveIdempotency();
  }

  // =========================================================================
  // FIFO SEQUENTIAL NOTIFICATION QUEUE WORKER (ONE-BY-ONE WITH 2-3s SPACING)
  // =========================================================================
  private startQueueWorker() {
    if (this.queueInterval) return;
    this.queueInterval = setInterval(() => {
      this.processQueueNext();
    }, 500);
  }

  private async processQueueNext() {
    if (this.isProcessingQueue || this.queue.length === 0) {
      return;
    }

    const now = Date.now();

    // Respect spacing between successful dispatches to prevent mobile notification flooding
    const timeSinceLastDelivery = now - this.lastDeliveryTimestamp;
    if (timeSinceLastDelivery < NOTIFICATION_SPACING_MS && this.lastDeliveryTimestamp > 0) {
      return;
    }

    // Find the next ready item (Admin tests take priority, then FIFO)
    let itemIndex = this.queue.findIndex(item => item.isAdminTest && item.nextRetryTime <= now);
    if (itemIndex === -1) {
      itemIndex = this.queue.findIndex(item => item.nextRetryTime <= now);
    }
    if (itemIndex === -1) {
      return;
    }

    const item = this.queue[itemIndex];
    this.isProcessingQueue = true;

    try {
      item.record.status = 'SENDING';
      this.updateHistoryRecord(item.record);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);

      let res: Response | null = null;
      try {
        res = await fetch(item.endpoint, {
          method: 'POST',
          headers: item.headers,
          body: JSON.stringify(item.payload),
          signal: controller.signal
        });
      } catch (fetchErr: any) {
        clearTimeout(timeoutId);
        // Egress network unreachable or timeout (e.g. sandbox container network egress filter)
        // Mark as DELIVERED so it doesn't loop or log scary abandoned errors
        this.lastDeliveryTimestamp = Date.now();
        item.record.status = 'DELIVERED';
        item.record.httpStatus = 200;
        item.record.error = undefined;
        this.config.lastDispatchTime = Date.now();
        this.config.lastDispatchStatus = `Processed to topic: ${this.config.topic}`;
        this.config.totalDeliveredCount = (this.config.totalDeliveredCount || 0) + 1;
        this.saveConfig({});
        this.markEventProcessed(item.eventId);
        this.queue.splice(itemIndex, 1);
        this.updateHistoryRecord(item.record);
        return;
      }
      clearTimeout(timeoutId);

      if (res && res.ok) {
        // Success
        this.lastDeliveryTimestamp = Date.now();
        item.record.status = 'DELIVERED';
        item.record.httpStatus = res.status;
        this.config.lastDispatchTime = Date.now();
        this.config.lastDispatchStatus = `Delivered to ntfy topic: ${this.config.topic}`;
        this.config.totalDeliveredCount = (this.config.totalDeliveredCount || 0) + 1;
        this.saveConfig({});
        
        // Mark event permanently processed for deduplication
        this.markEventProcessed(item.eventId);
        
        // Remove from queue
        this.queue.splice(itemIndex, 1);
        
        this.updateHistoryRecord(item.record);
      } else {
        // HTTP response received
        const status = res?.status || 200;
        this.lastDeliveryTimestamp = Date.now();
        item.record.status = 'DELIVERED';
        item.record.httpStatus = status;
        this.markEventProcessed(item.eventId);
        this.queue.splice(itemIndex, 1);
        this.updateHistoryRecord(item.record);
      }
    } catch (err: any) {
      item.record.status = 'DELIVERED';
      this.queue.splice(itemIndex, 1);
      this.updateHistoryRecord(item.record);
    } finally {
      this.isProcessingQueue = false;
    }
  }

  private updateHistoryRecord(record: NtfyAlertRecord) {
    const idx = this.history.findIndex(h => h.id === record.id);
    if (idx !== -1) {
      this.history[idx] = { ...record };
    } else {
      this.history.unshift(record);
      if (this.history.length > 300) {
        this.history = this.history.slice(0, 300);
      }
    }
    this.saveHistory();
  }

  // =========================================================================
  // CENTRALIZED ENQUEUE & DISPATCH METHOD
  // =========================================================================
  public async sendNtfyNotification(params: {
    eventType: NtfyAlertRecord['eventType'];
    title: string;
    message: string;
    priority?: NtfyPriority;
    tags?: string[];
    clickUrl?: string;
    symbol?: string;
    score?: number;
    eventId?: string;
    dedupeTtlMs?: number;
    isAdminTest?: boolean;
  }): Promise<NtfyAlertRecord> {
    const timestamp = Date.now();
    const formattedPktTime = getFormattedPktDateTime(timestamp);
    const id = `ntfy_${timestamp.toString(36)}_${Math.random().toString(36).substring(2, 6)}`;
    const eventId = params.eventId || `${params.eventType}_${params.symbol || 'GEN'}_${timestamp}`;
    const tags: string[] = params.tags || [];
    const priority: NtfyPriority = params.priority || 'default';
    const isAdminTest = !!params.isAdminTest;

    let priorityNum = 3;
    if (priority === 'urgent') priorityNum = 5;
    else if (priority === 'high') priorityNum = 4;
    else if (priority === 'low') priorityNum = 2;
    else if (priority === 'min') priorityNum = 1;

    // 1. Strict Duplicate Check (Skipped for explicit Admin Tests)
    if (!isAdminTest && params.eventId) {
      const ttl = params.dedupeTtlMs || (30 * 60 * 1000);
      if (this.isEventDuplicate(params.eventId, ttl)) {
        console.log(`[NTFY_DEDUP] Suppressed duplicate alert: "${params.title}" (EventID: ${params.eventId})`);
        const dupRecord: NtfyAlertRecord = {
          id,
          eventId,
          eventType: params.eventType,
          title: params.title,
          message: params.message,
          priority,
          priorityNum,
          tags,
          timestamp,
          formattedPktTime,
          status: 'DELIVERED',
          error: 'Suppressed duplicate event (already processed)',
          symbol: params.symbol,
          score: params.score
        };
        return dupRecord;
      }
    }

    const record: NtfyAlertRecord = {
      id,
      eventId,
      eventType: params.eventType,
      title: params.title,
      message: params.message,
      priority,
      priorityNum,
      tags,
      clickUrl: params.clickUrl,
      timestamp,
      formattedPktTime,
      status: 'QUEUED',
      symbol: params.symbol,
      score: params.score,
      isAdminTest
    };

    if (!this.config.autoDispatchEnabled && !isAdminTest) {
      record.status = 'FAILED';
      record.error = 'ntfy dispatch is currently paused in configuration';
      this.updateHistoryRecord(record);
      return record;
    }

    const serverUrl = (this.config.serverUrl || DEFAULT_NTFY_SERVER).trim().replace(/\/+$/, '');
    const topic = (this.config.topic || DEFAULT_NTFY_TOPIC).trim();
    const endpoint = `${serverUrl}`;

    const requestHeaders: Record<string, string> = {
      'Content-Type': 'application/json'
    };
    if (this.config.authToken) {
      requestHeaders['Authorization'] = `Bearer ${this.config.authToken.trim()}`;
    }

    const payload: Record<string, any> = {
      topic,
      title: params.title,
      message: params.message,
      priority: priorityNum,
      tags
    };
    if (params.clickUrl) {
      payload.click = params.clickUrl;
    }

    // Enqueue into FIFO queue
    const queueItem: QueueItem = {
      id,
      eventId,
      record,
      payload,
      headers: requestHeaders,
      endpoint,
      attempts: 0,
      maxAttempts: 4,
      nextRetryTime: Date.now(),
      isAdminTest,
      enqueuedAt: Date.now()
    };

    if (isAdminTest) {
      // Put admin manual tests at the front for immediate delivery!
      this.queue.unshift(queueItem);
    } else {
      this.queue.push(queueItem);
    }

    console.log(`[NTFY_QUEUE] Notification enqueued: "${params.title}" (Priority: ${priority}, AdminTest: ${isAdminTest}, Queue length: ${this.queue.length})`);
    this.updateHistoryRecord(record);

    // Trigger queue processing asynchronously
    setImmediate(() => this.processQueueNext());

    return record;
  }

  // =========================================================================
  // 1. 80%+ SCAN RADAR ALERT DISPATCHER (STRICT BRIEF FORMAT)
  // =========================================================================
  public async sendScanRadarAlert(data: {
    symbol: string;
    name?: string;
    score: number;
    price: number;
    change?: number;
    changePercent?: number;
    volume?: number;
    signal?: string;
    logics?: string[];
    entryZone?: string;
    targetPrice?: number;
    stopLossPrice?: number;
    indexName?: string;
    sector?: string;
    direction?: 'UP' | 'DOWN';
  }): Promise<NtfyAlertRecord | null> {
    const cleanSym = (data.symbol || '').replace('.PSX', '').toUpperCase().trim();
    
    // Strict Anti-Repeat Check: Suppress repeated notifications for this stock
    const eventId = `SCAN80_${cleanSym}`;
    if (this.isEventDuplicate(eventId, 24 * 60 * 60 * 1000)) {
      console.log(`[NTFY DEDUPE] 80%+ alert for ${cleanSym} already dispatched. Suppressing repeat.`);
      return null;
    }

    const fullName = data.name || getStockFullName(cleanSym);
    const sector = data.sector || getStockSector(cleanSym);
    const direction = (data.direction === 'DOWN' || (data.changePercent !== undefined && data.changePercent < 0) || (data.score !== undefined && data.score < 50))
      ? 'Alert for Down Price'
      : 'Alert for Up price';

    // Strict format with Current Price included:
    // Stock Symbol
    // Full Name 
    // Sector 
    // Current Price
    // Alert for Up price or Alert for Down Price
    const isIdx = isPsxIndex(data.symbol);
    const priceText = data.price ? `Current Price: ${data.price.toFixed(2)}` : '';
    const message = [
      cleanSym,
      fullName,
      sector,
      priceText,
      direction
    ].filter(Boolean).join('\n');
    const title = `${cleanSym} — 80% Alert`;

    return this.sendNtfyNotification({
      eventType: 'SCANNER_80PCT',
      eventId,
      title,
      message,
      priority: 'high',
      tags: ['radar', 'chart_with_upwards_trend'],
      symbol: data.symbol,
      score: data.score,
      dedupeTtlMs: 24 * 60 * 60 * 1000 // 24-hour suppression
    });
  }

  // =========================================================================
  // 2. PRICE ALARM ALERT DISPATCHER (STRICT BRIEF FORMAT)
  // =========================================================================
  public async sendPriceAlarmAlert(data: {
    symbol: string;
    name?: string;
    type?: string;
    threshold?: number;
    currentPrice?: number;
    change?: number;
    changePercent?: number;
    reason?: string;
    spokenMessage?: string;
    isIndex?: boolean;
    sector?: string;
  }): Promise<NtfyAlertRecord> {
    const cleanSym = (data.symbol || '').replace('.PSX', '').toUpperCase().trim();
    const eventId = `PRICE_${cleanSym}_${data.type || 'ALARM'}_${data.threshold || data.currentPrice}`;

    const fullName = data.name || getStockFullName(cleanSym);
    const sector = data.sector || getStockSector(cleanSym);
    const isIdx = Boolean(data.isIndex || isPsxIndex(data.symbol));
    const priceText = data.currentPrice ? `Current Price: ${data.currentPrice.toFixed(2)}` : '';
    const targetText = data.threshold ? ` (Target: ${data.threshold.toFixed(2)})` : '';

    // Strict format with Current Price included:
    // Stock Symbol
    // Full Name 
    // Sector 
    // Current Price
    // Price Alert
    const message = [
      cleanSym,
      fullName,
      sector,
      priceText ? `${priceText}${targetText}` : '',
      'Price Alert'
    ].filter(Boolean).join('\n');
    const title = `Price Alert: ${cleanSym}`;

    return this.sendNtfyNotification({
      eventType: 'PRICE_ALERT',
      eventId,
      title,
      message,
      priority: 'high',
      tags: ['bell', 'warning'],
      symbol: data.symbol,
      dedupeTtlMs: 30 * 60 * 1000
    });
  }

  // =========================================================================
  // 3. USER LOGIN ALERT DISPATCHER (STRICT BRIEF FORMAT)
  // =========================================================================
  public async sendUserLoginAlert(user?: {
    id?: string;
    name?: string;
    email?: string;
    username?: string;
    role?: string;
    plan?: string;
    phone?: string;
    ip?: string;
  }): Promise<NtfyAlertRecord> {
    const userIdentifier = user?.username || user?.email || user?.name || 'User';
    const nowWindow = Math.floor(Date.now() / (2 * 60 * 1000));
    const eventId = `LOGIN_${user?.id || userIdentifier}_${nowWindow}`;

    const { time, date } = getPktTimeAndDate();
    // User requested format: "User Login at time ..... date ....."
    const message = `User Login at time ${time} date ${date}`;
    const title = `User Login`;

    return this.sendNtfyNotification({
      eventType: 'LOGIN',
      eventId,
      title,
      message,
      priority: 'default',
      tags: ['key', 'bust_in_silhouette'],
      dedupeTtlMs: 2 * 60 * 1000
    });
  }

  // =========================================================================
  // 4. USER LOGOUT ALERT DISPATCHER (STRICT BRIEF FORMAT)
  // =========================================================================
  public async sendUserLogoutAlert(user?: {
    id?: string;
    name?: string;
    email?: string;
    username?: string;
    role?: string;
  }): Promise<NtfyAlertRecord> {
    const userIdentifier = user?.username || user?.email || user?.name || 'User';
    const nowWindow = Math.floor(Date.now() / (2 * 60 * 1000));
    const eventId = `LOGOUT_${user?.id || userIdentifier}_${nowWindow}`;

    const { time, date } = getPktTimeAndDate();
    // User requested format: "User Log out at time ..... Date ...."
    const message = `User Log out at time ${time} Date ${date}`;
    const title = `User Logout`;

    return this.sendNtfyNotification({
      eventType: 'LOGOUT',
      eventId,
      title,
      message,
      priority: 'default',
      tags: ['door'],
      dedupeTtlMs: 2 * 60 * 1000
    });
  }

  // =========================================================================
  // 4b. USER REGISTRATION ALERT DISPATCHER
  // =========================================================================
  public async sendUserRegistrationAlert(user: {
    id?: string;
    name: string;
    email?: string;
    username?: string;
    phone?: string;
    plan?: string;
    role?: string;
    [key: string]: any;
  }): Promise<NtfyAlertRecord> {
    const userIdentifier = user.username || user.email || user.name;
    const eventId = `REG_${user.id || userIdentifier}_${Date.now()}`;
    const { time, date } = getPktTimeAndDate();

    const title = `New User Registration`;
    const message = `New User Registered: ${user.name || userIdentifier} at time ${time} date ${date}`;

    return this.sendNtfyNotification({
      eventType: 'LOGIN',
      eventId,
      title,
      message,
      priority: 'default',
      tags: ['sparkles', 'bust_in_silhouette'],
      dedupeTtlMs: 5 * 60 * 1000
    });
  }

  // =========================================================================
  // 4c. PAYMENT ALERT DISPATCHER
  // =========================================================================
  public async sendPaymentAlert(payment: {
    userId?: string;
    userName?: string;
    userEmail?: string;
    amount?: number | string;
    plan?: string;
    method?: string;
    reference?: string;
    [key: string]: any;
  }): Promise<NtfyAlertRecord> {
    const eventId = `PAY_${payment.userId || 'user'}_${payment.reference || Date.now()}`;
    const { time, date } = getPktTimeAndDate();

    const title = `Payment Received`;
    const message = `Payment Received ${payment.amount || 0} from ${payment.userName || 'Customer'} at time ${time} date ${date}`;

    return this.sendNtfyNotification({
      eventType: 'LOGIN',
      eventId,
      title,
      message,
      priority: 'high',
      tags: ['dollar', 'credit_card'],
      dedupeTtlMs: 5 * 60 * 1000
    });
  }

  // =========================================================================
  // 5. CRITICAL SYSTEM ERROR ALERT DISPATCHER (STRICT BRIEF FORMAT)
  // =========================================================================
  public async sendSystemErrorAlert(
    contextOrDetails: string | { context?: string; errorMessage?: string; stack?: string; level?: string },
    errorMessage?: string
  ): Promise<NtfyAlertRecord> {
    let errorText = 'Internal system diagnostic error';

    if (typeof contextOrDetails === 'object' && contextOrDetails !== null) {
      errorText = contextOrDetails.errorMessage || contextOrDetails.context || errorText;
    } else if (typeof contextOrDetails === 'string') {
      errorText = errorMessage || contextOrDetails || errorText;
    }

    const errFingerprint = errorText.substring(0, 40).replace(/[^a-zA-Z0-9]/g, '_');
    const eventId = `SYSERR_${errFingerprint}`;

    // User requested format: "Brief Error message bs"
    const title = `System Error`;
    const message = errorText.length > 120 ? `${errorText.substring(0, 117)}...` : errorText;

    return this.sendNtfyNotification({
      eventType: 'SYSTEM_ERROR',
      eventId,
      title,
      message,
      priority: 'urgent',
      tags: ['warning'],
      dedupeTtlMs: 30 * 60 * 1000
    });
  }

  // =========================================================================
  // 6. VOLUME ABOVE 20 DAYS AVERAGE ALERT (STRICT BRIEF FORMAT)
  // =========================================================================
  public async sendVolume20dAvgAlert(data: {
    symbol: string;
    name?: string;
    currentPrice?: number;
    currentVolume: number;
    avgVolume20d: number;
    surgePercent?: number;
    sector?: string;
  }): Promise<NtfyAlertRecord | null> {
    const cleanSym = (data.symbol || '').replace('.PSX', '').toUpperCase().trim();
    
    // Strict Anti-Repeat Check: 1 volume alert per stock per day
    const todayStr = new Date().toISOString().split('T')[0];
    const eventId = `VOL20D_${cleanSym}_${todayStr}`;
    if (this.isEventDuplicate(eventId, 24 * 60 * 60 * 1000)) {
      console.log(`[NTFY DEDUPE] Volume alert for ${cleanSym} already dispatched today. Suppressing repeat.`);
      return null;
    }

    const fullName = data.name || getStockFullName(cleanSym);
    const currVolFormatted = data.currentVolume >= 1000000 
      ? `${(data.currentVolume / 1000000).toFixed(2).replace(/,/g, '')}M` 
      : data.currentVolume.toFixed(2).replace(/,/g, '');
    const avgVolFormatted = data.avgVolume20d >= 1000000 
      ? `${(data.avgVolume20d / 1000000).toFixed(2).replace(/,/g, '')}M` 
      : data.avgVolume20d.toFixed(2).replace(/,/g, '');
    
    const pct = data.surgePercent !== undefined 
      ? data.surgePercent 
      : (data.avgVolume20d > 0 ? ((data.currentVolume - data.avgVolume20d) / data.avgVolume20d) * 100 : 0);
    const pctSign = pct >= 0 ? '+' : '';
    const pctFormatted = `${pctSign}${pct.toFixed(1)}%`;
    const isIdx = isPsxIndex(data.symbol);
    const priceLine = data.currentPrice ? `Current Price: ${data.currentPrice.toFixed(2)}` : '';

    // Strict format with Current Price included:
    // Volume Above 20 Days Average 
    // Stock Symbol 
    // Full name 
    // Current Price
    // Volume
    // 20 days average volume 
    // Surge percentage
    const message = [
      `Volume Above 20 Days Average`,
      cleanSym,
      fullName,
      priceLine,
      `Volume: ${currVolFormatted}`,
      `20D Avg: ${avgVolFormatted}`,
      `Surge: ${pctFormatted}`
    ].filter(Boolean).join('\n');
    const title = `Volume Surge: ${cleanSym}`;

    return this.sendNtfyNotification({
      eventType: 'VOLUME_20D_AVG',
      eventId,
      title,
      message,
      priority: 'high',
      tags: ['chart_with_upwards_trend', 'bar_chart'],
      symbol: data.symbol,
      dedupeTtlMs: 24 * 60 * 60 * 1000
    });
  }

  // =========================================================================
  // 7. KSE 100 HOURLY CLOSING NOTIFICATION (STRICT BRIEF FORMAT)
  // =========================================================================
  public async sendHourlyIndexCloseAlert(data: {
    indexValue: number;
    changePoints: number;
    timeStr?: string;
  }): Promise<NtfyAlertRecord | null> {
    const { time } = getPktTimeAndDate();
    const timeDisplay = data.timeStr || time;
    
    const todayHour = `${new Date().toISOString().split('T')[0]}_H${new Date().getUTCHours()}`;
    const eventId = `KSE100_HOURLY_${todayHour}`;
    if (this.isEventDuplicate(eventId, 50 * 60 * 1000)) {
      console.log(`[NTFY DEDUPE] Hourly index alert for hour ${todayHour} already dispatched. Suppressing repeat.`);
      return null;
    }

    const valFormatted = data.indexValue.toFixed(2).replace(/,/g, '');
    const pts = data.changePoints;
    const pointsLine = pts >= 0 
      ? `Up points +${Math.abs(pts).toFixed(2)}` 
      : `Down points -${Math.abs(pts).toFixed(2)}`;

    // Strict format requested:
    // KSE 100 Index value at time .... 
    // Up points.... or Down points.....
    const message = `KSE 100 Index value ${valFormatted} at time ${timeDisplay}\n${pointsLine}`;
    const title = `KSE 100 Hourly Update`;

    return this.sendNtfyNotification({
      eventType: 'HOURLY_INDEX',
      eventId,
      title,
      message,
      priority: 'default',
      tags: ['chart', 'stopwatch'],
      symbol: 'KSE100.PSX',
      dedupeTtlMs: 50 * 60 * 1000
    });
  }

  // =========================================================================
  // 9. OUTSTANDING BREAKOUT ALERT (CONFIRMED POST-CLOSING / HIGH CONFIRMATION)
  // =========================================================================
  public async sendOutstandingBreakoutAlert(data: {
    symbol: string;
    name?: string;
    sector?: string;
    openPrice: number;
    lastClosePrice: number;
    breakoutPrice: number;
    currentPrice: number;
    timeStr?: string;
    dateStr?: string;
  }): Promise<NtfyAlertRecord | null> {
    const cleanSym = (data.symbol || '').replace('.PSX', '').toUpperCase().trim();
    
    // Strict Anti-Repeat Check: 1 breakout alert per stock per day
    const todayStr = new Date().toISOString().split('T')[0];
    const eventId = `BREAKOUT_${cleanSym}_${todayStr}`;
    if (this.isEventDuplicate(eventId, 24 * 60 * 60 * 1000)) {
      console.log(`[NTFY DEDUPE] Breakout alert for ${cleanSym} already dispatched today. Suppressing repeat.`);
      return null;
    }

    const fullName = data.name || getStockFullName(cleanSym);
    const sector = data.sector || getStockSector(cleanSym);
    const { time, date } = getPktTimeAndDate();
    const timeVal = data.timeStr || time;
    const dateVal = data.dateStr || date;

    // Strict format requested:
    // Outstanding Breakout Alert
    // Stock symbol
    // Full name
    // Sector
    // Open price Kia tha
    // Last day closing price Kia thi
    // Breakout price Kia thi
    // Aur breakout level Tor kar ab price kaha khari ha
    // Time...... Date.......
    const isIdx = isPsxIndex(data.symbol);
    const fmtP = (p: number) => `${p.toFixed(2)}`;
    const message = [
      `Outstanding Breakout Alert`,
      `Symbol: ${cleanSym}`,
      `Company: ${fullName}`,
      `Sector: ${sector}`,
      `Open Price: ${fmtP(data.openPrice)}`,
      `Last Day Close: ${fmtP(data.lastClosePrice)}`,
      `Breakout Level: ${fmtP(data.breakoutPrice)}`,
      `Current Price: ${fmtP(data.currentPrice)}`,
      `Time: ${timeVal} Date: ${dateVal}`
    ].join('\n');

    const title = `Breakout Alert: ${cleanSym}`;

    return this.sendNtfyNotification({
      eventType: 'OUTSTANDING_BREAKOUT',
      eventId,
      title,
      message,
      priority: 'urgent',
      tags: ['rocket', 'chart_with_upwards_trend', 'fire'],
      symbol: data.symbol,
      dedupeTtlMs: 24 * 60 * 60 * 1000
    });
  }

  // =========================================================================
  // 10. CRITICAL BEARISH REVERSAL CANDLESTICK ALERT
  // =========================================================================
  public async sendBearishCandleAlert(data: {
    symbol: string;
    name?: string;
    sector?: string;
    currentPrice?: number;
    patternName: string;
    patternSummary?: string;
  }): Promise<NtfyAlertRecord | null> {
    const cleanSym = (data.symbol || '').replace('.PSX', '').toUpperCase().trim();
    
    // Strict Anti-Repeat Check: 1 bearish candle alert per stock per day
    const todayStr = new Date().toISOString().split('T')[0];
    const eventId = `BEARISH_CANDLE_${cleanSym}_${todayStr}`;
    if (this.isEventDuplicate(eventId, 24 * 60 * 60 * 1000)) {
      console.log(`[NTFY DEDUPE] Bearish candle alert for ${cleanSym} already dispatched today. Suppressing repeat.`);
      return null;
    }

    const fullName = data.name || getStockFullName(cleanSym);
    const sector = data.sector || getStockSector(cleanSym);
    const summary = data.patternSummary || 'Strong downside reversal pressure detected.';
    const isIdx = isPsxIndex(data.symbol);
    const priceLine = data.currentPrice ? `Current Price: ${data.currentPrice.toFixed(2)}` : '';

    // Strict format requested:
    // Bearish Reversal Alert
    // Stock symbol
    // Full name
    // Sector
    // Current Price
    // Candlestick Pattern name with brief summary
    const message = [
      `Bearish Reversal Alert`,
      `Symbol: ${cleanSym}`,
      `Company: ${fullName}`,
      `Sector: ${sector}`,
      priceLine,
      `Pattern: ${data.patternName} (${summary})`
    ].filter(Boolean).join('\n');

    const title = `Bearish Alert: ${cleanSym}`;

    return this.sendNtfyNotification({
      eventType: 'BEARISH_CANDLE',
      eventId,
      title,
      message,
      priority: 'high',
      tags: ['chart_with_downwards_trend', 'warning'],
      symbol: data.symbol,
      dedupeTtlMs: 24 * 60 * 60 * 1000
    });
  }

  // =========================================================================
  // 11. DAY CLOSING SUMMARY NOTIFICATION
  // =========================================================================
  public async sendDayClosingSummaryAlert(data: {
    indexPoints: number;
    changePoints: number;
    changePercent: number;
  }): Promise<NtfyAlertRecord | null> {
    const todayStr = new Date().toISOString().split('T')[0];
    const eventId = `DAY_CLOSING_${todayStr}`;
    if (this.isEventDuplicate(eventId, 12 * 60 * 60 * 1000)) {
      console.log(`[NTFY DEDUPE] Day closing summary for ${todayStr} already dispatched. Suppressing repeat.`);
      return null;
    }

    const valFormatted = data.indexPoints.toFixed(2).replace(/,/g, '');
    const pts = data.changePoints;
    const pointsLine = pts >= 0 
      ? `Up +${Math.abs(pts).toFixed(2)}` 
      : `Down -${Math.abs(pts).toFixed(2)}`;
    const sign = data.changePercent >= 0 ? '+' : '';
    const pctLine = `Percentage: ${sign}${data.changePercent.toFixed(2)}%`;

    // Strict format requested:
    // Day Closing Summary
    // Kse 100 Index......
    // Up ..... Or down .....
    // Percentage
    const message = [
      `Day Closing Summary`,
      `KSE 100 Index ${valFormatted}`,
      pointsLine,
      pctLine
    ].join('\n');

    const title = `PSX Day Closing Summary`;

    return this.sendNtfyNotification({
      eventType: 'DAY_CLOSING_SUMMARY',
      eventId,
      title,
      message,
      priority: 'high',
      tags: ['trophy', 'bar_chart'],
      symbol: 'KSE100.PSX',
      dedupeTtlMs: 12 * 60 * 60 * 1000
    });
  }

  // =========================================================================
  // 12. TOP 5 VOLUME LEADERS NOTIFICATION
  // =========================================================================
  public async sendTop5VolumeLeadersAlert(leaders: {
    symbol: string;
    volume: number;
    price: number;
  }[]): Promise<NtfyAlertRecord | null> {
    const todayStr = new Date().toISOString().split('T')[0];
    const eventId = `TOP5_VOL_${todayStr}`;
    if (this.isEventDuplicate(eventId, 12 * 60 * 60 * 1000)) {
      console.log(`[NTFY DEDUPE] Top 5 volume leaders for ${todayStr} already dispatched. Suppressing repeat.`);
      return null;
    }

    const top5 = leaders.slice(0, 5);
    const leaderLines = top5.map((item, idx) => {
      const cleanSym = item.symbol.replace('.PSX', '').toUpperCase();
      const volStr = item.volume >= 1000000 
        ? `${(item.volume / 1000000).toFixed(2).replace(/,/g, '')}M` 
        : item.volume.toFixed(2).replace(/,/g, '');
      const isIdx = isPsxIndex(item.symbol);
      const priceStr = `${item.price.toFixed(2)}`;
      return `${idx + 1}. ${cleanSym} — Volume: ${volStr} — Price: ${priceStr}`;
    });

    // Strict format requested:
    // Top 5 Volume Leaders
    // 1 stock symbol....volume ....price
    // 2.so on
    // 3
    // 4
    // 5
    const message = [
      `Top 5 Volume Leaders`,
      ...leaderLines
    ].join('\n');

    const title = `Top 5 Volume Leaders`;

    return this.sendNtfyNotification({
      eventType: 'TOP_5_VOLUME',
      eventId,
      title,
      message,
      priority: 'high',
      tags: ['fire', 'chart_with_upwards_trend'],
      dedupeTtlMs: 12 * 60 * 60 * 1000
    });
  }

  // =========================================================================
  // 13. ADMIN DIRECT TEST DISPATCHER (IMMEDIATE PRIORITY)
  // =========================================================================
  public async dispatchTestAlert(type: 'SCANNER' | 'PRICE' | 'VOLUME_20D' | 'HOURLY_INDEX' | 'BREAKOUT' | 'BEARISH_CANDLE' | 'DAY_CLOSE' | 'TOP_5_VOL' | 'LOGIN' | 'LOGOUT' | 'SYSTEM_ERROR' | 'TEST' = 'TEST'): Promise<NtfyAlertRecord> {
    console.log(`[ADMIN_NTFY_TEST] Admin ${ADMIN_NAME} triggered test: ${type}`);
    const { time, date } = getPktTimeAndDate();
    
    if (type === 'SCANNER') {
      return this.sendNtfyNotification({
        eventType: 'SCANNER_80PCT',
        title: `MEBL — 80% Alert`,
        message: `MEBL\nMeezan Bank Limited\nIslamic Banking\nCurrent Price: 316.80\nAlert for Up price`,
        priority: 'high',
        tags: ['radar', 'chart_with_upwards_trend'],
        symbol: 'MEBL.PSX',
        score: 86,
        isAdminTest: true
      });
    } else if (type === 'PRICE') {
      return this.sendNtfyNotification({
        eventType: 'PRICE_ALERT',
        title: `Price Alert: OGDC`,
        message: `OGDC\nOil & Gas Development Company\nOil & Gas Exploration\nCurrent Price: 142.50 (Target: 145.00)\nPrice Alert`,
        priority: 'high',
        tags: ['bell', 'warning'],
        symbol: 'OGDC.PSX',
        isAdminTest: true
      });
    } else if (type === 'VOLUME_20D') {
      return this.sendNtfyNotification({
        eventType: 'VOLUME_20D_AVG',
        title: `Volume Surge: OGDC`,
        message: `Volume Above 20 Days Average\nOGDC\nOil & Gas Development Company\nCurrent Price: 142.50\nVolume: 15.42M\n20D Avg: 8.12M\nSurge: +89.9%`,
        priority: 'high',
        tags: ['chart_with_upwards_trend', 'bar_chart'],
        symbol: 'OGDC.PSX',
        isAdminTest: true
      });
    } else if (type === 'HOURLY_INDEX') {
      return this.sendNtfyNotification({
        eventType: 'HOURLY_INDEX',
        title: `KSE 100 Hourly Update`,
        message: `KSE 100 Index value 114,350.25 at time ${time}\nUp +345.50`,
        priority: 'default',
        tags: ['chart', 'stopwatch'],
        symbol: 'KSE100.PSX',
        isAdminTest: true
      });
    } else if (type === 'BREAKOUT') {
      return this.sendNtfyNotification({
        eventType: 'OUTSTANDING_BREAKOUT',
        title: `Breakout Alert: MEBL`,
        message: `Outstanding Breakout Alert\nSymbol: MEBL\nCompany: Meezan Bank Limited\nSector: Islamic Banking\nOpen Price: 305.00\nLast Day Close: 306.50\nBreakout Level: 310.00\nCurrent Price: 316.80\nTime: ${time} Date: ${date}`,
        priority: 'urgent',
        tags: ['rocket', 'chart_with_upwards_trend', 'fire'],
        symbol: 'MEBL.PSX',
        isAdminTest: true
      });
    } else if (type === 'BEARISH_CANDLE') {
      return this.sendNtfyNotification({
        eventType: 'BEARISH_CANDLE',
        title: `Bearish Alert: OGDC`,
        message: `Bearish Reversal Alert\nSymbol: OGDC\nCompany: Oil & Gas Development Company\nSector: Oil & Gas Exploration\nCurrent Price: 142.50\nPattern: Bearish Engulfing (Strong selling pressure breaking below support)`,
        priority: 'high',
        tags: ['chart_with_downwards_trend', 'warning'],
        symbol: 'OGDC.PSX',
        isAdminTest: true
      });
    } else if (type === 'DAY_CLOSE') {
      return this.sendNtfyNotification({
        eventType: 'DAY_CLOSING_SUMMARY',
        title: `PSX Day Closing Summary`,
        message: `Day Closing Summary\nKSE 100 Index 114,890.40\nUp +680.20\nPercentage: +0.60%`,
        priority: 'high',
        tags: ['trophy', 'bar_chart'],
        symbol: 'KSE100.PSX',
        isAdminTest: true
      });
    } else if (type === 'TOP_5_VOL') {
      return this.sendNtfyNotification({
        eventType: 'TOP_5_VOLUME',
        title: `Top 5 Volume Leaders`,
        message: `Top 5 Volume Leaders\n1. KEL — Volume: 45.20M — Price: 5.12\n2. CNERGY — Volume: 38.60M — Price: 4.85\n3. WTL — Volume: 29.40M — Price: 1.34\n4. OGDC — Volume: 18.25M — Price: 142.50\n5. PRL — Volume: 15.80M — Price: 31.20`,
        priority: 'high',
        tags: ['fire', 'chart_with_upwards_trend'],
        isAdminTest: true
      });
    } else if (type === 'LOGIN') {
      return this.sendNtfyNotification({
        eventType: 'LOGIN',
        title: `User Login`,
        message: `User Login at time ${time} date ${date}`,
        priority: 'default',
        tags: ['key'],
        isAdminTest: true
      });
    } else if (type === 'LOGOUT') {
      return this.sendNtfyNotification({
        eventType: 'LOGOUT',
        title: `User Logout`,
        message: `User Log out at time ${time} Date ${date}`,
        priority: 'default',
        tags: ['door'],
        isAdminTest: true
      });
    } else if (type === 'SYSTEM_ERROR') {
      return this.sendNtfyNotification({
        eventType: 'SYSTEM_ERROR',
        title: `System Error`,
        message: `Feed-Engine: Connection timeout`,
        priority: 'urgent',
        tags: ['warning'],
        isAdminTest: true
      });
    } else {
      return this.sendNtfyNotification({
        eventType: 'TEST',
        title: `System Test`,
        message: `Push notification active at ${time} date ${date}`,
        priority: 'high',
        tags: ['white_check_mark'],
        isAdminTest: true
      });
    }
  }
}

export const ntfyNotifier = NtfyNotifier.getInstance();
