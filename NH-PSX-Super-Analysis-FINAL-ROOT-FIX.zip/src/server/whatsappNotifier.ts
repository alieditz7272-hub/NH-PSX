import fs from 'fs';
import path from 'path';
import { UserProfile } from '../types/subscription';
import { isPsxIndex } from '../utils/symbol';

export interface WhatsAppGatewayConfig {
  adminPhone: string;
  adminIntlPhone: string;
  adminName: string;
  provider: 'CALLMEBOT' | 'OPEN_WA' | 'GREEN_API' | 'ULTRAMSG' | 'TELEGRAM' | 'CUSTOM_WEBHOOK' | 'DIRECT_LINK';
  callMeBotApiKey?: string;
  openWaServerUrl?: string;
  openWaApiKey?: string;
  openWaSessionId?: string;
  greenApiInstanceId?: string;
  greenApiToken?: string;
  ultraMsgInstanceId?: string;
  ultraMsgToken?: string;
  telegramBotToken?: string;
  telegramChatId?: string;
  customWebhookUrl?: string;
  customWebhookAuthHeader?: string;
  autoDispatchEnabled: boolean;
  lastDispatchResult?: string;
  lastDispatchTime?: number;
}

export interface WhatsAppAlertRecord {
  id: string;
  eventType: 'LOGIN' | 'LOGOUT' | 'PRICE_ALERT' | 'SCANNER_80PCT' | 'CUSTOM' | 'TEST';
  userId: string;
  userName: string;
  username: string;
  userPhone?: string;
  userEmail?: string;
  userType: 'GUEST_VIP' | 'PAID_PRO' | 'ADMIN' | 'STANDARD_USER';
  userPlan?: string;
  timestamp: number;
  formattedPktTime: string;
  messageText: string;
  recipientPhone: string;
  recipientName: string;
  whatsappDirectUrl: string;
  dispatchStatus: 'DISPATCHED' | 'LOGGED' | 'FAILED' | 'DELIVERED_VIA_CLOUD_BOT';
  dispatchNote?: string;
  symbol?: string;
  score?: number;
  gatewayResponse?: string;
}

export const ADMIN_WHATSAPP_NUMBER = '03009412177';
export const ADMIN_WHATSAPP_INTL = '923009412177';
export const ADMIN_NAME = 'Nadeem Hassan';

const DATA_DIR = path.join(process.cwd(), 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'whatsapp_gateway_config.json');
const HISTORY_FILE = path.join(DATA_DIR, 'whatsapp_alerts_history.json');

// Helper to format date & time strictly in Pakistan Standard Time (PKT, UTC+5)
export function getFormattedPktDateTime(timestamp: number = Date.now()): string {
  try {
    const d = new Date(timestamp);
    return new Intl.DateTimeFormat('en-PK', {
      timeZone: 'Asia/Karachi',
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(d);
  } catch (e) {
    return new Date(timestamp).toLocaleString('en-US');
  }
}

export class WhatsAppNotifier {
  private static instance: WhatsAppNotifier;
  private config: WhatsAppGatewayConfig = {
    adminPhone: ADMIN_WHATSAPP_NUMBER,
    adminIntlPhone: ADMIN_WHATSAPP_INTL,
    adminName: ADMIN_NAME,
    provider: 'CALLMEBOT',
    callMeBotApiKey: process.env.CALLMEBOT_API_KEY || '',
    customWebhookUrl: process.env.WHATSAPP_WEBHOOK_URL || '',
    autoDispatchEnabled: true
  };
  private history: WhatsAppAlertRecord[] = [];

  private constructor() {
    this.ensureDataDir();
    this.loadConfig();
    this.loadHistory();
  }

  public static getInstance(): WhatsAppNotifier {
    if (!WhatsAppNotifier.instance) {
      WhatsAppNotifier.instance = new WhatsAppNotifier();
    }
    return WhatsAppNotifier.instance;
  }

  private ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
      try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      } catch (e) {
        console.error('Failed to create data directory for WhatsApp store:', e);
      }
    }
  }

  private loadConfig() {
    try {
      if (fs.existsSync(CONFIG_FILE)) {
        const raw = fs.readFileSync(CONFIG_FILE, 'utf-8');
        const loaded = JSON.parse(raw);
        this.config = { ...this.config, ...loaded };
      }
    } catch (e) {
      console.warn('Failed to load WhatsApp config, using defaults:', e);
    }
  }

  public saveConfig(newConfig: Partial<WhatsAppGatewayConfig>): WhatsAppGatewayConfig {
    this.config = { ...this.config, ...newConfig };
    try {
      this.ensureDataDir();
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(this.config, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to save WhatsApp config to disk:', e);
    }
    return this.config;
  }

  public getConfig(): WhatsAppGatewayConfig {
    return this.config;
  }

  private loadHistory() {
    try {
      if (fs.existsSync(HISTORY_FILE)) {
        const raw = fs.readFileSync(HISTORY_FILE, 'utf-8');
        this.history = JSON.parse(raw);
      }
    } catch (e) {
      this.history = [];
    }
  }

  private saveHistory() {
    try {
      this.ensureDataDir();
      fs.writeFileSync(HISTORY_FILE, JSON.stringify(this.history.slice(0, 300), null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to save WhatsApp history:', e);
    }
  }

  // Generate WhatsApp link URL
  public buildDirectUrl(messageText: string): string {
    const intlPhone = this.config.adminIntlPhone || ADMIN_WHATSAPP_INTL;
    return `https://api.whatsapp.com/send?phone=${intlPhone}&text=${encodeURIComponent(messageText)}`;
  }

  // Format WhatsApp message for User Login
  public generateLoginAlertMessage(user: UserProfile, pktTime: string): string {
    const isGuest = user.isGuest || user.role !== 'ADMIN' && (!user.plan || user.plan === 'MONTHLY') && user.guestNotes;
    const userCategory = user.role === 'ADMIN' 
      ? '👑 System Administrator' 
      : user.isGuest 
      ? '⭐ VIP Guest User (Free Access Pass)' 
      : `💎 Paid Pro Subscriber (${user.plan || 'Active Pro'})`;

    const displayUsername = user.username || user.email || 'N/A';
    const displayPhone = user.phone || 'N/A';

    let msg = `🔔 *PSX TERMINAL — USER LOGIN ALERT*\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `👤 *Username:* ${displayUsername}\n`;
    msg += `📛 *Full Name:* ${user.name}\n`;
    msg += `🏷️ *Account Type:* ${userCategory}\n`;
    msg += `📱 *Phone / Contact:* ${displayPhone}\n`;
    msg += `📧 *Email:* ${user.email || 'N/A'}\n`;
    msg += `⏰ *Login Time:* ${pktTime} (PKT)\n`;
    msg += `🟢 *Status:* LOGGED IN TO LIVE TERMINAL\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `*Nadeem Hassan Stock Trading Pro Terminal (24/7 Cloud Background)*`;

    return msg;
  }

  // Format WhatsApp message for User Logout
  public generateLogoutAlertMessage(user: UserProfile, pktTime: string): string {
    const isGuest = user.isGuest || user.role !== 'ADMIN' && (!user.plan || user.plan === 'MONTHLY') && user.guestNotes;
    const userCategory = user.role === 'ADMIN' 
      ? '👑 System Administrator' 
      : isGuest 
      ? '⭐ VIP Guest User' 
      : `💎 Paid Pro Subscriber (${user.plan || 'Pro'})`;

    const displayUsername = user.username || user.email || 'N/A';

    let msg = `🚪 *PSX TERMINAL — USER LOGOUT ALERT*\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `👤 *Username:* ${displayUsername}\n`;
    msg += `📛 *Full Name:* ${user.name}\n`;
    msg += `🏷️ *Account Type:* ${userCategory}\n`;
    msg += `⏰ *Logout Time:* ${pktTime} (PKT)\n`;
    msg += `🔴 *Status:* USER LOGGED OUT\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `*Nadeem Hassan Stock Trading Pro Terminal (24/7 Cloud Background)*`;

    return msg;
  }

  // Format WhatsApp message for Price / Index / Volume Alert
  public generatePriceAlertMessage(params: {
    symbol: string;
    name: string;
    type: string;
    threshold: number;
    currentPrice: number;
    change?: number;
    changePercent?: number;
    reason: string;
    spokenMessage?: string;
    pktTime: string;
    isIndex?: boolean;
  }): string {
    const isIndex = params.isIndex || params.symbol.startsWith('KSE') || params.symbol.startsWith('ALLSHR') || params.symbol.startsWith('KMI');
    const assetCategory = isIndex ? '📊 PSX MARKET INDEX' : '📈 PSX STOCK ASSET';
    const conditionLabel = 
      params.type === 'PRICE_ABOVE' ? '🔼 PRICE RESISTANCE BREAKOUT (ABOVE)' :
      params.type === 'PRICE_BELOW' ? '🔽 PRICE SUPPORT BREAKDOWN (BELOW)' :
      params.type === 'TARGET_HIT' ? '🎯 PROFIT TARGET REACHED' :
      params.type === 'STOP_LOSS_HIT' ? '🛑 STOP LOSS TRIGGERED' :
      params.type === 'VOLUME_SPIKE' ? '⚡ INSTITUTIONAL VOLUME SURGE' : params.type;

    const chgSign = (params.changePercent || 0) >= 0 ? '+' : '';
    const chgText = params.changePercent !== undefined ? ` (${chgSign}${(params.changePercent).toFixed(2)}%)` : '';

    const isIdx = isPsxIndex(params.symbol);
    let msg = `🚨 *PSX LIVE ALERT HIT — ADMIN NOTIFICATION*\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `${assetCategory}: *${params.symbol}* (${params.name})\n`;
    msg += `🎯 *Alert Type:* ${conditionLabel}\n`;
    msg += `💵 *Current Price:* ${params.currentPrice.toFixed(2)}${chgText}\n`;
    msg += `🎯 *Trigger Threshold:* ${params.threshold.toFixed(2)}\n`;
    msg += `⏰ *Trigger Time:* ${params.pktTime} (PKT)\n`;
    msg += `📝 *Reason:* ${params.reason}\n`;
    if (params.spokenMessage) {
      msg += `📢 *Voice Note:* "${params.spokenMessage}"\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `*Nadeem Hassan Stock Trading Pro Terminal (24/7 Cloud Background)*`;

    return msg;
  }

  // Format WhatsApp message for 80% Win-Rate Scanner Hit
  public generateScanner80PctAlertMessage(params: {
    symbol: string;
    name: string;
    score: number;
    bullishCount: number;
    totalIndicators: number;
    price: number;
    change?: number;
    changePercent?: number;
    volume?: number;
    logics: string[];
    entryZone: string;
    targetPrice: number;
    stopLossPrice: number;
    pktTime: string;
  }): string {
    const chgSign = (params.changePercent || 0) >= 0 ? '+' : '';
    const volFormatted = params.volume ? `${(params.volume / 1000000).toFixed(2)}M shares` : 'Active';

    const isIdx = isPsxIndex(params.symbol);
    let msg = `🔥 *PSX 80% HIGH-PROBABILITY WIN-RATE SCANNER HIT!*\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `🎯 *Stock:* *${params.symbol}* (${params.name})\n`;
    msg += `📊 *Confluence Score:* *${params.score}% WIN PROBABILITY* (${params.bullishCount}/${params.totalIndicators} Indicators Bullish)\n`;
    msg += `💵 *Live Price:* ${params.price.toFixed(2)} (${chgSign}${(params.changePercent || 0).toFixed(2)}%)\n`;
    msg += `📦 *Traded Volume:* ${volFormatted}\n`;
    msg += `⏰ *Detection Time:* ${params.pktTime} (PKT)\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `🧠 *KEY TECHNICAL LOGICS & REASONS:*\n`;
    
    const displayLogics = params.logics.slice(0, 6);
    displayLogics.forEach(l => {
      msg += `${l}\n`;
    });

    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `💡 *ACTIONABLE TRADE SETUP (RISK/REWARD):*\n`;
    msg += `• 🟢 *Entry Zone:* ${params.entryZone}\n`;
    msg += `• 🎯 *Target Resistance:* ${params.targetPrice.toFixed(2)} (+${(((params.targetPrice - params.price) / params.price) * 100).toFixed(1)}%)\n`;
    msg += `• 🛑 *Stop Loss Floor:* ${params.stopLossPrice.toFixed(2)} (-${(((params.price - params.stopLossPrice) / params.price) * 100).toFixed(1)}%)\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `*Nadeem Hassan Stock Trading Pro Terminal (24/7 Cloud Background Engine)*`;

    return msg;
  }

  // Main HTTP / Gateway Cloud Dispatcher
  public async executeCloudDispatch(record: WhatsAppAlertRecord): Promise<{ success: boolean; note: string }> {
    const config = this.config;
    const phone = config.adminIntlPhone || ADMIN_WHATSAPP_INTL;
    const formattedPlusPhone = phone.startsWith('+') ? phone : `+${phone}`;

    let success = false;
    let note = '';

    try {
      // 1. CallMeBot Integration (Zero-Config / Free Personal WhatsApp Bot API)
      if (config.provider === 'CALLMEBOT' && config.callMeBotApiKey) {
        const encodedText = encodeURIComponent(record.messageText);
        // CallMeBot supports both +34 623 78 64 49 & +34 623 75 84 18 bot gateways
        const url = `https://api.callmebot.com/whatsapp.php?phone=${encodeURIComponent(formattedPlusPhone)}&text=${encodedText}&apikey=${config.callMeBotApiKey.trim()}`;
        
        const res = await fetch(url, { method: 'GET' });
        const resText = await res.text();
        
        if (res.ok && (resText.includes('Message queued') || resText.includes('OK') || resText.includes('success'))) {
          success = true;
          note = `Delivered to WhatsApp (+${phone}) via CallMeBot API Cloud Gateway.`;
        } else {
          note = `CallMeBot Response: ${resText.substring(0, 100)}`;
        }
      } 
      // 2. Open-WA (wa-automate / open-wa.org REST API / port 2785)
      else if (config.provider === 'OPEN_WA') {
        const rawUrl = (config.openWaServerUrl || 'http://localhost:2785').trim().replace(/\/+$/, '');
        const targetChatId = `${phone.replace('+', '')}@c.us`;
        const apiKey = (config.openWaApiKey || '').trim();

        const headers: Record<string, string> = {
          'Content-Type': 'application/json'
        };
        if (apiKey) {
          headers['api_key'] = apiKey;
          headers['x-api-key'] = apiKey;
          headers['Authorization'] = `Bearer ${apiKey}`;
        }

        const bodyData = {
          chatId: targetChatId,
          text: record.messageText,
          args: {
            to: targetChatId,
            content: record.messageText
          }
        };

        const endpoints = [
          `${rawUrl}/api/sendText`,
          `${rawUrl}/sendText`,
          `${rawUrl}/api/sessions/${config.openWaSessionId || 'default'}/messages/send-text`
        ];

        let delivered = false;
        let lastErr = '';

        for (const ep of endpoints) {
          try {
            const urlWithKey = apiKey ? `${ep}?api_key=${encodeURIComponent(apiKey)}` : ep;
            const res = await fetch(urlWithKey, {
              method: 'POST',
              headers,
              body: JSON.stringify(bodyData)
            });
            const resText = await res.text();
            if (res.ok) {
              delivered = true;
              note = `Delivered to WhatsApp (+${phone}) via Open-WA Gateway.`;
              break;
            } else {
              lastErr = `Open-WA (${ep}) returned HTTP ${res.status}: ${resText.substring(0, 100)}`;
            }
          } catch (err: any) {
            lastErr = `Open-WA connection error (${ep}): ${err.message || err}`;
          }
        }

        if (delivered) {
          success = true;
        } else {
          note = lastErr || 'Failed to connect to Open-WA server';
        }
      }
      // 3. Green-API Integration
      else if (config.provider === 'GREEN_API' && config.greenApiInstanceId && config.greenApiToken) {
        const url = `https://api.green-api.com/waInstance${config.greenApiInstanceId.trim()}/sendMessage/${config.greenApiToken.trim()}`;
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chatId: `${phone.replace('+', '')}@c.us`,
            message: record.messageText
          })
        });
        const data = await res.json();
        if (res.ok && data.idMessage) {
          success = true;
          note = `Delivered via Green-API Message ID: ${data.idMessage}`;
        } else {
          note = `Green-API Error: ${JSON.stringify(data)}`;
        }
      }
      // 3. UltraMsg Integration
      else if (config.provider === 'ULTRAMSG' && config.ultraMsgInstanceId && config.ultraMsgToken) {
        const url = `https://api.ultramsg.com/${config.ultraMsgInstanceId.trim()}/messages/chat`;
        const params = new URLSearchParams();
        params.append('token', config.ultraMsgToken.trim());
        params.append('to', formattedPlusPhone);
        params.append('body', record.messageText);

        const res = await fetch(url, {
          method: 'POST',
          body: params
        });
        const data = await res.json();
        if (res.ok && data.sent === 'true') {
          success = true;
          note = `Delivered via UltraMsg Message ID: ${data.id}`;
        } else {
          note = `UltraMsg Error: ${JSON.stringify(data)}`;
        }
      }
      // 4. Telegram Instant Bot Gateway
      else if (config.provider === 'TELEGRAM' && config.telegramBotToken && config.telegramChatId) {
        const url = `https://api.telegram.org/bot${config.telegramBotToken.trim()}/sendMessage`;
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: config.telegramChatId.trim(),
            text: record.messageText
          })
        });
        const data = await res.json();
        if (res.ok && data.ok) {
          success = true;
          note = `Instant Delivery to Telegram Chat (${config.telegramChatId}) via Bot API.`;
        } else {
          note = `Telegram Error: ${data.description || JSON.stringify(data)}`;
        }
      }
      // 5. Custom Webhook / Cloud Function Gateway
      else if (config.customWebhookUrl) {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (config.customWebhookAuthHeader) {
          headers['Authorization'] = config.customWebhookAuthHeader;
        }
        const res = await fetch(config.customWebhookUrl, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            recipient: phone,
            recipientPhone: config.adminPhone || ADMIN_WHATSAPP_NUMBER,
            message: record.messageText,
            eventType: record.eventType,
            username: record.username,
            userName: record.userName,
            symbol: record.symbol,
            score: record.score,
            timestamp: record.timestamp,
            pktTime: record.formattedPktTime
          })
        });
        if (res.ok) {
          success = true;
          note = `Dispatched via custom webhook gateway (${res.status} OK)`;
        } else {
          note = `Custom Webhook status: ${res.status}`;
        }
      } else {
        note = `Direct WhatsApp 1-Click Launch Ready (+${phone}). For automatic background bot delivery, activate Free CallMeBot key or Webhook.`;
      }
    } catch (e: any) {
      note = `Gateway communication error: ${e.message || e}`;
    }

    this.config.lastDispatchResult = note;
    this.config.lastDispatchTime = Date.now();
    this.saveConfig({});

    return { success, note };
  }

  // 1. Dispatch Login Alert
  public async dispatchLoginAlert(user: UserProfile): Promise<WhatsAppAlertRecord> {
    const now = Date.now();
    const pktTime = getFormattedPktDateTime(now);
    const messageText = this.generateLoginAlertMessage(user, pktTime);
    const directUrl = this.buildDirectUrl(messageText);

    const userType = user.role === 'ADMIN' ? 'ADMIN' : user.isGuest ? 'GUEST_VIP' : user.subscriptionStatus === 'ACTIVE' ? 'PAID_PRO' : 'STANDARD_USER';

    const alertRecord: WhatsAppAlertRecord = {
      id: 'wa_login_' + Math.random().toString(36).substring(2, 9) + '_' + now.toString(36),
      eventType: 'LOGIN',
      userId: user.id,
      userName: user.name,
      username: user.username || user.email || user.name,
      userPhone: user.phone,
      userEmail: user.email,
      userType,
      userPlan: user.plan,
      timestamp: now,
      formattedPktTime: pktTime,
      messageText,
      recipientPhone: this.config.adminPhone || ADMIN_WHATSAPP_NUMBER,
      recipientName: this.config.adminName || ADMIN_NAME,
      whatsappDirectUrl: directUrl,
      dispatchStatus: 'DISPATCHED',
      dispatchNote: `Instant login notification queued for ${this.config.adminName} (${this.config.adminPhone})`
    };

    const cloudRes = await this.executeCloudDispatch(alertRecord);
    if (cloudRes.success) {
      alertRecord.dispatchStatus = 'DELIVERED_VIA_CLOUD_BOT';
      alertRecord.gatewayResponse = cloudRes.note;
    } else {
      alertRecord.dispatchNote = cloudRes.note;
    }

    this.history.unshift(alertRecord);
    this.saveHistory();

    console.log(`[WHATSAPP ALERT] User LOGIN triggered for ${user.name} -> Dispatched to ${this.config.adminPhone}`);
    return alertRecord;
  }

  // 2. Dispatch Logout Alert
  public async dispatchLogoutAlert(user: UserProfile): Promise<WhatsAppAlertRecord> {
    const now = Date.now();
    const pktTime = getFormattedPktDateTime(now);
    const messageText = this.generateLogoutAlertMessage(user, pktTime);
    const directUrl = this.buildDirectUrl(messageText);

    const userType = user.role === 'ADMIN' ? 'ADMIN' : user.isGuest ? 'GUEST_VIP' : user.subscriptionStatus === 'ACTIVE' ? 'PAID_PRO' : 'STANDARD_USER';

    const alertRecord: WhatsAppAlertRecord = {
      id: 'wa_logout_' + Math.random().toString(36).substring(2, 9) + '_' + now.toString(36),
      eventType: 'LOGOUT',
      userId: user.id,
      userName: user.name,
      username: user.username || user.email || user.name,
      userPhone: user.phone,
      userEmail: user.email,
      userType,
      userPlan: user.plan,
      timestamp: now,
      formattedPktTime: pktTime,
      messageText,
      recipientPhone: this.config.adminPhone || ADMIN_WHATSAPP_NUMBER,
      recipientName: this.config.adminName || ADMIN_NAME,
      whatsappDirectUrl: directUrl,
      dispatchStatus: 'DISPATCHED',
      dispatchNote: `Instant logout notification queued for ${this.config.adminName} (${this.config.adminPhone})`
    };

    const cloudRes = await this.executeCloudDispatch(alertRecord);
    if (cloudRes.success) {
      alertRecord.dispatchStatus = 'DELIVERED_VIA_CLOUD_BOT';
      alertRecord.gatewayResponse = cloudRes.note;
    } else {
      alertRecord.dispatchNote = cloudRes.note;
    }

    this.history.unshift(alertRecord);
    this.saveHistory();

    console.log(`[WHATSAPP ALERT] User LOGOUT triggered for ${user.name} -> Dispatched to ${this.config.adminPhone}`);
    return alertRecord;
  }

  // 3. Dispatch Price / Index / Volume Alert
  public async dispatchPriceAlert(params: {
    symbol: string;
    name: string;
    type: string;
    threshold: number;
    currentPrice: number;
    change?: number;
    changePercent?: number;
    reason: string;
    spokenMessage?: string;
    isIndex?: boolean;
  }): Promise<WhatsAppAlertRecord> {
    const now = Date.now();
    const pktTime = getFormattedPktDateTime(now);
    const messageText = this.generatePriceAlertMessage({ ...params, pktTime });
    const directUrl = this.buildDirectUrl(messageText);

    const alertRecord: WhatsAppAlertRecord = {
      id: 'wa_price_' + params.symbol.replace(/[^a-zA-Z0-9]/g, '') + '_' + now.toString(36),
      eventType: 'PRICE_ALERT',
      userId: 'system_admin',
      userName: this.config.adminName || ADMIN_NAME,
      username: 'admin_nadeem',
      userPhone: this.config.adminPhone || ADMIN_WHATSAPP_NUMBER,
      userType: 'ADMIN',
      timestamp: now,
      formattedPktTime: pktTime,
      messageText,
      recipientPhone: this.config.adminPhone || ADMIN_WHATSAPP_NUMBER,
      recipientName: this.config.adminName || ADMIN_NAME,
      whatsappDirectUrl: directUrl,
      dispatchStatus: 'DISPATCHED',
      dispatchNote: `Price Alert for ${params.symbol} queued for ${this.config.adminName} (${this.config.adminPhone})`,
      symbol: params.symbol
    };

    const cloudRes = await this.executeCloudDispatch(alertRecord);
    if (cloudRes.success) {
      alertRecord.dispatchStatus = 'DELIVERED_VIA_CLOUD_BOT';
      alertRecord.gatewayResponse = cloudRes.note;
    } else {
      alertRecord.dispatchNote = cloudRes.note;
    }

    this.history.unshift(alertRecord);
    this.saveHistory();

    console.log(`[WHATSAPP ALERT] Price Alert for ${params.symbol} hit -> Dispatched to Admin ${this.config.adminPhone}`);
    return alertRecord;
  }

  // 4. Dispatch 80% Scanner Alert
  public async dispatchScanner80PctAlert(params: {
    symbol: string;
    name: string;
    score: number;
    bullishCount: number;
    totalIndicators: number;
    price: number;
    change?: number;
    changePercent?: number;
    volume?: number;
    logics: string[];
    entryZone: string;
    targetPrice: number;
    stopLossPrice: number;
  }): Promise<WhatsAppAlertRecord> {
    const now = Date.now();
    const pktTime = getFormattedPktDateTime(now);
    const messageText = this.generateScanner80PctAlertMessage({ ...params, pktTime });
    const directUrl = this.buildDirectUrl(messageText);

    const alertRecord: WhatsAppAlertRecord = {
      id: 'wa_scan80_' + params.symbol.replace(/[^a-zA-Z0-9]/g, '') + '_' + now.toString(36),
      eventType: 'SCANNER_80PCT',
      userId: 'system_admin',
      userName: this.config.adminName || ADMIN_NAME,
      username: 'admin_nadeem',
      userPhone: this.config.adminPhone || ADMIN_WHATSAPP_NUMBER,
      userType: 'ADMIN',
      timestamp: now,
      formattedPktTime: pktTime,
      messageText,
      recipientPhone: this.config.adminPhone || ADMIN_WHATSAPP_NUMBER,
      recipientName: this.config.adminName || ADMIN_NAME,
      whatsappDirectUrl: directUrl,
      dispatchStatus: 'DISPATCHED',
      dispatchNote: `80% Scanner Alert for ${params.symbol} (${params.score}%) queued for ${this.config.adminName} (${this.config.adminPhone})`,
      symbol: params.symbol,
      score: params.score
    };

    const cloudRes = await this.executeCloudDispatch(alertRecord);
    if (cloudRes.success) {
      alertRecord.dispatchStatus = 'DELIVERED_VIA_CLOUD_BOT';
      alertRecord.gatewayResponse = cloudRes.note;
    } else {
      alertRecord.dispatchNote = cloudRes.note;
    }

    this.history.unshift(alertRecord);
    this.saveHistory();

    console.log(`[WHATSAPP ALERT] 80% Scanner hit for ${params.symbol} (${params.score}%) -> Dispatched to Admin ${this.config.adminPhone}`);
    return alertRecord;
  }

  // 5. Send Test WhatsApp Alert
  public async dispatchTestAlert(): Promise<WhatsAppAlertRecord> {
    const now = Date.now();
    const pktTime = getFormattedPktDateTime(now);
    
    let messageText = `🧪 *PSX TERMINAL — WHATSAPP NOTIFICATION TEST*\n`;
    messageText += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    messageText += `✅ *Status:* WhatsApp Notification Engine is ACTIVE & ONLINE\n`;
    messageText += `📱 *Target Admin Phone:* ${this.config.adminPhone || ADMIN_WHATSAPP_NUMBER} (${this.config.adminName || ADMIN_NAME})\n`;
    messageText += `⏰ *Timestamp:* ${pktTime} (PKT)\n`;
    messageText += `🔔 *Active Cloud Triggers:*\n`;
    messageText += ` • 🔥 80%+ Confluence Scanner Signals (with Logics)\n`;
    messageText += ` • 🚨 Stock & Index Price/Volume Alert Hits\n`;
    messageText += ` • 👤 Paid Pro & VIP Guest User Logins/Logouts\n`;
    messageText += `━━━━━━━━━━━━━━━━━━━━━━━\n`;
    messageText += `*Nadeem Hassan Stock Trading Pro Terminal (24/7 Cloud Background)*`;

    const directUrl = this.buildDirectUrl(messageText);

    const alertRecord: WhatsAppAlertRecord = {
      id: 'wa_test_' + Date.now().toString(36),
      eventType: 'TEST',
      userId: 'system_admin',
      userName: this.config.adminName || ADMIN_NAME,
      username: 'admin_nadeem',
      userPhone: this.config.adminPhone || ADMIN_WHATSAPP_NUMBER,
      userType: 'ADMIN',
      timestamp: now,
      formattedPktTime: pktTime,
      messageText,
      recipientPhone: this.config.adminPhone || ADMIN_WHATSAPP_NUMBER,
      recipientName: this.config.adminName || ADMIN_NAME,
      whatsappDirectUrl: directUrl,
      dispatchStatus: 'DISPATCHED',
      dispatchNote: `Test notification generated for ${this.config.adminName} (${this.config.adminPhone})`
    };

    const cloudRes = await this.executeCloudDispatch(alertRecord);
    if (cloudRes.success) {
      alertRecord.dispatchStatus = 'DELIVERED_VIA_CLOUD_BOT';
      alertRecord.gatewayResponse = cloudRes.note;
    } else {
      alertRecord.dispatchNote = cloudRes.note;
    }

    this.history.unshift(alertRecord);
    this.saveHistory();
    return alertRecord;
  }

  // Get list of recent alerts
  public getAlerts(): WhatsAppAlertRecord[] {
    return this.history;
  }
}

export const whatsappNotifier = WhatsAppNotifier.getInstance();
