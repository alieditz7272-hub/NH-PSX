import fs from 'fs';
import path from 'path';
import { 
  AnalyticsEvent, 
  AnalyticsEventType, 
  ComprehensiveAnalyticsData, 
  DateFilterRange, 
  DeviceCategory, 
  BrowserCategory, 
  TrafficSourceCategory,
  AdminAlertNotification,
  FunnelStage,
  UserDropOffItem,
  PaymentAbandonmentStats,
  PaymentMethodMetrics,
  PlanMetrics,
  RealTimeVisitorCounters,
  TodayOverviewMetrics,
  TrafficSourceBreakdown,
  DeviceBreakdown,
  BrowserBreakdown,
  UserJourneyItem,
  HourlyTrendPoint,
  DailyTrendPoint,
  LiveActivityEvent
} from '../types/analytics';
import { subscriptionStore } from './subscriptionStore';

const DATA_DIR = path.join(process.cwd(), 'data');
const ANALYTICS_DB_FILE = path.join(DATA_DIR, 'analytics_store.json');

interface AnalyticsDBSchema {
  events: AnalyticsEvent[];
  activeSessions: Record<string, {
    sessionId: string;
    visitorId: string;
    userId?: string;
    userName?: string;
    deviceCategory: DeviceCategory;
    browser: BrowserCategory;
    trafficSource: TrafficSourceCategory;
    firstSeen: number;
    lastSeen: number;
    currentStage: string;
    planSelected?: 'MONTHLY' | 'YEARLY';
    methodSelected?: 'EASYPAISA' | 'BANK_TRANSFER';
    formStartedAt?: number;
    submittedPaymentAt?: number;
  }>;
  notifications: AdminAlertNotification[];
}

class AnalyticsStore {
  private db: AnalyticsDBSchema = {
    events: [],
    activeSessions: {},
    notifications: []
  };

  // Fast in-memory deduplication cache: `${sessionId}_${eventType}` -> timestamp
  private recentEventCache: Map<string, number> = new Map();

  constructor() {
    this.init();
  }

  private init() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(ANALYTICS_DB_FILE)) {
        const raw = fs.readFileSync(ANALYTICS_DB_FILE, 'utf-8');
        this.db = JSON.parse(raw);
      } else {
        this.seedInitialEventsIfEmpty();
        this.save();
      }
    } catch (e) {
      console.warn('Could not load analytics store from disk, initializing fresh', e);
      this.seedInitialEventsIfEmpty();
    }

    // Clean up stale session entries periodically (every 10 minutes)
    setInterval(() => {
      this.cleanupStaleSessions();
    }, 10 * 60 * 1000);
  }

  private save() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      // Cap events to last 15,000 for high performance
      if (this.db.events.length > 15000) {
        this.db.events = this.db.events.slice(-15000);
      }
      fs.writeFileSync(ANALYTICS_DB_FILE, JSON.stringify(this.db, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to save analytics store to disk', e);
    }
  }

  private seedInitialEventsIfEmpty() {
    // If the database has real payment/subscription records in subscriptionStore,
    // generate historical baseline events so historical payments correlate accurately.
    const now = Date.now();
    const payments = subscriptionStore.getAdminPayments({});
    
    if (this.db.events.length === 0 && payments.length > 0) {
      payments.forEach((p, idx) => {
        const fakeSession = `sess_hist_${p.userId}_${idx}`;
        const fakeVisitor = `vis_hist_${p.userId}`;
        const ts = p.submittedAt || (now - (payments.length - idx) * 3600000);

        this.db.events.push({
          eventId: `evt_hist_open_${idx}`,
          eventType: 'app_open',
          sessionId: fakeSession,
          visitorId: fakeVisitor,
          userId: p.userId,
          userName: p.userName,
          userEmail: p.userEmail,
          timestamp: ts - 600000,
          page: '/',
          deviceCategory: 'Desktop',
          browser: 'Chrome',
          trafficSource: 'Direct'
        });

        this.db.events.push({
          eventId: `evt_hist_sub_${idx}`,
          eventType: 'subscription_page_view',
          sessionId: fakeSession,
          visitorId: fakeVisitor,
          userId: p.userId,
          userName: p.userName,
          userEmail: p.userEmail,
          timestamp: ts - 400000,
          page: '/subscription',
          deviceCategory: 'Desktop',
          browser: 'Chrome',
          trafficSource: 'Direct'
        });

        this.db.events.push({
          eventId: `evt_hist_plan_${idx}`,
          eventType: 'plan_selected',
          sessionId: fakeSession,
          visitorId: fakeVisitor,
          userId: p.userId,
          userName: p.userName,
          userEmail: p.userEmail,
          timestamp: ts - 300000,
          plan: p.plan,
          page: '/subscription',
          deviceCategory: 'Desktop',
          browser: 'Chrome',
          trafficSource: 'Direct'
        });

        this.db.events.push({
          eventId: `evt_hist_mth_${idx}`,
          eventType: p.paymentMethod === 'EASYPAISA' ? 'easypaisa_selected' : 'bank_transfer_selected',
          sessionId: fakeSession,
          visitorId: fakeVisitor,
          userId: p.userId,
          userName: p.userName,
          userEmail: p.userEmail,
          timestamp: ts - 200000,
          plan: p.plan,
          paymentMethod: p.paymentMethod,
          page: '/subscription',
          deviceCategory: 'Desktop',
          browser: 'Chrome',
          trafficSource: 'Direct'
        });

        this.db.events.push({
          eventId: `evt_hist_start_${idx}`,
          eventType: 'payment_form_started',
          sessionId: fakeSession,
          visitorId: fakeVisitor,
          userId: p.userId,
          userName: p.userName,
          userEmail: p.userEmail,
          timestamp: ts - 100000,
          plan: p.plan,
          paymentMethod: p.paymentMethod,
          page: '/subscription',
          deviceCategory: 'Desktop',
          browser: 'Chrome',
          trafficSource: 'Direct'
        });

        this.db.events.push({
          eventId: `evt_hist_submit_${idx}`,
          eventType: 'payment_submitted',
          sessionId: fakeSession,
          visitorId: fakeVisitor,
          userId: p.userId,
          userName: p.userName,
          userEmail: p.userEmail,
          timestamp: ts,
          plan: p.plan,
          paymentMethod: p.paymentMethod,
          amount: p.amount,
          page: '/subscription',
          deviceCategory: 'Desktop',
          browser: 'Chrome',
          trafficSource: 'Direct'
        });

        if (p.status === 'APPROVED') {
          this.db.events.push({
            eventId: `evt_hist_appr_${idx}`,
            eventType: 'payment_approved',
            sessionId: fakeSession,
            visitorId: fakeVisitor,
            userId: p.userId,
            userName: p.userName,
            userEmail: p.userEmail,
            timestamp: (p.reviewedAt || ts) + 60000,
            plan: p.plan,
            paymentMethod: p.paymentMethod,
            amount: p.amount,
            page: '/admin',
            deviceCategory: 'Desktop',
            browser: 'Chrome',
            trafficSource: 'Direct'
          });
        }
      });
    }
  }

  private cleanupStaleSessions() {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000; // 24 hours
    for (const [key, session] of Object.entries(this.db.activeSessions)) {
      if (session.lastSeen < cutoff) {
        delete this.db.activeSessions[key];
      }
    }
    // Clean old event dedup cache
    const cacheCutoff = Date.now() - 60000;
    for (const [key, ts] of this.recentEventCache.entries()) {
      if (ts < cacheCutoff) {
        this.recentEventCache.delete(key);
      }
    }
  }

  // Record an incoming analytics event
  public recordEvent(eventData: Omit<AnalyticsEvent, 'eventId' | 'timestamp'> & { eventId?: string; timestamp?: number }): AnalyticsEvent | null {
    const now = eventData.timestamp || Date.now();
    const eventType = eventData.eventType;
    const sessionId = eventData.sessionId || 'sess_anon';
    const visitorId = eventData.visitorId || sessionId;

    // 1. Duplicate Protection: If exact same event received for same session within 2.5 seconds, ignore to prevent React rerender floods
    const cacheKey = `${sessionId}_${eventType}_${eventData.plan || ''}_${eventData.paymentMethod || ''}`;
    const lastEventTime = this.recentEventCache.get(cacheKey);
    if (lastEventTime && now - lastEventTime < 2500) {
      // Just update heartbeat on session
      this.updateActiveSession(sessionId, visitorId, eventData, now);
      return null;
    }
    this.recentEventCache.set(cacheKey, now);

    const event: AnalyticsEvent = {
      eventId: eventData.eventId || 'evt_' + Math.random().toString(36).substring(2, 9) + now.toString(36),
      eventType: eventData.eventType,
      sessionId,
      visitorId,
      userId: eventData.userId,
      userName: eventData.userName,
      userEmail: eventData.userEmail,
      timestamp: now,
      plan: eventData.plan,
      paymentMethod: eventData.paymentMethod,
      amount: eventData.amount,
      page: eventData.page || '/',
      deviceCategory: eventData.deviceCategory || 'Unknown',
      browser: eventData.browser || 'Other',
      trafficSource: eventData.trafficSource || 'Direct',
      meta: eventData.meta
    };

    // If this is a heartbeat, do not save as a separate bulky event in history, only update active session
    if (eventType === 'heartbeat') {
      this.updateActiveSession(sessionId, visitorId, eventData, now);
      return event;
    }

    this.db.events.push(event);
    this.updateActiveSession(sessionId, visitorId, eventData, now);

    // Generate real-time Admin alerts for critical conversion events
    this.checkAndGenerateAdminNotification(event);

    this.save();
    return event;
  }

  private updateActiveSession(
    sessionId: string, 
    visitorId: string, 
    eventData: Partial<AnalyticsEvent>, 
    now: number
  ) {
    if (!this.db.activeSessions[sessionId]) {
      this.db.activeSessions[sessionId] = {
        sessionId,
        visitorId,
        userId: eventData.userId,
        userName: eventData.userName,
        deviceCategory: eventData.deviceCategory || 'Unknown',
        browser: eventData.browser || 'Other',
        trafficSource: eventData.trafficSource || 'Direct',
        firstSeen: now,
        lastSeen: now,
        currentStage: eventData.eventType || 'app_open'
      };
    } else {
      const s = this.db.activeSessions[sessionId];
      s.lastSeen = now;
      if (eventData.userId) s.userId = eventData.userId;
      if (eventData.userName) s.userName = eventData.userName;
      if (eventData.eventType) s.currentStage = eventData.eventType;
      if (eventData.plan) s.planSelected = eventData.plan;
      if (eventData.paymentMethod) s.methodSelected = eventData.paymentMethod;
      if (eventData.eventType === 'payment_form_started' && !s.formStartedAt) {
        s.formStartedAt = now;
      }
      if (eventData.eventType === 'payment_submitted') {
        s.submittedPaymentAt = now;
      }
    }
  }

  private checkAndGenerateAdminNotification(event: AnalyticsEvent) {
    if (event.eventType === 'payment_submitted') {
      this.addNotification({
        id: 'notif_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
        type: 'PAYMENT_SUBMITTED',
        title: 'New Payment Submitted',
        message: `${event.userName || 'User'} submitted ${event.plan || 'Pro'} payment (${Number(event.amount || 5000).toFixed(2).replace(/,/g, '')}) via ${event.paymentMethod || 'Wallet'} for verification.`,
        timestamp: Date.now(),
        read: false,
        sessionId: event.sessionId,
        userId: event.userId,
        amount: event.amount,
        plan: event.plan
      });
    } else if (event.eventType === 'payment_approved') {
      this.addNotification({
        id: 'notif_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
        type: 'PAYMENT_APPROVED',
        title: 'New Subscriber Activated',
        message: `Subscription activated for ${event.userName || 'Subscriber'} (${event.plan || 'Pro'}).`,
        timestamp: Date.now(),
        read: false,
        sessionId: event.sessionId,
        userId: event.userId,
        amount: event.amount,
        plan: event.plan
      });
    } else if (event.eventType === 'payment_form_started') {
      this.addNotification({
        id: 'notif_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
        type: 'HIGH_INTENT',
        title: 'High-Intent User Reached Payment Form',
        message: `A user started filling the payment form for ${event.plan || 'Pro'} via ${event.paymentMethod || 'Bank Transfer'}.`,
        timestamp: Date.now(),
        read: false,
        sessionId: event.sessionId,
        userId: event.userId,
        plan: event.plan
      });
    } else if (event.eventType === 'subscription_page_view') {
      // Throttle subscription view alerts to avoid alert fatigue (only 1 per 15 min if unread)
      const hasRecentViewAlert = this.db.notifications.some(
        n => n.type === 'PAYMENT_PAGE_REACHED' && Date.now() - n.timestamp < 15 * 60 * 1000
      );
      if (!hasRecentViewAlert) {
        this.addNotification({
          id: 'notif_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
          type: 'PAYMENT_PAGE_REACHED',
          title: 'User Reached Subscription Page',
          message: `A user has navigated to the NH Stock Trading Pro subscription paywall.`,
          timestamp: Date.now(),
          read: false,
          sessionId: event.sessionId
        });
      }
    }
  }

  private addNotification(notif: AdminAlertNotification) {
    this.db.notifications.unshift(notif);
    if (this.db.notifications.length > 100) {
      this.db.notifications = this.db.notifications.slice(0, 100);
    }
  }

  public markNotificationAsRead(id: string): boolean {
    const notif = this.db.notifications.find(n => n.id === id);
    if (notif) {
      notif.read = true;
      this.save();
      return true;
    }
    return false;
  }

  public markAllNotificationsAsRead(): void {
    this.db.notifications.forEach(n => { n.read = true; });
    this.save();
  }

  // Parse date range filter into timestamp boundaries
  private getDateBounds(range: DateFilterRange, customStart?: string, customEnd?: string): { startTs: number; endTs: number } {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const endOfToday = startOfToday + 24 * 60 * 60 * 1000 - 1;

    switch (range) {
      case 'TODAY':
        return { startTs: startOfToday, endTs: endOfToday };

      case 'YESTERDAY': {
        const startYesterday = startOfToday - 24 * 60 * 60 * 1000;
        const endYesterday = startOfToday - 1;
        return { startTs: startYesterday, endTs: endYesterday };
      }

      case 'LAST_7_DAYS': {
        const start7d = startOfToday - 6 * 24 * 60 * 60 * 1000;
        return { startTs: start7d, endTs: endOfToday };
      }

      case 'LAST_30_DAYS': {
        const start30d = startOfToday - 29 * 24 * 60 * 60 * 1000;
        return { startTs: start30d, endTs: endOfToday };
      }

      case 'THIS_MONTH': {
        const startMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
        return { startTs: startMonth, endTs: endOfToday };
      }

      case 'LAST_MONTH': {
        const startLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1).getTime();
        const endLastMonth = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999).getTime();
        return { startTs: startLastMonth, endTs: endLastMonth };
      }

      case 'THIS_YEAR': {
        const startYear = new Date(now.getFullYear(), 0, 1).getTime();
        return { startTs: startYear, endTs: endOfToday };
      }

      case 'CUSTOM': {
        const sTs = customStart ? new Date(customStart).getTime() : 0;
        const eTs = customEnd ? new Date(customEnd + 'T23:59:59.999Z').getTime() : Date.now();
        return { startTs: isNaN(sTs) ? 0 : sTs, endTs: isNaN(eTs) ? Date.now() : eTs };
      }

      case 'ALL_TIME':
      default:
        return { startTs: 0, endTs: Date.now() + 86400000 };
    }
  }

  // Get Comprehensive Real-Time Analytics
  public getComprehensiveAnalytics(
    range: DateFilterRange = 'TODAY',
    customStart?: string,
    customEnd?: string
  ): ComprehensiveAnalyticsData {
    const { startTs, endTs } = this.getDateBounds(range, customStart, customEnd);
    const now = Date.now();

    // 1. Filter events within range
    const filteredEvents = this.db.events.filter(e => e.timestamp >= startTs && e.timestamp <= endTs);

    // 2. Active Now Calculation: Unique sessions with activity within the last 5 minutes
    const fiveMinutesAgo = now - 5 * 60 * 1000;
    const activeNowSessions = Object.values(this.db.activeSessions).filter(s => s.lastSeen >= fiveMinutesAgo);
    const activeNow = activeNowSessions.length;

    // 3. Visitor counters across distinct standard horizons
    const startOfToday = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).getTime();
    const startOfWeek = startOfToday - 6 * 24 * 60 * 60 * 1000;
    const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime();

    const allVisitors = new Set(this.db.events.map(e => e.visitorId || e.sessionId));
    const todayVisitors = new Set(this.db.events.filter(e => e.timestamp >= startOfToday).map(e => e.visitorId || e.sessionId));
    const weekVisitors = new Set(this.db.events.filter(e => e.timestamp >= startOfWeek).map(e => e.visitorId || e.sessionId));
    const monthVisitors = new Set(this.db.events.filter(e => e.timestamp >= startOfMonth).map(e => e.visitorId || e.sessionId));
    const totalSessions = new Set(this.db.events.map(e => e.sessionId)).size;

    const counters: RealTimeVisitorCounters = {
      totalVisitors: allVisitors.size,
      activeNow: Math.max(activeNow, 1), // Minimum 1 for current active admin view
      todayVisitors: todayVisitors.size,
      thisWeekVisitors: weekVisitors.size,
      thisMonthVisitors: monthVisitors.size,
      totalSessions: Math.max(totalSessions, 1)
    };

    // 4. Extract unique users / sessions per stage in the filtered range
    const visitorsSet = new Set<string>();
    const subPageSet = new Set<string>();
    const planSelectedSet = new Set<string>();
    const paymentMethodSet = new Set<string>();
    const paymentFormStartSet = new Set<string>();
    const paymentSubmittedSet = new Set<string>();
    const paymentPendingSet = new Set<string>();
    const paymentApprovedSet = new Set<string>();
    const activeSubscriberSet = new Set<string>();

    filteredEvents.forEach(e => {
      const entityId = e.visitorId || e.sessionId;

      if (e.eventType === 'app_open' || e.eventType === 'landing_page_view' || e.eventType === 'session_started') {
        visitorsSet.add(entityId);
      }
      if (e.eventType === 'subscription_page_view') {
        visitorsSet.add(entityId);
        subPageSet.add(entityId);
      }
      if (e.eventType === 'plan_selected' || e.eventType === 'monthly_plan_view' || e.eventType === 'yearly_plan_view') {
        visitorsSet.add(entityId);
        subPageSet.add(entityId);
        planSelectedSet.add(entityId);
      }
      if (e.eventType === 'payment_method_view' || e.eventType === 'easypaisa_selected' || e.eventType === 'bank_transfer_selected') {
        visitorsSet.add(entityId);
        subPageSet.add(entityId);
        planSelectedSet.add(entityId);
        paymentMethodSet.add(entityId);
      }
      if (e.eventType === 'payment_form_started' || e.eventType === 'payment_form_completed') {
        visitorsSet.add(entityId);
        subPageSet.add(entityId);
        planSelectedSet.add(entityId);
        paymentMethodSet.add(entityId);
        paymentFormStartSet.add(entityId);
      }
      if (e.eventType === 'payment_submitted') {
        visitorsSet.add(entityId);
        subPageSet.add(entityId);
        planSelectedSet.add(entityId);
        paymentMethodSet.add(entityId);
        paymentFormStartSet.add(entityId);
        paymentSubmittedSet.add(entityId);
        paymentPendingSet.add(entityId);
      }
      if (e.eventType === 'payment_pending') {
        paymentPendingSet.add(entityId);
      }
      if (e.eventType === 'payment_approved' || e.eventType === 'subscription_activated') {
        paymentApprovedSet.add(entityId);
        activeSubscriberSet.add(entityId);
      }
    });

    // 5. Reconcile with actual payments from subscriptionStore
    const actualAdminPayments = subscriptionStore.getAdminPayments({});
    const rangePayments = actualAdminPayments.filter(p => p.submittedAt >= startTs && p.submittedAt <= endTs);
    const rangeApproved = rangePayments.filter(p => p.status === 'APPROVED');
    const rangePending = rangePayments.filter(p => p.status === 'PENDING');
    const rangeRejected = rangePayments.filter(p => p.status === 'REJECTED');

    // Combine payment counts for ground-truth financial integrity
    const verifiedSubmittedCount = Math.max(paymentSubmittedSet.size, rangePayments.length);
    const verifiedApprovedCount = Math.max(paymentApprovedSet.size, rangeApproved.length);
    const verifiedPendingCount = rangePending.length;
    const verifiedRejectedCount = rangeRejected.length;

    // Financial revenue calculation from APPROVED payments only
    const verifiedRevenue = rangeApproved.reduce((sum, p) => sum + p.amount, 0);

    // Ensure funnel numbers maintain logical hierarchy (each stage >= downstream stage)
    const baseVisitors = Math.max(visitorsSet.size, subPageSet.size, 1);
    const subPageVisitors = Math.max(subPageSet.size, planSelectedSet.size);
    const planSelectedCount = Math.max(planSelectedSet.size, paymentMethodSet.size);
    const paymentMethodCount = Math.max(paymentMethodSet.size, paymentFormStartSet.size);
    const paymentFormStarts = Math.max(paymentFormStartSet.size, verifiedSubmittedCount);
    const paymentsSubmitted = verifiedSubmittedCount;
    const paymentsPending = verifiedPendingCount;
    const paymentsApproved = verifiedApprovedCount;
    const activeSubscribers = Math.max(activeSubscriberSet.size, verifiedApprovedCount);

    // Calculate 9-Stage Visual Funnel
    const rawStages: { id: string; name: string; description: string; count: number }[] = [
      { id: 'app_visitors', name: 'App Visitors', description: 'Total unique visitors on terminal', count: baseVisitors },
      { id: 'sub_viewed', name: 'Subscription Page Viewed', description: 'Viewed subscription plans screen', count: subPageVisitors },
      { id: 'plan_selected', name: 'Plan Selected', description: 'Selected monthly or yearly membership tier', count: planSelectedCount },
      { id: 'method_viewed', name: 'Payment Method Viewed', description: 'Viewed Easypaisa or Bank account details', count: paymentMethodCount },
      { id: 'form_started', name: 'Payment Form Started', description: 'Started entering transaction information', count: paymentFormStarts },
      { id: 'payment_submitted', name: 'Payment Submitted', description: 'Submitted transaction receipt and TRX ID', count: paymentsSubmitted },
      { id: 'payment_pending', name: 'Payment Pending', description: 'Awaiting admin verification', count: paymentsPending },
      { id: 'payment_approved', name: 'Payment Approved', description: 'Verified and approved by admin', count: paymentsApproved },
      { id: 'active_subscriber', name: 'Active Subscriber', description: 'Unlocked full pro terminal access', count: activeSubscribers }
    ];

    const funnel: FunnelStage[] = rawStages.map((stage, idx) => {
      const prevCount = idx === 0 ? stage.count : rawStages[idx - 1].count;
      const percentOfTotal = baseVisitors > 0 ? parseFloat(((stage.count / baseVisitors) * 100).toFixed(1)) : 0;
      const conversionFromPrev = prevCount > 0 ? parseFloat(((stage.count / prevCount) * 100).toFixed(1)) : 0;
      const dropOffCount = Math.max(0, prevCount - stage.count);
      const dropOffPercent = prevCount > 0 ? parseFloat(((dropOffCount / prevCount) * 100).toFixed(1)) : 0;

      return {
        stageId: stage.id,
        stageName: stage.name,
        stageDescription: stage.description,
        usersCount: stage.count,
        percentOfTotalVisitors: percentOfTotal,
        conversionFromPrevPercent: conversionFromPrev,
        dropOffPercent,
        dropOffCount
      };
    });

    // 6. Detailed Drop-off Analysis ("WHERE USERS ARE LEAVING")
    const dropOffStages: UserDropOffItem[] = [
      {
        stageName: 'App Open → Subscription Page',
        dropOffCount: Math.max(0, baseVisitors - subPageVisitors),
        dropOffPercent: baseVisitors > 0 ? parseFloat((((baseVisitors - subPageVisitors) / baseVisitors) * 100).toFixed(1)) : 0,
        reasonDescription: 'Users opened the terminal but did not proceed to check subscription plans.',
        nextStepName: 'Subscription Page Viewed'
      },
      {
        stageName: 'Subscription Page → Plan Selection',
        dropOffCount: Math.max(0, subPageVisitors - planSelectedCount),
        dropOffPercent: subPageVisitors > 0 ? parseFloat((((subPageVisitors - planSelectedCount) / subPageVisitors) * 100).toFixed(1)) : 0,
        reasonDescription: 'Viewed pricing plans but did not select Monthly (5,000) or Yearly (50,000).',
        nextStepName: 'Plan Selected'
      },
      {
        stageName: 'Plan Selection → Payment Method',
        dropOffCount: Math.max(0, planSelectedCount - paymentMethodCount),
        dropOffPercent: planSelectedCount > 0 ? parseFloat((((planSelectedCount - paymentMethodCount) / planSelectedCount) * 100).toFixed(1)) : 0,
        reasonDescription: 'Selected a plan but left before choosing Easypaisa or Faysal Bank.',
        nextStepName: 'Payment Method Viewed'
      },
      {
        stageName: 'Payment Method → Payment Form Start',
        dropOffCount: Math.max(0, paymentMethodCount - paymentFormStarts),
        dropOffPercent: paymentMethodCount > 0 ? parseFloat((((paymentMethodCount - paymentFormStarts) / paymentMethodCount) * 100).toFixed(1)) : 0,
        reasonDescription: 'Viewed bank / wallet details but did not begin entering TRX ID or receipt.',
        nextStepName: 'Payment Form Started'
      },
      {
        stageName: 'Payment Form Start → Payment Submission',
        dropOffCount: Math.max(0, paymentFormStarts - paymentsSubmitted),
        dropOffPercent: paymentFormStarts > 0 ? parseFloat((((paymentFormStarts - paymentsSubmitted) / paymentFormStarts) * 100).toFixed(1)) : 0,
        reasonDescription: 'Started filling form but abandoned before final submission.',
        nextStepName: 'Payment Submitted'
      }
    ];

    const highestDropOff = [...dropOffStages].sort((a, b) => b.dropOffCount - a.dropOffCount)[0]?.stageName || 'Subscription Page';

    // 7. Payment Page Abandonment Calculations (30-minute inactivity definition)
    const thirtyMinAgo = now - 30 * 60 * 1000;
    const paymentAbandonedSessions = Object.values(this.db.activeSessions).filter(s => {
      return (
        s.formStartedAt !== undefined &&
        s.submittedPaymentAt === undefined &&
        s.lastSeen < thirtyMinAgo
      );
    });

    const paymentPageVisitors = Math.max(subPageVisitors, paymentFormStarts);
    const paymentStarted = paymentFormStarts;
    const paymentSubmitted = paymentsSubmitted;
    const paymentAbandoned = Math.max(
      paymentAbandonedSessions.length,
      Math.max(0, paymentStarted - paymentSubmitted)
    );

    const paymentConversionRate = paymentPageVisitors > 0
      ? parseFloat(((paymentSubmitted / paymentPageVisitors) * 100).toFixed(1))
      : 0;

    const paymentAbandonmentRate = paymentPageVisitors > 0
      ? parseFloat(((paymentAbandoned / paymentPageVisitors) * 100).toFixed(1))
      : 0;

    // High Intent Users (selected plan/method or started form but haven't submitted yet)
    const highIntentUsers = Object.values(this.db.activeSessions)
      .filter(s => (s.formStartedAt || s.methodSelected || s.planSelected) && !s.submittedPaymentAt)
      .map(s => ({
        sessionId: s.sessionId,
        visitorId: s.visitorId,
        userName: s.userName,
        email: s.userId ? (subscriptionStore.getUserByToken(s.userId)?.email || '') : undefined,
        plan: s.planSelected,
        paymentMethod: s.methodSelected,
        startedAt: s.formStartedAt || s.firstSeen,
        lastActive: s.lastSeen,
        status: s.lastSeen < thirtyMinAgo ? 'Abandoned (>30m inactive)' : 'Active / In Progress'
      }));

    const abandonmentStats: PaymentAbandonmentStats = {
      paymentPageVisitors,
      paymentStarted,
      paymentSubmitted,
      paymentAbandoned,
      paymentConversionRate,
      paymentAbandonmentRate,
      highIntentUsersCount: highIntentUsers.length
    };

    // 8. Payment Method Analytics (Easypaisa vs Faysal Bank)
    const epViews = filteredEvents.filter(e => e.eventType === 'payment_method_view' || e.eventType === 'easypaisa_selected').length;
    const epSelected = filteredEvents.filter(e => e.eventType === 'easypaisa_selected' || (e.paymentMethod === 'EASYPAISA')).length;
    const epSubmitted = rangePayments.filter(p => p.paymentMethod === 'EASYPAISA').length;
    const epApproved = rangeApproved.filter(p => p.paymentMethod === 'EASYPAISA').length;

    const fbViews = filteredEvents.filter(e => e.eventType === 'payment_method_view' || e.eventType === 'bank_transfer_selected').length;
    const fbSelected = filteredEvents.filter(e => e.eventType === 'bank_transfer_selected' || (e.paymentMethod === 'BANK_TRANSFER')).length;
    const fbSubmitted = rangePayments.filter(p => p.paymentMethod === 'BANK_TRANSFER').length;
    const fbApproved = rangeApproved.filter(p => p.paymentMethod === 'BANK_TRANSFER').length;

    const paymentMethods = {
      easypaisa: {
        views: Math.max(epViews, epSelected),
        selected: epSelected,
        submitted: epSubmitted,
        approved: epApproved,
        conversionRate: epSelected > 0 ? parseFloat(((epApproved / epSelected) * 100).toFixed(1)) : 0
      },
      faysalBank: {
        views: Math.max(fbViews, fbSelected),
        selected: fbSelected,
        submitted: fbSubmitted,
        approved: fbApproved,
        conversionRate: fbSelected > 0 ? parseFloat(((fbApproved / fbSelected) * 100).toFixed(1)) : 0
      }
    };

    // 9. Plan Analytics (Monthly vs Yearly)
    const mViews = filteredEvents.filter(e => e.eventType === 'monthly_plan_view' || (e.plan === 'MONTHLY')).length;
    const mSelected = filteredEvents.filter(e => e.plan === 'MONTHLY').length;
    const mStarted = filteredEvents.filter(e => e.eventType === 'payment_form_started' && e.plan === 'MONTHLY').length;
    const mSubmitted = rangePayments.filter(p => p.plan === 'MONTHLY').length;
    const mApproved = rangeApproved.filter(p => p.plan === 'MONTHLY').length;

    const yViews = filteredEvents.filter(e => e.eventType === 'yearly_plan_view' || (e.plan === 'YEARLY')).length;
    const ySelected = filteredEvents.filter(e => e.plan === 'YEARLY').length;
    const yStarted = filteredEvents.filter(e => e.eventType === 'payment_form_started' && e.plan === 'YEARLY').length;
    const ySubmitted = rangePayments.filter(p => p.plan === 'YEARLY').length;
    const yApproved = rangeApproved.filter(p => p.plan === 'YEARLY').length;

    const plans = {
      monthly: {
        views: Math.max(mViews, mSelected),
        selected: mSelected,
        paymentStarted: Math.max(mStarted, mSubmitted),
        submitted: mSubmitted,
        approved: mApproved,
        conversionRate: mSelected > 0 ? parseFloat(((mApproved / mSelected) * 100).toFixed(1)) : 0
      },
      yearly: {
        views: Math.max(yViews, ySelected),
        selected: ySelected,
        paymentStarted: Math.max(yStarted, ySubmitted),
        submitted: ySubmitted,
        approved: yApproved,
        conversionRate: ySelected > 0 ? parseFloat(((yApproved / ySelected) * 100).toFixed(1)) : 0
      }
    };

    // 10. Today's Specific Snapshot
    const todayEvents = this.db.events.filter(e => e.timestamp >= startOfToday);
    const todayPayments = actualAdminPayments.filter(p => p.submittedAt >= startOfToday);
    const todayApproved = todayPayments.filter(p => p.status === 'APPROVED');
    const todayRejected = todayPayments.filter(p => p.status === 'REJECTED');
    const todayRevenue = todayApproved.reduce((sum, p) => sum + p.amount, 0);

    const todayMetrics: TodayOverviewMetrics = {
      uniqueVisitors: new Set(todayEvents.map(e => e.visitorId || e.sessionId)).size,
      totalSessions: new Set(todayEvents.map(e => e.sessionId)).size,
      subscriptionPageViews: todayEvents.filter(e => e.eventType === 'subscription_page_view').length,
      planSelections: todayEvents.filter(e => e.eventType === 'plan_selected').length,
      paymentMethodViews: todayEvents.filter(e => e.eventType === 'payment_method_view' || e.eventType === 'easypaisa_selected' || e.eventType === 'bank_transfer_selected').length,
      paymentFormStarts: todayEvents.filter(e => e.eventType === 'payment_form_started').length,
      paymentSubmissions: todayPayments.length,
      approvedPayments: todayApproved.length,
      rejectedPayments: todayRejected.length,
      newSubscribers: todayApproved.length,
      revenue: todayRevenue
    };

    // 11. Traffic Source Breakdown
    const trafficSources: TrafficSourceBreakdown = {
      direct: 0,
      google: 0,
      facebook: 0,
      instagram: 0,
      otherReferral: 0,
      unknown: 0
    };
    filteredEvents.forEach(e => {
      const src = e.trafficSource || 'Direct';
      if (src === 'Direct') trafficSources.direct++;
      else if (src === 'Google/Search') trafficSources.google++;
      else if (src === 'Facebook') trafficSources.facebook++;
      else if (src === 'Instagram') trafficSources.instagram++;
      else if (src === 'Other Referral') trafficSources.otherReferral++;
      else trafficSources.unknown++;
    });

    // 12. Device Breakdown & Mobile/Desktop percentages
    const devices: DeviceBreakdown = {
      android: 0,
      ios: 0,
      desktop: 0,
      tablet: 0,
      unknown: 0,
      mobilePercent: 0,
      desktopPercent: 0
    };
    filteredEvents.forEach(e => {
      const dev = e.deviceCategory || 'Desktop';
      if (dev === 'Android') devices.android++;
      else if (dev === 'iPhone/iOS') devices.ios++;
      else if (dev === 'Desktop') devices.desktop++;
      else if (dev === 'Tablet') devices.tablet++;
      else devices.unknown++;
    });
    const totalDeviceEvents = devices.android + devices.ios + devices.desktop + devices.tablet + devices.unknown;
    if (totalDeviceEvents > 0) {
      const mobileEvents = devices.android + devices.ios + devices.tablet;
      devices.mobilePercent = parseFloat(((mobileEvents / totalDeviceEvents) * 100).toFixed(1));
      devices.desktopPercent = parseFloat(((devices.desktop / totalDeviceEvents) * 100).toFixed(1));
    } else {
      devices.desktopPercent = 100;
    }

    // 13. Browser Breakdown
    const browsers: BrowserBreakdown = {
      chrome: 0,
      safari: 0,
      edge: 0,
      firefox: 0,
      other: 0
    };
    filteredEvents.forEach(e => {
      const br = e.browser || 'Chrome';
      if (br === 'Chrome') browsers.chrome++;
      else if (br === 'Safari') browsers.safari++;
      else if (br === 'Edge') browsers.edge++;
      else if (br === 'Firefox') browsers.firefox++;
      else browsers.other++;
    });

    // 14. Hourly Analytics for Today (00:00 to 23:00)
    const hourlyTrends: HourlyTrendPoint[] = [];
    for (let h = 0; h < 24; h++) {
      const hStart = startOfToday + h * 3600000;
      const hEnd = hStart + 3600000 - 1;
      const hEvents = this.db.events.filter(e => e.timestamp >= hStart && e.timestamp <= hEnd);
      const hPayments = actualAdminPayments.filter(p => p.submittedAt >= hStart && p.submittedAt <= hEnd);
      const hApproved = hPayments.filter(p => p.status === 'APPROVED');

      hourlyTrends.push({
        hour: h,
        hourLabel: `${h < 10 ? '0' + h : h}:00`,
        visitors: new Set(hEvents.map(e => e.visitorId || e.sessionId)).size,
        subscriptionViews: hEvents.filter(e => e.eventType === 'subscription_page_view').length,
        paymentStarts: hEvents.filter(e => e.eventType === 'payment_form_started').length,
        paymentSubmissions: hPayments.length,
        approvedPayments: hApproved.length
      });
    }

    // 15. Daily Trend for selected date range (up to 30 days back)
    const dailyTrends: DailyTrendPoint[] = [];
    const daysCount = Math.min(30, Math.max(1, Math.ceil((endTs - startTs) / (24 * 3600000))));
    
    for (let d = daysCount - 1; d >= 0; d--) {
      const dStart = endTs - (d + 1) * 24 * 3600000 + 1;
      const dEnd = endTs - d * 24 * 3600000;
      const dDateObj = new Date(dStart);
      const dStr = dDateObj.toISOString().split('T')[0];
      const dLabel = `${dDateObj.getDate()} ${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][dDateObj.getMonth()]}`;

      const dEvents = this.db.events.filter(e => e.timestamp >= dStart && e.timestamp <= dEnd);
      const dPayments = actualAdminPayments.filter(p => p.submittedAt >= dStart && p.submittedAt <= dEnd);
      const dApproved = dPayments.filter(p => p.status === 'APPROVED');
      const dRevenue = dApproved.reduce((sum, p) => sum + p.amount, 0);

      dailyTrends.push({
        date: dStr,
        dateLabel: dLabel,
        visitors: new Set(dEvents.map(e => e.visitorId || e.sessionId)).size,
        paymentStarts: dEvents.filter(e => e.eventType === 'payment_form_started').length,
        paymentSubmissions: dPayments.length,
        approvals: dApproved.length,
        revenue: dRevenue
      });
    }

    // 16. Privacy-Conscious User Journeys (Group events by session ID)
    const sessionMap: Record<string, AnalyticsEvent[]> = {};
    filteredEvents.forEach(e => {
      if (!sessionMap[e.sessionId]) sessionMap[e.sessionId] = [];
      sessionMap[e.sessionId].push(e);
    });

    const userJourneys: UserJourneyItem[] = Object.entries(sessionMap)
      .map(([sId, evts]) => {
        const sorted = evts.sort((a, b) => a.timestamp - b.timestamp);
        const first = sorted[0];
        const last = sorted[sorted.length - 1];

        // Format steps nicely
        const steps = sorted.map(ev => {
          let stepLabel = ev.eventType.replace(/_/g, ' ').toUpperCase();
          if (ev.eventType === 'plan_selected' && ev.plan) stepLabel = `Selected ${ev.plan} Plan`;
          else if (ev.eventType === 'easypaisa_selected') stepLabel = 'Selected Easypaisa';
          else if (ev.eventType === 'bank_transfer_selected') stepLabel = 'Selected Faysal Bank';
          else if (ev.eventType === 'payment_submitted') stepLabel = `Submitted Payment (${ev.plan || 'Pro'} - ${Number(ev.amount || 5000).toFixed(2).replace(/,/g, '')})`;
          else if (ev.eventType === 'payment_approved') stepLabel = `Payment Approved by Admin`;
          else if (ev.eventType === 'subscription_page_view') stepLabel = `Viewed Subscription Page`;

          const d = new Date(ev.timestamp);
          const timeFormatted = `${d.getHours() % 12 || 12}:${d.getMinutes() < 10 ? '0' + d.getMinutes() : d.getMinutes()} ${d.getHours() >= 12 ? 'PM' : 'AM'}`;

          return {
            step: stepLabel,
            timestamp: ev.timestamp,
            timeFormatted,
            meta: ev.meta
          };
        });

        // Determine outcome
        const hasApproved = sorted.some(e => e.eventType === 'payment_approved');
        const hasSubmitted = sorted.some(e => e.eventType === 'payment_submitted');
        const hasStarted = sorted.some(e => e.eventType === 'payment_form_started');
        const hasSubView = sorted.some(e => e.eventType === 'subscription_page_view');

        let outcome: UserJourneyItem['outcome'] = 'BROWSING';
        if (hasApproved) outcome = 'APPROVED_SUBSCRIBER';
        else if (hasSubmitted) outcome = 'PENDING_VERIFICATION';
        else if (hasStarted && now - last.timestamp > 30 * 60 * 1000) outcome = 'ABANDONED_PAYMENT';
        else if (hasStarted || sorted.some(e => e.eventType === 'plan_selected')) outcome = 'HIGH_INTENT';
        else if (sorted.length <= 1) outcome = 'BOUNCED';

        const authUser = first.userId ? subscriptionStore.getUserByToken(first.userId) : null;

        return {
          journeyId: `jrn_${sId}`,
          sessionId: sId,
          visitorId: first.visitorId || sId,
          userId: first.userId,
          userName: authUser?.name || first.userName,
          userEmail: authUser?.email || first.userEmail,
          isRegistered: !!(first.userId || authUser),
          deviceCategory: first.deviceCategory || 'Unknown',
          browser: first.browser || 'Other',
          trafficSource: first.trafficSource || 'Direct',
          startTime: first.timestamp,
          lastActiveTime: last.timestamp,
          steps,
          outcome,
          totalDurationSeconds: Math.max(1, Math.round((last.timestamp - first.timestamp) / 1000))
        };
      })
      .sort((a, b) => b.lastActiveTime - a.lastActiveTime)
      .slice(0, 50);

    // 17. Live Activity Feed (Recent 30 events)
    const liveFeed: LiveActivityEvent[] = [...this.db.events]
      .reverse()
      .slice(0, 30)
      .map(ev => {
        let desc = 'User interacted with terminal';
        let badgeType: LiveActivityEvent['badgeType'] = 'info';

        switch (ev.eventType) {
          case 'app_open':
            desc = 'User opened NH Stock Trading terminal';
            badgeType = 'info';
            break;
          case 'subscription_page_view':
            desc = 'User reached subscription paywall';
            badgeType = 'purple';
            break;
          case 'monthly_plan_view':
            desc = 'User viewed Monthly Pro Plan (5,000)';
            badgeType = 'amber';
            break;
          case 'yearly_plan_view':
            desc = 'User viewed Yearly Pro Plan (50,000)';
            badgeType = 'amber';
            break;
          case 'plan_selected':
            desc = `User selected ${ev.plan || 'Pro'} plan`;
            badgeType = 'amber';
            break;
          case 'payment_method_view':
            desc = 'User viewed payment transfer options';
            badgeType = 'info';
            break;
          case 'easypaisa_selected':
            desc = 'User selected Easypaisa Mobile Wallet';
            badgeType = 'success';
            break;
          case 'bank_transfer_selected':
            desc = 'User selected Faysal Bank Online Transfer';
            badgeType = 'success';
            break;
          case 'payment_form_started':
            desc = `Payment form started for ${ev.plan || 'Pro'} (${ev.paymentMethod || 'Transfer'})`;
            badgeType = 'warning';
            break;
          case 'payment_submitted':
            desc = `Payment submitted: ${Number(ev.amount || 5000).toFixed(2).replace(/,/g, '')} (${ev.plan || 'Pro'})`;
            badgeType = 'warning';
            break;
          case 'payment_approved':
            desc = `Payment APPROVED & Pro subscription activated for ${ev.userName || 'Subscriber'}`;
            badgeType = 'success';
            break;
          case 'payment_rejected':
            desc = `Payment rejected by Admin for ${ev.userName || 'User'}`;
            badgeType = 'warning';
            break;
        }

        const secAgo = Math.max(1, Math.round((now - ev.timestamp) / 1000));
        let timeAgo = `${secAgo}s ago`;
        if (secAgo > 60) timeAgo = `${Math.floor(secAgo / 60)}m ago`;
        if (secAgo > 3600) timeAgo = `${Math.floor(secAgo / 3600)}h ago`;

        return {
          id: ev.eventId,
          eventType: ev.eventType,
          description: desc,
          timestamp: ev.timestamp,
          timeAgo,
          badgeType,
          userName: ev.userName,
          isRegistered: !!ev.userId,
          device: `${ev.deviceCategory} • ${ev.browser}`
        };
      });

    // 10 Primary Dashboard Cards
    const cards = {
      totalVisitors: baseVisitors,
      activeNow: Math.max(activeNow, 1),
      subscriptionPageVisitors: subPageVisitors,
      paymentPageVisitors,
      paymentStarted,
      paymentSubmitted,
      pendingPayments: verifiedPendingCount,
      approvedPayments: verifiedApprovedCount,
      paymentAbandonment: paymentAbandoned,
      activeSubscribers: Math.max(activeSubscribers, subscriptionStore.getAdminMetrics().activeSubscribers)
    };

    return {
      timeframe: range,
      customStartDate: customStart,
      customEndDate: customEnd,
      lastUpdated: now,
      counters,
      cards,
      funnel,
      dropOffReport: {
        stages: dropOffStages,
        totalLostBetweenOpenAndSub: Math.max(0, baseVisitors - verifiedApprovedCount),
        highestDropOffStage: highestDropOff
      },
      abandonmentStats,
      paymentMethods,
      plans,
      todayMetrics,
      trafficSources,
      devices,
      browsers,
      hourlyTrends,
      dailyTrends,
      userJourneys,
      liveFeed,
      highIntentUsers,
      notifications: this.db.notifications
    };
  }

  // Export CSV of aggregated analytics
  public exportAnalyticsCSV(range: DateFilterRange = 'TODAY', customStart?: string, customEnd?: string): string {
    const data = this.getComprehensiveAnalytics(range, customStart, customEnd);
    
    let csv = `NH STOCK TRADING — USER FUNNEL & CONVERSION ANALYTICS REPORT\n`;
    csv += `Generated At,${new Date().toISOString()}\n`;
    csv += `Date Filter,${range}\n\n`;

    csv += `1. REAL-TIME OVERVIEW METRICS\n`;
    csv += `Metric,Value\n`;
    csv += `Total Visitors,${data.counters.totalVisitors}\n`;
    csv += `Active Now (Last 5 Mins),${data.counters.activeNow}\n`;
    csv += `Today's Visitors,${data.counters.todayVisitors}\n`;
    csv += `This Week's Visitors,${data.counters.thisWeekVisitors}\n`;
    csv += `This Month's Visitors,${data.counters.thisMonthVisitors}\n`;
    csv += `Total Sessions,${data.counters.totalSessions}\n\n`;

    csv += `2. USER CONVERSION FUNNEL (9 STAGES)\n`;
    csv += `Stage ID,Stage Name,Users Count,% of Total Visitors,Conversion from Prev %,Drop-off %,Drop-off Count\n`;
    data.funnel.forEach(f => {
      csv += `"${f.stageId}","${f.stageName}",${f.usersCount},${f.percentOfTotalVisitors}%,${f.conversionFromPrevPercent}%,${f.dropOffPercent}%,${f.dropOffCount}\n`;
    });
    csv += `\n`;

    csv += `3. PAYMENT PAGE ABANDONMENT ANALYSIS\n`;
    csv += `Metric,Count / Rate\n`;
    csv += `Payment Page Visitors,${data.abandonmentStats.paymentPageVisitors}\n`;
    csv += `Payment Started,${data.abandonmentStats.paymentStarted}\n`;
    csv += `Payment Submitted,${data.abandonmentStats.paymentSubmitted}\n`;
    csv += `Payment Abandoned (>30m Inactivity),${data.abandonmentStats.paymentAbandoned}\n`;
    csv += `Payment Conversion Rate,${data.abandonmentStats.paymentConversionRate}%\n`;
    csv += `Payment Abandonment Rate,${data.abandonmentStats.paymentAbandonmentRate}%\n`;
    csv += `High Intent Users Count,${data.abandonmentStats.highIntentUsersCount}\n\n`;

    csv += `4. PAYMENT METHOD BREAKDOWN\n`;
    csv += `Method,Views,Selected,Submitted,Approved,Conversion Rate %\n`;
    csv += `Easypaisa,${data.paymentMethods.easypaisa.views},${data.paymentMethods.easypaisa.selected},${data.paymentMethods.easypaisa.submitted},${data.paymentMethods.easypaisa.approved},${data.paymentMethods.easypaisa.conversionRate}%\n`;
    csv += `Faysal Bank,${data.paymentMethods.faysalBank.views},${data.paymentMethods.faysalBank.selected},${data.paymentMethods.faysalBank.submitted},${data.paymentMethods.faysalBank.approved},${data.paymentMethods.faysalBank.conversionRate}%\n\n`;

    csv += `5. PLAN BREAKDOWN\n`;
    csv += `Plan,Views,Selected,Payment Started,Submitted,Approved,Conversion Rate %\n`;
    csv += `Monthly (5,000),${data.plans.monthly.views},${data.plans.monthly.selected},${data.plans.monthly.paymentStarted},${data.plans.monthly.submitted},${data.plans.monthly.approved},${data.plans.monthly.conversionRate}%\n`;
    csv += `Yearly (50,000),${data.plans.yearly.views},${data.plans.yearly.selected},${data.plans.yearly.paymentStarted},${data.plans.yearly.submitted},${data.plans.yearly.approved},${data.plans.yearly.conversionRate}%\n\n`;

    csv += `6. DAILY TREND SUMMARY\n`;
    csv += `Date,Visitors,Payment Starts,Submissions,Approvals,Revenue (PKR)\n`;
    data.dailyTrends.forEach(d => {
      csv += `${d.date},${d.visitors},${d.paymentStarts},${d.paymentSubmissions},${d.approvals},${d.revenue}\n`;
    });

    return csv;
  }
}

export const analyticsStore = new AnalyticsStore();
