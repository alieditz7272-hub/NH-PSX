import crypto from 'crypto';
import express from 'express';

// =========================================================================
// HIGH-SECURITY INFRASTRUCTURE & CRYPTOGRAPHIC VERIFICATION
// =========================================================================

const ADMIN_SECRET_MASTER = process.env.ADMIN_SECRET_KEY || 'nhpro2026';

// Timing-safe comparison to prevent side-channel timing attacks on the Admin Key
export function verifyAdminKey(providedKey: string | undefined): boolean {
  if (!providedKey || typeof providedKey !== 'string') return false;
  try {
    const keyBuf = Buffer.from(providedKey.trim());
    const masterBuf = Buffer.from(ADMIN_SECRET_MASTER);
    if (keyBuf.length !== masterBuf.length) return false;
    return crypto.timingSafeEqual(keyBuf, masterBuf);
  } catch {
    return false;
  }
}

// Multi-Tier In-Memory Sliding Window Rate Limiter
interface RateLimitEntry {
  count: number;
  resetTime: number;
}

export class SlidingWindowRateLimiter {
  private limits = new Map<string, RateLimitEntry>();
  private intervalId: NodeJS.Timeout;

  constructor(cleanupIntervalMs = 60000) {
    this.intervalId = setInterval(() => {
      const now = Date.now();
      for (const [key, entry] of this.limits.entries()) {
        if (now > entry.resetTime) {
          this.limits.delete(key);
        }
      }
    }, cleanupIntervalMs);
  }

  public check(key: string, maxRequests: number, windowMs: number): { allowed: boolean; remaining: number; retryAfterSec: number } {
    const now = Date.now();
    const entry = this.limits.get(key);

    if (!entry || now > entry.resetTime) {
      this.limits.set(key, { count: 1, resetTime: now + windowMs });
      return { allowed: true, remaining: maxRequests - 1, retryAfterSec: Math.ceil(windowMs / 1000) };
    }

    if (entry.count >= maxRequests) {
      const retryAfterSec = Math.max(1, Math.ceil((entry.resetTime - now) / 1000));
      return { allowed: false, remaining: 0, retryAfterSec };
    }

    entry.count++;
    return { allowed: true, remaining: maxRequests - entry.count, retryAfterSec: Math.ceil((entry.resetTime - now) / 1000) };
  }
}

const authRateLimiter = new SlidingWindowRateLimiter();
const paymentRateLimiter = new SlidingWindowRateLimiter();
const aiRateLimiter = new SlidingWindowRateLimiter();
const apiRateLimiter = new SlidingWindowRateLimiter();

function getClientIp(req: express.Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  return req.socket.remoteAddress || '127.0.0.1';
}

export function createRateLimiterMiddleware(limiter: SlidingWindowRateLimiter, maxRequests: number, windowMs: number, name: string) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const ip = getClientIp(req);
    const key = `${name}:${ip}`;
    const result = limiter.check(key, maxRequests, windowMs);

    res.setHeader('X-RateLimit-Limit', maxRequests.toString());
    res.setHeader('X-RateLimit-Remaining', result.remaining.toString());

    if (!result.allowed) {
      res.setHeader('Retry-After', result.retryAfterSec.toString());
      return res.status(429).json({
        status: "error",
        error: "RATE_LIMIT_EXCEEDED",
        message: `Security Rate Limit Exceeded: Too many requests for ${name}. Please wait ${result.retryAfterSec} seconds before retrying.`
      });
    }

    next();
  };
}

// Exported Rate Limiting Middlewares for specific critical endpoints
export const authRateLimitMiddleware = createRateLimiterMiddleware(authRateLimiter, 10, 60000, "Authentication & Login");
export const paymentRateLimitMiddleware = createRateLimiterMiddleware(paymentRateLimiter, 6, 60000, "Payment Submission");
export const aiRateLimitMiddleware = createRateLimiterMiddleware(aiRateLimiter, 15, 60000, "AI & Grounding Engine");
export const apiRateLimitMiddleware = createRateLimiterMiddleware(apiRateLimiter, 200, 60000, "Terminal Market API");

// Deep recursive parameter and payload sanitizer against prototype pollution, path traversal & injection
export function sanitizeInputData(data: any): boolean {
  if (data === null || data === undefined) return true;
  if (typeof data === "string") {
    if (data.includes("\0") || data.includes("%00")) return false; // Null byte injection
    if (data.includes("<script") || data.includes("</script>")) return false; // Cross-site scripting
    if (data.includes("javascript:") || data.includes("vbscript:")) return false;
    return true;
  }
  if (typeof data === "object") {
    for (const key of Object.keys(data)) {
      // Prototype pollution defense
      if (key === "__proto__" || key === "constructor" || key === "prototype") {
        return false;
      }
      if (!sanitizeInputData(data[key])) {
        return false;
      }
    }
  }
  return true;
}

// Enterprise-Grade Security Headers Middleware with seamless AI Studio Preview & PWA Support
export function securityHeadersMiddleware(req: express.Request, res: express.Response, next: express.NextFunction) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-XSS-Protection", "1; mode=block");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("X-Download-Options", "noopen");
  res.setHeader("X-Permitted-Cross-Domain-Policies", "none");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()");
  // Allow cross-origin embedding for AI Studio preview & PWA environments
  res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");

  // Content-Security-Policy with comprehensive AI Studio framing support
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self' https: http: data: blob: 'unsafe-inline' 'unsafe-eval'; " +
    "script-src 'self' 'unsafe-inline' 'unsafe-eval' https: http: data: blob:; " +
    "style-src 'self' 'unsafe-inline' https: http: fonts.googleapis.com; " +
    "font-src 'self' https: http: data: fonts.gstatic.com; " +
    "img-src 'self' data: blob: https: http:; " +
    "connect-src 'self' https: http: wss: ws:; " +
    "frame-ancestors 'self' https://*.google.com https://aistudio.google.com https://*.aistudio.google.com https://*.googleusercontent.com https://*.run.app http://localhost:* http://127.0.0.1:* https:;"
  );

  // Validate query parameters against traversal & injection
  if (req.query && !sanitizeInputData(req.query)) {
    return res.status(400).json({ error: "Invalid parameter format detected by Security Shield." });
  }

  next();
}
