import { TickerQuote } from '../types';
import {
  calculateDynamicPunterStocks,
  calculateDynamicInstitutionalStocks,
  CalculatedPunterStock,
  CalculatedInstitutionalStock
} from '../utils/marketBuzzIntelligenceEngine';

export interface ExitedStockRecord {
  symbol: string;
  name: string;
  category: 'Punter' | 'Institution';
  exitPktTime: string;
  replacedBy: string;
  reason: string;
}

export interface Favorites247Snapshot {
  status: 'ok';
  isMarketOpen: boolean;
  serverTimePkt: string;
  engineMode: '24/7 SERVER DESK ACTIVE';
  cycleCount: number;
  lastEvaluatedTimestamp: number;
  punters: CalculatedPunterStock[];
  institutions: CalculatedInstitutionalStock[];
  recentPunterExits: ExitedStockRecord[];
  recentInstExits: ExitedStockRecord[];
  activeSpeedLeader: string;
  activeInstitutionalLeader: string;
}

function getPktTimeString(): string {
  try {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Karachi',
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
    const parts = formatter.formatToParts(now);
    let day = '', month = '', year = '', hour = '', minute = '', second = '', dayPeriod = '';
    for (const p of parts) {
      if (p.type === 'day') day = p.value;
      if (p.type === 'month') month = p.value;
      if (p.type === 'year') year = p.value;
      if (p.type === 'hour') hour = p.value;
      if (p.type === 'minute') minute = p.value;
      if (p.type === 'second') second = p.value;
      if (p.type === 'dayPeriod') dayPeriod = p.value.toUpperCase();
    }
    return `${day} ${month} ${year} • ${hour}:${minute}:${second} ${dayPeriod} PKT`;
  } catch (e) {
    return `${new Date().toLocaleTimeString()} PKT`;
  }
}

class Favorites247Engine {
  private punters: CalculatedPunterStock[] = [];
  private institutions: CalculatedInstitutionalStock[] = [];
  private previousPunterSymbols: string[] = [];
  private previousInstSymbols: string[] = [];
  private recentPunterExits: ExitedStockRecord[] = [];
  private recentInstExits: ExitedStockRecord[] = [];
  private cycleCount: number = 0;
  private lastEvaluatedTimestamp: number = Date.now();
  private lastEvaluatedPkt: string = getPktTimeString();
  private isMarketOpen: boolean = false;
  private timer: NodeJS.Timeout | null = null;
  private latestQuotesRef: TickerQuote[] = [];

  constructor() {
    this.lastEvaluatedPkt = getPktTimeString();
  }

  public startBackgroundWorker(getLatestQuotes: () => TickerQuote[], checkMarketOpen: () => boolean) {
    if (this.timer) {
      clearInterval(this.timer);
    }

    // Initial evaluation immediately
    try {
      this.latestQuotesRef = getLatestQuotes();
      this.isMarketOpen = checkMarketOpen();
      this.evaluate(this.latestQuotesRef, this.isMarketOpen);
    } catch (e) {
      console.error('[FAVORITES 24/7 ENGINE] Initial evaluation failed:', e);
    }

    // Run continuous 24/7 background worker loop every 10 seconds
    this.timer = setInterval(() => {
      try {
        this.latestQuotesRef = getLatestQuotes();
        this.isMarketOpen = checkMarketOpen();
        this.evaluate(this.latestQuotesRef, this.isMarketOpen);
      } catch (err) {
        console.error('[FAVORITES 24/7 ENGINE] Background tick error:', err);
      }
    }, 10000);

    console.log('⚡ [FAVORITES 24/7 ENGINE] Autonomous Background Desk Worker initialized (10s Cycle)');
  }

  public evaluate(quotes: TickerQuote[], marketOpen: boolean) {
    this.cycleCount++;
    this.lastEvaluatedTimestamp = Date.now();
    this.lastEvaluatedPkt = getPktTimeString();
    this.isMarketOpen = marketOpen;

    const effectiveQuotes = quotes && quotes.length > 0 ? quotes : this.latestQuotesRef;

    // 1. Calculate Punter's Favorite Stocks with real-time speed velocity (Top 10)
    const newPunters = calculateDynamicPunterStocks(effectiveQuotes, {
      cycleTick: this.cycleCount,
      isMarketOpen: marketOpen,
      previousTop10: this.previousPunterSymbols,
      previousTop5: this.previousPunterSymbols
    });

    // Detect displaced / exited punter stocks from Top 10
    const newPunterSymbols = newPunters.map(p => p.symbol);
    if (this.previousPunterSymbols.length > 0) {
      const exitedSymbols = this.previousPunterSymbols.filter(sym => !newPunterSymbols.includes(sym));
      exitedSymbols.forEach(exSym => {
        const replacementStock = newPunters.find(p => !this.previousPunterSymbols.includes(p.symbol));
        const oldPunter = this.punters.find(p => p.symbol === exSym);
        this.recentPunterExits.unshift({
          symbol: exSym,
          name: oldPunter?.name || `${exSym} Limited`,
          category: 'Punter',
          exitPktTime: this.lastEvaluatedPkt,
          replacedBy: replacementStock?.symbol || 'Faster Mover',
          reason: 'Overtaken by higher momentum velocity & volume surge'
        });
      });
      // Keep only last 10 exits
      if (this.recentPunterExits.length > 10) {
        this.recentPunterExits = this.recentPunterExits.slice(0, 10);
      }
    }

    this.punters = newPunters;
    this.previousPunterSymbols = newPunterSymbols;

    // 2. Calculate Institution's Favorite Stocks with accumulation velocity & CDC delivery ratio (Top 10)
    const newInstitutions = calculateDynamicInstitutionalStocks(effectiveQuotes, {
      cycleTick: this.cycleCount,
      isMarketOpen: marketOpen,
      previousTop10: this.previousInstSymbols,
      previousTop5: this.previousInstSymbols
    });

    // Detect displaced / exited institutional stocks from Top 10
    const newInstSymbols = newInstitutions.map(inst => inst.symbol);
    if (this.previousInstSymbols.length > 0) {
      const exitedInstSymbols = this.previousInstSymbols.filter(sym => !newInstSymbols.includes(sym));
      exitedInstSymbols.forEach(exSym => {
        const replacementStock = newInstitutions.find(inst => !this.previousInstSymbols.includes(inst.symbol));
        const oldInst = this.institutions.find(i => i.symbol === exSym);
        this.recentInstExits.unshift({
          symbol: exSym,
          name: oldInst?.name || `${exSym} Limited`,
          category: 'Institution',
          exitPktTime: this.lastEvaluatedPkt,
          replacedBy: replacementStock?.symbol || 'Higher Accumulation',
          reason: 'Overtaken by higher CDC physical delivery & institutional block inflows'
        });
      });
      // Keep only last 10 exits
      if (this.recentInstExits.length > 10) {
        this.recentInstExits = this.recentInstExits.slice(0, 10);
      }
    }

    this.institutions = newInstitutions;
    this.previousInstSymbols = newInstSymbols;
  }

  public getSnapshot(): Favorites247Snapshot {
    return {
      status: 'ok',
      isMarketOpen: this.isMarketOpen,
      serverTimePkt: this.lastEvaluatedPkt,
      engineMode: '24/7 SERVER DESK ACTIVE',
      cycleCount: this.cycleCount,
      lastEvaluatedTimestamp: this.lastEvaluatedTimestamp,
      punters: this.punters,
      institutions: this.institutions,
      recentPunterExits: this.recentPunterExits,
      recentInstExits: this.recentInstExits,
      activeSpeedLeader: this.punters[0]?.symbol || 'N/A',
      activeInstitutionalLeader: this.institutions[0]?.symbol || 'N/A'
    };
  }
}

export const favorites247Engine = new Favorites247Engine();
