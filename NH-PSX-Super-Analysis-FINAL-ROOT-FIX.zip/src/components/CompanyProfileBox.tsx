import React, { useEffect, useMemo, useState } from 'react';
import { Building2, RefreshCw, Rocket } from 'lucide-react';
import { getPSXCompanyProfile } from '../data/psxCompanyProfiles';
import { getPSXExpansionIntelligence } from '../data/psxExpansionData';
import { TickerQuote } from '../types';
import { fetchFundamentalSnapshot, FundamentalSnapshot } from '../services/psxFundamentalSnapshot';

interface Props { selectedTicker: TickerQuote; sectorName?: string; defaultLang?: 'URDU' | 'EN'; }
const fmt = (v: number | null | undefined, digits = 2) => v == null || !Number.isFinite(v) ? '—' : v.toFixed(digits);
const fmtInt = (v: number | null | undefined) => v == null || !Number.isFinite(v) ? '—' : Math.round(v).toLocaleString('en-US');

export const CompanyProfileBox: React.FC<Props> = ({ selectedTicker, sectorName, defaultLang='URDU' }) => {
  const [lang, setLang] = useState(defaultLang);
  const [tab, setTab] = useState<'OVERVIEW'|'VALUE'|'EXPANSION'>('OVERVIEW');
  const [data, setData] = useState<FundamentalSnapshot | null>(null);
  const [loading, setLoading] = useState(false);
  const symbol = (selectedTicker.symbol || '').replace(/\.PSX$|\.KA$/i,'').toUpperCase();
  const profile = useMemo(() => getPSXCompanyProfile(selectedTicker.symbol, selectedTicker.name, sectorName, selectedTicker.price), [selectedTicker.symbol, selectedTicker.name, selectedTicker.price, sectorName]);
  const isIndex = /^(KSE100|KSE30|KMI30|ALLSHR|KSE)$/i.test(symbol) || profile.businessScale === 'Benchmark Index';
  const expansion = useMemo(() => getPSXExpansionIntelligence(symbol, sectorName || selectedTicker.sector), [symbol, sectorName, selectedTicker.sector]);

  const load = async () => {
    if (isIndex) return;
    setLoading(true);
    try { setData(await fetchFundamentalSnapshot(symbol)); } catch { setData(null); }
    finally { setLoading(false); }
  };
  useEffect(() => { setData(null); void load(); }, [symbol]);

  const value = useMemo(() => {
    if (!data?.expectedEps || !data.sectorMedianPe) return null;
    const earnings = data.expectedEps * data.sectorMedianPe;
    const current = selectedTicker.price || 0;
    return { earnings, current, upside: current ? ((earnings-current)/current)*100 : 0 };
  }, [data, selectedTicker.price]);

  const field = (label: string, val: React.ReactNode) => (
    <div className="rounded-lg bg-black/35 border border-white/5 p-2"><div className="text-[9px] text-slate-400 uppercase">{label}</div><div className="text-sm font-bold text-white mt-0.5">{val}</div></div>
  );

  return <div className="w-full rounded-2xl bg-[#07101B] border border-cyan-500/20 p-2.5 text-slate-200 space-y-2">
    <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-2">
      <div className="flex items-center gap-2 min-w-0"><Building2 className="w-4 h-4 text-cyan-300 shrink-0"/><div className="min-w-0"><div className="text-xs font-black text-white truncate">{profile.companyName}</div><div className="text-[9px] text-slate-400 truncate">{symbol} • {sectorName || selectedTicker.sector || 'PSX'}</div></div></div>
      <div className="flex gap-1 shrink-0"><button onClick={()=>setLang('URDU')} className={`px-2 py-1 text-[9px] rounded ${lang==='URDU'?'bg-emerald-500 text-black':'bg-black/50 text-slate-400'}`}>UR</button><button onClick={()=>setLang('EN')} className={`px-2 py-1 text-[9px] rounded ${lang==='EN'?'bg-cyan-500 text-black':'bg-black/50 text-slate-400'}`}>EN</button>{!isIndex&&<button onClick={load} className="p-1 rounded bg-black/50 text-cyan-300"><RefreshCw className={`w-3 h-3 ${loading?'animate-spin':''}`}/></button>}</div>
    </div>
    <div className="flex gap-1 overflow-x-auto no-scrollbar"><button onClick={()=>setTab('OVERVIEW')} className={`px-2.5 py-1.5 rounded text-[9px] font-bold whitespace-nowrap ${tab==='OVERVIEW'?'bg-cyan-500 text-black':'bg-black/40 text-slate-400'}`}>Overview</button><button onClick={()=>setTab('VALUE')} className={`px-2.5 py-1.5 rounded text-[9px] font-bold whitespace-nowrap ${tab==='VALUE'?'bg-emerald-400 text-black':'bg-black/40 text-slate-400'}`}>True Fundamental Value</button><button onClick={()=>setTab('EXPANSION')} className={`px-2.5 py-1.5 rounded text-[9px] font-bold whitespace-nowrap ${tab==='EXPANSION'?'bg-cyan-500 text-black':'bg-black/40 text-slate-400'}`}>Expansion</button></div>

    {tab==='OVERVIEW' && <>
      {isIndex ? <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">{field('Current Index',fmtInt(selectedTicker.price))}{field('Change',fmt(selectedTicker.change))}{field('% Change',`${fmt(selectedTicker.changePercent)}%`)}{field('Day High',fmt(selectedTicker.high))}{field('Day Low',fmt(selectedTicker.low))}{field('Previous Close',fmt(selectedTicker.previousClose))}</div> : <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
        {field('Face Value',fmt(data?.faceValue))}{field('Current EPS',fmt(data?.currentEps))}{field('Expected EPS',fmt(data?.expectedEps))}{field('Current Book Value',fmt(data?.currentBookValue))}{field('Expected Book Value',fmt(data?.expectedBookValue))}{field('Current Enterprise Value',fmtInt(data?.currentEnterpriseValue))}{field('Expected Enterprise Value',fmtInt(data?.expectedEnterpriseValue))}{field('Latest Cash Dividend',fmt(data?.latestCashDividend))}{field('Expected Cash Dividend',fmt(data?.expectedCashDividend))}{field('Latest Cash Dividend Ex Date',data?.latestCashDividendExDate || '—')}{field('Current Year Profit/Loss',fmtInt(data?.currentYearProfitLoss))}{field('Previous Year Profit/Loss',fmtInt(data?.previousYearProfitLoss))}
      </div>}
      <div className="grid grid-cols-2 gap-1.5">{field('P/E Ratio',fmt(data?.peRatio,1)+'x')}{field('Sector Median P/E',fmt(data?.sectorMedianPe,1)+'x')}{field('Founded',profile.foundedYear || '—')}{field('Listed',profile.listingYear || '—')}</div>
    </>}

    {tab==='VALUE' && <div className="space-y-2">{isIndex ? <div className="p-3 rounded-xl bg-black/30 border border-white/10 text-sm font-bold text-slate-300">True Fundamental Value is for operating companies; KSE-100 is an index.</div> : value ? <><div className="rounded-xl bg-emerald-950/25 border border-emerald-400/30 p-3"><div className="text-[10px] uppercase text-emerald-300">True Fundamental Value</div><div className="text-3xl font-black text-white mt-1">{fmt(value.earnings)}</div><div className="text-[10px] text-slate-400 mt-1">Expected EPS × sector median P/E</div><div className="text-xs font-bold mt-2 text-emerald-300">{value.upside>=0?'+':''}{value.upside.toFixed(1)}% vs current price</div></div><div className="grid grid-cols-2 gap-1.5">{field('Expected EPS',fmt(data?.expectedEps))}{field('Sector Median P/E',fmt(data?.sectorMedianPe,1)+'x')}{field('Current Price',fmt(selectedTicker.price))}{field('Earnings Value',fmt(value.earnings))}</div></> : <div className="p-3 rounded-xl bg-black/30 border border-white/10 text-sm text-slate-400">Verified inputs unavailable. No value is estimated.</div>}</div>}

    {tab==='EXPANSION' && <div className="rounded-xl bg-black/30 border border-white/10 p-3 text-xs">{expansion.hasExpansion ? <><div className="flex items-center gap-1.5 font-bold text-white"><Rocket className="w-4 h-4 text-emerald-400"/> {expansion.statusBadgeEnglish}</div><p className="text-slate-300 mt-2 leading-relaxed">{lang==='URDU'?expansion.detailsUrdu:expansion.detailsEnglish}</p></> : <div className="text-slate-400">No verified major expansion data available.</div>}</div>}
  </div>;
};
