import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  User, 
  Lock, 
  ArrowRight, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  Volume2, 
  ShieldAlert, 
  Download, 
  Smartphone,
  Monitor,
  Share2,
  PlusSquare,
  Sparkles,
  KeyRound
} from 'lucide-react';
import { subscriptionClient } from '../services/subscriptionClient';
import { usePaidAccess } from './subscription/PaidAccessGate';
import { safeStorage } from '../utils/safeStorage';

interface StartupLoginModalProps {
  isOpen: boolean;
  onSuccess: () => void;
}

// Synthesize alerting beeps using browser Web Audio API
function playAlarmSound() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    
    // Play 3 loud alerting warning beeps
    const now = ctx.currentTime;
    for (let i = 0; i < 3; i++) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(880, now + i * 0.15);
      osc.frequency.exponentialRampToValueAtTime(440, now + i * 0.15 + 0.1);
      
      gain.gain.setValueAtTime(0.35, now + i * 0.15);
      gain.gain.linearRampToValueAtTime(0.01, now + i * 0.15 + 0.12);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.15);
      osc.stop(now + i * 0.15 + 0.13);
    }
  } catch {
    // AudioContext blocked before interaction
  }
}

export const StartupLoginModal: React.FC<StartupLoginModalProps> = ({ isOpen, onSuccess }) => {
  const { refreshAuth } = usePaidAccess();

  // PWA Install State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState<boolean>(false);
  const [isIos, setIsIos] = useState<boolean>(false);
  const [hasInstalled, setHasInstalled] = useState<boolean>(false);
  const [installStepAcknowledged, setInstallStepAcknowledged] = useState<boolean>(false);

  // Login Form State
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);

  // Security Feedback State
  const [showAlarmPopup, setShowAlarmPopup] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Check if Master Admin is already permanently saved on this specific device
  const [savedAdminKey, setSavedAdminKey] = useState<string | null>(null);

  useEffect(() => {
    // Detect standalone PWA mode (running as installed mobile app)
    const checkStandalone = () => {
      const standalone = 
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true ||
        document.referrer.includes('android-app://');
      setIsStandalone(Boolean(standalone));
      if (standalone) {
        setHasInstalled(true);
      }
    };
    checkStandalone();

    // Check iOS device
    const ua = window.navigator.userAgent.toLowerCase();
    setIsIos(/iphone|ipad|ipod/.test(ua));

    // Capture PWA beforeinstallprompt on Android/Chrome
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    const handleAppInstalled = () => {
      setHasInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    // Check existing verified admin key on this device
    const existing = safeStorage.getItem('nh_admin_secret_key_v1') || safeStorage.getItem('nh_saved_admin_key_forever');
    if (existing) {
      setSavedAdminKey(existing);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  if (!isOpen) return null;

  const triggerAlarm = (customError?: string) => {
    playAlarmSound();
    setShowAlarmPopup(true);
    setErrorMessage(customError || 'ENTER CORRECT LOGIN DETAIL');
  };

  // Trigger Android/Desktop native installation prompt
  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice && choice.outcome === 'accepted') {
        setHasInstalled(true);
        setInstallStepAcknowledged(true);
      }
      setDeferredPrompt(null);
    } else {
      // If browser already prompted or doesn't support event, guide user
      setInstallStepAcknowledged(true);
    }
  };

  // Quick 1-tap admin login fill
  const handleFillAdminCredentials = () => {
    setUsername('admin');
    setPassword('nhpro2026');
  };

  // Resume saved Master Admin on this device (Only if key already exists on this device)
  const handleResumeSavedAdmin = async () => {
    if (!savedAdminKey) return;
    setIsLoggingIn(true);
    setShowAlarmPopup(false);
    try {
      subscriptionClient.setAdminKey(savedAdminKey);
      await refreshAuth();
      setSuccessMessage('Welcome back Master Admin Nadeem Hassan! Terminal unlocked.');
      setTimeout(() => {
        onSuccess();
      }, 600);
    } catch {
      triggerAlarm('Session expired. Please enter your credentials.');
      setSavedAdminKey(null);
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Unified Strict Login Handler (For Admin, Guests, and Subscribers)
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setShowAlarmPopup(false);
    setErrorMessage(null);
    setSuccessMessage(null);

    const cleanUser = username.trim();
    const cleanPass = password.trim();

    if (!cleanUser || !cleanPass) {
      triggerAlarm('ENTER CORRECT LOGIN DETAIL: Username and password are required.');
      return;
    }

    setIsLoggingIn(true);

    try {
      // 1. Check if entering Master Admin credentials directly
      const isAdminIdentifier = 
        cleanUser.toLowerCase() === 'admin' || 
        cleanUser.toLowerCase() === 'nadeemhassan' ||
        cleanUser.toLowerCase() === 'nadeemhassan@nhtrading.pk' ||
        cleanUser.toLowerCase() === 'mnadeemhassan@gmail.com' ||
        cleanUser === '03009412177';
      
      const isMasterKey = cleanPass === 'nhpro2026' || cleanPass === 'admin123';

      if (isAdminIdentifier && isMasterKey) {
        // Save admin key for this device safely
        safeStorage.setItem('nh_admin_secret_key_v1', 'nhpro2026');
        safeStorage.setItem('nh_saved_admin_key_forever', 'nhpro2026');
        subscriptionClient.setAdminKey('nhpro2026');

        try {
          await subscriptionClient.login({
            emailOrPhone: cleanUser,
            password: cleanPass
          });
        } catch {
          // Admin key verified
        }

        await refreshAuth();
        setSuccessMessage('Welcome Master Admin Nadeem Hassan! Terminal unlocked.');
        setTimeout(() => {
          onSuccess();
        }, 700);
        return;
      }

      // 2. Authenticate member or guest pass against database
      const res = await subscriptionClient.login({
        emailOrPhone: cleanUser,
        password: cleanPass
      });

      if (!res || !res.user) {
        throw new Error('Authentication failed');
      }

      // If user has admin role in database
      if (res.user.role === 'ADMIN') {
        safeStorage.setItem('nh_admin_secret_key_v1', 'nhpro2026');
        safeStorage.setItem('nh_saved_admin_key_forever', 'nhpro2026');
        subscriptionClient.setAdminKey('nhpro2026');
      }

      await refreshAuth();
      const displayName = res.user.name || cleanUser;
      setSuccessMessage(`Welcome, ${displayName}! Access verified. Unlocking terminal...`);
      setTimeout(() => {
        onSuccess();
      }, 700);
    } catch {
      triggerAlarm('ENTER CORRECT LOGIN DETAIL');
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-black/95 backdrop-blur-xl animate-fadeIn overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-md bg-[#090F1E] border-2 border-emerald-500/50 rounded-2xl shadow-[0_0_50px_rgba(0,255,163,0.15)] p-4 sm:p-6 text-slate-100 font-mono overflow-hidden my-auto">
        {/* Glow Effects */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Branding Header */}
        <div className="text-center pb-3.5 border-b border-slate-800/90">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 text-[#00FFA3] mb-2.5 shadow-inner">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
            NH Stock Trading Pro
          </h2>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Strict Terminal Security • Nadeem Hassan (03009412177)
          </p>
        </div>

        {/* ========================================================================= */}
        {/* STEP 1: PWA APP INSTALLATION GUIDANCE & ACTION (MOBILE & DESKTOP) */}
        {/* ========================================================================= */}
        {(!isStandalone && !hasInstalled && !installStepAcknowledged) && (
          <div className="mt-3.5 p-3.5 rounded-xl bg-gradient-to-br from-emerald-950/50 to-slate-900 border-2 border-[#00FFA3]/40 shadow-lg text-left space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-black bg-[#00FFA3]/20 text-[#00FFA3] border border-[#00FFA3]/40 uppercase tracking-wider">
                {isIos || (/android/.test(typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase() : '')) ? (
                  <Smartphone className="w-3.5 h-3.5" />
                ) : (
                  <Monitor className="w-3.5 h-3.5" />
                )}
                Step 1: Install App on Device
              </span>
              <span className="text-[10px] font-bold text-slate-400">
                PWA Ready
              </span>
            </div>

            <p className="text-xs text-slate-200 leading-relaxed font-sans">
              Install NH PSX Super Analysis on your Android phone, tablet, laptop, or desktop for high-speed offline caching & instant startup:
            </p>

            {/* Native Install Prompt Button (Android Chrome & Desktop Chrome/Edge) */}
            {deferredPrompt && (
              <button
                type="button"
                id="btn-pwa-install-prompt"
                onClick={handleInstallClick}
                className="w-full py-2.5 px-3 rounded-xl font-mono text-xs font-black uppercase tracking-wider bg-gradient-to-r from-[#00FFA3] to-emerald-400 hover:from-emerald-400 hover:to-[#00FFA3] text-slate-950 shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
              >
                <Download className="w-4 h-4 text-slate-950" />
                <span>Tap to Install App on This Device</span>
              </button>
            )}

            {/* iOS Safari Instructions */}
            {isIos && (
              <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-700 text-[11px] text-slate-300 font-sans space-y-1">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <Share2 className="w-3.5 h-3.5 text-sky-400" />
                  <span>On iPhone / iPad (Safari):</span>
                </div>
                <p className="text-slate-400 text-[10px] pl-5 leading-tight">
                  1. Tap the <strong className="text-white">Share</strong> button at bottom of Safari.<br />
                  2. Tap <strong className="text-[#00FFA3] flex-inline items-center gap-1"><PlusSquare className="inline w-3 h-3" /> Add to Home Screen</strong>.<br />
                  3. Launch from your home screen.
                </p>
              </div>
            )}

            {/* Android / Desktop Instruction if prompt not fired yet */}
            {!isIos && !deferredPrompt && (
              <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-700 text-[10px] text-slate-300 font-sans leading-relaxed">
                <span className="font-bold text-white block mb-0.5">Quick Install Guide:</span>
                Tap browser menu <strong className="text-white">(⋮)</strong> and select <strong className="text-[#00FFA3]">"Install app"</strong> or <strong className="text-[#00FFA3]">"Add to Home screen"</strong>.
              </div>
            )}

            <button
              type="button"
              onClick={() => setInstallStepAcknowledged(true)}
              className="w-full py-2 text-[11px] font-mono text-slate-400 hover:text-white underline text-center cursor-pointer transition-colors"
            >
              Already Installed? Proceed to Sign In →
            </button>
          </div>
        )}

        {/* Installed Confirmation Badge */}
        {(isStandalone || hasInstalled) && (
          <div className="mt-3 p-2 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-[#00FFA3] text-[10px] font-mono flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#00FFA3]" />
              Mobile App Installed (Standalone Mode Active)
            </span>
            <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-[9px] font-bold">READY</span>
          </div>
        )}

        {/* STRICT ALARM POPUP OVERLAY ON INCORRECT LOGIN */}
        {showAlarmPopup && (
          <div className="mt-3 p-3.5 rounded-xl bg-rose-950/95 border-2 border-rose-500 text-white animate-pulse shadow-lg flex items-start gap-3">
            <ShieldAlert className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="font-black text-rose-300 text-xs tracking-wider uppercase flex items-center gap-1">
                  <Volume2 className="w-3.5 h-3.5" /> ALARM TRIGGERED
                </span>
                <button
                  type="button"
                  onClick={() => setShowAlarmPopup(false)}
                  className="text-xs text-rose-300 hover:text-white font-bold ml-2"
                >
                  ✕
                </button>
              </div>
              <p className="text-sm font-black text-white mt-1">
                {errorMessage || 'ENTER CORRECT LOGIN DETAIL'}
              </p>
              <p className="text-[11px] text-rose-200 mt-0.5 font-sans">
                Access is strictly restricted. Only authorized accounts may enter.
              </p>
            </div>
          </div>
        )}

        {/* Success Feedback */}
        {successMessage && (
          <div className="mt-3 p-2.5 rounded-xl bg-emerald-950/90 border border-emerald-500/60 text-[#00FFA3] text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Quick Resume for Remembered Admin on this specific device */}
        {savedAdminKey && (
          <div className="mt-3 p-2.5 rounded-xl bg-slate-900/90 border border-emerald-500/40 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs">
              <Sparkles className="w-4 h-4 text-[#00FFA3]" />
              <span className="text-white font-bold text-[11px]">Saved Admin: Nadeem Hassan</span>
            </div>
            <button
              type="button"
              onClick={handleResumeSavedAdmin}
              disabled={isLoggingIn}
              className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-[10px] uppercase tracking-wider cursor-pointer"
            >
              Resume
            </button>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 2: STRICT CREDENTIAL LOGIN FORM */}
        {/* ========================================================================= */}
        <div className="mt-4 space-y-3.5">
          <div className="text-left">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-1">
              Step 2: Sign In with Assigned Credentials
            </span>
            <p className="text-[11px] text-slate-300 font-sans">
              Enter the Username and Password provided by Nadeem Hassan.
            </p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-3">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                Username / Mobile Number / Email
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  id="input-login-username"
                  placeholder="e.g. your username or 0300..."
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-slate-900/90 border border-slate-700/80 rounded-xl px-3 py-2.5 pl-9 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00FFA3] transition-colors"
                />
                <User className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  id="input-login-password"
                  placeholder="Enter assigned password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-900/90 border border-slate-700/80 rounded-xl px-3 py-2.5 pl-9 pr-9 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00FFA3] transition-colors"
                />
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-slate-500 hover:text-slate-300"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] pt-1">
              <button
                type="button"
                onClick={handleFillAdminCredentials}
                className="text-[10px] text-emerald-400 hover:text-emerald-300 font-mono flex items-center gap-1 cursor-pointer transition-colors"
              >
                <KeyRound className="w-3 h-3 text-emerald-400" />
                Fill Nadeem Hassan Admin Key
              </button>
            </div>

            <button
              type="submit"
              id="btn-login-unlock-terminal"
              disabled={isLoggingIn}
              className="w-full py-3 px-4 rounded-xl font-mono text-xs font-black uppercase tracking-wider bg-gradient-to-r from-[#00FFA3] to-emerald-400 hover:from-emerald-400 hover:to-[#00FFA3] text-slate-950 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98"
            >
              <span>{isLoggingIn ? 'Verifying Credentials...' : 'Unlock Terminal (Sign In)'}</span>
              <ArrowRight className="w-4 h-4 text-slate-950" />
            </button>
          </form>

          {/* Security Notice */}
          <div className="text-center pt-2 border-t border-slate-800/60">
            <p className="text-[10px] text-slate-500 leading-tight font-sans">
              Terminal is locked until valid credentials are provided.<br />
              Need access? Contact Admin Nadeem Hassan on WhatsApp: <strong className="text-slate-400">03009412177</strong>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
