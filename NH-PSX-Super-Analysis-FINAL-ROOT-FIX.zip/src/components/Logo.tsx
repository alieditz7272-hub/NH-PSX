import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | 'full';
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ size = 'full', className = '' }) => {
  const sizeMap = {
    sm: 'w-44 aspect-[520/96]',
    md: 'w-60 aspect-[520/96]',
    lg: 'w-72 aspect-[520/96]',
    xl: 'w-88 aspect-[520/96]',
    '2xl': 'w-[420px] aspect-[520/96]',
    '3xl': 'w-full max-w-[520px] aspect-[520/96]',
    full: 'w-full aspect-[520/96]',
  };

  const dimClass = sizeMap[size] || sizeMap['full'];

  return (
    <div
      className={`nh-logo-exempt relative flex items-center justify-center shrink-0 ${dimClass} ${className} group cursor-pointer select-none font-mono`}
    >
      {/* Subtle, Calm Institutional Glow (No excessive neon blur) */}
      <div className="absolute inset-0 bg-emerald-500/5 rounded-xl pointer-events-none transition-opacity duration-300 group-hover:opacity-100 opacity-40" />

      {/* Main Container: Pure Obsidian Terminal Surface, Precision Refined Metallic Border */}
      <div className="relative w-full h-full bg-[#060a12] border border-slate-700/60 hover:border-slate-600 rounded-xl flex items-center justify-center overflow-hidden transition-all duration-300 shadow-[0_2px_12px_rgba(0,0,0,0.75)] z-10">
        
        {/* Master Horizontal Fintech Vector SVG (Widescreen 520x96) */}
        <svg
          viewBox="0 0 520 96"
          className="w-full h-full relative z-10"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Subtle Gradient for Outer Hairline */}
            <linearGradient id="nhGlowBorderGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#334155" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#0ea5e9" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#334155" stopOpacity="0.8" />
            </linearGradient>

            {/* Crisp Metallic Gradient for N & H Letters */}
            <linearGradient id="nhFullGreenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#34d399" />
              <stop offset="40%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#065f46" />
            </linearGradient>

            {/* Sub-text Gradient for PRO TERMINAL */}
            <linearGradient id="proTerminalGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#34d399" />
              <stop offset="50%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#34d399" />
            </linearGradient>

            {/* Ambient Radial Aura Behind NH Monogram (Ultra Minimal) */}
            <radialGradient id="nhCenterAura" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.05" />
              <stop offset="100%" stopColor="#060a12" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* 1. CLEAN DARK TERMINAL BACKGROUND */}
          <rect x="0" y="0" width="520" height="96" fill="#060a12" />
          
          {/* Subtle Outer Bevel Perimeter */}
          <rect
            x="2"
            y="2"
            width="516"
            height="92"
            rx="10"
            fill="none"
            stroke="url(#nhGlowBorderGrad)"
            strokeWidth="1"
            opacity="0.4"
          />

          {/* Central Soft Aura Spot behind NH Monogram */}
          <circle cx="84" cy="48" r="48" fill="url(#nhCenterAura)" />

          {/* 2. SOLID, SHARP "NH" MONOGRAM ON THE LEFT */}
          <g id="nh-block-letters">
            {/* --- LETTER 'N' --- */}
            <rect
              x="18"
              y="18"
              width="16"
              height="60"
              rx="3"
              fill="url(#nhFullGreenGrad)"
              stroke="#10b981"
              strokeWidth="1"
            />
            <polygon
              points="18,18 34,18 76,78 60,78"
              fill="url(#nhFullGreenGrad)"
              stroke="#10b981"
              strokeWidth="1"
            />
            <rect
              x="60"
              y="18"
              width="16"
              height="60"
              rx="3"
              fill="url(#nhFullGreenGrad)"
              stroke="#10b981"
              strokeWidth="1"
            />

            {/* Specular Core Light Tubes for Letter 'N' */}
            <line
              x1="26"
              y1="23"
              x2="26"
              y2="73"
              stroke="#FFFFFF"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.85"
            />
            <line
              x1="26"
              y1="23"
              x2="68"
              y2="73"
              stroke="#FFFFFF"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.85"
            />
            <line
              x1="68"
              y1="23"
              x2="68"
              y2="73"
              stroke="#FFFFFF"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.85"
            />

            {/* --- LETTER 'H' --- */}
            <rect
              x="90"
              y="18"
              width="16"
              height="60"
              rx="3"
              fill="url(#nhFullGreenGrad)"
              stroke="#10b981"
              strokeWidth="1"
            />
            <rect
              x="90"
              y="39"
              width="58"
              height="18"
              rx="2.5"
              fill="url(#nhFullGreenGrad)"
              stroke="#10b981"
              strokeWidth="1"
            />
            <rect
              x="132"
              y="18"
              width="16"
              height="60"
              rx="3"
              fill="url(#nhFullGreenGrad)"
              stroke="#10b981"
              strokeWidth="1"
            />

            {/* Specular Core Light Tubes for Letter 'H' */}
            <line
              x1="98"
              y1="23"
              x2="98"
              y2="73"
              stroke="#FFFFFF"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.85"
            />
            <line
              x1="98"
              y1="48"
              x2="140"
              y2="48"
              stroke="#FFFFFF"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.85"
            />
            <line
              x1="140"
              y1="23"
              x2="140"
              y2="73"
              stroke="#FFFFFF"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.85"
            />
          </g>

          {/* 3. VERTICAL PRECISION DIVIDER */}
          <line
            x1="164"
            y1="18"
            x2="164"
            y2="78"
            stroke="url(#nhGlowBorderGrad)"
            strokeWidth="1"
            strokeLinecap="round"
            opacity="0.4"
          />
          <circle cx="164" cy="48" r="2" fill="#10b981" opacity="0.7" />

          {/* 4. BRAND TYPOGRAPHY (CRISP, PROFESSIONAL TERMINAL STYLE) */}
          {/* Line 1: NH STOCK TRADING */}
          <text
            x="180"
            y="33"
            fill="#FFFFFF"
            fontFamily="ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"
            fontWeight="900"
            fontSize="18"
            letterSpacing="0.14em"
          >
            NH STOCK TRADING
          </text>

          {/* Line 2: PRO TERMINAL with Sharp Cyan-Emerald Gradient & Live PSX Badge */}
          <text
            x="180"
            y="57"
            fill="url(#proTerminalGrad)"
            fontFamily="ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"
            fontWeight="900"
            fontSize="14.5"
            letterSpacing="0.22em"
          >
            PRO TERMINAL
          </text>

          {/* LIVE PSX Pill */}
          <g transform="translate(366, 42)">
            <rect
              x="0"
              y="0"
              width="78"
              height="18"
              rx="4"
              fill="#10b981"
              fillOpacity="0.08"
              stroke="#10b981"
              strokeWidth="1"
              strokeOpacity="0.4"
            />
            <circle cx="10" cy="9" r="2" fill="#10b981" opacity="0.8" />
            <text
              x="45"
              y="12.5"
              textAnchor="middle"
              fill="#34d399"
              fontFamily="ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"
              fontSize="9"
              fontWeight="900"
              letterSpacing="0.08em"
            >
              LIVE PSX
            </text>
          </g>

          {/* Line 3: Developed by Nadeem Hassan */}
          <text
            x="180"
            y="78"
            fill="#94a3b8"
            fontFamily="ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"
            fontWeight="700"
            fontSize="11.5"
            letterSpacing="0.08em"
          >
            Developed by Nadeem Hassan
          </text>

          {/* 5. TOP-RIGHT HARDWARE STATUS BEACON */}
          <g transform="translate(494, 14)">
            <circle cx="8" cy="8" r="2" fill="#10b981" opacity="0.7" />
          </g>
        </svg>

        {/* Live Top-Right Hardware Status LED (Subtle) */}
        <div className="absolute top-2.5 right-2.5 flex items-center justify-center w-2 h-2 z-30 pointer-events-none">
          <span className="inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500/70" />
        </div>
      </div>
    </div>
  );
};
