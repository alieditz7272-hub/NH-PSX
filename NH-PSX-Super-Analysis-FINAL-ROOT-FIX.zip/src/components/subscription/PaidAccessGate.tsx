import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserProfile, SubscriptionRecord } from '../../types/subscription';
import { subscriptionClient } from '../../services/subscriptionClient';
import { safeStorage } from '../../utils/safeStorage';

interface PaidAccessContextValue {
  currentUser: UserProfile | null;
  subscription: SubscriptionRecord | null;
  isAdmin: boolean;
  isSubscribed: boolean;
  isLoading: boolean;
  refreshAuth: () => Promise<void>;
}

const PaidAccessContext = createContext<PaidAccessContextValue>({
  currentUser: null,
  subscription: null,
  isAdmin: false,
  isSubscribed: false,
  isLoading: false,
  refreshAuth: async () => {},
});

export const PaidAccessProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [subscription, setSubscription] = useState<SubscriptionRecord | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const refreshAuth = useCallback(async () => {
    try {
      setIsLoading(true);
      const res = await subscriptionClient.checkAuth();
      setCurrentUser(res.user);
      setSubscription(res.subscription);
    } catch {
      setCurrentUser(null);
      setSubscription(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshAuth();
  }, [refreshAuth]);

  const hasAdminKey = Boolean(
    subscriptionClient.getAdminKey() ||
    safeStorage.getItem('nh_admin_secret_key_v1') ||
    safeStorage.getItem('nh_saved_admin_key_forever')
  );
  const isAdmin = currentUser?.role === 'ADMIN' || hasAdminKey;
  const isSubscribed = Boolean(subscription?.status === 'ACTIVE') || isAdmin;

  return (
    <PaidAccessContext.Provider
      value={{
        currentUser,
        subscription,
        isAdmin,
        isSubscribed,
        isLoading,
        refreshAuth,
      }}
    >
      {children}
    </PaidAccessContext.Provider>
  );
};

export const usePaidAccess = () => {
  const context = useContext(PaidAccessContext);
  // Fallback if rendered outside provider
  const [localUser, setLocalUser] = useState<UserProfile | null>(null);
  const [localIsAdmin, setLocalIsAdmin] = useState<boolean>(() => {
    return Boolean(subscriptionClient.getAdminKey());
  });

  useEffect(() => {
    if (!context || !context.currentUser) {
      subscriptionClient
        .checkAuth()
        .then((res) => {
          if (res.user) {
            setLocalUser(res.user);
            if (res.user.role === 'ADMIN') {
              setLocalIsAdmin(true);
            }
          }
        })
        .catch(() => {});
    }
  }, [context]);

  if (context && (context.currentUser || context.isAdmin || context.isLoading)) {
    return context;
  }

  const hasKey = Boolean(subscriptionClient.getAdminKey());
  const isAdmin = localIsAdmin || hasKey || localUser?.role === 'ADMIN';

  return {
    currentUser: localUser,
    subscription: null,
    isAdmin,
    isSubscribed: isAdmin,
    isLoading: false,
    refreshAuth: async () => {},
  };
};

export interface PaidAccessGateProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
  requiredRole?: 'USER' | 'SUBSCRIBER' | 'ADMIN';
}

export const PaidAccessGate: React.FC<PaidAccessGateProps> = ({
  children,
  fallback = null,
  requiredRole = 'SUBSCRIBER',
}) => {
  const { currentUser, isAdmin, isSubscribed, isLoading } = usePaidAccess();

  if (isLoading) {
    return null;
  }

  if (requiredRole === 'ADMIN' && !isAdmin) {
    return <>{fallback}</>;
  }

  if (requiredRole === 'SUBSCRIBER' && !isSubscribed && !isAdmin) {
    return <>{fallback}</>;
  }

  if (requiredRole === 'USER' && !currentUser && !isAdmin) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};

export default PaidAccessGate;
