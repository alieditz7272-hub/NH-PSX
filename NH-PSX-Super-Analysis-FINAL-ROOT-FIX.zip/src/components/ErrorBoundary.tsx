import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  private recoveryTimeout: number | null = null;

  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.warn('Terminal auto-recovered from transient error:', error, errorInfo);
    // Auto-recover after 800ms to prevent stuck anomaly screens
    if (this.recoveryTimeout) {
      window.clearTimeout(this.recoveryTimeout);
    }
    this.recoveryTimeout = window.setTimeout(() => {
      this.setState({ hasError: false, error: null });
    }, 800);
  }

  public componentWillUnmount() {
    if (this.recoveryTimeout) {
      window.clearTimeout(this.recoveryTimeout);
    }
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="w-full p-4 bg-slate-900/90 border border-emerald-500/30 rounded-2xl text-center shadow-lg my-4">
          <div className="flex items-center justify-center gap-2 text-xs font-mono text-emerald-400 mb-2">
            <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
            <span>Synchronizing PSX Data Stream...</span>
          </div>
          <button
            type="button"
            onClick={this.handleReset}
            className="text-[11px] font-mono px-3 py-1 bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/40 hover:bg-emerald-500/30 transition cursor-pointer"
          >
            Resume Live Terminal
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
export default ErrorBoundary;
