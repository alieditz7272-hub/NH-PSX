import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  Target, 
  TrendingUp, 
  Award, 
  Briefcase, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  Activity, 
  RefreshCw, 
  Lock, 
  Landmark, 
  Zap, 
  AlertTriangle,
  Brain
} from 'lucide-react';
import { TickerQuote } from '../types';
import { formatDisplaySymbol, formatDisplayName, isPsxIndex, isPsxDefaulter } from '../utils/symbol';
import { formatPrice } from '../utils/currency';
import { calculateDynamicInstitutionalStocks, CalculatedInstitutionalStock } from '../utils/marketBuzzIntelligenceEngine';
import { authFetch } from '../services/subscriptionClient';

interface InstitutionsFavoriteSectionProps {
  allTickers: TickerQuote[];
  onSelectStock: (symbol: string) => void;
}

interface ExitedRecord {
  symbol: string;
  name: string;
  category: 'Punter' | 'Institution';
  exitPktTime: string;
  replacedBy: string;
  reason: string;
}

export const InstitutionsFavoriteSection: React.FC<InstitutionsFavoriteSectionProps> = ({
  allTickers,
  onSelectStock
}) => {
  const [serverStocks, setServerStocks] = useState<CalculatedInstitutionalStock[] | null>(null);
  const [recentExits, setRecentExits] = useState<ExitedRecord[]>([]);
  const [serverTimePkt, setServerTimePkt] = useState<string>('');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastSyncSecondsAgo, setLastSyncSecondsAgo] = useState<number>(0);

  // Fallback client-side calculation
  const clientStocks = useMemo(() => {
    return calculateDynamicInstitutionalStocks(allTickers);
  }, [allTickers]);

  // Prefer 24/7 server background calculated ranking
  const displayStocks: CalculatedInstitutionalStock[] = serverStocks && serverStocks.length > 0 ? serverStocks : clientStocks;

  // Fetch 24/7 background favorites from server
  const fetchServerFavorites = useCallback(async (isManual = false) => {
    if (isManual) setIsRefreshing(true);
    try {
      const res = await authFetch('/api/market/dynamic-favorites');
      if (res.ok) {
        const data = await res.json();
        if (data.status === 'ok') {
          if (Array.isArray(data.institutions) && data.institutions.length > 0) {
            setServerStocks(data.institutions);
          }
          if (Array.isArray(data.recentInstExits)) {
            setRecentExits(data.recentInstExits);
          }
          if (data.serverTimePkt) {
            setServerTimePkt(data.serverTimePkt);
          }
          setLastSyncSecondsAgo(0);
        }
      }
    } catch (e) {
      // Keep using fallback clientStocks
    } finally {
      if (isManual) {
        setTimeout(() => setIsRefreshing(false), 400);
      }
    }
  }, []);

  // Poll 24/7 continuous server desk every 10 seconds
  useEffect(() => {
    fetchServerFavorites(false);
    const interval = setInterval(() => {
      fetchServerFavorites(false);
    }, 10000);

    const secondTimer = setInterval(() => {
      setLastSyncSecondsAgo(prev => prev + 1);
    }, 1000);

    return () => {
      clearInterval(interval);
      clearInterval(secondTimer);
    };
  }, [fetchServerFavorites]);

  const latestExit = recentExits[0];

  const handleSelectSuperBrain = (symbol: string) => {
    onSelectStock(symbol);
    setTimeout(() => {
      const el = document.getElementById('section-super-analyst') || document.getElementById('super-analyst-view');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }, 120);
  };

  return (
    <section 
      id="section-institutions-favorite-stocks" 
      className="w-full space-y-3 sm:space-y-4 scroll-mt-28"
    >
      {/* Sleek Compact Header */}
      <div className="w-full p-3 sm:p-4 rounded-2xl bg-gradient-to-r from-blue-950/40 via-[#0a0f1d] to-[#0d1527] border border-blue-500/40 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5 relative z-10">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400 border border-blue-500/40 shrink-0">
                <ShieldCheck className="w-4 h-4 sm:w-5 sm:h-5 animate-pulse" />
              </span>
              <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-[#00FFA3] font-mono uppercase tracking-tight drop-shadow-[0_2px_10px_rgba(0,255,163,0.45)]">
                Institution's Favorite Stocks
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[10px] sm:text-xs font-black font-mono flex items-center gap-1">
                <Building2 className="w-2.5 h-2.5 text-blue-400" />
                NCCPL, MUFAP & FIPI Accumulation Tracker
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 font-sans max-w-3xl leading-snug">
              Autonomous 24/7 institutional flow engine monitoring net buying across Mutual Funds (MUFAP), Pension Portfolios, Insurance Desks, and Foreign Corporates (FIPI). Dynamically filters and re-ranks CDC physical delivery custody and long-term fundamental conviction across the top 10 institutional leaders.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0 pt-1 md:pt-0 border-t md:border-t-0 border-white/5">
            <span className="text-[10px] sm:text-xs font-mono font-bold text-emerald-300 bg-emerald-950/70 border border-emerald-500/40 px-2.5 py-1 rounded-lg flex items-center gap-1.5">
              <Activity className="w-3 h-3 text-emerald-400 animate-pulse" />
              24/7 Server Desk Active
            </span>
            {serverTimePkt && (
              <span className="text-[10px] font-mono text-slate-300 bg-slate-900/80 border border-slate-700/60 px-2.5 py-1 rounded-lg hidden sm:flex items-center gap-1">
                <Clock className="w-2.5 h-2.5 text-blue-400" />
                {serverTimePkt}
              </span>
            )}
            <button
              type="button"
              onClick={() => fetchServerFavorites(true)}
              disabled={isRefreshing}
              className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/40 text-[10px] sm:text-xs font-mono font-bold flex items-center gap-1 transition-all cursor-pointer"
              title="Refresh 24/7 Institutional Rankings"
            >
              <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin text-blue-300' : ''}`} />
              <span className="hidden sm:inline">{isRefreshing ? 'Syncing...' : 'Sync Live'}</span>
            </button>
          </div>
        </div>

        {/* Dynamic Rotation Alert Bar (Shows when an institutional pick overtakes another) */}
        {latestExit && (
          <div className="mt-2.5 pt-2 border-t border-blue-500/20 flex items-center justify-between gap-2 text-[10px] sm:text-[11px] font-mono">
            <div className="flex items-center gap-1.5 text-blue-300/90 truncate">
              <Landmark className="w-3 h-3 text-blue-400 shrink-0 animate-pulse" />
              <span className="font-bold text-blue-400">Institutional Inflow Rotation:</span>
              <span className="truncate">
                <span className="text-white font-bold">{latestExit.replacedBy}</span> climbed into Top 10 • <span className="text-slate-400">{latestExit.symbol}</span> rotated out ({latestExit.reason})
              </span>
            </div>
            <span className="text-slate-400 shrink-0 hidden md:inline text-[10px]">
              {latestExit.exitPktTime}
            </span>
          </div>
        )}
      </div>

      {/* Top 10 Dynamic Institution Stocks - Brief List */}
      <div className="flex flex-col gap-2">
        {displayStocks.map((stock: CalculatedInstitutionalStock) => {
          const isPositive = stock.changePercent >= 0;
          const isDefaulter = isPsxDefaulter(stock.symbol, stock);
          const isRankOne = stock.rank === 1;

          return (
            <div
              key={stock.symbol}
              onClick={() => handleSelectSuperBrain(stock.symbol)}
              className={`w-full p-2.5 sm:p-3 rounded-xl transition-all duration-200 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-2.5 cursor-pointer group ${
                isDefaulter
                  ? 'bg-rose-950/25 border-2 border-rose-500/60 hover:border-rose-400 shadow-rose-950/20'
                  : isRankOne
                  ? 'bg-[#0a0f1d] border-2 border-blue-500/50 hover:border-blue-400 shadow-blue-950/20'
                  : 'bg-[#080d1a] border border-blue-500/20 hover:border-blue-500/40'
              }`}
            >
              {/* Left: Numbering & Symbol with Full Company Name + Defaulter Counter Badge */}
              <div className="flex items-center gap-2 sm:gap-2.5 min-w-0 flex-1">
                {/* Numbering */}
                <span className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg font-mono font-black text-xs sm:text-sm flex items-center justify-center shrink-0 ${
                  stock.rank === 1
                    ? 'bg-blue-500 text-white shadow-sm'
                    : stock.rank === 2
                    ? 'bg-blue-500/30 border border-blue-400/50 text-blue-200'
                    : stock.rank === 3
                    ? 'bg-blue-600/30 border border-blue-500/50 text-blue-300'
                    : 'bg-blue-500/15 border border-blue-500/30 text-blue-300'
                }`}>
                  #{stock.rank}
                </span>

                {/* Symbol with Full Company Name */}
                <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 min-w-0">
                  <span className="text-base sm:text-lg font-black text-white font-mono tracking-wide group-hover:text-blue-300 transition-colors">
                    {formatDisplaySymbol(stock.symbol)}
                  </span>
                  <span className="text-xs sm:text-sm text-slate-300 font-sans truncate">
                    {formatDisplayName({ symbol: stock.symbol, name: stock.name })}
                  </span>

                  {/* PSX Defaulter Counter Indicator if on defaulters list */}
                  {isDefaulter && (
                    <span className="px-2 py-0.5 rounded bg-rose-900/70 border border-rose-500/80 text-rose-200 font-mono font-black text-[10px] sm:text-xs flex items-center gap-1 shadow-[0_0_8px_rgba(244,63,94,0.35)] animate-pulse">
                      <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
                      PSX DEFAULTER COUNTER
                    </span>
                  )}
                </div>
              </div>

              {/* Right: Current Price & Consensus Target + Action Button */}
              <div className="flex flex-wrap items-center justify-between md:justify-end gap-x-4 gap-y-1.5 shrink-0 pt-1.5 md:pt-0 border-t md:border-t-0 border-white/5 font-mono">
                {/* Current Price (Strictly formatted without Rs. or Points) */}
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-400 font-mono">Current Price:</span>
                  <span className="text-sm sm:text-base font-black text-white font-mono">
                    {stock.price > 0 ? formatPrice(stock.price, stock) : '—'}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[11px] font-bold ${
                      isPositive
                        ? 'text-[#00FFA3] bg-emerald-500/15 border border-emerald-500/30'
                        : 'text-rose-400 bg-rose-500/15 border border-rose-500/30'
                    }`}
                  >
                    {isPositive ? '+' : ''}{stock.changePercent.toFixed(2)}%
                  </span>
                </div>

                {/* Consensus Target / Institutional Target */}
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-blue-300 font-mono font-bold flex items-center gap-1">
                    <Target className="w-3 h-3 text-blue-400" />
                    Consensus Target:
                  </span>
                  <span className="text-sm sm:text-base font-black text-blue-400 font-mono">
                    {stock.calculatedConsensusTarget.toFixed(2).replace(/,/g, '')}
                  </span>
                  <span className="text-xs font-bold text-blue-300">
                    (+{Math.max(stock.upsidePercent, 12).toFixed(1)}%)
                  </span>
                </div>

                {/* Super Brain View Button */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSelectSuperBrain(stock.symbol);
                  }}
                  className="px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-black font-mono uppercase tracking-wider transition-all shadow hover:scale-105 active:scale-95 flex items-center gap-1.5 cursor-pointer shrink-0"
                  title="Analyze in Super Brain View"
                >
                  <Brain className="w-3.5 h-3.5 text-cyan-200" />
                  <span>Super Brain View</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
