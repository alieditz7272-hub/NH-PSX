import React, { useState, useEffect, useCallback } from 'react';
import { 
  ShieldCheck, 
  UserPlus, 
  Trash2, 
  Edit3, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  Key, 
  ChevronDown, 
  ChevronUp, 
  Check, 
  X,
  Lock,
  Eye,
  EyeOff
} from 'lucide-react';
import { subscriptionClient } from '../services/subscriptionClient';
import { usePaidAccess } from './subscription/PaidAccessGate';

interface ManagedUser {
  id: string;
  name: string;
  username: string;
  email: string;
  phone?: string;
  role: string;
  isGuest: boolean;
  subscriptionStatus: string;
  daysRemaining: number;
  passwordHint?: string;
  notes?: string;
  createdAt: number;
  isActive: boolean;
}

const LOCAL_USERS_KEY = 'nh_admin_managed_users_backup_v2';

export const CompactAdminSection: React.FC = () => {
  const { isAdmin } = usePaidAccess();
  const [users, setUsers] = useState<ManagedUser[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_USERS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [];
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(true);
  const [showCreateForm, setShowCreateForm] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Create Form State
  const [formType, setFormType] = useState<'GUEST' | 'MEMBER'>('GUEST');
  const [formDuration, setFormDuration] = useState<number>(1); // 1, 7, 30, 36500
  const [formName, setFormName] = useState<string>('');
  const [formUsername, setFormUsername] = useState<string>('');
  const [formPassword, setFormPassword] = useState<string>('');
  const [formPhone, setFormPhone] = useState<string>('');
  const [formNotes, setFormNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Edit Modal State
  const [editingUser, setEditingUser] = useState<ManagedUser | null>(null);
  const [editName, setEditName] = useState<string>('');
  const [editPassword, setEditPassword] = useState<string>('');
  const [editDuration, setEditDuration] = useState<number>(30);
  const [showEditPassword, setShowEditPassword] = useState<boolean>(false);
  const [isSavingEdit, setIsSavingEdit] = useState<boolean>(false);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  const loadUsers = useCallback(async () => {
    if (!isAdmin) return;
    setIsLoading(true);
    try {
      const data = await subscriptionClient.getManagedUsers();
      if (Array.isArray(data) && data.length > 0) {
        setUsers(data);
        try { localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(data)); } catch {}
      }
    } catch (err: any) {
      // Quiet fail if not admin
    } finally {
      setIsLoading(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    if (isAdmin) {
      loadUsers();
    }
  }, [isAdmin, loadUsers]);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formUsername.trim() || !formPassword.trim()) {
      showToast('Name, Username, and Password are required', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      await subscriptionClient.createManagedUser({
        name: formName.trim(),
        username: formUsername.trim(),
        password: formPassword.trim(),
        phone: formPhone.trim() || undefined,
        isGuest: formType === 'GUEST',
        durationDays: formType === 'GUEST' ? formDuration : 36500,
        notes: formNotes.trim() || undefined
      });

      showToast(`Created ${formType === 'GUEST' ? 'Guest Pass' : 'Member'} for ${formName}!`, 'success');
      setFormName('');
      setFormUsername('');
      setFormPassword('');
      setFormPhone('');
      setFormNotes('');
      setShowCreateForm(false);
      await loadUsers();
    } catch (err: any) {
      showToast(err.message || 'Failed to create user', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteUser = async (user: ManagedUser) => {
    if (user.role === 'ADMIN') {
      showToast('Cannot delete master admin account', 'error');
      return;
    }
    const confirmed = window.confirm(`Permanently delete account for "${user.name}" (${user.username})?`);
    if (!confirmed) return;

    try {
      await subscriptionClient.deleteManagedUser(user.id);
      showToast(`User ${user.name} deleted permanently`, 'success');
      await loadUsers();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete user', 'error');
    }
  };

  const handleToggleStatus = async (user: ManagedUser) => {
    if (user.role === 'ADMIN') return;
    try {
      await subscriptionClient.updateManagedUser(user.id, {
        isActive: !user.isActive
      });
      showToast(`Account status updated to ${!user.isActive ? 'ACTIVE' : 'PAUSED'}`, 'success');
      await loadUsers();
    } catch (err: any) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  const handleSaveEdit = async () => {
    if (!editingUser) return;
    setIsSavingEdit(true);
    try {
      await subscriptionClient.updateManagedUser(editingUser.id, {
        name: editName.trim() || undefined,
        password: editPassword.trim() || undefined,
        durationDays: editDuration > 0 ? editDuration : undefined
      });
      showToast(`Updated details for ${editingUser.name}`, 'success');
      setEditingUser(null);
      await loadUsers();
    } catch (err: any) {
      showToast(err.message || 'Failed to update user', 'error');
    } finally {
      setIsSavingEdit(false);
    }
  };

  if (!isAdmin) {
    return null;
  }

  return (
    <section 
      id="section-compact-admin"
      aria-label="Admin Section"
      className="w-full bg-[#080E1B] border-y sm:border border-emerald-500/30 rounded-none sm:rounded-2xl p-2.5 sm:p-5 shadow-2xl font-mono text-slate-100 my-4 relative overflow-hidden"
    >
      {/* Toast Alert */}
      {toastMessage && (
        <div 
          role="status" 
          aria-live="polite"
          className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl border text-xs font-bold shadow-2xl transition-all duration-300 flex items-center gap-2 ${
            toastMessage.type === 'success' 
              ? 'bg-emerald-950/90 border-emerald-500/60 text-[#00FFA3]' 
              : 'bg-rose-950/90 border-rose-500/60 text-rose-300'
          }`}
        >
          {toastMessage.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/40 text-[#00FFA3]">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-black tracking-wider text-white uppercase">
                Admin Management Section
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-[#00FFA3] border border-emerald-500/40 uppercase">
                Master Admin
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Compact User & Guest Pass Manager • Nadeem Hassan
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          <button
            type="button"
            id="btn-admin-add-user-toggle"
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/50 text-[#00FFA3] transition-all cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>{showCreateForm ? 'Close Form' : '+ New User'}</span>
          </button>

          <button
            type="button"
            id="btn-admin-refresh-users"
            onClick={loadUsers}
            disabled={isLoading}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition-all cursor-pointer disabled:opacity-50"
            title="Refresh Users"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            type="button"
            id="btn-admin-collapse-toggle"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-400 transition-all cursor-pointer"
            title={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {isExpanded && (
        <div className="pt-3 space-y-4">
          {/* Quick Stats Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
            <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-slate-400 text-[10px] block uppercase">Total Users</span>
              <span className="text-base font-bold text-white">{users.length}</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-slate-400 text-[10px] block uppercase">Active Members</span>
              <span className="text-base font-bold text-[#00FFA3]">{users.filter(u => !u.isGuest && u.role !== 'ADMIN').length}</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-slate-400 text-[10px] block uppercase">Guest Passes</span>
              <span className="text-base font-bold text-sky-400">{users.filter(u => u.isGuest).length}</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-slate-400 text-[10px] block uppercase">Status</span>
              <span className="text-base font-bold text-amber-300">Operational</span>
            </div>
          </div>

          {/* Compact Create User / Guest Pass Form */}
          {showCreateForm && (
            <form 
              onSubmit={handleCreateUser}
              className="p-3.5 rounded-xl bg-[#0F172A] border border-emerald-500/40 space-y-3"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-white uppercase flex items-center gap-1.5">
                  <UserPlus className="w-3.5 h-3.5 text-[#00FFA3]" />
                  Create New Account
                </span>
                
                {/* Account Type Toggle */}
                <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
                  <button
                    type="button"
                    onClick={() => setFormType('GUEST')}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all ${
                      formType === 'GUEST' 
                        ? 'bg-emerald-500 text-slate-950 shadow-sm' 
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Guest Pass
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormType('MEMBER')}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all ${
                      formType === 'MEMBER' 
                        ? 'bg-emerald-500 text-slate-950 shadow-sm' 
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Standard Member
                  </button>
                </div>
              </div>

              {/* Guest Duration Selector (1 Day, 1 Week, 1 Month, Forever) */}
              {formType === 'GUEST' && (
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Pass Access Duration:
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setFormDuration(1)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                        formDuration === 1 
                          ? 'bg-emerald-500/20 border-emerald-400 text-[#00FFA3]' 
                          : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      1 Day
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormDuration(7)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                        formDuration === 7 
                          ? 'bg-emerald-500/20 border-emerald-400 text-[#00FFA3]' 
                          : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      1 Week
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormDuration(30)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                        formDuration === 30 
                          ? 'bg-emerald-500/20 border-emerald-400 text-[#00FFA3]' 
                          : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      1 Month
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormDuration(36500)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                        formDuration === 36500 
                          ? 'bg-emerald-500/20 border-emerald-400 text-[#00FFA3]' 
                          : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      Forever
                    </button>
                  </div>
                </div>
              )}

              {/* Input Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Tariq Mehmood"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Username / Login ID *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. tariq_psx"
                    value={formUsername}
                    onChange={(e) => setFormUsername(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Password *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. trade2026"
                    value={formPassword}
                    onChange={(e) => setFormPassword(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              {/* Optional Phone & Notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Phone (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 03001234567"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Admin Notes (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. WhatsApp contact, friend from Lahore"
                    value={formNotes}
                    onChange={(e) => setFormNotes(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-400 hover:text-white border border-slate-700 hover:border-slate-600 transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-1.5 rounded-lg text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'Creating...' : `Create ${formType === 'GUEST' ? 'Guest Pass' : 'Member'}`}
                </button>
              </div>
            </form>
          )}

          {/* Compact User List Table */}
          <div className="rounded-xl border border-slate-800 bg-[#0B1222] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-center text-xs">
                <thead>
                  <tr className="bg-slate-900/80 border-b border-slate-800 text-[10px] uppercase font-bold text-slate-400">
                    <th className="py-2.5 px-3 text-center">User / Account</th>
                    <th className="py-2.5 px-3 text-center">Type</th>
                    <th className="py-2.5 px-3 text-center">Password / Key</th>
                    <th className="py-2.5 px-3 text-center">Access / Expiry</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-sans">
                  {users.map((user) => {
                    const isMasterAdmin = user.role === 'ADMIN';
                    return (
                      <tr key={user.id} className="hover:bg-slate-800/30 transition-colors">
                        {/* User Details */}
                        <td className="py-2.5 px-3 font-mono text-center">
                          <div className="font-bold text-white text-xs flex items-center justify-center gap-1.5 text-center">
                            {user.name}
                            {isMasterAdmin && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                OWNER
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400 text-center">
                            @{user.username} {user.phone && `• ${user.phone}`}
                          </div>
                        </td>

                        {/* Type */}
                        <td className="py-2.5 px-3 text-center">
                          {isMasterAdmin ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              Master Admin
                            </span>
                          ) : user.isGuest ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                              Guest Pass
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                              Member
                            </span>
                          )}
                        </td>

                        {/* Password Hint */}
                        <td className="py-2.5 px-3 font-mono text-[11px] text-slate-300 text-center">
                          {isMasterAdmin ? (
                            <span className="text-slate-500 italic">Saved Forever</span>
                          ) : (
                            <span>{user.passwordHint || '••••••••'}</span>
                          )}
                        </td>

                        {/* Expiry / Days */}
                        <td className="py-2.5 px-3 font-mono text-xs text-center">
                          {isMasterAdmin ? (
                            <span className="text-emerald-400 font-bold">Lifetime</span>
                          ) : user.daysRemaining >= 3000 ? (
                            <span className="text-emerald-400 font-bold">Forever</span>
                          ) : user.daysRemaining > 0 ? (
                            <span className="text-slate-300">{user.daysRemaining} days left</span>
                          ) : (
                            <span className="text-rose-400 font-bold">Expired</span>
                          )}
                        </td>

                        {/* Status */}
                        <td className="py-2.5 px-3 text-center">
                          {user.isActive ? (
                            <span className="inline-flex items-center justify-center gap-1 text-[11px] text-emerald-400 font-bold">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                              Active
                            </span>
                          ) : (
                            <span className="inline-flex items-center justify-center gap-1 text-[11px] text-rose-400 font-bold">
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                              Paused
                            </span>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="py-2.5 px-3 text-center">
                          {isMasterAdmin ? (
                            <span className="text-[10px] text-slate-500 italic">Protected</span>
                          ) : (
                            <div className="flex items-center justify-center gap-1.5">
                              {/* Edit Button */}
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingUser(user);
                                  setEditName(user.name);
                                  setEditPassword(user.passwordHint || '');
                                  setEditDuration(user.daysRemaining || 30);
                                }}
                                className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
                                title="Edit User"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>

                              {/* Toggle Status Button */}
                              <button
                                type="button"
                                onClick={() => handleToggleStatus(user)}
                                className={`p-1.5 rounded border transition-colors ${
                                  user.isActive 
                                    ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 hover:bg-amber-500/20' 
                                    : 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/20'
                                }`}
                                title={user.isActive ? 'Pause Access' : 'Activate Access'}
                              >
                                {user.isActive ? <Clock className="w-3.5 h-3.5" /> : <Check className="w-3.5 h-3.5" />}
                              </button>

                              {/* Delete Button */}
                              <button
                                type="button"
                                onClick={() => handleDeleteUser(user)}
                                className="p-1.5 rounded bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/40 text-rose-400 transition-colors"
                                title="Delete Account"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#0F172A] border border-emerald-500/40 rounded-2xl p-4 sm:p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white uppercase">
                  Edit User Account
                </h3>
                <p className="text-xs text-slate-400">
                  @{editingUser.username} ({editingUser.isGuest ? 'Guest Pass' : 'Member'})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs focus:border-emerald-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                  New Password (or keep current)
                </label>
                <div className="relative">
                  <input
                    type={showEditPassword ? 'text' : 'password'}
                    value={editPassword}
                    onChange={(e) => setEditPassword(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs focus:border-emerald-400 focus:outline-none pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowEditPassword(!showEditPassword)}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white"
                  >
                    {showEditPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {editingUser.isGuest && (
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Duration Setting:
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setEditDuration(1)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                        editDuration === 1 
                          ? 'bg-emerald-500/20 border-emerald-400 text-[#00FFA3]' 
                          : 'bg-slate-900/80 border-slate-800 text-slate-400'
                      }`}
                    >
                      1 Day
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditDuration(7)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                        editDuration === 7 
                          ? 'bg-emerald-500/20 border-emerald-400 text-[#00FFA3]' 
                          : 'bg-slate-900/80 border-slate-800 text-slate-400'
                      }`}
                    >
                      1 Week
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditDuration(30)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                        editDuration === 30 
                          ? 'bg-emerald-500/20 border-emerald-400 text-[#00FFA3]' 
                          : 'bg-slate-900/80 border-slate-800 text-slate-400'
                      }`}
                    >
                      1 Month
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditDuration(36500)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                        editDuration === 36500 
                          ? 'bg-emerald-500/20 border-emerald-400 text-[#00FFA3]' 
                          : 'bg-slate-900/80 border-slate-800 text-slate-400'
                      }`}
                    >
                      Forever
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white border border-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isSavingEdit}
                onClick={handleSaveEdit}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-mono shadow-md disabled:opacity-50"
              >
                {isSavingEdit ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
