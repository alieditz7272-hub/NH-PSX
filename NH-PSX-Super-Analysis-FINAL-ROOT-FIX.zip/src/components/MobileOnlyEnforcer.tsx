import React from 'react';

interface MobileOnlyEnforcerProps {
  children: React.ReactNode;
}

export const MobileOnlyEnforcer: React.FC<MobileOnlyEnforcerProps> = ({ children }) => {
  return (
    <div className="w-full min-h-screen flex flex-col bg-[#05070A] overflow-x-hidden">
      {children}
    </div>
  );
};
