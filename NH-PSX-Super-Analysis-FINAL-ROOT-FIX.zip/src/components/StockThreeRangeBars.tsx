import React from 'react';
import { Clock, Calendar, Compass, ArrowUpRight, ArrowDownRight, TrendingUp, Activity, Layers } from 'lucide-react';
import { TickerQuote, Candle } from '../types';
import { getStockHistoricalRange } from '../utils/stockHistoricalRange';
import { isPsxIndex, formatDisplaySymbol } from '../utils/symbol';

interface StockThreeRangeBarsProps {
  selectedTicker: TickerQuote;
  candles?: Candle[];
}

interface SingleRangeBarProps {
  title: string;
  badge: string;
  icon: React.ReactNode;
  lowLabel: string;
  lowValue: number;
  lowDate?: string;
  highLabel: string;
  highValue: number;
  highDate?: string;
  currentPrice: number;
  isIndex: boolean;
  barColor: string;
  markerColor: string;
}

const SingleRangeBar: React.FC<SingleRangeBarProps> = ({
  title,
  badge,
  icon,
  lowLabel,
  lowValue,
  lowDate,
  highLabel,
  highValue,
  highDate,
  currentPrice,
  isIndex,
  barColor,
  markerColor
}) => {
  const formatVal = (val?: number | null) => {
    if (val === undefined || val === null || isNaN(val)) return 'N/A';
    if (isIndex) return Math.round(Number(val)).toString().replace(/,/g, '');
    return Number(val).toFixed(2).replace(/,/g, '');
  };

  const safeLow = isNaN(lowValue) || lowValue <= 0 ? currentPrice : lowValue;
  const safeHigh = isNaN(highValue) || highValue <= safeLow ? Math.max(safeLow + 0.01, currentPrice) : highValue;
  const spread = Math.max(0.0001, safeHigh - safeLow);

  // Position of Current Price between Low (0%) and High (100%)
  const rawPct = ((currentPrice - safeLow) / spread) * 100;
  const pct = Math.min(100, Math.max(0, rawPct));

  // Distance from low and to high
  const distFromLow = currentPrice - safeLow;
  const distToHigh = safeHigh - currentPrice;

  return (
    <div className="w-full p-3 sm:p-3.5 rounded-xl bg-gradient-to-r from-black/80 via-[#06101e] to-black/80 border border-white/10 hover:border-white/20 transition-all shadow-md flex flex-col gap-2.5">
      {/* Header Row: Title, Badge, and Prominent Current Price Position */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="p-1 rounded-md bg-white/5 border border-white/10 shrink-0">
            {icon}
          </span>
          <span className="text-xs sm:text-sm font-black text-white uppercase tracking-wider truncate">
            {title}
          </span>
          <span className="text-[9px] sm:text-[9.5px] px-1.5 py-0.2 rounded font-extrabold uppercase bg-white/5 border border-white/10 text-slate-300 shrink-0">
            {badge}
          </span>
        </div>

        {/* Current Price Callout with Position Percentage */}
        <div className="flex items-center gap-1.5 bg-black/80 border border-cyan-500/40 px-2.5 py-1 rounded-lg shadow-[0_0_10px_rgba(6,182,212,0.18)]">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
            Current Price:
          </span>
          <span className="text-xs sm:text-sm font-black text-cyan-300 font-mono">
            {formatVal(currentPrice)}
          </span>
          <span className="text-[9.5px] font-black px-1.5 py-0.2 rounded bg-cyan-950/70 border border-cyan-500/50 text-[#00FFA3]">
            {pct.toFixed(1)}%
          </span>
        </div>
      </div>

      {/* Visual Range Bar with Sliding Current Price Marker */}
      <div className="relative w-full pt-4 pb-2 px-1">
        {/* Track */}
        <div className="relative w-full h-3 sm:h-3.5 rounded-full bg-slate-900/90 border border-white/15 p-0.5 overflow-hidden shadow-inner">
          {/* Multi-stop colorful spectrum */}
          <div className={`w-full h-full rounded-full ${barColor}`} />
        </div>

        {/* Sliding Current Price Needle Pin & Pointer */}
        <div
          className="absolute top-0 bottom-0 pointer-events-none transition-all duration-300 z-10 flex flex-col items-center"
          style={{ left: `${pct}%`, transform: 'translateX(-50%)' }}
        >
          {/* Top Pointer Indicator */}
          <div className="flex flex-col items-center">
            <span className="text-[9px] font-mono leading-none text-cyan-300 drop-shadow-[0_0_4px_#22d3ee]">
              ▼
            </span>
          </div>

          {/* Marker Needle Center Ring */}
          <div
            className={`w-3.5 h-3.5 sm:w-4 sm:h-4 -mt-0.5 rounded-full bg-white border-2 ${markerColor} shadow-[0_0_12px_rgba(34,211,238,0.8)] flex items-center justify-center`}
          >
            <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />
          </div>

          {/* Bottom Pointer Indicator */}
          <span className="text-[9px] font-mono leading-none text-cyan-300 -mt-0.5 drop-shadow-[0_0_4px_#22d3ee]">
            ▲
          </span>
        </div>
      </div>

      {/* Footer Row: Range Bounds (Low & High) with Dates */}
      <div className="flex items-start justify-between gap-2 text-[10px] sm:text-[11px] font-mono border-t border-white/5 pt-1.5">
        {/* Low Side */}
        <div className="flex flex-col items-start min-w-0">
          <div className="flex items-center gap-1 text-red-400 font-bold uppercase tracking-tight">
            <ArrowDownRight className="w-3 h-3 shrink-0" />
            <span>{lowLabel}:</span>
            <span className="text-white font-black">{formatVal(safeLow)}</span>
          </div>
          {lowDate && (
            <span className="text-[9px] text-slate-400 truncate max-w-[130px] sm:max-w-[180px]" title={lowDate}>
              {lowDate}
            </span>
          )}
          <span className="text-[8.5px] text-slate-500">
            +{formatVal(Math.max(0, distFromLow))} from Low
          </span>
        </div>

        {/* Center: Range Spread */}
        <div className="hidden sm:flex flex-col items-center justify-center text-center px-2 py-0.5 rounded bg-white/5 border border-white/10">
          <span className="text-[8.5px] text-slate-400 uppercase font-semibold">Range Spread</span>
          <span className="text-[10px] font-black text-slate-200">{formatVal(spread)}</span>
        </div>

        {/* High Side */}
        <div className="flex flex-col items-end min-w-0 text-right">
          <div className="flex items-center gap-1 text-emerald-400 font-bold uppercase tracking-tight">
            <span>{highLabel}:</span>
            <span className="text-white font-black">{formatVal(safeHigh)}</span>
            <ArrowUpRight className="w-3 h-3 shrink-0" />
          </div>
          {highDate && (
            <span className="text-[9px] text-slate-400 truncate max-w-[130px] sm:max-w-[180px]" title={highDate}>
              {highDate}
            </span>
          )}
          <span className="text-[8.5px] text-slate-500">
            -{formatVal(Math.max(0, distToHigh))} to High
          </span>
        </div>
      </div>
    </div>
  );
};

export const StockThreeRangeBars: React.FC<StockThreeRangeBarsProps> = ({
  selectedTicker,
  candles
}) => {
  const rangeStats = getStockHistoricalRange(selectedTicker, candles);
  const isIndex = isPsxIndex(selectedTicker);
  const cleanSym = formatDisplaySymbol(selectedTicker.symbol);

  const currentPrice = typeof selectedTicker.price === 'number' && selectedTicker.price > 0 ? selectedTicker.price : 0;
  
  // Day range extraction
  const dayHigh = typeof selectedTicker.high === 'number' && selectedTicker.high > 0 
    ? selectedTicker.high 
    : Math.max(currentPrice, typeof selectedTicker.open === 'number' ? selectedTicker.open : currentPrice);
  
  const dayLow = typeof selectedTicker.low === 'number' && selectedTicker.low > 0 
    ? selectedTicker.low 
    : Math.min(currentPrice, typeof selectedTicker.open === 'number' ? selectedTicker.open : currentPrice);

  return (
    <div
      id="section-52w-range"
      data-alt-id="stock-52w-ever-high-low-bar"
      className="w-full flex flex-col gap-2 font-mono scroll-mt-28"
    >
      {/* Module Super-Header */}
      <div className="w-full flex items-center justify-between px-3 py-1.5 rounded-xl bg-gradient-to-r from-black via-[#091524] to-black border border-white/10 shadow-sm">
        <div className="flex items-center gap-2">
          <Layers className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-xs font-black text-white uppercase tracking-wider">
            Range Spectrum: Day • 52-Week • Ever High-Low
          </span>
          <span className="text-[9.5px] px-1.5 py-0.2 rounded bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 font-bold">
            {cleanSym}
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-bold">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Real-Time Position Tracking</span>
        </div>
      </div>

      {/* 3 Range Bars Stack */}
      <div className="w-full flex flex-col gap-2">
        {/* BAR 1: CURRENT DAY RANGE */}
        <SingleRangeBar
          title="Current Day Range"
          badge="Session Range"
          icon={<Clock className="w-3.5 h-3.5 text-amber-400" />}
          lowLabel="Day Low"
          lowValue={dayLow}
          highLabel="Day High"
          highValue={dayHigh}
          currentPrice={currentPrice}
          isIndex={isIndex}
          barColor="bg-gradient-to-r from-rose-500 via-amber-400 to-emerald-400 shadow-[0_0_8px_rgba(244,63,94,0.3)]"
          markerColor="border-amber-400"
        />

        {/* BAR 2: 52-WEEK RANGE */}
        <SingleRangeBar
          title="52-Week Range"
          badge="1-Year Cycle"
          icon={<Calendar className="w-3.5 h-3.5 text-cyan-400" />}
          lowLabel="52-Week Low"
          lowValue={rangeStats.week52Low}
          lowDate={rangeStats.week52LowDate}
          highLabel="52-Week High"
          highValue={rangeStats.week52High}
          highDate={rangeStats.week52HighDate}
          currentPrice={currentPrice}
          isIndex={isIndex}
          barColor="bg-gradient-to-r from-red-500 via-yellow-400 to-[#00FFA3] shadow-[0_0_8px_rgba(0,255,163,0.3)]"
          markerColor="border-[#00FFA3]"
        />

        {/* BAR 3: EVER (ALL-TIME) RANGE */}
        <SingleRangeBar
          title="Ever (All-Time) Range"
          badge="Historical Span"
          icon={<Compass className="w-3.5 h-3.5 text-purple-400" />}
          lowLabel="Ever Low"
          lowValue={rangeStats.everLow}
          lowDate={rangeStats.everLowDate}
          highLabel="Ever High"
          highValue={rangeStats.everHigh}
          highDate={rangeStats.everHighDate}
          currentPrice={currentPrice}
          isIndex={isIndex}
          barColor="bg-gradient-to-r from-purple-600 via-sky-400 to-emerald-400 shadow-[0_0_8px_rgba(168,85,247,0.3)]"
          markerColor="border-purple-400"
        />
      </div>
    </div>
  );
};

export default StockThreeRangeBars;
