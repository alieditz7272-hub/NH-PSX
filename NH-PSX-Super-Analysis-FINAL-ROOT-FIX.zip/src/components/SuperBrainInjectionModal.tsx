// ============================================================================
// SUPER BRAIN AUTONOMOUS UPGRADE & OTA NOTIFICATION MODAL
// ============================================================================
// Displays an owner briefing for Nadeem Hassan whenever Super Brain
// searches the internet, discovers, and autonomously injects modern market
// wisdom, detailing exact backend coding updates and frontend UI adaptations.
// ============================================================================

import React from 'react';
import {
  Brain,
  Cpu,
  Code,
  Layout,
  CheckCircle2,
  Download,
  X,
  Sparkles,
  ShieldCheck,
  Zap,
  Radio
} from 'lucide-react';
import { InjectedUpgradeNotice } from '../utils/superBrainContinuousLearning';

interface SuperBrainInjectionModalProps {
  notice: InjectedUpgradeNotice | null;
  isOpen: boolean;
  onClose: () => void;
}

export const SuperBrainInjectionModal: React.FC<SuperBrainInjectionModalProps> = ({
  notice,
  isOpen,
  onClose
}) => {
  if (!isOpen || !notice) return null;

  const handleDownloadBackupZip = () => {
    window.location.href = '/api/superbrain/download-zip';
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn font-mono">
      <div className="relative w-full max-w-xl rounded-2xl bg-gradient-to-b from-[#0B1220] via-[#070D18] to-[#040810] border border-cyan-500/50 shadow-[0_0_50px_rgba(6,182,212,0.25)] p-4 sm:p-6 space-y-4 my-auto">
        
        {/* Top Header Bar */}
        <div className="flex items-start justify-between gap-3 border-b border-cyan-500/20 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 via-emerald-500/20 to-purple-600/30 border border-cyan-400/50 flex items-center justify-center shrink-0">
              <Brain className="w-5 h-5 text-cyan-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-xs sm:text-sm font-black text-white uppercase tracking-wider">
                  Super Brain Autonomous Upgrade Alert
                </span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-[#00FFA3] border border-emerald-500/40 flex items-center gap-1">
                  <Radio className="w-2.5 h-2.5 animate-ping text-[#00FFA3]" />
                  OTA LIVE SYNCED
                </span>
              </div>
              <div className="text-[11px] text-cyan-300 font-sans mt-0.5">
                Executive Report for Application Owner: <strong className="text-white">Nadeem Hassan</strong>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/10 transition-colors cursor-pointer"
            title="Dismiss Alert"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Study Identification Banner */}
        <div className="p-3 rounded-xl bg-slate-950/80 border border-cyan-500/30 space-y-1">
          <div className="flex items-center justify-between text-[10px] text-slate-400 flex-wrap gap-1">
            <span className="uppercase text-purple-300 font-bold">{notice.category}</span>
            <span>Injected: {new Date(notice.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
          </div>
          <div className="text-sm font-black text-white flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-[#00FFA3] shrink-0" />
            <span>{notice.studyName}</span>
          </div>
          <div className="text-[10.5px] text-slate-300 font-sans">
            Domain: <strong className="text-cyan-300">{notice.domain}</strong>
          </div>
        </div>

        {/* 2-Column Diff: Backend Coding vs Frontend UI Adaptation */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          
          {/* Backend Programming & Coding Changes */}
          <div className="p-3 rounded-xl bg-blue-950/20 border border-blue-500/30 space-y-2">
            <div className="flex items-center gap-1.5 text-blue-300 font-bold text-[11px] uppercase">
              <Code className="w-3.5 h-3.5 text-blue-400" />
              <span>Backend Programming Updates</span>
            </div>
            <ul className="space-y-1.5 text-[10.5px] text-slate-300 font-sans">
              {notice.backendCodeUpdates.map((item, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Frontend User Interface Adaptations */}
          <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-500/30 space-y-2">
            <div className="flex items-center gap-1.5 text-purple-300 font-bold text-[11px] uppercase">
              <Layout className="w-3.5 h-3.5 text-purple-400" />
              <span>Frontend UI Adaptations</span>
            </div>
            <ul className="space-y-1.5 text-[10.5px] text-slate-300 font-sans">
              {notice.frontendUIUpdates.map((item, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">{item}</span>
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* OTA Assurance & Server Backup Notice */}
        <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-1 text-xs">
          <div className="flex items-center gap-1.5 text-[#00FFA3] font-bold text-[11px] uppercase">
            <ShieldCheck className="w-4 h-4 text-[#00FFA3]" />
            <span>Over-The-Air (OTA) Dynamic Implementation</span>
          </div>
          <p className="text-[10.5px] text-slate-300 font-sans leading-relaxed">
            {notice.ownerReport}
          </p>
          <div className="text-[9.5px] text-slate-400 pt-1 border-t border-emerald-500/20 flex items-center justify-between flex-wrap gap-1">
            <span>Main Server Program File: <strong className="text-white font-mono">nh_trading_terminal_latest.zip</strong></span>
            <span className="text-[#00FFA3] font-bold">Auto-Saved on Server</span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5 pt-1">
          <button
            type="button"
            onClick={handleDownloadBackupZip}
            className="w-full sm:w-auto px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/20 text-slate-200 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Download Updated Codebase Zip</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-black text-xs transition-all shadow-md active:scale-95 cursor-pointer"
          >
            Acknowledge & Continue
          </button>
        </div>

      </div>
    </div>
  );
};
