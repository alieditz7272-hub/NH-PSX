import React, { useState } from 'react';
import { 
  Building2, 
  Flame, 
  Cpu, 
  Zap, 
  Sprout, 
  Landmark, 
  Factory, 
  Car, 
  Pill
} from 'lucide-react';
import { formatDisplaySymbol } from '../utils/symbol';

interface StockLogoProps {
  symbol?: string;
  name?: string;
  logoUrl?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  className?: string;
}

// Company official domain map for PSX listed stocks & indices
const COMPANY_DOMAIN_MAP: Record<string, string> = {
  // Benchmark Indices
  'KSE100': 'psx.com.pk',
  'KSE30': 'psx.com.pk',
  'ALLSHR': 'psx.com.pk',
  'KMI30': 'psx.com.pk',
  'PSXDIV20': 'psx.com.pk',
  'BKTI': 'psx.com.pk',
  'OGTI': 'psx.com.pk',

  // Tech & Telecom
  'SYS': 'systemsltd.com',
  'TRG': 'trgworld.com',
  'AIRLINK': 'airlinkcommunication.com',
  'NETSOL': 'netsoltech.com',
  'AVN': 'avanceon.ae',
  'OCTOPUS': 'octopusdigital.com.pk',
  'PTC': 'ptcl.com.pk',
  'PTCL': 'ptcl.com.pk',
  'WTL': 'worldcall.com.pk',
  'TELE': 'telecard.com.pk',
  'TPLT': 'tpltrakker.com',
  'IMAGE': 'image.net.pk',

  // Commercial & Islamic Banks
  'MEBL': 'meezanbank.com',
  'MCB': 'mcb.com.pk',
  'UBL': 'ubldigital.com',
  'HBL': 'hbl.com',
  'AKBL': 'askaribank.com.pk',
  'BAHL': 'bankalhabib.com',
  'FABL': 'faysalbank.com',
  'NBP': 'nbp.com.pk',
  'BOP': 'bop.com.pk',
  'BAFL': 'bankalfalah.com',
  'ABL': 'abl.com',
  'JSBL': 'jsbl.com',
  'SNBL': 'soneribank.com',
  'BIPL': 'bankislami.com.pk',
  'HMBL': 'habibmetro.com',
  'SILK': 'silkbank.com.pk',
  'SAMBA': 'samba.com.pk',

  // Oil, Gas & Energy Exploration
  'OGDC': 'ogdcl.com',
  'PPL': 'ppl.com.pk',
  'MARI': 'maripetroleum.com.pk',
  'POL': 'pakoil.com.pk',
  'PSO': 'psopk.com',
  'SHEL': 'shell.com.pk',
  'SNGP': 'sngpl.com.pk',
  'SSGC': 'ssgc.com.pk',
  'APL': 'attockpetroleum.com',
  'HASCOL': 'hascol.com',
  'HTL': 'hi-techlubricants.com',

  // Fertilizer & Chemicals
  'ENGRO': 'engro.com',
  'FFC': 'ffc.com.pk',
  'EFERT': 'engrofertilizers.com',
  'FATIMA': 'fatima-group.com',
  'EPCL': 'engropolymer.com',
  'COLG': 'colgate.com.pk',
  'FFBL': 'ffbl.com',
  'LOTCHEM': 'lottechem.com.pk',
  'AGP': 'agp.com.pk',
  'ICI': 'lucky-core.com',
  'LCI': 'lucky-core.com',
  'SITC': 'sitara.com.pk',
  'SPL': 'sitara.com.pk',
  'DOL': 'descon.com',
  'AGTL': 'alghazitractors.com',

  // Cement
  'LUCK': 'lucky-cement.com',
  'FCCL': 'fccl.com.pk',
  'MLCF': 'kmlg.com',
  'DGKC': 'dgcement.com',
  'BWCL': 'bestway.com.pk',
  'PIOC': 'pioneercement.com',
  'CHCC': 'cheratcement.com',
  'KOHC': 'kohatcement.com',
  'FLYNG': 'flyingcement.com',
  'POWER': 'powercement.com.pk',
  'THCCL': 'thatta.cement.com.pk',
  'ACPL': 'attockcement.com',
  'DNCC': 'dandotcement.com',

  // Power Generation & Distribution
  'HUBC': 'hubpower.com',
  'KEL': 'ke.com.pk',
  'KAPCO': 'kapco.com.pk',
  'NCPL': 'nishatpower.com',
  'NPL': 'nishatchunian.com',
  'SPWL': 'saifpower.com',
  'LPL': 'lalpir.com',
  'PKGP': 'pakgenpower.com',

  // Automobiles & Parts
  'SAZEW': 'sazgar.com.pk',
  'INDU': 'toyota-indus.com',
  'HCAR': 'honda.com.pk',
  'PSMC': 'suzukipakistan.com',
  'MTL': 'millat.com.pk',
  'GHNI': 'gandhara.com.pk',
  'DFML': 'dewanmotors.com',
  'HINO': 'hinopak.com',
  'GTYR': 'gtyre.com.pk',
  'ATBA': 'atlasbattery.com.pk',
  'EXIDE': 'exide.com.pk',

  // Pharmaceuticals & Healthcare
  'SEARL': 'searlecompany.com',
  'ABOT': 'pk.abbott',
  'GLAXO': 'gsk.com',
  'FEROZ': 'ferozsons-labs.com',
  'CPHL': 'citi-pharma.com',
  'HINOON': 'highnoon-labs.com',
  'IBLHL': 'iblgrp.com',
  'SHFA': 'shifa.com.pk',

  // Foods, Personal Care & Dairy
  'NESTLE': 'nestle.pk',
  'UNITY': 'unityfoods.pk',
  'NATF': 'nationalfoods.org',
  'FCEPL': 'frieslandcampina.com.pk',
  'SUTM': 'suraj.com',
  'MFFL': 'murreebrewery.com',
  'ASC': 'al-shaheer.com',
  'TOMCL': 'themeatcompany.net',
  'SHEZ': 'shezan.com',
  'QUICE': 'quice.com.pk',

  // Refinery & Engineering & Steels
  'ATRL': 'arl.com.pk',
  'PRL': 'prl.com.pk',
  'CNERGY': 'cnergyico.com',
  'NRL': 'nrlpak.com',
  'INIL': 'inboxind.com',
  'ISL': 'internationalsteels.com',
  'MUGHAL': 'mughalsteel.com',
  'AGHA': 'aghasteel.com.pk',
  'ASTL': 'amrelisteels.com',
  'PAEL': 'pel.com.pk',
  'ITTEFAQ': 'ittefaqsteel.com',
  'CSAP': 'crescentsteel.com',

  // Textiles, Paper & Synthetics
  'ILP': 'interloop-pk.com',
  'NML': 'nishatmillsltd.com',
  'KTML': 'kmlg.com',
  'GATM': 'gulahmed.com',
  'FML': 'fazalcloth.com',
  'CRTM': 'crescenttextile.com',
  'SML': 'shakarganj.com.pk',
  'CENT': 'century.com.pk',
  'PKGS': 'packages.com.pk',

  // Glass, Ceramics & Construction
  'GHGL': 'ghaniglass.com',
  'GGL': 'ghani-group.com',
  'TGL': 'tariqglass.com',
  'STCL': 'shabbir.com',
  'EMCO': 'emco.com.pk',

  // Holdings, Real Estate, Transport & Logistics
  'HUMNL': 'hum.tv',
  'TPL': 'tplcorp.com',
  'TPLP': 'tplproperties.com',
  'TREET': 'treetgroup.com',
  'PNSC': 'pnsc.com.pk',
  'PIBTL': 'pibt.com.pk',
};

// Brand accent background and text pairings for beautiful, razor-sharp vector badges
const BRAND_BADGE_STYLES: Record<string, { bg: string; text: string; border: string }> = {
  'SYS': { bg: 'bg-gradient-to-br from-blue-700 to-indigo-950', text: 'text-white', border: 'border-blue-400/50' },
  'TRG': { bg: 'bg-gradient-to-br from-sky-600 to-slate-900', text: 'text-white', border: 'border-sky-400/50' },
  'OGDC': { bg: 'bg-gradient-to-br from-amber-600 to-amber-950', text: 'text-amber-100', border: 'border-amber-400/50' },
  'PPL': { bg: 'bg-gradient-to-br from-orange-600 to-neutral-900', text: 'text-orange-100', border: 'border-orange-400/50' },
  'MARI': { bg: 'bg-gradient-to-br from-red-700 to-stone-950', text: 'text-white', border: 'border-red-500/50' },
  'PSO': { bg: 'bg-gradient-to-br from-green-700 via-emerald-800 to-slate-950', text: 'text-[#00FFA3]', border: 'border-[#00FFA3]/50' },
  'MEBL': { bg: 'bg-gradient-to-br from-emerald-800 to-teal-950', text: 'text-emerald-200', border: 'border-emerald-400/50' },
  'MCB': { bg: 'bg-gradient-to-br from-orange-700 to-amber-950', text: 'text-amber-100', border: 'border-orange-400/50' },
  'UBL': { bg: 'bg-gradient-to-br from-blue-800 to-cyan-950', text: 'text-cyan-200', border: 'border-cyan-400/50' },
  'HBL': { bg: 'bg-gradient-to-br from-emerald-700 to-green-950', text: 'text-emerald-100', border: 'border-emerald-400/50' },
  'ENGRO': { bg: 'bg-gradient-to-br from-blue-700 via-cyan-800 to-slate-950', text: 'text-cyan-200', border: 'border-cyan-400/50' },
  'FFC': { bg: 'bg-gradient-to-br from-green-800 to-emerald-950', text: 'text-green-100', border: 'border-green-400/50' },
  'EFERT': { bg: 'bg-gradient-to-br from-emerald-700 to-teal-950', text: 'text-emerald-100', border: 'border-emerald-400/50' },
  'LUCK': { bg: 'bg-gradient-to-br from-red-800 to-neutral-950', text: 'text-red-100', border: 'border-red-400/50' },
  'HUBC': { bg: 'bg-gradient-to-br from-cyan-800 to-blue-950', text: 'text-cyan-100', border: 'border-cyan-400/50' },
  'AIRLINK': { bg: 'bg-gradient-to-br from-purple-800 to-slate-950', text: 'text-purple-100', border: 'border-purple-400/50' },
  'SAZEW': { bg: 'bg-gradient-to-br from-indigo-800 to-slate-950', text: 'text-indigo-100', border: 'border-indigo-400/50' },
  'SEARL': { bg: 'bg-gradient-to-br from-rose-800 to-slate-950', text: 'text-rose-100', border: 'border-rose-400/50' },
  'NESTLE': { bg: 'bg-gradient-to-br from-sky-800 to-blue-950', text: 'text-sky-100', border: 'border-sky-400/50' },
  'ATRL': { bg: 'bg-gradient-to-br from-amber-700 to-stone-950', text: 'text-amber-100', border: 'border-amber-400/50' },
  'PRL': { bg: 'bg-gradient-to-br from-red-700 to-slate-950', text: 'text-red-100', border: 'border-red-400/50' },
  'ILP': { bg: 'bg-gradient-to-br from-teal-800 to-slate-950', text: 'text-teal-100', border: 'border-teal-400/50' },
  'NML': { bg: 'bg-gradient-to-br from-slate-800 to-neutral-950', text: 'text-slate-100', border: 'border-slate-400/50' },
};

export const StockLogo: React.FC<StockLogoProps> = ({
  symbol = '',
  name = '',
  logoUrl,
  size = 'md',
  className = '',
}) => {
  const [sourceIdx, setSourceIdx] = useState(0);

  const cleanSym = (formatDisplaySymbol(symbol) || '').toUpperCase();
  const cleanName = (name || '').toLowerCase();

  // Reset image candidate source index whenever symbol changes to avoid logo mixups
  React.useEffect(() => {
    setSourceIdx(0);
  }, [symbol, logoUrl]);

  // Size mappings
  const dimensions = {
    xs: 'w-5 h-5 text-[9px] rounded',
    sm: 'w-7 h-7 text-xs rounded-md',
    md: 'w-9 h-9 text-sm rounded-lg',
    lg: 'w-12 h-12 text-base rounded-xl',
  }[size];

  const iconSizes = {
    xs: 'w-3 h-3',
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
  }[size];

  // Domain lookup or dynamic resolution
  const mappedDomain = COMPANY_DOMAIN_MAP[cleanSym];
  const derivedDomain = mappedDomain || `${cleanSym.toLowerCase()}.com.pk`;

  // Candidates list for multi-tiered fallback logo loading
  const candidates: string[] = [];
  if (logoUrl) candidates.push(logoUrl);

  const isPsxIndex = cleanSym.includes('KSE') || cleanSym.includes('PSX') || cleanSym.includes('KMI') || cleanSym === 'ALLSHR';

  if (isPsxIndex) {
    candidates.push('https://dps.psx.com.pk/static/images/logo-200.png');
    candidates.push('https://www.psx.com.pk/assets/theme/images/psx-logo.png');
    candidates.push('https://www.google.com/s2/favicons?domain=psx.com.pk&sz=128');
    candidates.push('https://unavatar.io/psx.com.pk');
  } else if (derivedDomain) {
    candidates.push(`https://www.google.com/s2/favicons?domain=${derivedDomain}&sz=128`);
    candidates.push(`https://unavatar.io/${derivedDomain}`);
    candidates.push(`https://icons.duckduckgo.com/ip3/${derivedDomain}.ico`);
    candidates.push(`https://logo.clearbit.com/${derivedDomain}`);
    candidates.push(`https://icon.horse/icon/${derivedDomain}`);
  }

  const activeSrc = candidates[sourceIdx];

  const handleImageError = () => {
    if (sourceIdx < candidates.length - 1) {
      setSourceIdx(prev => prev + 1);
    } else {
      setSourceIdx(999); // Exhausted image candidates
    }
  };

  // Render logo image if active candidate URL is available
  if (activeSrc && sourceIdx < candidates.length) {
    return (
      <div
        className={`${dimensions} bg-white p-0.5 border border-white/20 shadow-md flex items-center justify-center shrink-0 overflow-hidden relative ${className}`}
        title={`${cleanSym} - ${name}`}
      >
        <img
          key={activeSrc}
          src={activeSrc}
          alt={`${cleanSym} Logo`}
          className="w-full h-full object-contain rounded"
          onError={handleImageError}
          referrerPolicy="no-referrer"
          loading="eager"
        />
      </div>
    );
  }

  // Special Index Badge (KSE100, KSE30, KMI30, PSX)
  if (isPsxIndex) {
    const idxLabel = cleanSym.replace('.PSX', '');
    return (
      <div
        className={`${dimensions} bg-gradient-to-br from-emerald-950 via-emerald-900 to-slate-950 text-[#00FFA3] border border-[#00FFA3]/40 shadow-sm flex flex-col items-center justify-center shrink-0 overflow-hidden select-none ${className}`}
        title={`${cleanSym} - Pakistan Stock Exchange Official Index`}
      >
        <div className="flex items-center justify-center gap-0.5">
          <svg className="w-3 h-3 text-[#00FFA3]" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm1 14.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm4-4.5l1.2-0.8-0.5 1.4 1.2 0.8h-1.5L16 14.8 15.5 13.4H14l1.2-0.8-0.5-1.4z"/>
          </svg>
        </div>
        <span className="text-[9px] font-black tracking-tighter uppercase leading-none text-white">{idxLabel}</span>
      </div>
    );
  }

  // Custom branded badge styling if known
  const brandStyle = BRAND_BADGE_STYLES[cleanSym];
  if (brandStyle) {
    return (
      <div
        className={`${dimensions} ${brandStyle.bg} ${brandStyle.border} ${brandStyle.text} border shadow-md flex flex-col items-center justify-center font-black tracking-tight shrink-0 select-none overflow-hidden ${className}`}
        title={`${cleanSym} - ${name}`}
      >
        <span className="leading-none text-[11px] font-black">{cleanSym.slice(0, 4)}</span>
      </div>
    );
  }

  // Sector Category fallback icon matching
  let icon = null;
  let gradient = 'from-slate-700 to-slate-900 border-white/20 text-white';

  if (cleanSym === 'SYS' || cleanSym === 'TRG' || cleanSym === 'AIRLINK' || cleanName.includes('tech') || cleanName.includes('software')) {
    icon = <Cpu className={iconSizes} />;
    gradient = 'from-cyan-600 to-blue-950 border-cyan-400/40 text-cyan-300';
  } else if (cleanSym === 'OGDC' || cleanSym === 'PPL' || cleanSym === 'MARI' || cleanSym === 'PSO' || cleanName.includes('oil') || cleanName.includes('gas') || cleanName.includes('petroleum')) {
    icon = <Flame className={iconSizes} />;
    gradient = 'from-amber-600 to-red-950 border-amber-400/40 text-amber-300';
  } else if (cleanSym === 'MEBL' || cleanSym === 'MCB' || cleanSym === 'UBL' || cleanSym === 'HBL' || cleanSym === 'AKBL' || cleanName.includes('bank')) {
    icon = <Landmark className={iconSizes} />;
    gradient = 'from-emerald-600 to-teal-950 border-emerald-400/40 text-emerald-300';
  } else if (cleanSym === 'ENGRO' || cleanSym === 'FFC' || cleanSym === 'EFERT' || cleanSym === 'FATIMA' || cleanName.includes('fertilizer') || cleanName.includes('chemical')) {
    icon = <Sprout className={iconSizes} />;
    gradient = 'from-green-600 to-emerald-950 border-green-400/40 text-green-300';
  } else if (cleanSym === 'LUCK' || cleanSym === 'FCCL' || cleanSym === 'MLCF' || cleanSym === 'DGKC' || cleanName.includes('cement')) {
    icon = <Factory className={iconSizes} />;
    gradient = 'from-stone-600 to-neutral-900 border-stone-400/40 text-stone-200';
  } else if (cleanSym === 'HUBC' || cleanSym === 'KEL' || cleanSym === 'POWER' || cleanName.includes('power') || cleanName.includes('electric')) {
    icon = <Zap className={iconSizes} />;
    gradient = 'from-yellow-500 to-amber-900 border-yellow-400/40 text-yellow-300';
  } else if (cleanSym === 'SAZEW' || cleanName.includes('auto') || cleanName.includes('motor')) {
    icon = <Car className={iconSizes} />;
    gradient = 'from-indigo-600 to-slate-950 border-indigo-400/40 text-indigo-300';
  } else if (cleanSym === 'SEARL' || cleanName.includes('pharma')) {
    icon = <Pill className={iconSizes} />;
    gradient = 'from-rose-600 to-purple-950 border-rose-400/40 text-rose-300';
  } else {
    icon = <Building2 className={iconSizes} />;
    gradient = 'from-slate-700 via-slate-800 to-slate-950 border-white/20 text-emerald-400';
  }

  const initials = cleanSym.slice(0, 4);

  return (
    <div
      className={`${dimensions} bg-gradient-to-br ${gradient} border shadow-sm flex items-center justify-center font-black shrink-0 ${className}`}
      title={`${cleanSym} - ${name}`}
    >
      {icon || <span>{initials}</span>}
    </div>
  );
};
