// ============================================================================
// SUPER BRAIN ANALYSIS REPORT
// ============================================================================
// Ultra-compact, neat, clean, clear, simple, to-the-point technical intelligence:
// - Prominent Final Technical Verdict & Action Protocol (BULLISH/BEARISH/NEUTRAL VIEW)
// - Company Profile Box (5 Fundamental Tiles, 4 Leadership, 4 Concise 1-Line Insights)
// - Deep Inspection (local analytical tools)
// - Master Executive Directive & Technical Thesis (1 compact card)
// - Tactical Battle Map (4 sharp metric tiles: Demand, Supply, Invalidation Stop, Targets)
// - 4 Foundational Pillars (Structure, Multi-Timeframe, Trend/EMAs, Volume/RSI)
// - 4 Multi-Horizon Targets (Intraday, Swing, Position, Long-Term)
// - Collapsible Deep Inspection Matrix (5 Wisdoms, Live AI Studies, 10 Angles, Hypotheses)
// Strictly follows project directives:
// - Strictly use True Fundamental Value terminology.
// - Strictly NO commas in prices or values.
// - Strictly 'View' terminology enforced across all views and horizons.
// - Strictly NO 'Rs.' or 'Points' words.
// ============================================================================

import React, { useMemo, useState, useEffect } from 'react';
import {
  Brain,
  ShieldAlert,
  Target,
  Layers,
  Activity,
  TrendingUp,
  TrendingDown,
  BarChart2,
  AlertTriangle,
  Maximize2,
  Minimize2,
  Clock,
  Briefcase,
  Sparkles,
  Scale,
  Globe,
  RefreshCw,
  Cpu,
  BookOpen,
  X,
  Compass,
  CheckCircle2
} from 'lucide-react';
import { TickerQuote, Candle } from '../types';
import { evaluateSuperAnalyst, SuperAnalystResult } from '../utils/superAnalystEngine';
import { formatDisplaySymbol, formatDisplayName } from '../utils/symbol';
import { formatPrice } from '../utils/currency';
import { CompanyProfileBox } from './CompanyProfileBox';

interface SuperAnalystViewProps {
  selectedTicker: TickerQuote;
  candles?: Candle[];
}

export const SuperAnalystView: React.FC<SuperAnalystViewProps> = ({
  selectedTicker,
  candles
}) => {
  const [langMode, setLangMode] = useState<'EN' | 'URDU'>('EN');
  const [isExpanded, setIsExpanded] = useState(true);
  const [showDeepInspection, setShowDeepInspection] = useState(false);
  const [inspectionTab, setInspectionTab] = useState<'WISDOM' | 'LIVE_LEARNING' | 'ANGLES' | 'HYPOTHESES'>('WISDOM');
  const learningState = { totalInjectedNodes: 0, currentActiveStudy: 'Live search disabled in static build', injectedNodes: [] as any[] };

  // Independent analytical computation
  const analyst: SuperAnalystResult = useMemo(() => {
    return evaluateSuperAnalyst(selectedTicker, candles);
  }, [selectedTicker, candles]);

  const cleanSym = formatDisplaySymbol(selectedTicker.symbol);
  const fullName = formatDisplayName(selectedTicker);

  const isBull = analyst.finalVerdict === 'BULLISH VIEW';
  const isBear = analyst.finalVerdict === 'BEARISH VIEW';

  const getRegimeColor = (regime: string) => {
    if (regime.includes('STRONG UPTREND')) return 'text-[#00FFA3] bg-emerald-500/10 border-emerald-500/40';
    if (regime.includes('WEAK UPTREND')) return 'text-cyan-300 bg-cyan-500/10 border-cyan-500/40';
    if (regime.includes('STRONG DOWNTREND')) return 'text-rose-400 bg-rose-500/10 border-rose-500/40';
    if (regime.includes('WEAK DOWNTREND')) return 'text-amber-400 bg-amber-500/10 border-amber-500/40';
    if (regime.includes('RANGE')) return 'text-purple-300 bg-purple-500/10 border-purple-500/40';
    return 'text-slate-300 bg-slate-800/40 border-white/20';
  };

  // Concise text condenser for clean, to-the-point display
  const condenseSentence = (text: string = '', maxLen: number = 140): string => {
    if (!text) return '';
    const trimmed = text.trim();
    if (trimmed.length <= maxLen) return trimmed;
    const slice = trimmed.slice(0, maxLen);
    const lastPunct = Math.max(slice.lastIndexOf('.'), slice.lastIndexOf(';'), slice.lastIndexOf(','));
    if (lastPunct > 50) {
      return `${slice.slice(0, lastPunct)}.`;
    }
    return `${slice.trim()}...`;
  };

  return (
    <section id="section-super-analyst" className="w-full font-sans text-slate-200 scroll-mt-24">
      {/* Container Card - Compact, Ultra-Clean & High Density */}
      <div className="w-full rounded-2xl bg-gradient-to-b from-[#090E17] via-[#060910] to-[#04060A] border border-cyan-500/30 p-2 sm:p-3 shadow-[0_0_20px_rgba(6,182,212,0.08)] space-y-2.5">
        
        {/* ==================================================================== */}
        {/* 1. HEADER BAR: TITLE, VERDICT BADGE, ACTION, CONTROLS               */}
        {/* ==================================================================== */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-cyan-500/20">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-600/30 border border-cyan-400/40 flex items-center justify-center shrink-0">
              <Brain className="w-4 h-4 text-cyan-400" />
            </div>

            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h2 className="text-xs sm:text-sm font-black tracking-wide uppercase text-white font-mono flex items-center gap-1">
                  SUPER BRAIN ANALYSIS REPORT
                </h2>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-cyan-950/90 border border-cyan-400/40 text-cyan-300 font-bold uppercase">
                  Autonomous AI
                </span>

                {/* 🌟 PROMINENT FINAL TECHNICAL VERDICT BADGE 🌟 */}
                <div
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md border font-mono font-black text-[11px] uppercase shadow-sm ${
                    isBull
                      ? 'bg-emerald-950/80 border-[#00FFA3] text-[#00FFA3]'
                      : isBear
                      ? 'bg-rose-950/80 border-rose-500 text-rose-300'
                      : 'bg-amber-950/80 border-amber-400 text-amber-300'
                  }`}
                >
                  {isBull ? (
                    <TrendingUp className="w-3 h-3 text-[#00FFA3] stroke-[3]" />
                  ) : isBear ? (
                    <TrendingDown className="w-3 h-3 text-rose-400 stroke-[3]" />
                  ) : (
                    <Activity className="w-3 h-3 text-amber-300 stroke-[3]" />
                  )}
                  <span>VERDICT: {analyst.finalVerdict}</span>
                  <span className="text-[9.5px] font-bold px-1 rounded bg-black/60 border border-white/20 text-white">
                    {analyst.overallConvictionScore}%
                  </span>
                </div>

                {/* Action Tag */}
                <span className="text-[9.5px] font-mono font-bold px-1.5 py-0.5 rounded bg-black/60 border border-white/15 text-slate-200 uppercase">
                  Action: {analyst.finalVerdictAction}
                </span>

                {/* PSX Defaulter Warning Badge */}
                {analyst.isDefaulter && (
                  <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded bg-red-950/90 border border-red-500 text-red-300 font-black text-[9.5px] font-mono uppercase animate-pulse">
                    <AlertTriangle className="w-2.5 h-2.5 text-red-400 shrink-0" />
                    <span>Defaulter Counter • High Risk</span>
                  </span>
                )}
              </div>

              {/* Subtitle Identity */}
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-0.5 flex-wrap font-mono">
                <span className="font-bold text-[#00FFA3]">{cleanSym}</span>
                {fullName && <span className="text-white font-sans font-medium truncate max-w-xs">{fullName}</span>}
                <span className="text-slate-600">•</span>
                <span className="text-cyan-300">{analyst.sector || selectedTicker.sector || 'PSX Sector'}</span>
                <span className="text-slate-600">•</span>
                <span className="text-slate-300">
                  Current Price: <strong className="text-white">{formatPrice(analyst.currentPrice, selectedTicker)}</strong>
                </span>
              </div>
            </div>
          </div>

          {/* Right Toolbar: Language & Minimize */}
          <div className="flex items-center gap-1.5 self-start sm:self-auto shrink-0">
            <div className="flex items-center bg-black/60 rounded-md p-0.5 border border-white/10 text-[9.5px] font-mono">
              <button
                type="button"
                onClick={() => setLangMode('EN')}
                className={`px-1.5 py-0.5 rounded font-bold transition-all cursor-pointer ${
                  langMode === 'EN'
                    ? 'bg-cyan-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => setLangMode('URDU')}
                className={`px-1.5 py-0.5 rounded font-bold transition-all cursor-pointer ${
                  langMode === 'URDU'
                    ? 'bg-cyan-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Roman Urdu
              </button>
            </div>

            <button
              type="button"
              onClick={() => setIsExpanded(prev => !prev)}
              className="p-1 rounded-md bg-black/60 border border-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
              title={isExpanded ? 'Collapse Report' : 'Expand Report'}
            >
              {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {isExpanded && (
          <div className="space-y-2">
            
            {/* 🏢 AUTHENTIC COMPANY PROFILE BOX (DIRECTLY BELOW HEADER) */}
            <CompanyProfileBox 
              selectedTicker={selectedTicker}
              sectorName={analyst.sector || selectedTicker.sector}
              defaultLang={langMode}
            />

            {/* ================================================================ */}
            {/* 🌟 CARD 1: MASTER EXECUTIVE DIRECTIVE & TECHNICAL THESIS          */}
            {/* ================================================================ */}
            <div className="w-full rounded-xl bg-gradient-to-r from-emerald-950/30 via-slate-950/80 to-cyan-950/30 border border-emerald-500/35 p-2 sm:p-2.5 space-y-1.5 font-mono shadow-sm">
              {/* Top Row: Protocol & Key Metric Tags */}
              <div className="flex items-center justify-between gap-1.5 flex-wrap text-xs">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className={`text-[9.5px] font-black px-2 py-0.5 rounded border uppercase ${
                    analyst.humanVeteranGuidance.actionProtocol === 'STRONG IMMEDIATE ACTION'
                      ? 'bg-emerald-500/20 text-[#00FFA3] border-emerald-500/50'
                      : analyst.humanVeteranGuidance.actionProtocol === 'PATIENT DIP ACCUMULATION'
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                      : analyst.humanVeteranGuidance.actionProtocol === 'DEFENSIVE CAPITAL EXTRACTION'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  }`}>
                    PROTOCOL: {analyst.humanVeteranGuidance.actionProtocol}
                  </span>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-400/40 text-cyan-300 uppercase">
                    {analyst.stockArchetype}
                  </span>
                  <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border uppercase ${
                    analyst.benchmarkRelativeStrength.includes('OUTPERFORMING')
                      ? 'bg-emerald-500/20 text-[#00FFA3] border-emerald-500/40'
                      : analyst.benchmarkRelativeStrength.includes('UNDERPERFORMING')
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : 'bg-slate-800 text-slate-300 border-white/10'
                  }`}>
                    {analyst.benchmarkRelativeStrength.includes('OUTPERFORMING')
                      ? 'ALPHA LEADER'
                      : analyst.benchmarkRelativeStrength.includes('UNDERPERFORMING')
                      ? 'BENCHMARK DRAG'
                      : 'MARKET SYNC'}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-[9.5px] text-slate-400">
                  <span>Regime: <strong className="text-white">{analyst.regime.split(' ')[0]}</strong></span>
                  <span>•</span>
                  <span>R:R: <strong className="text-[#00FFA3]">{analyst.riskRewardRatio}:1</strong></span>
                </div>
              </div>

              {/* Direct Mentor Directive (Brief 1-2 sentences) */}
              <div className="text-[11px] sm:text-xs text-slate-100 font-sans leading-snug break-words pl-1 border-l-2 border-[#00FFA3]">
                "{condenseSentence(langMode === 'URDU' ? analyst.humanVeteranGuidance.mentorshipAdviceUrdu : analyst.humanVeteranGuidance.mentorshipAdvice, 140)}"
              </div>

              {/* Master Technical Thesis (Concise 1 line) */}
              <div className="text-[10px] sm:text-[11px] text-cyan-200/90 font-mono leading-snug break-words pt-1 border-t border-white/10 flex items-center justify-between flex-wrap gap-1">
                <span>
                  <strong>Technical Thesis: </strong>
                  {condenseSentence(langMode === 'URDU' ? (analyst.thesisHeadlineUrdu || analyst.thesisHeadline) : analyst.thesisHeadline, 130)}
                </span>
                <span className="text-[9px] text-slate-400">
                  {langMode === 'URDU' ? analyst.humanVeteranGuidance.veteranVerdictSummaryUrdu : analyst.humanVeteranGuidance.veteranVerdictSummary}
                </span>
              </div>
            </div>

            {/* ================================================================ */}
            {/* 🌟 GRID 1: TACTICAL BATTLE MAP LEVELS (4 SHARP METRIC TILES)     */}
            {/* ================================================================ */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-1.5 font-mono text-xs">
              {/* Demand Zone */}
              <div className="p-2 rounded-xl bg-emerald-950/25 border border-emerald-500/30 flex flex-col justify-between space-y-1">
                <div className="flex items-center justify-between text-[9.5px] text-emerald-300 font-bold uppercase">
                  <span>Demand Zone</span>
                  <span className="text-[8.5px] text-[#00FFA3]">BUY SHELF</span>
                </div>
                <div className="text-xs sm:text-sm font-black text-white my-0.5">
                  {formatPrice(analyst.keyDemandZone.low, selectedTicker)} - {formatPrice(analyst.keyDemandZone.high, selectedTicker)}
                </div>
                <div className="text-[8.5px] text-slate-300 truncate">
                  Institutional accumulation support
                </div>
              </div>

              {/* Supply Zone */}
              <div className="p-2 rounded-xl bg-rose-950/25 border border-rose-500/30 flex flex-col justify-between space-y-1">
                <div className="flex items-center justify-between text-[9.5px] text-rose-300 font-bold uppercase">
                  <span>Supply Zone</span>
                  <span className="text-[8.5px] text-rose-400">RESISTANCE</span>
                </div>
                <div className="text-xs sm:text-sm font-black text-white my-0.5">
                  {formatPrice(analyst.keySupplyZone.low, selectedTicker)} - {formatPrice(analyst.keySupplyZone.high, selectedTicker)}
                </div>
                <div className="text-[8.5px] text-slate-300 truncate">
                  Overhead profit taking ceiling
                </div>
              </div>

              {/* Invalidation Stop */}
              <div className="p-2 rounded-xl bg-red-950/30 border border-red-500/40 flex flex-col justify-between space-y-1">
                <div className="flex items-center justify-between text-[9.5px] text-red-300 font-bold uppercase">
                  <span className="flex items-center gap-1">
                    <ShieldAlert className="w-2.5 h-2.5 text-red-400" />
                    Invalidation Stop
                  </span>
                  <span className="text-[8.5px] text-red-400">EXIT LINE</span>
                </div>
                <div className="text-xs sm:text-sm font-black text-red-300 my-0.5">
                  {formatPrice(analyst.invalidationPrice, selectedTicker)}
                </div>
                <div className="text-[8.5px] text-slate-300 truncate">
                  Strict exit boundary • Capital first
                </div>
              </div>

              {/* Target Projections */}
              <div className="p-2 rounded-xl bg-cyan-950/25 border border-cyan-500/30 flex flex-col justify-between space-y-1">
                <div className="flex items-center justify-between text-[9.5px] text-cyan-300 font-bold uppercase">
                  <span>Targets</span>
                  <span className="text-[8.5px] text-cyan-400">T1 & T2</span>
                </div>
                <div className="flex items-center justify-between gap-1 text-xs sm:text-sm font-black my-0.5">
                  <span className="text-[#00FFA3]">T1: {formatPrice(analyst.target1Price, selectedTicker)}</span>
                  <span className="text-cyan-300">T2: {formatPrice(analyst.target2Price, selectedTicker)}</span>
                </div>
                <div className="text-[8.5px] text-slate-300 truncate">
                  R:R: {analyst.riskRewardRatio}:1 ({analyst.asymmetryRating})
                </div>
              </div>
            </div>

            {/* ================================================================ */}
            {/* 🌟 GRID 2: THE 4 FOUNDATIONAL PILLARS (HIGH-DENSITY DATA)         */}
            {/* ================================================================ */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-1.5 font-mono text-xs">
              {/* Pillar 1: Regime & Structure */}
              <div className="p-2 rounded-xl bg-slate-950/80 border border-white/10 space-y-0.5 flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[9.5px] uppercase font-bold text-slate-400 flex items-center gap-1">
                    <Activity className="w-3 h-3 text-cyan-400" />
                    Structure
                  </span>
                  <span className={`text-[8px] px-1 py-0.2 rounded border font-bold uppercase ${getRegimeColor(analyst.regime)}`}>
                    {analyst.regime.split(' ')[0]}
                  </span>
                </div>
                <div className="text-[10.5px] font-bold text-white truncate">
                  {analyst.structuralState.split('(')[0].trim()}
                </div>
                <div className="text-[8.5px] text-slate-300 truncate pt-0.5 border-t border-white/5">
                  Wyckoff: {analyst.wyckoffPhase.split(':')[0]}
                </div>
              </div>

              {/* Pillar 2: Multi-Timeframe Alignment */}
              <div className="p-2 rounded-xl bg-slate-950/80 border border-white/10 space-y-0.5 flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[9.5px] uppercase font-bold text-slate-400 flex items-center gap-1">
                    <Layers className="w-3 h-3 text-purple-400" />
                    Timeframes
                  </span>
                  <span className="text-[8px] px-1 py-0.2 rounded bg-purple-950/60 border border-purple-500/40 text-purple-300 font-bold uppercase">
                    {analyst.intradayLocation.split(' ')[0]}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-slate-400">W: <strong className={analyst.weeklyContext === 'BULLISH' ? 'text-[#00FFA3]' : analyst.weeklyContext === 'BEARISH' ? 'text-rose-400' : 'text-amber-400'}>{analyst.weeklyContext}</strong></span>
                  <span className="text-slate-400">D: <strong className={analyst.dailyContext === 'BULLISH' ? 'text-[#00FFA3]' : analyst.dailyContext === 'BEARISH' ? 'text-rose-400' : 'text-amber-400'}>{analyst.dailyContext}</strong></span>
                </div>
                <div className="text-[8.5px] text-slate-300 truncate pt-0.5 border-t border-white/5">
                  Location: {analyst.intradayLocation}
                </div>
              </div>

              {/* Pillar 3: Trend & EMAs */}
              <div className="p-2 rounded-xl bg-slate-950/80 border border-white/10 space-y-0.5 flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[9.5px] uppercase font-bold text-slate-400 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3 text-emerald-400" />
                    Trend & EMAs
                  </span>
                  <span className={`text-[8px] px-1 py-0.2 rounded border font-bold uppercase ${
                    analyst.trendDirection === 'BULLISH'
                      ? 'bg-emerald-500/20 text-[#00FFA3] border-emerald-500/40'
                      : analyst.trendDirection === 'BEARISH'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  }`}>
                    {analyst.trendDirection}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-1 text-[9px] text-white">
                  <span>20: <strong>{formatPrice(analyst.ema20, selectedTicker)}</strong></span>
                  <span>50: <strong>{formatPrice(analyst.ema50, selectedTicker)}</strong></span>
                  <span>200: <strong>{formatPrice(analyst.ema200, selectedTicker)}</strong></span>
                </div>
                <div className="text-[8.5px] text-slate-300 truncate pt-0.5 border-t border-white/5">
                  Momentum: {analyst.trendStrength}
                </div>
              </div>

              {/* Pillar 4: Volume & RVOL Participation */}
              <div className="p-2 rounded-xl bg-slate-950/80 border border-white/10 space-y-0.5 flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[9.5px] uppercase font-bold text-slate-400 flex items-center gap-1">
                    <BarChart2 className="w-3 h-3 text-amber-400" />
                    Participation
                  </span>
                  <span className="text-[8px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold uppercase">
                    RVOL: {analyst.rvol}x
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-slate-400">RSI: <strong className="text-white">{analyst.rsiValue.toFixed(2)}</strong></span>
                  <span className={`font-bold ${analyst.divergence.includes('BULLISH') ? 'text-[#00FFA3]' : analyst.divergence.includes('BEARISH') ? 'text-rose-400' : 'text-slate-400'}`}>
                    {analyst.divergence.split(' ')[0]}
                  </span>
                </div>
                <div className="text-[8.5px] text-slate-300 truncate pt-0.5 border-t border-white/5">
                  VSA: {analyst.vsaStatus.split('(')[0].trim()}
                </div>
              </div>
            </div>

            {/* ================================================================ */}
            {/* 🌟 GRID 3: MULTI-HORIZON OUTLOOK (INTRADAY • SWING • POSITION)    */}
            {/* ================================================================ */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-1.5 w-full font-mono text-xs">
              {analyst.horizons.map((h, i) => (
                <div key={i} className="p-2 rounded-xl bg-slate-950/80 border border-white/10 flex flex-col justify-between space-y-1">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-bold text-white uppercase flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5 text-cyan-400" />
                      {h.horizon}
                    </span>
                    <span className={`text-[8px] font-bold px-1.5 py-0.2 rounded border uppercase ${
                      h.view === 'BULLISH'
                        ? 'bg-emerald-500/15 border-emerald-500/30 text-[#00FFA3]'
                        : h.view === 'BEARISH'
                        ? 'bg-rose-500/15 border-rose-500/30 text-rose-300'
                        : 'bg-amber-500/15 border-amber-500/30 text-amber-300'
                    }`}>
                      {h.view} VIEW
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[10.5px]">
                    <span className="text-slate-400 flex items-center gap-1 text-[9.5px]">
                      <Target className="w-2.5 h-2.5 text-[#00FFA3]" />
                      Target:
                    </span>
                    <strong className="text-white font-mono text-xs">
                      {formatPrice(h.targetPrice, selectedTicker)}
                    </strong>
                  </div>

                  <div className="text-[8.5px] text-slate-400 pt-0.5 border-t border-white/5 truncate">
                    {h.expectedDuration} • {h.conviction}% Conviction
                  </div>
                </div>
              ))}
            </div>

            {/* ================================================================ */}
            {/* 🌟 TIER 5: DEEP INSTITUTIONAL INSPECTION MATRIX (EXPANDABLE)     */}
            {/* ================================================================ */}
            <div className="flex flex-col gap-1.5 pt-0.5">
              <button
                type="button"
                onClick={() => setShowDeepInspection(prev => !prev)}
                className="w-full flex items-center justify-center gap-2 py-1.5 px-3 rounded-xl bg-gradient-to-r from-cyan-950/40 via-slate-900/60 to-blue-950/40 border border-cyan-500/30 hover:border-cyan-400 text-xs font-mono text-cyan-300 transition-all cursor-pointer shadow-sm group"
              >
                <Brain className="w-3.5 h-3.5 text-cyan-400 group-hover:rotate-12 transition-transform" />
                <span className="font-bold">
                  {showDeepInspection ? 'Hide Deep Inspection Matrix' : 'Inspect Deep Brain Wisdoms & Research Studies (Click to View)'}
                </span>
                <span className="text-[9.5px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 font-bold">
                  5 Tactical Wisdoms • {learningState.totalInjectedNodes} Injected Studies • 10 Angles
                </span>
              </button>

              {/* Expandable Tabbed Container */}
              {showDeepInspection && (
                <div className="space-y-2 p-2 rounded-xl bg-black/70 border border-cyan-500/20 font-mono text-xs animate-fadeIn">
                  {/* Tab Headers */}
                  <div className="flex items-center justify-between gap-1 border-b border-white/10 pb-1.5 flex-wrap">
                    <div className="flex items-center gap-1 flex-wrap">
                      <button
                        type="button"
                        onClick={() => setInspectionTab('WISDOM')}
                        className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                          inspectionTab === 'WISDOM'
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm'
                            : 'text-slate-400 hover:text-white bg-white/5 border border-transparent'
                        }`}
                      >
                        5 Tactical Wisdoms
                      </button>
                      <button
                        type="button"
                        onClick={() => setInspectionTab('LIVE_LEARNING')}
                        className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
                          inspectionTab === 'LIVE_LEARNING'
                            ? 'bg-emerald-500/20 text-[#00FFA3] border border-emerald-500/50 shadow-sm'
                            : 'text-slate-400 hover:text-white bg-white/5 border border-transparent'
                        }`}
                      >
                        <Cpu className="w-2.5 h-2.5 text-[#00FFA3]" />
                        <span>AI Research Feed ({learningState.totalInjectedNodes})</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setInspectionTab('ANGLES')}
                        className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                          inspectionTab === 'ANGLES'
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm'
                            : 'text-slate-400 hover:text-white bg-white/5 border border-transparent'
                        }`}
                      >
                        10 Analytical Angles ({analyst.anglesCovered?.length || 10})
                      </button>
                      <button
                        type="button"
                        onClick={() => setInspectionTab('HYPOTHESES')}
                        className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                          inspectionTab === 'HYPOTHESES'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-sm'
                            : 'text-slate-400 hover:text-white bg-white/5 border border-transparent'
                        }`}
                      >
                        Competing Hypotheses ({analyst.competingHypotheses?.length || 4})
                      </button>
                    </div>

                    <span className="text-[9.5px] text-slate-400">
                      Sync: <span className="text-[#00FFA3] font-bold">REALTIME</span>
                    </span>
                  </div>

                  {/* TAB 1: 5 Tactical Wisdoms Grid */}
                  {inspectionTab === 'WISDOM' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
                      {/* 1. Order Flow & Trap Structure */}
                      <div className="p-2 rounded-lg bg-slate-950/80 border border-cyan-500/30 space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-cyan-300 font-bold uppercase">
                          <span>1. Order Flow & Trap Structure</span>
                          <span className="text-[8.5px] text-cyan-200">Structure Quality</span>
                        </div>
                        <div className="text-[10px] text-slate-200 leading-snug">
                          <strong>Trap: </strong>{condenseSentence(langMode === 'URDU' ? analyst.institutionalFootprint.trapScenarioUrdu : analyst.institutionalFootprint.trapScenario, 110)}
                        </div>
                        <div className="text-[9.5px] text-[#00FFA3] truncate">
                          <strong>Location Prudence: </strong>{condenseSentence(langMode === 'URDU' ? analyst.institutionalFootprint.entryPrudenceCheckUrdu : analyst.institutionalFootprint.entryPrudenceCheck, 90)}
                        </div>
                      </div>

                      {/* 2. 3 Scenarios & Invalidation */}
                      <div className="p-2 rounded-lg bg-slate-950/80 border border-cyan-500/30 space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-cyan-300 font-bold uppercase">
                          <span>2. 3 Scenarios & Triggers</span>
                          <span className="text-[8.5px] text-cyan-200">Stop: {formatPrice(analyst.scenarioSuite.invalidationTriggerPrice, selectedTicker)}</span>
                        </div>
                        <div className="text-[10px] text-slate-200 space-y-0.5">
                          <div><strong>Bull Case: </strong>&gt; {formatPrice(analyst.scenarioSuite.alternateBullCase.triggerLevel, selectedTicker)}</div>
                          <div><strong>Bear Case: </strong>&lt; {formatPrice(analyst.scenarioSuite.alternateBearCase.triggerLevel, selectedTicker)}</div>
                        </div>
                        <div className="text-[9px] text-red-300 truncate">
                          {condenseSentence(langMode === 'URDU' ? analyst.scenarioSuite.invalidationNotesUrdu : analyst.scenarioSuite.invalidationNotes, 100)}
                        </div>
                      </div>

                      {/* 3. Capital Protection */}
                      <div className="p-2 rounded-lg bg-slate-950/80 border border-cyan-500/30 space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-cyan-300 font-bold uppercase">
                          <span>3. Capital Protection</span>
                          <span className="text-[8.5px] text-[#00FFA3]">Capital First</span>
                        </div>
                        <div className="text-[10px] text-slate-200 leading-snug">
                          <strong>Directive: </strong>{condenseSentence(langMode === 'URDU' ? analyst.capitalPreservation.capitalProtectionDirectiveUrdu : analyst.capitalPreservation.capitalProtectionDirective, 110)}
                        </div>
                        <div className="text-[9px] text-amber-300 truncate">
                          Rule: {condenseSentence(langMode === 'URDU' ? analyst.capitalPreservation.riskManagementMandateUrdu : analyst.capitalPreservation.riskManagementMandate, 90)}
                        </div>
                      </div>

                      {/* 4. Global Intermarket & Commodities */}
                      <div className="p-2 rounded-lg bg-slate-950/80 border border-cyan-500/30 space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-cyan-300 font-bold uppercase">
                          <span>4. Global Intermarket & FX</span>
                          <span className="text-[8.5px] text-cyan-200">{analyst.intermarketCommodities.globalMacroSentiment}</span>
                        </div>
                        <div className="text-[9.5px] text-slate-300 space-y-0.5">
                          <div>USD/PKR: {condenseSentence(langMode === 'URDU' ? analyst.intermarketCommodities.usdpkrImpactUrdu : analyst.intermarketCommodities.usdpkrImpact, 80)}</div>
                          <div>Crude Oil: {condenseSentence(langMode === 'URDU' ? analyst.intermarketCommodities.crudeOilImpactUrdu : analyst.intermarketCommodities.crudeOilImpact, 80)}</div>
                        </div>
                      </div>

                      {/* 5. Institutional Smart Money Footprint */}
                      <div className="p-2 rounded-lg bg-slate-950/80 border border-emerald-500/30 space-y-1 md:col-span-2">
                        <div className="flex items-center justify-between text-[10px] text-[#00FFA3] font-bold uppercase">
                          <span>5. Smart Money Footprint & Order Block</span>
                          <span className="text-[8.5px] text-white">Zone: {formatPrice(analyst.orderBlockZone.low, selectedTicker)} - {formatPrice(analyst.orderBlockZone.high, selectedTicker)}</span>
                        </div>
                        <div className="text-[10px] text-slate-200 leading-snug">
                          {analyst.orderBlockZone.type} • Liquidity State: {analyst.liquidityState.split('(')[0].trim()}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* TAB 2: AI Research Feed (Injected Studies) */}
                  {inspectionTab === 'LIVE_LEARNING' && (
                    <div className="space-y-1.5">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
                        {learningState.injectedNodes.map((node, idx) => (
                          <div
                            key={node.id || idx}
                            className="p-2 rounded-lg bg-slate-950/85 border border-cyan-500/25 space-y-1"
                          >
                            <div className="flex items-center justify-between gap-1 text-[10px]">
                              <span className="font-bold text-cyan-300 uppercase truncate">
                                {idx + 1}. {node.name}
                              </span>
                              <span className="text-[8px] px-1 py-0.2 rounded bg-purple-500/15 text-purple-200 border border-purple-500/30 font-bold shrink-0">
                                {node.version}
                              </span>
                            </div>
                            <div className="text-[9px] text-slate-400 font-mono flex items-center justify-between">
                              <span className="truncate">Domain: {node.domain}</span>
                              <span className="text-[#00FFA3] font-bold shrink-0">{node.weightPct}% Weight</span>
                            </div>
                            <div className="text-[9.5px] text-slate-200 leading-snug font-sans">
                              {condenseSentence(langMode === 'URDU' ? node.summaryUrdu : node.summary, 120)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* TAB 3: 10 Analytical Angles */}
                  {inspectionTab === 'ANGLES' && analyst.multiAngleInsights && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
                      {analyst.multiAngleInsights.map((insight, idx) => (
                        <div key={idx} className="p-1.5 rounded-lg bg-slate-950/80 border border-white/10 space-y-0.5">
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="font-bold text-cyan-300 uppercase">
                              {idx + 1}. {insight.angle}
                            </span>
                            <span className="text-[8.5px] px-1 py-0.2 rounded bg-white/5 border border-white/10 text-white font-bold">
                              {insight.status}
                            </span>
                          </div>
                          <div className="text-[9.5px] text-slate-300 leading-snug">
                            {condenseSentence(langMode === 'URDU' ? insight.takeawayUrdu : insight.takeaway, 110)}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* TAB 4: Competing Hypotheses */}
                  {inspectionTab === 'HYPOTHESES' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
                      {analyst.competingHypotheses?.map((h, idx) => (
                        <div key={idx} className="p-2 rounded-lg bg-slate-950/80 border border-white/10 space-y-1">
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="font-bold text-white truncate">
                              {h.hypothesis}
                            </span>
                            <span className={`text-[8.5px] px-1 py-0.2 rounded border font-bold shrink-0 ${
                              h.probabilityPct >= 40
                                ? 'bg-emerald-500/20 text-[#00FFA3] border-emerald-500/40'
                                : h.probabilityPct >= 20
                                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                                : 'bg-slate-800 text-slate-400 border-white/10'
                            }`}>
                              {h.probabilityPct}% Prob
                            </span>
                          </div>
                          <div className="text-[9px] text-slate-300">
                            <strong>Evidence: </strong>{condenseSentence(h.evidenceFor, 90)}
                          </div>
                          <div className="text-[8.5px] text-rose-300 pt-0.5 border-t border-white/5 truncate">
                            <strong>Invalidation: </strong>{h.invalidationTrigger}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Bottom Minimal Disclaimer */}
            <div className="text-center text-[9px] font-mono text-slate-500 pt-0.5">
              Super Brain Analysis Report operates as an autonomous discretionary engine • Strictly for educational & analytical purposes.
            </div>

          </div>
        )}

      </div>

    </section>
  );
};
