import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

// Capture the native PWA install prompt before any UI component needs it.
if (typeof window !== 'undefined') {
  (window as any).__nhInstallPrompt = (window as any).__nhInstallPrompt || null;
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    (window as any).__nhInstallPrompt = event;
    window.dispatchEvent(new Event('nh-pwa-install-ready'));
  });
  window.addEventListener('appinstalled', () => {
    (window as any).__nhInstallPrompt = null;
    window.dispatchEvent(new Event('nh-pwa-installed'));
  });
  window.addEventListener('load', () => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js', { scope: './' }).catch(() => {});
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);

