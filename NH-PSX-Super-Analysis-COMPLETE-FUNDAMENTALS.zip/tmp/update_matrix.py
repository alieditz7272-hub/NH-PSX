import sys

with open('src/components/TradeConfluenceMatrixSection.tsx', 'r') as f:
    content = f.read()

download_func = """  // =========================================================================================
  // 9:16 HIGH-PROBABILITY CONFLUENCE POSTER GENERATION & GALLERY DOWNLOAD
  // Centers the live interactive chart with all active user settings directly from the application
  // =========================================================================================
  const handleDownloadPosterImage = async () => {
    if (isGeneratingImage) return;
    setIsGeneratingImage(true);

    try {
      const qvW = 1080;
      const qvH = 1920; // 9:16 Aspect Ratio
      const canvas = document.createElement('canvas');
      canvas.width = qvW;
      canvas.height = qvH;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        setIsGeneratingImage(false);
        return;
      }

      // Background Gradient (Deep cyber navy / black)
      const bg = ctx.createLinearGradient(0, 0, 0, qvH);
      bg.addColorStop(0, '#060d1a');
      bg.addColorStop(0.25, '#030814');
      bg.addColorStop(0.7, '#02050c');
      bg.addColorStop(1, '#000000');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, qvW, qvH);

      // Subtle Background Grid Lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.025)';
      ctx.lineWidth = 1;
      for (let x = 40; x < qvW; x += 60) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, qvH);
        ctx.stroke();
      }
      for (let y = 40; y < qvH; y += 60) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(qvW, y);
        ctx.stroke();
      }

      // 1. TOP HEADER BANNER (Y: 45 to 175, Height: 130px)
      const hdrX = 45;
      const hdrY = 45;
      const hdrW = 990;
      const hdrH = 130;

      ctx.fillStyle = '#081225';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(hdrX, hdrY, hdrW, hdrH, 20); else ctx.rect(hdrX, hdrY, hdrW, hdrH);
      ctx.fill();

      ctx.strokeStyle = '#00FFA3';
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#00FFA3';
      ctx.font = '900 32px monospace';
      ctx.fillText('⚡ NH STOCK TRADING TERMINAL 🇵🇰', qvW / 2, hdrY + 42);

      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 20px monospace';
      ctx.fillText('HIGH-PROBABILITY TRADE CONFLUENCE MATRIX', qvW / 2, hdrY + 88);

      // 2. LIVE DATE, TIME & TICKER SUMMARY BAR (Y: 195 to 335, Height: 140px)
      const tickY = 195;
      const tickH = 140;
      ctx.fillStyle = '#040b17';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(hdrX, tickY, hdrW, tickH, 18); else ctx.rect(hdrX, tickY, hdrW, tickH);
      ctx.fill();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
      ctx.lineWidth = 2;
      ctx.stroke();

      const liveDateStr = formatPSXDate();
      const liveTimeStr = formatPSXTime();

      // Top mini sub-row: Date and Time
      ctx.textAlign = 'left';
      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 15px monospace';
      ctx.fillText(`📅 DATE: ${liveDateStr}   |   ⏰ TIME: ${liveTimeStr} PKT`, hdrX + 25, tickY + 28);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#cbd5e1';
      ctx.fillText(`Timeframe: ${timeframe || '1D'} • Official PSX Real-Time`, hdrX + hdrW - 25, tickY + 28);

      // Main Symbol + CMP + Verdict
      ctx.textAlign = 'left';
      ctx.fillStyle = '#ffffff';
      ctx.font = '900 38px monospace';
      ctx.fillText(symbolClean, hdrX + 25, tickY + 80);

      const symW = ctx.measureText(symbolClean).width;
      ctx.fillStyle = '#00FFA3';
      ctx.font = '900 36px monospace';
      const curPriceFormatted = formatPriceWithUnit(analysis.currentPrice, isIdx);
      ctx.fillText(curPriceFormatted, hdrX + 45 + symW, tickY + 80);

      // Price Change subtext
      const deltaFormatted = `${formatDeltaWithUnit(analysis.priceChange, isIdx)} (${isPositiveDay ? '+' : ''}${analysis.priceChangePercent.toFixed(2)}%)`;
      ctx.font = 'bold 16px monospace';
      ctx.fillStyle = isPositiveDay ? '#00FFA3' : '#fb7185';
      ctx.fillText(deltaFormatted, hdrX + 25, tickY + 115);

      // Verdict Badge on Right
      const vBadgeW = 270;
      const vBadgeH = 46;
      const vBadgeX = hdrX + hdrW - vBadgeW - 25;
      const vBadgeY = tickY + 55;
      ctx.fillStyle = analysis.verdictBadgeBg || 'rgba(16, 185, 129, 0.2)';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(vBadgeX, vBadgeY, vBadgeW, vBadgeH, 12); else ctx.rect(vBadgeX, vBadgeY, vBadgeW, vBadgeH);
      ctx.fill();
      ctx.strokeStyle = analysis.verdictColor || '#00FFA3';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.textAlign = 'center';
      ctx.font = '900 15px monospace';
      ctx.fillStyle = analysis.verdictColor || '#00FFA3';
      ctx.fillText(`${analysis.verdict} • ${analysis.confluenceScore}% CONFLUENCE`, vBadgeX + vBadgeW / 2, vBadgeY + vBadgeH / 2);

      // 3. IMPORTANT TRADE LEVELS (4 KEY CARDS) (Y: 350 to 480, Height: 130px)
      const lvlY = 350;
      const lvlH = 130;
      const cardGap = 12;
      const numCards = 4;
      const cardW = (hdrW - (numCards - 1) * cardGap) / numCards;

      const levelsData = [
        {
          title: 'ENTRY ZONE',
          val: `${formatPriceWithUnit(analysis.entryLow, isIdx)} – ${formatPriceWithUnit(analysis.entryHigh, isIdx)}`,
          sub: analysis.cmpStatusTitle || 'Inside Active Zone',
          color: '#38bdf8',
          bg: 'rgba(14, 116, 144, 0.2)',
          border: 'rgba(56, 189, 248, 0.4)'
        },
        {
          title: 'STOP LOSS (SL)',
          val: formatPriceWithUnit(analysis.stopLoss, isIdx),
          sub: `-${analysis.riskPercent.toFixed(2)}% Risk Control`,
          color: '#fb7185',
          bg: 'rgba(159, 18, 57, 0.25)',
          border: 'rgba(244, 63, 94, 0.4)'
        },
        {
          title: 'TARGET 1 (TP1)',
          val: formatPriceWithUnit(analysis.tp1, isIdx),
          sub: `+${analysis.tp1GainPercent.toFixed(2)}% Initial TP`,
          color: '#34d399',
          bg: 'rgba(6, 78, 59, 0.3)',
          border: 'rgba(16, 185, 129, 0.4)'
        },
        {
          title: 'TARGET 2 (TP2)',
          val: formatPriceWithUnit(analysis.tp2, isIdx),
          sub: `+${analysis.tp2GainPercent.toFixed(2)}% Runner`,
          color: '#a7f3d0',
          bg: 'rgba(6, 78, 59, 0.25)',
          border: 'rgba(52, 211, 153, 0.4)'
        }
      ];

      levelsData.forEach((lvl, i) => {
        const cX = hdrX + i * (cardW + cardGap);
        ctx.fillStyle = lvl.bg;
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(cX, lvlY, cardW, lvlH, 14); else ctx.rect(cX, lvlY, cardW, lvlH);
        ctx.fill();
        ctx.strokeStyle = lvl.border;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.textAlign = 'center';
        ctx.fillStyle = '#94a3b8';
        ctx.font = 'bold 12px monospace';
        ctx.fillText(lvl.title, cX + cardW / 2, lvlY + 26);

        ctx.fillStyle = lvl.color;
        ctx.font = '900 16px monospace';
        ctx.fillText(lvl.val, cX + cardW / 2, lvlY + 62);

        ctx.fillStyle = '#e2e8f0';
        ctx.font = 'bold 11px monospace';
        ctx.fillText(lvl.sub, cX + cardW / 2, lvlY + 98);
      });

      // 4. CENTER SECTION: LIVE INTERACTIVE CHART FROM THE APPLICATION (Y: 495 to 1345, Height: 850px)
      const chartBoxY = 495;
      const chartBoxH = 850;

      ctx.fillStyle = '#01050e';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(hdrX, chartBoxY, hdrW, chartBoxH, 20); else ctx.rect(hdrX, chartBoxY, hdrW, chartBoxH);
      ctx.fill();
      ctx.strokeStyle = '#00FFA3';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // Chart Box Top Header Bar
      const chHdrH = 46;
      ctx.fillStyle = '#061325';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(hdrX, chartBoxY, hdrW, chHdrH, 20); else ctx.rect(hdrX, chartBoxY, hdrW, chHdrH);
      ctx.fill();

      // Flat bottom of header
      ctx.fillRect(hdrX, chartBoxY + chHdrH - 12, hdrW, 12);
      ctx.strokeStyle = 'rgba(0, 255, 163, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(hdrX, chartBoxY + chHdrH);
      ctx.lineTo(hdrX + hdrW, chartBoxY + chHdrH);
      ctx.stroke();

      ctx.textAlign = 'left';
      ctx.fillStyle = '#00FFA3';
      ctx.font = '900 17px monospace';
      ctx.fillText(`📈 LIVE CHART • APPLICATION SETTINGS (${symbolClean} • ${timeframe || '1D'})`, hdrX + 20, chartBoxY + 28);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 13px monospace';
      ctx.fillText(`EMAs • Candlesticks • Support / Resistance Levels`, hdrX + hdrW - 20, chartBoxY + 28);

      // Now draw the live chart canvas from the DOM
      const liveChartCanvas = document.getElementById('main-interactive-candlestick-canvas') as HTMLCanvasElement | null;
      const chartDstX = hdrX + 10;
      const chartDstY = chartBoxY + chHdrH + 8;
      const chartDstW = hdrW - 20;
      const chartDstH = chartBoxH - chHdrH - 16;

      let drawnLiveChart = false;
      if (liveChartCanvas && liveChartCanvas.width > 20 && liveChartCanvas.height > 20) {
        try {
          ctx.drawImage(
            liveChartCanvas,
            0,
            0,
            liveChartCanvas.width,
            liveChartCanvas.height,
            chartDstX,
            chartDstY,
            chartDstW,
            chartDstH
          );
          drawnLiveChart = true;
        } catch (drawErr) {
          console.error('Error drawing live chart canvas:', drawErr);
        }
      }

      // Fallback if canvas is somehow empty or unreadable
      if (!drawnLiveChart) {
        const chartCandles = candles && candles.length > 0 ? candles.slice(-40) : [];
        let cMin = Infinity;
        let cMax = -Infinity;
        chartCandles.forEach(c => {
          if (c.low < cMin) cMin = c.low;
          if (c.high > cMax) cMax = c.high;
        });
        if (cMin === Infinity || cMax === -Infinity || cMin === cMax) {
          cMin = analysis.currentPrice * 0.92;
          cMax = analysis.currentPrice * 1.08;
        }
        const pad = (cMax - cMin) * 0.08;
        cMin -= pad;
        cMax += pad;
        const range = cMax - cMin;

        const getCy = (val: number) => chartDstY + chartDstH - 30 - ((val - cMin) / range) * (chartDstH - 60);

        // Grid
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
        for (let g = 0; g <= 5; g++) {
          const gp = cMin + (range / 5) * g;
          const gy = getCy(gp);
          ctx.beginPath();
          ctx.moveTo(chartDstX + 15, gy);
          ctx.lineTo(chartDstX + chartDstW - 75, gy);
          ctx.stroke();

          ctx.textAlign = 'left';
          ctx.fillStyle = '#64748b';
          ctx.font = 'bold 12px monospace';
          ctx.fillText(formatPriceWithUnit(gp, isIdx), chartDstX + chartDstW - 68, gy + 4);
        }

        // Candles
        const nBars = chartCandles.length;
        const bStep = (chartDstW - 90) / Math.max(1, nBars);
        const candleW = Math.max(3, bStep * 0.65);
        const emaPts: { x: number; y: number }[] = [];
        let pEma = null;
        const k = 2 / 10;

        for (let b = 0; b < nBars; b++) {
          const c = chartCandles[b];
          const bx = chartDstX + 20 + b * bStep + bStep / 2;
          const isG = c.close >= c.open;
          const oy = getCy(c.open);
          const cy = getCy(c.close);
          const hy = getCy(c.high);
          const ly = getCy(c.low);

          ctx.strokeStyle = isG ? '#00FFA3' : '#f43f5e';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(bx, hy);
          ctx.lineTo(bx, ly);
          ctx.stroke();

          ctx.fillStyle = isG ? '#00FFA3' : '#f43f5e';
          ctx.fillRect(bx - candleW / 2, Math.min(oy, cy), candleW, Math.max(2, Math.abs(cy - oy)));

          pEma = pEma === null ? c.close : c.close * k + pEma * (1 - k);
          emaPts.push({ x: bx, y: getCy(pEma) });
        }

        if (emaPts.length > 1) {
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.moveTo(emaPts[0].x, emaPts[0].y);
          for (let p = 1; p < emaPts.length; p++) ctx.lineTo(emaPts[p].x, emaPts[p].y);
          ctx.stroke();
        }
      }

      // 5. INSTITUTIONAL CONFLUENCE SUMMARY (Y: 1360 to 1645, Height: 285px)
      const confBoxY = 1360;
      const confBoxH = 285;
      ctx.fillStyle = '#040d1c';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(hdrX, confBoxY, hdrW, confBoxH, 18); else ctx.rect(hdrX, confBoxY, hdrW, confBoxH);
      ctx.fill();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.textAlign = 'left';
      ctx.fillStyle = '#38bdf8';
      ctx.font = '900 18px monospace';
      ctx.fillText('⚡ INSTITUTIONAL CONFLUENCE & KEY MOMENTUM SIGNALS', hdrX + 25, confBoxY + 34);

      // 3 info rows/boxes
      const confCardW = (hdrW - 50 - 24) / 3;
      const confCardH = 100;
      const confCardY = confBoxY + 54;

      // Col 1: EMAs
      const c1X = hdrX + 25;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(c1X, confCardY, confCardW, confCardH, 12); else ctx.rect(c1X, confCardY, confCardW, confCardH);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.stroke();

      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 12px monospace';
      ctx.fillText('EMA STACK TREND', c1X + 16, confCardY + 24);

      ctx.fillStyle = '#ffffff';
      ctx.font = '900 14px monospace';
      ctx.fillText(`EMA 9:  ${analysis.ema9 > 0 ? formatPriceWithUnit(analysis.ema9, isIdx) : '-'}`, c1X + 16, confCardY + 48);
      ctx.fillText(`EMA 21: ${analysis.ema21 > 0 ? formatPriceWithUnit(analysis.ema21, isIdx) : '-'}`, c1X + 16, confCardY + 68);
      ctx.fillText(`EMA 50: ${analysis.ema50 > 0 ? formatPriceWithUnit(analysis.ema50, isIdx) : '-'}`, c1X + 16, confCardY + 88);

      // Col 2: Momentum
      const c2X = c1X + confCardW + 12;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(c2X, confCardY, confCardW, confCardH, 12); else ctx.rect(c2X, confCardY, confCardW, confCardH);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.stroke();

      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 12px monospace';
      ctx.fillText('MOMENTUM OSCILLATORS', c2X + 16, confCardY + 24);

      ctx.fillStyle = '#ffffff';
      ctx.font = '900 14px monospace';
      ctx.fillText(`RSI (14): ${analysis.rsi14.toFixed(1)} (${analysis.rsi14 >= 70 ? 'Overbought' : analysis.rsi14 <= 30 ? 'Oversold' : 'Neutral'})`, c2X + 16, confCardY + 48);
      ctx.fillText(`MACD: ${analysis.macdHist >= 0 ? '🟢 Bullish Cross' : '🔴 Bearish Cross'}`, c2X + 16, confCardY + 68);
      ctx.fillText(`Volume: ${analysis.volumeRatio.toFixed(2)}x (20D Avg)`, c2X + 16, confCardY + 88);

      // Col 3: Strategy & R:R
      const c3X = c2X + confCardW + 12;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(c3X, confCardY, confCardW, confCardH, 12); else ctx.rect(c3X, confCardY, confCardW, confCardH);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.stroke();

      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 12px monospace';
      ctx.fillText('RISK-TO-REWARD RATIO', c3X + 16, confCardY + 24);

      ctx.fillStyle = '#00FFA3';
      ctx.font = '900 20px monospace';
      ctx.fillText(analysis.riskRewardRatio, c3X + 16, confCardY + 54);

      ctx.fillStyle = '#cbd5e1';
      ctx.font = 'bold 12px monospace';
      ctx.fillText(`Max Risk: ${analysis.riskPercent.toFixed(2)}% of Capital`, c3X + 16, confCardY + 84);

      // Bottom Commentary inside Confluence Box
      const commBoxY = confCardY + confCardH + 14;
      const commBoxH = 88;
      ctx.fillStyle = 'rgba(6, 17, 34, 0.95)';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(c1X, commBoxY, hdrW - 50, commBoxH, 12); else ctx.rect(c1X, commBoxY, hdrW - 50, commBoxH);
      ctx.fill();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
      ctx.stroke();

      ctx.fillStyle = '#38bdf8';
      ctx.font = '900 13px monospace';
      ctx.fillText(`STATUS: ${analysis.cmpStatusTitle.toUpperCase()}`, c1X + 16, commBoxY + 25);

      ctx.fillStyle = '#e2e8f0';
      ctx.font = '500 13.5px sans-serif';
      const descText = analysis.cmpStatusDescription || analysis.verdictSubtext || '';
      ctx.fillText(descText, c1X + 16, commBoxY + 52);

      // 6. BOTTOM FOOTER SECTION (Y: 1665 to 1885, Height: 220px)
      const ftrX = hdrX;
      const ftrY = 1665;
      const ftrW = hdrW;
      const ftrH = 220;

      ctx.fillStyle = '#050c18';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(ftrX, ftrY, ftrW, ftrH, 18); else ctx.rect(ftrX, ftrY, ftrW, ftrH);
      ctx.fill();
      ctx.strokeStyle = 'rgba(0, 255, 163, 0.35)';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.textAlign = 'center';
      ctx.fillStyle = '#00FFA3';
      ctx.font = '900 23px monospace';
      ctx.fillText('🇵🇰 DEVELOPED BY NADEEM HASSAN', qvW / 2, ftrY + 40);

      ctx.fillStyle = '#facc15';
      ctx.font = '900 21px monospace';
      ctx.fillText('📞 WHATSAPP & CALL: 03009412177', qvW / 2, ftrY + 76);

      // Disclaimer Box
      const discY = ftrY + 104;
      const discH = 76;
      ctx.fillStyle = 'rgba(239, 68, 68, 0.08)';
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(ftrX + 25, discY, ftrW - 50, discH, 10); else ctx.rect(ftrX + 25, discY, ftrW - 50, discH);
      ctx.fill();
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#fb7185';
      ctx.font = '900 13px monospace';
      ctx.fillText('⚠️ CRITICAL EDUCATIONAL DISCLAIMER (DYOR)', qvW / 2, discY + 24);

      ctx.fillStyle = '#cbd5e1';
      ctx.font = '500 12px sans-serif';
      ctx.fillText('Generated strictly for algorithmic learning and analytical study. Never trade without proper stop loss.', qvW / 2, discY + 46);
      ctx.fillText('Always perform your own due diligence before executing live trades on Pakistan Stock Exchange.', qvW / 2, discY + 64);

      ctx.fillStyle = '#64748b';
      ctx.font = 'bold 12px monospace';
      ctx.fillText('© 2026 NH Stock Trading Terminal Pro • High-Definition 9:16 Social Poster', qvW / 2, ftrY + ftrH - 12);

      // Save to Mobile Gallery & Trigger Direct Download
      canvas.toBlob(async (blob) => {
        if (!blob) {
          setIsGeneratingImage(false);
          return;
        }

        const fileName = `NH_High_Probability_${symbolClean}_9x16.png`;

        // Direct Download
        const link = document.createElement('a');
        link.download = fileName;
        link.href = URL.createObjectURL(blob);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);

        // Native mobile share if supported
        if (navigator.share && navigator.canShare && navigator.canShare({ files: [new File([blob], fileName, { type: 'image/png' })] })) {
          try {
            await navigator.share({
              files: [new File([blob], fileName, { type: 'image/png' })],
              title: `NH Stock Trading — High Probability: ${symbolClean}`,
              text: `⚡ High Probability Trade Confluence Plan for ${symbolClean}`,
            });
          } catch (shareErr) {
            console.log('Mobile share dialog closed or dismissed:', shareErr);
          }
        }

        setImageSavedMessage('Image Saved');
        setTimeout(() => setImageSavedMessage(null), 4500);
        setIsGeneratingImage(false);
      }, 'image/png', 1.0);
    } catch (err) {
      console.error('Failed to generate high probability poster:', err);
      setIsGeneratingImage(false);
    }
  };"""

# Replace copy function with download_func
start_copy = content.find("  // Copy trade plan handler\n  const handleCopyTradePlan = () => {")
end_copy = content.find("  const symbolClean = (liveTicker.symbol || '').toUpperCase().replace('.PSX', '').trim();")

if start_copy == -1 or end_copy == -1:
    print("Could not find copy function indices:", start_copy, end_copy)
    sys.exit(1)

new_content = content[:start_copy] + download_func + "\n\n" + content[end_copy:]

# Replace the button
old_button = """          {/* Copy plan button */}
          <button
            onClick={handleCopyTradePlan}
            id="btn-copy-trade-plan"
            className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-mono font-bold transition-all duration-200 bg-white/5 hover:bg-white/10 border border-white/15 text-slate-200 active:scale-95"
            title="Copy entire trade plan to clipboard"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-[#00FFA3]" />
                <span className="text-[#00FFA3]">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-slate-300" />
                <span>Copy Plan</span>
              </>
            )}
          </button>"""

new_button = """          {/* 9:16 Image Download Button */}
          <button
            onClick={handleDownloadPosterImage}
            disabled={isGeneratingImage}
            id="btn-download-high-prob-poster"
            className="flex items-center gap-1.5 px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl text-xs font-mono font-bold transition-all duration-200 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 border border-emerald-400/40 text-white active:scale-95 shadow-[0_0_15px_rgba(16,185,129,0.3)] disabled:opacity-60 cursor-pointer"
            title="Save High-Probability Analysis & Live Chart to Mobile Gallery in 9:16 Format"
          >
            {isGeneratingImage ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Saving 9:16...</span>
              </>
            ) : imageSavedMessage ? (
              <>
                <Check className="w-4 h-4 text-[#00FFA3]" />
                <span className="text-[#00FFA3]">Image Saved</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 text-emerald-100" />
                <span>Download 9:16</span>
              </>
            )}
          </button>"""

if old_button not in new_content:
    print("old_button not found")
    sys.exit(1)

new_content = new_content.replace(old_button, new_button)

# Add toast banner before </section>
toast_banner = """      {/* Image Saved Notification Banner */}
      {imageSavedMessage && (
        <div 
          id="high-prob-image-saved-toast"
          className="fixed bottom-6 right-6 z-50 bg-[#061122] border-2 border-[#00FFA3] text-white px-5 py-3.5 rounded-xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-bottom-5 font-mono text-sm"
        >
          <div className="w-7 h-7 rounded-full bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-[#00FFA3]">
            <Check className="w-4 h-4" />
          </div>
          <div>
            <div className="font-black text-[#00FFA3] uppercase tracking-wide">Image Saved</div>
            <div className="text-xs text-slate-300">Saved to mobile gallery & downloads successfully!</div>
          </div>
        </div>
      )}
    </section>"""

if "    </section>\n  );\n};" not in new_content:
    print("closing section not found")
    sys.exit(1)

new_content = new_content.replace("    </section>\n  );\n};", toast_banner + "\n  );\n};")

with open('src/components/TradeConfluenceMatrixSection.tsx', 'w') as f:
    f.write(new_content)

print("SUCCESSFULLY_UPDATED_MATRIX")
