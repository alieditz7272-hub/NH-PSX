import json,re,time,concurrent.futures
from datetime import datetime,timezone
from urllib.request import Request,urlopen

BASE='https://dps.psx.com.pk'
HEADERS={'User-Agent':'Mozilla/5.0 (compatible; NH-PSX-Super-Analysis/1.0)','Accept':'text/html,application/xhtml+xml'}

def get(url):
    req=Request(url,headers=HEADERS)
    with urlopen(req,timeout=25) as r:return r.read().decode('utf-8','replace')

def num(v):
    try:
        x=str(v).replace(',','').replace('%','').replace('Rs','').strip()
        return float(x) if x not in ('','-','—','N/A','n/a') else None
    except:return None

def clean(s):
    s=re.sub(r'<script[\s\S]*?</script>|<style[\s\S]*?</style>',' ',s,flags=re.I)
    s=re.sub(r'<[^>]+>',' ',s); s=re.sub(r'&nbsp;',' ',s,flags=re.I); s=re.sub(r'&amp;','&',s,flags=re.I)
    return re.sub(r'\s+',' ',s).strip()

def table_rows(html):
    out=[]
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>',html,re.I|re.S):
        cells=[]
        for c in re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>',tr,re.I|re.S): cells.append(clean(c))
        if cells: out.append(cells)
    return out

def parse_symbol(sym):
    try: html=get(f'{BASE}/company/{sym}')
    except:return None
    rows=table_rows(html)
    annual=[]; ratios=[]; payouts=[]
    section=''
    for r in rows:
        joined=' | '.join(r)
        low=joined.lower()
        if 'financials' in low: section='financials'
        if 'ratios' in low: section='ratios'
        if 'payouts' in low: section='payouts'
        if any(x in low for x in ['profit after taxation','eps','sales','total income','net income']): annual.append(r)
        if any(x in low for x in ['book value','enterprise value','price to book','price earnings']): ratios.append(r)
        if any(x in low for x in ['dividend','cash dividend']): payouts.append(r)
    # Direct text parsing is intentionally conservative: only values clearly labelled by PSX page are accepted.
    text=clean(html)
    years=[]
    ym=re.search(r'Annual\s+(20\d{2})\s+(20\d{2})\s+(20\d{2})\s+(20\d{2})',text,re.I)
    if ym: years=[int(x) for x in ym.groups()]
    def row(label, source):
        for r in source:
            if r and label.lower() in r[0].lower(): return r[1:]
        return []
    epss=row('EPS',annual)
    profits=row('Profit after Taxation',annual)
    sales=row('Sales',annual)
    bvs=row('Break-up Value per Share',ratios) or row('Book value Per Share',ratios)
    evs=row('Enterprise Value',ratios)
    divs=row('Cash Dividend per Share',payouts) or row('Cash dividend',payouts)
    # Fallback for pages whose table parser labels sections differently.
    if not epss:
        m=re.search(r'EPS\s+([\d().,-]+)\s+([\d().,-]+)\s+([\d().,-]+)\s+([\d().,-]+)',text,re.I)
        if m: epss=list(m.groups())
    if not profits:
        m=re.search(r'Profit after Taxation\s+([\d().,-]+)\s+([\d().,-]+)\s+([\d().,-]+)\s+([\d().,-]+)',text,re.I)
        if m: profits=list(m.groups())
    vals=lambda a:[num(x) for x in a]
    eps=vals(epss); prof=vals(profits); bv=vals(bvs); ev=vals(evs); div=vals(divs)
    current_eps=eps[0] if eps else None
    prev_eps=eps[1] if len(eps)>1 else None
    current_profit=prof[0] if prof else None
    prev_profit=prof[1] if len(prof)>1 else None
    expected_eps=None
    if current_eps is not None and current_profit is not None and prev_profit not in (None,0):
        growth=max(-.20,min(.25,current_profit/prev_profit-1)); expected_eps=round(current_eps*(1+growth),2)
    latest_div=next((x for x in div if x is not None),None)
    current_bv=next((x for x in bv if x is not None),None)
    expected_bv=None
    if current_bv is not None and len(bv)>1 and bv[1] is not None: expected_bv=round(current_bv*(current_bv/bv[1]),2)
    current_ev=next((x for x in ev if x is not None),None)
    expected_ev=None
    if current_ev is not None and current_eps not in (None,0) and expected_eps is not None: expected_ev=round(current_ev*(expected_eps/current_eps),2)
    # Face value is normally 10 or 5; only take it when explicitly shown.
    mf=re.search(r'(?:Face Value|Par Value)\s*(?:Rs\.?\s*)?([\d,.]+)',text,re.I)
    face=num(mf.group(1)) if mf else None
    return {'symbol':sym,'currentEps':current_eps,'expectedEps':expected_eps,'currentBookValue':current_bv,'expectedBookValue':expected_bv,'currentEnterpriseValue':current_ev,'expectedEnterpriseValue':expected_ev,'latestCashDividend':latest_div,'expectedCashDividend':latest_div,'latestCashDividendExDate':None,'currentYearProfitLoss':current_profit,'previousYearProfitLoss':prev_profit,'faceValue':face,'source':'PSX Data Portal — company financials','fetchedAt':int(time.time()*1000)}

def symbols():
    html=get(BASE+'/screener/')
    syms=[]
    for m in re.finditer(r'<td[^>]*>\s*([A-Z0-9&._-]{1,20})\s*</td>',html,re.I):
        s=m.group(1).upper()
        if s not in syms and s not in {'SYMBOL','KSE100','KSE100PR','ALLSHR','KSE30','KMI30','KMIALLSHR'}: syms.append(s)
    return syms

syms=symbols(); print('symbols',len(syms))
results={}
def one(s):
    try:return s,parse_symbol(s)
    except Exception:return s,None
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex:
    for s,r in ex.map(one,syms):
        if r: results[s]=r
        if len(results)%50==0: print('parsed',len(results))
payload={'fetchedAt':datetime.now(timezone.utc).isoformat(),'source':'PSX Data Portal — official company financials','data':results}
with open('public/data/fundamentals.json','w',encoding='utf-8') as f:json.dump(payload,f,separators=(',',':'))
print('wrote',len(results))
