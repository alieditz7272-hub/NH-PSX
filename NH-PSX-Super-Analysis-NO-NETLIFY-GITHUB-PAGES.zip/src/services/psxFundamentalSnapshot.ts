export interface FundamentalSnapshot {
  symbol: string;
  companyName: string;
  currentEps: number | null;
  expectedEps: number | null;
  peRatio: number | null;
  sectorMedianPe: number | null;
  faceValue: number | null;
  currentBookValue: number | null;
  expectedBookValue: number | null;
  currentEnterpriseValue: number | null;
  expectedEnterpriseValue: number | null;
  latestCashDividend: number | null;
  expectedCashDividend: number | null;
  latestCashDividendExDate: string | null;
  currentYearProfitLoss: number | null;
  previousYearProfitLoss: number | null;
  source: string;
  fetchedAt: number;
}

const API = 'https://psxdata-api.fastapicloud.dev';
const n = (v: any) => {
  const x = Number(String(v ?? '').replace(/,/g, '').replace(/%/g, '').trim());
  return Number.isFinite(x) ? x : null;
};

export async function fetchFundamentalSnapshot(symbol: string): Promise<FundamentalSnapshot> {
  const clean = symbol.replace(/\.PSX$|\.KA$/i, '').replace(/[^A-Z0-9&._-]/gi, '').toUpperCase();
  const [screenRes, companyRes] = await Promise.all([
    fetch(`${API}/screener?ts=${Date.now()}`, { cache: 'no-store' }),
    fetch(`https://dps.psx.com.pk/company/${encodeURIComponent(clean)}?ts=${Date.now()}`, { cache: 'no-store' })
  ]);

  if (!screenRes.ok) throw new Error(`PSX screener HTTP ${screenRes.status}`);
  const screenPayload = await screenRes.json();
  const rows = Array.isArray(screenPayload) ? screenPayload : screenPayload?.data;
  if (!Array.isArray(rows)) throw new Error('PSX screener returned no rows');
  const row = rows.find((r: any) => String(r.symbol || r.SYMBOL || '').toUpperCase() === clean);
  if (!row) throw new Error(`${clean} not found in PSX screener`);

  const price = n(row.price ?? row.current ?? row.CURRENT);
  const pe = n(row.peRatio ?? row.pe ?? row['P/E RATIO'] ?? row['PE RATIO']);
  const eps = price && pe && pe > 0 ? Number((price / pe).toFixed(4)) : null;
  const sector = String(row.sector || row.SECTOR || '');
  const sectorPes = rows
    .filter((r: any) => String(r.sector || r.SECTOR || '') === sector)
    .map((r: any) => n(r.peRatio ?? r.pe ?? r['P/E RATIO'] ?? r['PE RATIO']))
    .filter((v: number | null): v is number => v !== null && v > 0 && v < 100);
  sectorPes.sort((a,b) => a-b);
  const sectorMedianPe = sectorPes.length ? sectorPes[Math.floor(sectorPes.length / 2)] : null;

  let companyText = '';
  if (companyRes.ok) companyText = await companyRes.text();
  const text = companyText.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
  const annual = [...text.matchAll(/(20\d{2})\s*\|\s*([\d,.-]+)\s*\|\s*([\d,.-]+)\s*\|\s*([\d,.-]+)\s*\|\s*([\d,.-]+)/g)].slice(0, 1);
  let latestEps = eps;
  let latestProfit: number | null = null;
  let previousProfit: number | null = null;
  if (annual.length) {
    const m = annual[0];
    latestProfit = n(m[3]);
    previousProfit = n(m[4]);
    latestEps = n(m[5]) ?? latestEps;
  }
  const expectedEps = latestEps && previousProfit !== null && latestProfit !== null && previousProfit !== 0
    ? Number((latestEps * (1 + Math.max(-0.20, Math.min(0.25, (latestProfit / previousProfit) - 1)))).toFixed(2))
    : null;

  return {
    symbol: clean,
    companyName: String(row.name || row.companyName || clean),
    currentEps: latestEps,
    expectedEps,
    peRatio: pe,
    sectorMedianPe,
    faceValue: null,
    currentBookValue: null,
    expectedBookValue: null,
    currentEnterpriseValue: null,
    expectedEnterpriseValue: null,
    latestCashDividend: null,
    expectedCashDividend: null,
    latestCashDividendExDate: null,
    currentYearProfitLoss: latestProfit,
    previousYearProfitLoss: previousProfit,
    source: 'PSX Data Portal',
    fetchedAt: Date.now(),
  };
}
