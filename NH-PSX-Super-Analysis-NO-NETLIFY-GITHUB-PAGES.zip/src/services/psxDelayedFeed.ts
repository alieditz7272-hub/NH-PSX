import { TickerQuote } from '../types';

type CellMap = Record<string, string>;

const clean = (value: string) => value
  .replace(/\u00a0/g, ' ')
  .replace(/\s+/g, ' ')
  .trim();

const numberValue = (value?: string) => {
  const n = Number(String(value ?? '').replace(/,/g, '').replace(/%/g, '').trim());
  return Number.isFinite(n) ? n : 0;
};

const keyName = (value: string) => value.toLowerCase().replace(/[^a-z0-9]/g, '');

function cellValue(cell: HTMLTableCellElement) {
  const order = cell.getAttribute('data-order');
  return order && order.trim() !== '' ? order : clean(cell.textContent || '');
}

function makeQuote(named: CellMap, positional: string[]): TickerQuote | null {
  const symbol = clean(named.symbol || positional[0] || '').replace(/\s+/g, '').toUpperCase();
  if (!/^[A-Z0-9&._-]{1,20}$/.test(symbol) || symbol === 'SYMBOL') return null;

  const previousClose = numberValue(named.ldcp || named.previousclose || positional[1]);
  const open = numberValue(named.open || positional[2]);
  const high = numberValue(named.high || positional[3]);
  const low = numberValue(named.low || positional[4]);
  const price = numberValue(named.current || named.close || positional[5]);
  const change = numberValue(named.change || positional[6]);
  const changePercent = numberValue(named.percentchange || named.changepercent || named.changepercentage || positional[7]);
  const volume = numberValue(named.volume || positional[8]);

  if (price <= 0) return null;

  return {
    symbol: `${symbol}.PSX`,
    name: clean(named.name || symbol),
    price,
    change,
    changePercent,
    open: open || price,
    high: high || price,
    low: low || price,
    previousClose,
    volume,
    avgVolume: volume,
    marketCap: 0,
    sector: 'PSX',
    assetClass: 'Stock',
    exchange: 'PSX (Pakistan)',
    countryFlag: '🇵🇰',
    lastTickTime: Date.now(),
    bid: 0,
    ask: 0,
    bidSize: 0,
    askSize: 0,
    vwap: 0,
    rsi: 50,
    macd: { macd: 0, signal: 0, histogram: 0 },
    sma20: 0,
    sma50: 0,
    sma200: 0,
    aiScore: 0,
    aiSignal: 'Neutral',
    isVerified: true,
    source: 'PSX Official Market Watch — 5-minute delayed data',
    receivedAt: Date.now(),
  };
}

export async function fetchPSXDelayedQuotes(force = false): Promise<{ data: TickerQuote[]; fetchedAt: number; sourceTime: string }> {
  const cacheKey = '__NH_PSX_DELAYED_CACHE__';
  if (!force) {
    const cached = (globalThis as any)[cacheKey];
    if (cached && Date.now() - cached.fetchedAt < 4 * 60 * 1000 && cached.data.length > 20) return cached;
  }

  const configured = (import.meta as any).env?.VITE_PSX_DATA_URL as string | undefined;
  const url = configured || 'https://psxdata-api.fastapicloud.dev/screener';
  const response = await fetch(`${url}${url.includes('?') ? '&' : '?'}ts=${Date.now()}`, { cache: 'no-store' });
  if (!response.ok) throw new Error(`PSX snapshot HTTP ${response.status}`);
  const payload = await response.json();
  const raw = Array.isArray(payload) ? payload : payload?.data;
  if (!Array.isArray(raw) || raw.length < 20) throw new Error('PSX snapshot has insufficient verified rows');

  const data: TickerQuote[] = raw.map((q: any) => ({
    symbol: `${String(q.symbol || '').replace(/\.PSX$|\.KA$/i, '').toUpperCase()}.PSX`,
    name: String(q.name || q.symbol || ''),
    price: numberValue(String(q.price ?? q.current ?? 0)),
    change: numberValue(String(q.change ?? 0)),
    changePercent: numberValue(String(q.changePercent ?? 0)),
    open: numberValue(String(q.open ?? q.price ?? 0)),
    high: numberValue(String(q.high ?? q.price ?? 0)),
    low: numberValue(String(q.low ?? q.price ?? 0)),
    previousClose: numberValue(String(q.previousClose ?? q.ldcp ?? 0)),
    volume: numberValue(String(q.volume ?? 0)),
    avgVolume: numberValue(String(q.volume ?? 0)),
    marketCap: 0,
    sector: 'PSX', assetClass: 'Stock', exchange: 'PSX (Pakistan)', countryFlag: '🇵🇰',
    lastTickTime: payload?.fetchedAt ? Date.parse(payload.fetchedAt) : Date.now(),
    bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0,
    rsi: 50, macd: { macd: 0, signal: 0, histogram: 0 }, sma20: 0, sma50: 0, sma200: 0,
    aiScore: 0, aiSignal: 'Neutral', isVerified: true,
    source: String(payload?.source || 'PSX via psxdata'), receivedAt: Date.now(),
  })).filter((q: TickerQuote) => q.price > 0 && q.symbol.length > 5);

  if (data.length < 20) throw new Error(`PSX snapshot has only ${data.length} valid quotes`);
  const result = {
    data,
    fetchedAt: payload?.fetchedAt ? Date.parse(payload.fetchedAt) : Date.now(),
    sourceTime: payload?.fetchedAt || payload?.meta?.timestamp || new Date().toISOString(),
  };
  (globalThis as any)[cacheKey] = result;
  return result;
}
