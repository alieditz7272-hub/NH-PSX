import { TickerQuote } from '../types';

type CellMap = Record<string, string>;

const clean = (value: string) => value
  .replace(/\u00a0/g, ' ')
  .replace(/\s+/g, ' ')
  .trim();

const numberValue = (value?: string) => {
  const n = Number(String(value ?? '').replace(/,/g, '').replace(/%/g, '').trim());
  return Number.isFinite(n) ? n : 0;
};

const keyName = (value: string) => value.toLowerCase().replace(/[^a-z0-9]/g, '');

function cellValue(cell: HTMLTableCellElement) {
  const order = cell.getAttribute('data-order');
  return order && order.trim() !== '' ? order : clean(cell.textContent || '');
}

function makeQuote(named: CellMap, positional: string[]): TickerQuote | null {
  const symbol = clean(named.symbol || positional[0] || '').replace(/\s+/g, '').toUpperCase();
  if (!/^[A-Z0-9&._-]{1,20}$/.test(symbol) || symbol === 'SYMBOL') return null;

  const previousClose = numberValue(named.ldcp || named.previousclose || positional[1]);
  const open = numberValue(named.open || positional[2]);
  const high = numberValue(named.high || positional[3]);
  const low = numberValue(named.low || positional[4]);
  const price = numberValue(named.current || named.close || positional[5]);
  const change = numberValue(named.change || positional[6]);
  const changePercent = numberValue(named.percentchange || named.changepercent || named.changepercentage || positional[7]);
  const volume = numberValue(named.volume || positional[8]);

  if (price <= 0) return null;

  return {
    symbol: `${symbol}.PSX`,
    name: clean(named.name || symbol),
    price,
    change,
    changePercent,
    open: open || price,
    high: high || price,
    low: low || price,
    previousClose,
    volume,
    avgVolume: volume,
    marketCap: 0,
    sector: clean(named.sector || 'PSX'),
    assetClass: 'Stock',
    exchange: 'PSX (Pakistan)',
    countryFlag: '🇵🇰',
    lastTickTime: Date.now(),
    bid: 0,
    ask: 0,
    bidSize: 0,
    askSize: 0,
    vwap: 0,
    rsi: 50,
    macd: { macd: 0, signal: 0, histogram: 0 },
    sma20: 0,
    sma50: 0,
    sma200: 0,
    aiScore: 0,
    aiSignal: 'Neutral',
    isVerified: true,
    source: 'PSX Official Market Watch — 5-minute delayed data',
    receivedAt: Date.now(),
  };
}


function parseOfficialIndexHtml(html: string, cleanCode: string): TickerQuote | null {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const text = (doc.body?.innerText || '').replace(/\u00a0/g, ' ').replace(/[ \t]+/g, ' ').trim();
  const marker = new RegExp(`${cleanCode}\\s+([\\d,]+(?:\\.\\d+)?)\\s+([+-]?[\\d,]+(?:\\.\\d+)?)\\s*\\(([+-]?[\\d.]+)%\\)`, 'i').exec(text);
  if (!marker) return null;

  const current = numberValue(marker[1]);
  const change = numberValue(marker[2]);
  const changePercent = numberValue(marker[3]);
  if (current <= 0) return null;

  let high = current;
  let low = current;
  const tableMarker = new RegExp(`${cleanCode}\\s*\\|\\s*High\\s*\\|\\s*Low\\s*\\|\\s*Current`, 'i');
  const idx = text.search(tableMarker);
  if (idx >= 0) {
    const tail = text.slice(idx, idx + 700);
    const nums = tail.match(/[\d,]+(?:\.\d+)?/g) || [];
    if (nums.length >= 2) {
      high = numberValue(nums[0]);
      low = numberValue(nums[1]);
    }
  }

  return {
    symbol: `${cleanCode}.PSX`,
    name: cleanCode === 'KSE100' ? 'KSE-100 Index' : cleanCode,
    price: current,
    change,
    changePercent,
    open: current,
    high: high > 0 ? high : current,
    low: low > 0 ? low : current,
    previousClose: current - change,
    volume: 0,
    avgVolume: 0,
    marketCap: 0,
    sector: 'Pakistan Benchmark Index',
    assetClass: 'Index' as const,
    exchange: 'PSX (Pakistan)',
    countryFlag: '🇵🇰',
    lastTickTime: Date.now(),
    bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0,
    rsi: 50, macd: { macd: 0, signal: 0, histogram: 0 }, sma20: 0, sma50: 0, sma200: 0,
    aiScore: 0, aiSignal: 'Neutral', isVerified: true,
    source: 'PSX Data Portal — official index snapshot',
    receivedAt: Date.now(),
  };
}

async function fetchOfficialIndexQuote(code: string): Promise<TickerQuote | null> {
  const cleanCode = code.replace(/[^A-Z0-9]/g, '').toUpperCase();

  // Primary: official PSX index snapshot. It is the exchange's own
  // published current value and remains valid after the trading session closes.
  for (const endpoint of [
    `https://dps.psx.com.pk/indices?ts=${Date.now()}`,
    `https://dps.psx.com.pk/indices/${cleanCode}?ts=${Date.now()}`,
  ]) {
    try {
      const res = await fetch(endpoint, {
        cache: 'no-store',
        headers: { 'Accept': 'text/html,application/xhtml+xml' },
      });
      if (res.ok) {
        const quote = parseOfficialIndexHtml(await res.text(), cleanCode);
        if (quote) return quote;
      }
    } catch {
      // Try the next official endpoint, then the JSON timeseries fallback.
    }
  }

  // Secondary: official PSX JSON timeseries. PSX returns newest tick first.
  try {
    const [intradayRes, eodRes] = await Promise.all([
      fetch(`https://dps.psx.com.pk/timeseries/int/${cleanCode}?ts=${Date.now()}`, { cache: 'no-store' }),
      fetch(`https://dps.psx.com.pk/timeseries/eod/${cleanCode}?ts=${Date.now()}`, { cache: 'no-store' })
    ]);
    if (!intradayRes.ok) return null;
    const intraday = await intradayRes.json();
    const eod = eodRes.ok ? await eodRes.json() : null;
    const ticks = Array.isArray(intraday?.data) ? intraday.data : [];
    if (!ticks.length) return null;

    const last = ticks[0];
    const prices = ticks.map((r: any[]) => Number(r?.[1])).filter((n: number) => Number.isFinite(n) && n > 0);
    const current = Number(last?.[1]);
    if (!Number.isFinite(current) || current <= 0) return null;

    const previousClose = Number(Array.isArray(eod?.data) && eod.data.length ? eod.data[0]?.[1] : 0);
    const change = previousClose > 0 ? current - previousClose : 0;
    const changePercent = previousClose > 0 ? (change / previousClose) * 100 : 0;
    const timestamp = Number(last?.[0]) * 1000;

    return {
      symbol: `${cleanCode}.PSX`,
      name: cleanCode === 'KSE100' ? 'KSE-100 Index' : cleanCode,
      price: current,
      change,
      changePercent,
      open: prices[prices.length - 1] || current,
      high: Math.max(...prices),
      low: Math.min(...prices),
      previousClose,
      volume: Number(last?.[2] || 0),
      avgVolume: 0,
      marketCap: 0,
      sector: 'Pakistan Benchmark Index',
      assetClass: 'Index' as const,
      exchange: 'PSX (Pakistan)',
      countryFlag: '🇵🇰',
      lastTickTime: Number.isFinite(timestamp) ? timestamp : Date.now(),
      bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0,
      rsi: 50, macd: { macd: 0, signal: 0, histogram: 0 }, sma20: 0, sma50: 0, sma200: 0,
      aiScore: 0, aiSignal: 'Neutral', isVerified: true,
      source: 'PSX Data Portal — official index timeseries',
      receivedAt: Date.now(),
    };
  } catch {
    return null;
  }
}

function parseMarketWatchHtml(html: string): TickerQuote[] {
  if (typeof DOMParser === 'undefined') return [];
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const tables = Array.from(doc.querySelectorAll('table'));
  const aliases: Record<string, string[]> = {
    symbol: ['symbol', 'scrip', 'code'], name: ['name', 'company'], ldcp: ['ldcp', 'previousclose', 'prevclose'],
    open: ['open'], high: ['high'], low: ['low'], current: ['current', 'close', 'price'],
    change: ['change'], percentchange: ['change%', 'changepercent', 'percentchange', 'pctchange'], volume: ['volume'],
  };
  const normalized = (v: string) => keyName(clean(v));
  const matchKey = (header: string) => {
    const raw = clean(header);
    // PSX renders both `CHANGE` and `CHANGE (%)`. They normalize to the same
    // string, so percent-change must be detected before punctuation is removed.
    if (/change\s*\(%?\)?/i.test(raw) && /%/.test(raw)) return 'percentchange';
    if (/^change$/i.test(raw)) return 'change';
    const h = normalized(raw);
    for (const [key, list] of Object.entries(aliases)) if (list.includes(h)) return key;
    return '';
  };

  let best: { table: HTMLTableElement; headers: string[] } | null = null;
  for (const table of tables) {
    const headerRow = table.querySelector('thead tr') || table.querySelector('tr');
    if (!headerRow) continue;
    const headers = Array.from(headerRow.querySelectorAll('th,td')).map(c => matchKey(c.textContent || ''));
    if (headers.includes('symbol') && headers.includes('current') && headers.includes('ldcp')) {
      best = { table, headers };
      break;
    }
  }
  if (!best) return [];

  const quotes: TickerQuote[] = [];
  const rows = Array.from(best.table.querySelectorAll('tbody tr')).length
    ? Array.from(best.table.querySelectorAll('tbody tr'))
    : Array.from(best.table.querySelectorAll('tr')).slice(1);
  for (const row of rows) {
    const cells = Array.from(row.querySelectorAll('td'));
    if (!cells.length) continue;
    const named: CellMap = {};
    const positional = cells.map(cellValue);
    cells.forEach((cell, i) => {
      const dataName = cell.getAttribute('data-name');
      const key = dataName ? normalized(dataName) : best!.headers[i] || '';
      if (key) named[key] = cellValue(cell);
    });
    const q = makeQuote(named, positional);
    if (q) quotes.push(q);
  }
  return quotes;
}

async function fetchOfficialSymbols(): Promise<{ data: TickerQuote[]; fetchedAt: number; sourceTime: string }> {
  const response = await fetch(`https://dps.psx.com.pk/symbols?ts=${Date.now()}`, {
    cache: 'no-store',
    headers: { Accept: 'application/json, text/plain, */*' },
  });
  if (!response.ok) throw new Error(`PSX Symbols HTTP ${response.status}`);
  const payload = await response.json();
  const raw = Array.isArray(payload) ? payload : payload?.data;
  if (!Array.isArray(raw) || raw.length < 500) throw new Error(`PSX Symbols returned only ${Array.isArray(raw) ? raw.length : 0} symbols`);
  const fetchedAt = Date.now();
  const data = raw.map((r: any): TickerQuote | null => {
    const symbol = String(r.symbol ?? r.SYMBOL ?? r.ticker ?? '').replace(/\.PSX$|\.KA$/i, '').trim().toUpperCase();
    if (!/^[A-Z0-9&._-]{1,20}$/.test(symbol)) return null;
    return {
      symbol: `${symbol}.PSX`,
      name: String(r.name ?? r.companyName ?? r.NAME ?? symbol).trim() || symbol,
      price: 0, change: 0, changePercent: 0, open: 0, high: 0, low: 0, previousClose: 0, volume: 0, avgVolume: 0,
      marketCap: 0, sector: String(r.sectorName ?? r.sector ?? r.SECTOR ?? 'PSX'), assetClass: 'Stock',
      exchange: 'PSX (Pakistan)', countryFlag: '🇵🇰', lastTickTime: fetchedAt, bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0,
      rsi: 50, macd: { macd: 0, signal: 0, histogram: 0 }, sma20: 0, sma50: 0, sma200: 0, aiScore: 0, aiSignal: 'Neutral',
      isVerified: true, source: 'PSX Official Symbols — universe', receivedAt: fetchedAt,
    };
  }).filter((x: TickerQuote | null): x is TickerQuote => Boolean(x));
  if (data.length < 500) throw new Error(`PSX symbol mapping incomplete: ${data.length}`);
  return { data, fetchedAt, sourceTime: new Date(fetchedAt).toISOString() };
}

async function fetchMarketWatchDirect(): Promise<{ data: TickerQuote[]; fetchedAt: number; sourceTime: string }> {
  const response = await fetch(`https://dps.psx.com.pk/market-watch?ts=${Date.now()}`, {
    cache: 'no-store',
    headers: { Accept: 'text/html,application/xhtml+xml' },
  });
  if (!response.ok) throw new Error(`PSX Market Watch HTTP ${response.status}`);
  const html = await response.text();
  const data = parseMarketWatchHtml(html);
  if (data.length < 20) throw new Error(`PSX Market Watch returned only ${data.length} mapped quotes`);
  const fetchedAt = Date.now();
  return {
    data,
    fetchedAt,
    sourceTime: new Date(fetchedAt).toISOString(),
  };
}

async function fetchJsonMarketFeed(url: string): Promise<{ data: TickerQuote[]; fetchedAt: number; sourceTime: string }> {
  const response = await fetch(`${url}${url.includes('?') ? '&' : '?'}ts=${Date.now()}`, { cache: 'no-store' });
  if (!response.ok) throw new Error(`PSX feed HTTP ${response.status}`);
  const payload = await response.json();
  const raw = Array.isArray(payload) ? payload : payload?.data;
  if (!Array.isArray(raw) || raw.length < 100) throw new Error('PSX feed has insufficient universe rows');

  const fetchedAt = Date.now();
  const data: TickerQuote[] = raw.map((q: any): TickerQuote => {
    const symbol = String(q.symbol ?? q.SYMBOL ?? q.ticker ?? '').replace(/\.PSX$|\.KA$/i, '').trim().toUpperCase();
    const current = numberValue(String(q.current ?? q.close ?? q.price ?? q.CURRENT ?? q.PRICE ?? 0));
    const ldcp = numberValue(String(q.ldcp ?? q.previousClose ?? q.LDCP ?? q.prev_close ?? 0));
    const change = numberValue(String(q.change ?? q.CHANGE ?? (current - ldcp)));
    const changePercent = numberValue(String(q.percentChange ?? q.changePercent ?? q.pchange ?? q.CHANGE_PCT ?? (ldcp > 0 ? (change / ldcp) * 100 : 0)));
    const fallbackPrice = current > 0 ? current : ldcp;
    return {
      symbol: `${symbol}.PSX`,
      name: String(q.name ?? q.company ?? q.companyName ?? q.NAME ?? symbol),
      price: fallbackPrice,
      change,
      changePercent,
      open: numberValue(String(q.open ?? q.OPEN ?? fallbackPrice)),
      high: numberValue(String(q.high ?? q.HIGH ?? fallbackPrice)),
      low: numberValue(String(q.low ?? q.LOW ?? fallbackPrice)),
      previousClose: ldcp,
      volume: numberValue(String(q.volume ?? q.VOLUME ?? 0)),
      avgVolume: numberValue(String(q.avgVolume ?? q.avg_volume ?? q.volume ?? 0)),
      marketCap: numberValue(String(q.marketCap ?? q.market_cap ?? 0)),
      sector: String(q.sector ?? q.SECTOR ?? 'PSX'),
      assetClass: 'Stock',
      exchange: 'PSX (Pakistan)', countryFlag: '🇵🇰',
      lastTickTime: fetchedAt,
      bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0, rsi: 50,
      macd: { macd: 0, signal: 0, histogram: 0 }, sma20: 0, sma50: 0, sma200: 0,
      aiScore: 0, aiSignal: 'Neutral', isVerified: true,
      source: 'PSX screener/universe snapshot', receivedAt: fetchedAt,
    };
  }).filter((q: TickerQuote) => /^[A-Z0-9&._-]{1,20}\.PSX$/.test(q.symbol) && q.price > 0);

  if (data.length < 100) throw new Error(`PSX feed has only ${data.length} valid mapped quotes`);
  return {
    data,
    fetchedAt,
    sourceTime: payload?.meta?.timestamp || payload?.fetchedAt || new Date(fetchedAt).toISOString(),
  };
}

function mergeQuotes(universe: TickerQuote[], live: TickerQuote[]) {
  const liveMap = new Map(live.map(q => [q.symbol, q]));
  return universe.map(base => {
    const q = liveMap.get(base.symbol);
    if (!q) return base;
    return {
      ...base,
      ...q,
      name: q.name && q.name !== q.symbol.replace('.PSX', '') ? q.name : base.name,
      sector: q.sector !== 'PSX' ? q.sector : base.sector,
      marketCap: q.marketCap || base.marketCap,
      avgVolume: q.avgVolume || base.avgVolume,
      source: 'PSX Market Watch + PSX screener — 5-minute delayed universe',
    };
  });
}

async function fetchFullUniverseSnapshot(): Promise<{ data: TickerQuote[]; fetchedAt: number; sourceTime: string }> {
  const [officialUniverseResult, liveResult, apiUniverseResult] = await Promise.allSettled([
    fetchOfficialSymbols(),
    fetchMarketWatchDirect(),
    fetchJsonMarketFeed('https://psxdata-api.fastapicloud.dev/screener'),
  ]);

  const universeResult = officialUniverseResult.status === 'fulfilled'
    ? officialUniverseResult
    : apiUniverseResult;

  const universe = universeResult.status === 'fulfilled' ? universeResult.value : null;
  const live = liveResult.status === 'fulfilled' ? liveResult.value : null;

  if (!universe && !live) throw new Error('PSX universe and delayed market feed both unavailable');
  if (!universe) {
    if (!live || live.data.length < 100) throw new Error('PSX delayed feed is incomplete');
    return live;
  }

  const merged = live ? mergeQuotes(universe.data, live.data) : universe.data;
  if (merged.length < 500) throw new Error(`PSX universe sync incomplete: ${merged.length} mapped symbols`);
  const fetchedAt = Date.now();
  return {
    data: merged,
    fetchedAt,
    sourceTime: live?.sourceTime || universe.sourceTime || new Date(fetchedAt).toISOString(),
  };
}

export async function fetchPSXDelayedQuotes(force = false): Promise<{ data: TickerQuote[]; fetchedAt: number; sourceTime: string }> {
  const cacheKey = '__NH_PSX_DELAYED_CACHE__';
  if (!force) {
    const cached = (globalThis as any)[cacheKey];
    if (cached && Date.now() - cached.fetchedAt < 60 * 1000 && cached.data.length > 20) return cached;
  }

  const sources: Array<() => Promise<{ data: TickerQuote[]; fetchedAt: number; sourceTime: string }>> = [
    () => fetchFullUniverseSnapshot(),
  ];

  const configured = (import.meta as any).env?.VITE_PSX_DATA_URL as string | undefined;
  if (configured) sources.push(() => fetchJsonMarketFeed(configured));

  let lastError: unknown = null;
  for (const source of sources) {
    try {
      const result = await source();
      (globalThis as any)[cacheKey] = result;
      return result;
    } catch (err) {
      lastError = err;
    }
  }

  throw lastError instanceof Error ? lastError : new Error('PSX delayed feed unavailable');
}
