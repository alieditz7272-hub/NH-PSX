<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/07fe067f-510d-4862-a3d9-68eeefaa9414

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## PSX Universe
This build uses the official PSX Eligible Scrips (Regular Deliverable Equity Market) as the universe source. GitHub Actions refreshes `public/data/market.json` and `public/data/psx-universe.json` from PSX before deployment, so the app is not limited to a hard-coded 56-symbol list. Securities without a current quote remain in the universe instead of being silently removed.


## V17 PSX Sync
- Complete Regular Deliverable Equity Market universe is synchronized from official PSX Eligible Scrips.
- `public/data/psx-symbol-map.json` provides authoritative symbol/name mapping.
- `market.json.sourceTime` is the official PSX market-summary update timestamp; `syncTime` is the GitHub sync time.
- PWA service-worker cache is versioned `v17`.


## V20 Fundamentals Reliability
The build ships a non-empty fundamentals seed from the bundled PSX company-profile repository. Live GitHub PSX sync overwrites matching symbols and never replaces the seed with an empty result.
