import json, re
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from html import unescape

BASE='https://dps.psx.com.pk'
HEADERS={'User-Agent':'Mozilla/5.0 (compatible; NH-PSX-Super-Analysis/1.0)','Accept':'text/html,application/xhtml+xml,application/json'}

def get(url):
    req=Request(url,headers=HEADERS)
    with urlopen(req,timeout=45) as r:
        return r.read().decode('utf-8','replace')

def clean_html(v):
    v=re.sub(r'<[^>]+>',' ',v or '')
    v=unescape(v).replace('\xa0',' ')
    return re.sub(r'\s+',' ',v).strip()

def num(v):
    try: return float(str(v).replace(',','').replace('%','').strip())
    except: return 0

def canonical_symbol(v):
    s=str(v or '').upper().strip()
    s=re.sub(r'\.(PSX|KA)$','',s,flags=re.I)
    return re.sub(r'[^A-Z0-9&._-]','',s)

def parse_eligible(html):
    """Official PSX Eligible Scrips -> complete regular equity universe."""
    rows=[]
    in_regular=False
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>', html, re.I|re.S):
        cells=re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>', tr, re.I|re.S)
        vals=[clean_html(x) for x in cells]
        if len(vals) < 2: continue
        sym=canonical_symbol(vals[0])
        name=vals[1].strip()
        if sym=='SYMBOL' and name=='NAME':
            in_regular=True
            continue
        if not in_regular: continue
        if not re.fullmatch(r'[A-Z0-9&._-]{1,24}',sym): continue
        if not name or sym in {'SYMBOL','NAME'}: continue
        rows.append({'symbol':sym,'name':name})
    return list({r['symbol']:r for r in rows}.values())

def parse_market(html):
    rows=[]
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>', html, re.I|re.S):
        fields={}
        for cell in re.findall(r'<t[dh][^>]*>.*?</t[dh]>', tr, re.I|re.S):
            name=re.search(r'data-name=["\']([^"\']+)',cell,re.I)
            if not name: continue
            order=re.search(r'data-order=["\']([^"\']+)',cell,re.I)
            text=clean_html(cell)
            fields[name.group(1).lower().replace(' ','')]=order.group(1) if order else text
        sym=canonical_symbol(fields.get('symbol',''))
        if not re.fullmatch(r'[A-Z0-9&._-]{1,24}',sym): continue
        ldcp=num(fields.get('ldcp')); op=num(fields.get('open')); hi=num(fields.get('high')); lo=num(fields.get('low'))
        cur=num(fields.get('close') or fields.get('current')); ch=num(fields.get('change')); pct=num(fields.get('percentchange') or fields.get('changepercent') or fields.get('percent_change')); vol=num(fields.get('volume'))
        rows.append({'symbol':sym,'name':sym,'price':cur,'change':ch,'changePercent':pct,'open':op or cur,'high':hi or cur,'low':lo or cur,'previousClose':ldcp,'volume':vol})
    return list({r['symbol']:r for r in rows}.values())

def parse_screener(html):
    """Parse official PSX screener fields used as a fundamentals fallback."""
    rows=[]
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>', html, re.I|re.S):
        fields={}
        for cell in re.findall(r'<t[dh][^>]*>.*?</t[dh]>', tr, re.I|re.S):
            name=re.search(r'data-name=["\']([^"\']+)',cell,re.I)
            if not name: continue
            order=re.search(r'data-order=["\']([^"\']+)',cell,re.I)
            fields[name.group(1).lower().replace(' ','')]=order.group(1) if order else clean_html(cell)
        sym=canonical_symbol(fields.get('symbol',''))
        if not re.fullmatch(r'[A-Z0-9&._-]{1,24}',sym): continue
        def n(key): return num(fields.get(key))
        rows.append({'symbol':sym,'marketCap':n('marketcap'),'peRatio':n('peratio'),'dividendYield':n('dividendyield'),'freeFloat':n('freefloat'),'volume30d':n('30dvolumeavg')})
    return list({r['symbol']:r for r in rows}.values())

now=datetime.now(timezone.utc).isoformat()
# PSX publishes an official market-summary timestamp. Use that as the displayed
# 'PSX Update Time' instead of confusing the GitHub sync time with exchange time.
psx_update_time=now
try:
    summary_html=get(BASE+'/market-summary/')
    m=re.search(r'\b(20\d{2}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\b', clean_html(summary_html))
    if m:
        psx_update_time=m.group(1).replace(' ','T')+'+05:00'
except Exception as exc:
    print('Market summary timestamp unavailable; using sync time:', exc)

eligible_html=get(BASE+'/eligible-scrips')
universe=parse_eligible(eligible_html)
if len(universe)<200:
    raise RuntimeError(f'PSX eligible-scrip parser returned only {len(universe)} symbols')

market_html=get(BASE+'/market-watch')
market=parse_market(market_html)
market_by={r['symbol']:r for r in market}

screener=[]
try:
    screener=parse_screener(get(BASE+'/screener'))
except Exception as exc:
    print('PSX screener fundamentals unavailable:', exc)
screener_by={r['symbol']:r for r in screener}

# Keep the COMPLETE PSX regular equity universe. Securities with no current quote
# remain in the universe with zero quote fields instead of silently disappearing.
rows=[]
for u in universe:
    q=market_by.get(u['symbol'],{})
    f=screener_by.get(u['symbol'],{})
    rows.append({
        'symbol':u['symbol'],'name':u['name'],'price':q.get('price',0),'change':q.get('change',0),
        'changePercent':q.get('changePercent',0),'open':q.get('open',0),'high':q.get('high',0),
        'low':q.get('low',0),'previousClose':q.get('previousClose',0),'volume':q.get('volume',0),
        'marketCap':f.get('marketCap',0),'peRatio':f.get('peRatio',0),'dividendYield':f.get('dividendYield',0),
        'freeFloat':f.get('freeFloat',0),'volume30d':f.get('volume30d',0)
    })

payload={
 'fetchedAt':now,'sourceTime':psx_update_time,'syncTime':now,
 'source':'PSX Data Portal — official Eligible Scrips + market-watch',
 'delay':'PSX delayed/public snapshot','universe':'Regular Deliverable Equity Market',
 'universeCount':len(rows),'quotedCount':sum(1 for r in rows if r['price']>0),'data':rows
}
with open('public/data/market.json','w',encoding='utf-8') as f: json.dump(payload,f,separators=(',',':'))
with open('public/data/psx-universe.json','w',encoding='utf-8') as f: json.dump({'fetchedAt':now,'sourceTime':psx_update_time,'source':'PSX Eligible Scrips — Regular Deliverable Equity Market','count':len(universe),'data':universe},f,separators=(',',':'))
# Explicit symbol map: the frontend can always resolve a PSX symbol to the exact
# eligible-scrip record even when today's quote is zero/missing.
symbol_map={canonical_symbol(u['symbol']): {'symbol':u['symbol'],'name':u['name']} for u in universe}
with open('public/data/psx-symbol-map.json','w',encoding='utf-8') as f: json.dump({'fetchedAt':now,'sourceTime':psx_update_time,'count':len(symbol_map),'data':symbol_map},f,separators=(',',':'))
print(f'Wrote COMPLETE PSX universe: {len(rows)} symbols; quoted today: {payload["quotedCount"]}; PSX update: {psx_update_time}')
