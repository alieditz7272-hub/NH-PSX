import { getPSXCompanyProfile } from '../data/psxCompanyProfiles';

export interface FundamentalSnapshot {
  symbol: string; companyName: string; currentEps: number|null; expectedEps: number|null; peRatio: number|null; sectorMedianPe: number|null;
  faceValue:number|null; currentBookValue:number|null; expectedBookValue:number|null; currentEnterpriseValue:number|null; expectedEnterpriseValue:number|null;
  latestCashDividend:number|null; expectedCashDividend:number|null; latestCashDividendExDate:string|null; currentYearProfitLoss:number|null; previousYearProfitLoss:number|null;
  source:string; fetchedAt:number;
}
const n=(v:any)=>{const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null};
let cache: Record<string, any>|null=null;
let marketCache: Record<string, any>|null=null;
export async function fetchFundamentalSnapshot(symbol:string):Promise<FundamentalSnapshot>{
  const clean=symbol.replace(/\.PSX$|\.KA$/i,'').toUpperCase();
  if(!cache){
    try {
      const r=await fetch(`./data/fundamentals.json?ts=${Date.now()}`,{cache:'no-store'});
      if(r.ok){ const p=await r.json(); cache=p?.data||{}; } else cache={};
    } catch { cache={}; }
  }
  const row=cache[clean];
  if(row) return {
    symbol:clean, companyName:row.companyName||clean, currentEps:n(row.currentEps), expectedEps:n(row.expectedEps),
    peRatio:n(row.peRatio), sectorMedianPe:n(row.sectorMedianPe), faceValue:n(row.faceValue), currentBookValue:n(row.currentBookValue), expectedBookValue:n(row.expectedBookValue),
    currentEnterpriseValue:n(row.currentEnterpriseValue), expectedEnterpriseValue:n(row.expectedEnterpriseValue), latestCashDividend:n(row.latestCashDividend),
    expectedCashDividend:n(row.expectedCashDividend), latestCashDividendExDate:row.latestCashDividendExDate||null, currentYearProfitLoss:n(row.currentYearProfitLoss),
    previousYearProfitLoss:n(row.previousYearProfitLoss), source:row.source||'PSX Data Portal', fetchedAt:n(row.fetchedAt)||Date.now()
  };

  // Safety fallback: the official PSX screener is included in market.json by the
  // sync job. This keeps fundamentals visible even when the detailed company-page
  // financial snapshot has not completed yet.
  if(!marketCache){
    try{
      const mr=await fetch(`./data/market.json?ts=${Date.now()}`,{cache:'no-store'});
      if(mr.ok){ const mp=await mr.json(); marketCache=Object.fromEntries((mp?.data||[]).map((x:any)=>[String(x.symbol||'').toUpperCase(),x])); }
    }catch{}
  }
  const m=marketCache?.[clean];
  if(m){
    const price=n(m.price), pe=n(m.peRatio);
    const derivedEps=(price!=null && pe!=null && pe>0)?price/pe:null;
    if(derivedEps!=null || pe!=null){
      return {
        symbol:clean, companyName:m.name||clean, currentEps:derivedEps, expectedEps:null,
        peRatio:pe, sectorMedianPe:null, faceValue:null, currentBookValue:null, expectedBookValue:null,
        currentEnterpriseValue:null, expectedEnterpriseValue:null, latestCashDividend:null, expectedCashDividend:null,
        latestCashDividendExDate:null, currentYearProfitLoss:null, previousYearProfitLoss:null,
        source:'PSX official screener fallback (EPS derived from Price ÷ P/E)', fetchedAt:Date.now()
      };
    }
  }

  // Build-safe repository fallback. The app already ships verified company
  // profiles for 100+ important PSX names. This prevents an empty fundamentals
  // JSON on the first deployment from turning the entire Fundamentals panel
  // into dashes while GitHub Actions performs the live PSX sync.
  const profile=getPSXCompanyProfile(clean);
  if(profile && (n(profile.currentEps)!=null || n(profile.peRatio)!=null || n(profile.bookValue)!=null)){
    const eps=n(profile.currentEps);
    const pe=n(profile.peRatio);
    const book=n(profile.bookValue);
    return {
      symbol:clean, companyName:profile.companyName||clean, currentEps:eps, expectedEps:null,
      peRatio:pe, sectorMedianPe:null, faceValue:null, currentBookValue:book, expectedBookValue:null,
      currentEnterpriseValue:null, expectedEnterpriseValue:null, latestCashDividend:null, expectedCashDividend:null,
      latestCashDividendExDate:null, currentYearProfitLoss:null, previousYearProfitLoss:null,
      source:'NH PSX Company Profiles (live PSX sync pending)', fetchedAt:Date.now()
    };
  }
  throw new Error(`${clean} fundamentals unavailable`);
}
