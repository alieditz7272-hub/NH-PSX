import React, { useState, useEffect, useRef } from 'react';
import { TimeFrame, TickerQuote, Candle } from './types';
import { DEFAULT_PSX_TICKER } from './data/marketData';
import { Header, AppModule } from './components/Header';
import { PuntersFavoriteSection } from './components/PuntersFavoriteSection';
import { InstitutionsFavoriteSection } from './components/InstitutionsFavoriteSection';
import { MobileOnlyEnforcer } from './components/MobileOnlyEnforcer';
import { TopBrandingBar } from './components/TopBrandingBar';
import { authFetch, subscriptionClient } from './services/subscriptionClient';
import { StartupLoginModal } from './components/StartupLoginModal';
import { CompactAdminSection } from './components/CompactAdminSection';
import { SectorRotationMatrixSection } from './components/SectorRotationMatrixSection';
import { isPsxIndex } from './utils/symbol';
import { usePaidAccess } from './components/subscription/PaidAccessGate';
import { safeStorage } from './utils/safeStorage';
import { fetchPSXDelayedQuotes } from './services/psxDelayedFeed';

export default function App() {
  const { isAdmin, refreshAuth } = usePaidAccess();
  // Strict Terminal Gate: Requires valid authenticated session or admin key to enter
  const [isTerminalUnlocked, setIsTerminalUnlocked] = useState<boolean>(() => {
    const hasAdminKey = safeStorage.getItem('nh_admin_secret_key_v1') || safeStorage.getItem('nh_saved_admin_key_forever');
    const hasToken = safeStorage.getItem('nh_trading_auth_token_v1');
    return Boolean(hasAdminKey || hasToken);
  });

  const handleLockTerminal = () => {
    safeStorage.removeItem('nh_admin_secret_key_v1');
    safeStorage.removeItem('nh_saved_admin_key_forever');
    safeStorage.removeItem('nh_trading_auth_token_v1');
    subscriptionClient.setAdminKey(null);
    subscriptionClient.setToken(null);
    setIsTerminalUnlocked(false);
    refreshAuth();
  };

  const EMPTY_TICKER: TickerQuote = { ...DEFAULT_PSX_TICKER, price: 0, change: 0, changePercent: 0, open: 0, high: 0, low: 0, previousClose: 0, volume: 0, avgVolume: 0, bid: 0, ask: 0, bidSize: 0, askSize: 0, vwap: 0, sma20: 0, sma50: 0, sma200: 0, lastTickTime: 0, source: 'Waiting for PSX Official 5-minute delayed data' };
  const [tickers, setTickers] = useState<TickerQuote[]>([]);
  const [selectedTicker, setSelectedTicker] = useState<TickerQuote>(EMPTY_TICKER);
  const [timeframe, setTimeframe] = useState<TimeFrame>('1D');
  const [candles, setCandles] = useState<Candle[]>([]);
  const [isLoadingChart, setIsLoadingChart] = useState<boolean>(false);
  const [isLiveFeed, setIsLiveFeed] = useState<boolean>(false);
  const [psxDataStatus, setPsxDataStatus] = useState<string>('PSX FEED');
  const [lastSourceTimestamp, setLastSourceTimestamp] = useState<string>('');
  const [activeModule, setActiveModule] = useState<AppModule>('TERMINAL');

  // Ref to always track the latest selected ticker to prevent async polling from reverting/mixing state
  const selectedTickerRef = useRef<TickerQuote>(selectedTicker);
  selectedTickerRef.current = selectedTicker;

  // Request counter to cancel stale candle responses
  const activeCandleRequestIdRef = useRef<number>(0);

  // Candle Cache per symbol + timeframe
  const candleCacheRef = useRef<Record<string, Candle[]>>({});

  const currentTicker = selectedTicker || tickers[0] || EMPTY_TICKER;

  // Handle ticker selection cleanly with strict state isolation & dismiss virtual keyboard
  const handleSelectTicker = (ticker: TickerQuote, preferredTimeframe?: TimeFrame) => {
    if (!ticker || !ticker.symbol) return;

    // Automatically blur any active input so mobile/virtual keyboard immediately closes
    if (typeof document !== 'undefined' && document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }

    const incomingSym = (ticker.symbol || '').toUpperCase().trim();
    const cleanSym = incomingSym.replace('.PSX', '').replace('.KA', '');

    // Reset candles and set loading immediately so previous stock's data is never displayed
    setCandles([]);
    setIsLoadingChart(true);
    setSelectedTicker(ticker);
    selectedTickerRef.current = ticker;

    if (preferredTimeframe) {
      setTimeframe(preferredTimeframe);
    }

    setTickers((prev) => {
      const exists = prev.some((t) => (t?.symbol || '').toUpperCase().replace('.PSX', '') === cleanSym);
      if (!exists) {
        return [ticker, ...prev];
      }
      return prev;
    });
  };

  // Fetch quotes periodically with protection against reverting active ticker
  const applyQuotes = (quotes: TickerQuote[], sourceTime?: string) => {
    setTickers(quotes);
    setPsxDataStatus('DELAYED');
    if (sourceTime) setLastSourceTimestamp(sourceTime);
    const activeSym = (selectedTickerRef.current?.symbol || '').toUpperCase().replace('.PSX', '').replace('.KA', '').trim();
    const currentQuote = quotes.find((t) =>
      (t?.symbol || '').toUpperCase().replace('.PSX', '').replace('.KA', '').trim() === activeSym
    );
    if (currentQuote && activeSym) {
      setSelectedTicker(currentQuote);
      selectedTickerRef.current = currentQuote;
    }
  };

  const fetchQuotes = async () => {
    try {
      const result = await fetchPSXDelayedQuotes(false);
      applyQuotes(result.data, result.sourceTime);
    } catch (err) {
      console.error('PSX delayed feed:', err);
    }
  };

  const [isHardRefreshing, setIsHardRefreshing] = useState<boolean>(false);

  // Manual official PSX 5-minute delayed feed refresh
  const handleTriggerAISync = async () => {
    try {
      const result = await fetchPSXDelayedQuotes(true);
      applyQuotes(result.data, result.sourceTime);
    } catch (err) {
      console.error('PSX delayed sync:', err);
      await fetchQuotes();
    }
  };

  // Complete Terminal refresh & official PSX 5-minute delayed feed re-sync
  const handleTerminalHardRefresh = async () => {
    if (isHardRefreshing) return;
    setIsHardRefreshing(true);

    try {
      // 1. Invalidate and purge local candle memory cache
      candleCacheRef.current = {};

      // 2. Clear any browser session cache
      try {
        if (typeof window !== 'undefined') {
          sessionStorage.clear();
        }
      } catch {}

      // 3. Trigger backend server AI anti-blocker synchronization
      await handleTriggerAISync();

      // 4. Re-fetch all market ticker quotes & breadth
      await fetchQuotes();

      // 5. Force fresh candle retrieval & full technical module re-computation
      await fetchCandles();
    } catch (err) {
      console.error('Terminal hard refresh error:', err);
      await fetchQuotes();
      await fetchCandles();
    } finally {
      setTimeout(() => {
        setIsHardRefreshing(false);
      }, 1200);
    }
  };

  useEffect(() => {
    fetchQuotes();
    const timer = window.setInterval(fetchQuotes, 5 * 60 * 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Fetch historical candles when ticker or timeframe changes with race condition cancellation
  const fetchCandles = async () => {
    const targetTicker = selectedTickerRef.current || currentTicker;
    const targetSymbol = (targetTicker.symbol || '').toUpperCase().trim();
    const cleanSym = targetSymbol.replace('.PSX', '').replace('.KA', '');
    const targetTimeframe = timeframe;
    const cacheKey = `${cleanSym}_${targetTimeframe}`;
    const requestId = ++activeCandleRequestIdRef.current;

    setIsLoadingChart(true);

    // If cache available for THIS exact symbol & timeframe:
    if (candleCacheRef.current[cacheKey] && candleCacheRef.current[cacheKey].length > 0) {
      setCandles(candleCacheRef.current[cacheKey]);
      setIsLoadingChart(false);
    } else {
      setCandles([]);
    }

    try {
      const end = new Date();
      const start = new Date(end);
      start.setFullYear(start.getFullYear() - 3);
      const api = `https://psxdata-api.fastapicloud.dev/stocks/${encodeURIComponent(cleanSym)}/historical?start=${start.toISOString().slice(0,10)}&end=${end.toISOString().slice(0,10)}`;
      const res = await fetch(api, { cache: 'no-store' });
      const envelope = await res.json();
      const rows = Array.isArray(envelope?.data) ? envelope.data : [];
      const daily = rows.map((r: any) => ({
        time: Math.floor(new Date(r.date).getTime() / 1000),
        timeLabel: String(r.date),
        open: Number(r.open || 0), high: Number(r.high || 0), low: Number(r.low || 0), close: Number(r.close || 0), volume: Number(r.volume || 0), isVerified: true,
      })).filter((c: Candle) => c.close > 0).sort((a: Candle, b: Candle) => a.time - b.time);
      let candlesForView = daily.slice(-400);
      if (targetTimeframe !== '1D') {
        const buckets = new Map<string, Candle>();
        for (const c of daily) {
          const d = new Date(c.time * 1000);
          const key = targetTimeframe === '1W'
            ? `${d.getUTCFullYear()}-W${String(Math.ceil((((d.getTime() - Date.UTC(d.getUTCFullYear(),0,1)) / 86400000) + new Date(Date.UTC(d.getUTCFullYear(),0,1)).getUTCDay() + 1) / 7)).padStart(2,'0')}`
            : `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}`;
          const prev = buckets.get(key);
          if (!prev) buckets.set(key, {...c});
          else { prev.high = Math.max(prev.high, c.high); prev.low = Math.min(prev.low, c.low); prev.close = c.close; prev.volume += c.volume; prev.time = c.time; prev.timeLabel = c.timeLabel; }
        }
        candlesForView = Array.from(buckets.values()).sort((a,b)=>a.time-b.time).slice(-400);
      }
      const currentActiveSym = (selectedTickerRef.current?.symbol || '').toUpperCase().replace('.PSX', '').replace('.KA', '').trim();
      if (requestId === activeCandleRequestIdRef.current && currentActiveSym === cleanSym) {
        candleCacheRef.current[cacheKey] = candlesForView;
        setCandles(candlesForView);
      }
    } catch (err) {
      if (requestId === activeCandleRequestIdRef.current) {
        setCandles([]);
      }
    } finally {
      if (requestId === activeCandleRequestIdRef.current) {
        setIsLoadingChart(false);
      }
    }
  };

  useEffect(() => {
    fetchCandles();
  }, [currentTicker.symbol, timeframe]);

  // Always reset scroll to the very top when application first opens
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
    const t = setTimeout(() => {
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
    }, 100);
    return () => clearTimeout(t);
  }, []);

  // Inter-Module Link Handlers
  const handleSelectStockForAnalysis = (ticker: TickerQuote, preferredTimeframe?: TimeFrame) => {
    handleSelectTicker(ticker, preferredTimeframe);
    setActiveModule('TERMINAL');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <MobileOnlyEnforcer>
      <div className="w-full min-h-screen bg-[#05070A] bg-radial-immersive text-[#E0E0E0] font-sans selection:bg-[#00FFA3] selection:text-slate-950 flex flex-col justify-between">
        <div className="w-full flex flex-col">
          {/* Locked Top Section Up To WhatsApp Number */}
          <TopBrandingBar 
            isUnlocked={isTerminalUnlocked}
            onLockTerminal={handleLockTerminal}
          />

          {isTerminalUnlocked ? (
            <>
              {/* Terminal Main Header */}
              <Header
                tickers={tickers}
                selectedTicker={currentTicker}
                setSelectedTicker={handleSelectTicker}
                isLiveFeed={isLiveFeed}
                setIsLiveFeed={setIsLiveFeed}
                psxDataStatus={psxDataStatus}
                lastSourceTimestamp={lastSourceTimestamp}
                activeModule={activeModule}
                setActiveModule={setActiveModule}
                onTriggerAISync={handleTriggerAISync}
                onTriggerHardRefresh={handleTerminalHardRefresh}
                isHardRefreshing={isHardRefreshing}
                candles={candles}
                timeframe={timeframe}
                setTimeframe={setTimeframe}
                isLoadingChart={isLoadingChart}
                onRefreshChart={fetchCandles}
              />

              {/* Main Continuous Stack Container */}
              <main className="w-full px-0 sm:px-3 md:px-6 lg:px-8 pb-16 space-y-6 md:space-y-10">
                {/* ADMIN MANAGEMENT SECTION (COMPACT & PROFESSIONAL) */}
                <CompactAdminSection />

                {/* 3. PUNTER'S FAVORITE 10 STOCKS (POST-CLOSE MARKET RUMOR RADAR) */}
            <PuntersFavoriteSection
              allTickers={tickers}
              onSelectStock={(sym) => {
                const clean = sym.toUpperCase().replace('.PSX', '').trim();
                const found = tickers.find(t => (t.symbol || '').toUpperCase().replace('.PSX', '').trim() === clean);
                if (found) {
                  handleSelectStockForAnalysis(found, '1D');
                }
              }}
            />

            {/* 4. INSTITUTION'S FAVORITE 10 STOCKS (NCCPL & MUFAP ACCUMULATION INFLOWS) */}
            <InstitutionsFavoriteSection
              allTickers={tickers}
              onSelectStock={(sym) => {
                const clean = sym.toUpperCase().replace('.PSX', '').trim();
                const found = tickers.find(t => (t.symbol || '').toUpperCase().replace('.PSX', '').trim() === clean);
                if (found) {
                  handleSelectStockForAnalysis(found, '1D');
                }
              }}
            />

            {/* 17. SECTOR CAPITAL ROTATION & MARKET REGIME MATRIX (RELATIVE ROTATION GRAPH) */}
            <SectorRotationMatrixSection
              allTickers={tickers}
              selectedSymbol={currentTicker.symbol}
              onSelectStock={(sym) => {
                const clean = sym.toUpperCase().replace('.PSX', '').trim();
                const found = tickers.find(t => (t.symbol || '').toUpperCase().replace('.PSX', '').trim() === clean);
                if (found) {
                  handleSelectStockForAnalysis(found, '1D');
                }
              }}
            />
          </main>
          </>
          ) : (
            <div className="w-full py-24 px-4 flex flex-col items-center justify-center text-center font-mono">
              <div className="p-6 rounded-2xl bg-[#090F1E] border border-emerald-500/30 max-w-sm w-full space-y-3 shadow-2xl">
                <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping mx-auto block" />
                <h3 className="text-white font-black text-sm uppercase tracking-wider">
                  Terminal Locked
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Security verification required. Please login with your authorized Username and Password to access live market data and calculations.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Strict Startup Login Modal (Blocks Terminal Access until Valid Login) */}
        <StartupLoginModal 
          isOpen={!isTerminalUnlocked} 
          onSuccess={() => setIsTerminalUnlocked(true)} 
        />

        {/* Professional Copyright Footer */}
        <footer className="w-full border-t border-white/10 bg-[#080d14]/90 backdrop-blur-md py-4 px-4 text-center mt-auto space-y-1">
          <p className="text-xs sm:text-sm font-mono font-bold uppercase tracking-[0.15em] text-[#00FFA3] select-none">
            © 2026 NH Stock Trading Pro Terminal 🇵🇰 | All Rights Reserved
          </p>
          <p className="text-[11px] font-mono text-slate-400">
            Engineered by <strong className="text-white">Nadeem Hassan</strong> • Strictly Secured Mobile Terminal
          </p>
        </footer>
      </div>
    </MobileOnlyEnforcer>
  );
}
