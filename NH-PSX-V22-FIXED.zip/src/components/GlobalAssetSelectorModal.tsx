import React, { useState } from 'react';
import { Search, Globe, Plus, TrendingUp, TrendingDown, X, Sparkles, Filter, Layers, ArrowUpRight, ArrowDownRight, Activity } from 'lucide-react';
import { TickerQuote } from '../types';
import { createCustomTicker } from '../data/marketData';
import { formatPrice } from '../utils/currency';
import { formatDisplaySymbol, formatDisplayName, isPsxIndex } from '../utils/symbol';
import { calculateDailyPriceChange } from '../utils/dailyPriceChange';
import { getStockHistoricalRange } from '../utils/stockHistoricalRange';
import { StockLogo } from './StockLogo';

interface GlobalAssetSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  tickers: TickerQuote[];
  selectedTicker: TickerQuote;
  onSelectTicker: (ticker: TickerQuote) => void;
}

export const GlobalAssetSelectorModal: React.FC<GlobalAssetSelectorModalProps> = ({
  isOpen,
  onClose,
  tickers,
  selectedTicker,
  onSelectTicker,
}) => {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('ALL');

  if (!isOpen) return null;

  const categories = [
    { id: 'ALL', label: 'All PSX Stocks & Indices', icon: '🇵🇰' },
    { id: 'INDEX', label: 'PSX Indices (KSE-100 / KSE-30)', icon: '📊' },
    { id: 'TECH', label: 'IT & Telecom (SYS / AIRLINK / TRG)', icon: '💻' },
    { id: 'OIL', label: 'Oil & Gas (OGDC / MARI / PPL / PSO)', icon: '🛢️' },
    { id: 'BANK', label: 'Banking & Finance (MEBL / MCB / UBL)', icon: '🏦' },
    { id: 'CEMENT', label: 'Cement & Steel (LUCK / FCCL / MLCF)', icon: '🏗️' },
    { id: 'FERTILIZER', label: 'Fertilizers (ENGRO / FFC / EFERT)', icon: '🌾' },
    { id: 'POWER', label: 'Power & EV (HUBC / SAZEW / KEL)', icon: '⚡' },
  ];

  const popularPrioritySymbols = [
    'KSE100.PSX', 'KSE30.PSX', 'SYS.PSX', 'OGDC.PSX', 'LUCK.PSX', 'MARI.PSX', 
    'ENGRO.PSX', 'PPL.PSX', 'HUBC.PSX', 'PSO.PSX', 'MEBL.PSX', 'UBL.PSX', 
    'MCB.PSX', 'FFC.PSX', 'EFERT.PSX', 'AIRLINK.PSX', 'TRG.PSX', 'PAEL.PSX', 
    'SAZEW.PSX', 'FCCL.PSX', 'MLCF.PSX', 'DGKC.PSX', 'SEARL.PSX', 'AHCL.PSX', 
    'AKBL.PSX', 'POWER.PSX', 'PSX.PSX', 'ASL.PSX', 'FATIMA.PSX', 'KEL.PSX'
  ];

  const filtered = tickers.filter((t) => {
    const q = query.toLowerCase().trim();
    const matchesSearch =
      t.symbol.toLowerCase().includes(q) ||
      t.name.toLowerCase().includes(q) ||
      t.sector.toLowerCase().includes(q) ||
      (t.exchange && t.exchange.toLowerCase().includes(q));

    if (!matchesSearch) return false;
    if (activeCategory === 'ALL') return true;
    if (activeCategory === 'INDEX') return t.assetClass === 'Index' || t.symbol.includes('KSE');
    if (activeCategory === 'TECH') return t.sector.toLowerCase().includes('it') || t.sector.toLowerCase().includes('telecom') || t.sector.toLowerCase().includes('tech') || t.sector.toLowerCase().includes('software');
    if (activeCategory === 'OIL') return t.sector.toLowerCase().includes('oil') || t.sector.toLowerCase().includes('gas');
    if (activeCategory === 'BANK') return t.sector.toLowerCase().includes('bank') || t.sector.toLowerCase().includes('finance');
    if (activeCategory === 'CEMENT') return t.sector.toLowerCase().includes('cement') || t.sector.toLowerCase().includes('steel') || t.sector.toLowerCase().includes('materials');
    if (activeCategory === 'FERTILIZER') return t.sector.toLowerCase().includes('fertilizer') || t.sector.toLowerCase().includes('chemical');
    if (activeCategory === 'POWER') return t.sector.toLowerCase().includes('power') || t.sector.toLowerCase().includes('auto') || t.sector.toLowerCase().includes('utility');
    return true;
  });

  // Sort filtered list so popular / requested items appear at top
  const sorted = [...filtered].sort((a, b) => {
    const indexA = popularPrioritySymbols.indexOf(a.symbol);
    const indexB = popularPrioritySymbols.indexOf(b.symbol);

    if (indexA !== -1 && indexB !== -1) return indexA - indexB;
    if (indexA !== -1) return -1;
    if (indexB !== -1) return 1;
    return 0;
  });

  const exactMatchExists = tickers.some(
    (t) => t.symbol.toLowerCase() === query.trim().toLowerCase()
  );

  const dismissKeyboard = () => {
    if (typeof document !== 'undefined' && document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
  };

  const handleSelect = (ticker: TickerQuote) => {
    dismissKeyboard();
    onSelectTicker(ticker);
    onClose();
    setQuery('');
  };

  const handleCustomSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;
    dismissKeyboard();
    const custom = createCustomTicker(query.trim());
    onSelectTicker(custom);
    onClose();
    setQuery('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn font-mono">
      <div 
        className="bg-slate-950 border border-white/10 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#00FFA3]/10 border border-[#00FFA3]/30 text-[#00FFA3]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Pakistan Stock Exchange (PSX) Asset Selector
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#00FFA3]/20 text-[#00FFA3] border border-[#00FFA3]/30 uppercase font-mono">
                  PSX DELAYED
                </span>
              </h2>
              <p className="text-xs text-white/50">
                Select or analyze ANY Pakistan Stock Exchange (PSX) listed stock or benchmark index
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/50 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Input Box */}
        <div className="p-4 border-b border-white/10 bg-slate-900/60">
          <div className="mb-2 flex items-center gap-1.5 text-[11px] sm:text-xs font-mono font-semibold text-[#00FFA3] bg-[#00FFA3]/10 border border-[#00FFA3]/25 px-2.5 py-1 rounded-md">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00FFA3]" />
            <span>When You Select any Stock , Just give it Some Seconds to Update the Values</span>
          </div>

          <form onSubmit={handleCustomSubmit} className="relative flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-3 w-4 h-4 text-[#00FFA3]" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  if (activeCategory !== 'ALL' && e.target.value.trim().length > 0) {
                    setActiveCategory('ALL');
                  }
                }}
                placeholder="Search PSX Symbol or Company (e.g. AKBL, POWER, SYS, OGDC, LUCK, MARI, KSE100, MEBL, FFC)..."
                className="w-full bg-black/80 border-2 border-[#00FFA3] focus:border-[#00FFA3] rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none ring-1 ring-[#00FFA3]/50 focus:ring-2 focus:ring-[#00FFA3] shadow-[0_0_12px_rgba(0,255,163,0.2)] transition font-mono"
              />
            </div>

            {query.trim().length > 0 && (
              <button
                type="submit"
                className="px-4 py-2.5 bg-[#00FFA3] hover:bg-[#00FFA3]/90 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition whitespace-nowrap shadow-[0_0_15px_rgba(0,255,163,0.3)]"
              >
                <Plus className="w-4 h-4" />
                <span>Select & Analyze</span>
              </button>
            )}
          </form>

          {/* Quick Presets / Examples */}
          <div className="mt-2.5 flex items-center gap-1.5 flex-wrap text-[11px] text-white/50">
            <span className="text-white/40 font-semibold">Popular PSX Equities:</span>
            {[
              'AKBL',
              'POWER',
              'SYS',
              'OGDC',
              'LUCK',
              'MARI',
              'ENGRO',
              'MEBL',
              'FFC',
              'KSE100',
            ].map((symbol) => (
              <button
                key={symbol}
                type="button"
                onClick={() => {
                  setQuery(symbol);
                  setActiveCategory('ALL');
                }}
                className="px-2 py-0.5 bg-white/5 hover:bg-white/10 text-white/80 hover:text-[#00FFA3] border border-white/10 rounded transition text-[10px] font-bold"
              >
                {symbol}
              </button>
            ))}
          </div>

          {/* Currently Selected Stock Closing Details & 52W / Ever Range Box */}
          {selectedTicker && (() => {
            const range = getStockHistoricalRange(selectedTicker);
            const isIndex = isPsxIndex(selectedTicker);
            const formatVal = (val?: number | null) => {
              if (val === undefined || val === null || isNaN(val)) return 'N/A';
              if (isIndex) return Math.round(Number(val)).toString();
              return Number(val).toFixed(2).replace(/,/g, '');
            };

            return (
              <div className="mt-3 p-2.5 sm:p-3 bg-black/60 border border-white/15 rounded-xl flex flex-col gap-2">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <StockLogo symbol={selectedTicker.symbol} name={selectedTicker.name} logoUrl={(selectedTicker as any).logoUrl} size="sm" />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-white">{formatDisplaySymbol(selectedTicker.symbol)}</span>
                        <span className="text-[10px] text-white/70 font-semibold">{formatDisplayName(selectedTicker)}</span>
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-white/10 text-[#00FFA3] font-bold uppercase">{selectedTicker.assetClass}</span>
                      </div>
                      <div className="text-xs font-bold text-white mt-0.5">
                        Current Price: {formatPrice(selectedTicker.price, selectedTicker)}
                      </div>
                    </div>
                  </div>
                  <div className="text-[10px] text-white/50 uppercase tracking-wider font-bold">
                    Historical Range & Record Dates
                  </div>
                </div>

                {/* 4 Stats Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  <div className="px-2.5 py-2 rounded-lg bg-emerald-950/40 border border-emerald-500/30 flex flex-col justify-between min-h-[76px]">
                    <div className="text-[9px] text-emerald-400 font-bold uppercase flex items-center gap-0.5">
                      <ArrowUpRight className="w-3 h-3 shrink-0" />
                      52-Week High
                    </div>
                    <div className="text-[11px] sm:text-xs font-black text-white mt-0.5">
                      {formatVal(range.week52High)}
                    </div>
                    <div className="text-[9.5px] text-emerald-300 font-mono mt-0.5 font-semibold leading-tight whitespace-normal break-words" title={range.week52HighDate}>
                      {range.week52HighDate}
                    </div>
                  </div>

                  <div className="px-2.5 py-2 rounded-lg bg-red-950/40 border border-red-500/30 flex flex-col justify-between min-h-[76px]">
                    <div className="text-[9px] text-red-400 font-bold uppercase flex items-center gap-0.5">
                      <ArrowDownRight className="w-3 h-3 shrink-0" />
                      52-Week Low
                    </div>
                    <div className="text-[11px] sm:text-xs font-black text-white mt-0.5">
                      {formatVal(range.week52Low)}
                    </div>
                    <div className="text-[9.5px] text-red-300 font-mono mt-0.5 font-semibold leading-tight whitespace-normal break-words" title={range.week52LowDate}>
                      {range.week52LowDate}
                    </div>
                  </div>

                  <div className="px-2.5 py-2 rounded-lg bg-cyan-950/40 border border-cyan-500/30 flex flex-col justify-between min-h-[76px]">
                    <div className="text-[9px] text-cyan-400 font-bold uppercase flex items-center gap-0.5">
                      <TrendingUp className="w-3 h-3 shrink-0" />
                      Ever High
                    </div>
                    <div className="text-[11px] sm:text-xs font-black text-white mt-0.5">
                      {formatVal(range.everHigh)}
                    </div>
                    <div className="text-[9.5px] text-cyan-300 font-mono mt-0.5 font-semibold leading-tight whitespace-normal break-words" title={range.everHighDate}>
                      {range.everHighDate}
                    </div>
                  </div>

                  <div className="px-2.5 py-2 rounded-lg bg-amber-950/40 border border-amber-500/30 flex flex-col justify-between min-h-[76px]">
                    <div className="text-[9px] text-amber-400 font-bold uppercase flex items-center gap-0.5">
                      <Activity className="w-3 h-3 shrink-0" />
                      Ever Low
                    </div>
                    <div className="text-[11px] sm:text-xs font-black text-white mt-0.5">
                      {formatVal(range.everLow)}
                    </div>
                    <div className="text-[9.5px] text-amber-300 font-mono mt-0.5 font-semibold leading-tight whitespace-normal break-words" title={range.everLowDate}>
                      {range.everLowDate}
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>

        {/* Category Tabs */}
        <div className="px-4 py-2 bg-black/40 border-b border-white/5 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 border ${
                activeCategory === cat.id
                  ? 'bg-[#00FFA3]/15 text-[#00FFA3] border-[#00FFA3]/40 shadow-sm'
                  : 'bg-white/5 text-white/60 hover:text-white border-transparent hover:bg-white/10'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Asset List Content */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          {/* Custom Symbol Button if user typed something not in list */}
          {query.trim().length > 0 && !exactMatchExists && (
            <button
              onClick={() => handleCustomSubmit()}
              className="w-full p-3.5 bg-[#00FFA3]/10 hover:bg-[#00FFA3]/20 border border-[#00FFA3]/40 rounded-xl flex items-center justify-between text-left transition group shadow-md"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#00FFA3]/20 border border-[#00FFA3]/40 flex items-center justify-center text-[#00FFA3]">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-2">
                    Analyze Custom Global Symbol: <span className="text-[#00FFA3] text-sm uppercase underline">{query.trim()}</span>
                  </div>
                  <div className="text-[11px] text-white/50">
                    Inspect PSX delayed quote status, Supertrend, and quantitative research for this instrument
                  </div>
                </div>
              </div>
              <span className="px-3 py-1 bg-[#00FFA3] text-slate-950 text-xs font-extrabold uppercase rounded-lg shadow-sm">
                Add & Analyze
              </span>
            </button>
          )}

          {sorted.length === 0 && exactMatchExists && (
            <div className="py-12 text-center text-white/40 text-xs">
              No assets matching this filter category.
            </div>
          )}

          {/* Grid of Tickers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {sorted.map((ticker) => {
              const isSelected = selectedTicker?.symbol ? selectedTicker.symbol === ticker.symbol : false;
              const info = calculateDailyPriceChange(ticker);

              return (
                <button
                  key={ticker.symbol}
                  onClick={() => handleSelect(ticker)}
                  className={`p-3 rounded-xl border text-left transition flex items-center justify-between group ${
                    isSelected
                      ? 'bg-[#10b981]/10 border-[#10b981]/60 shadow-[0_0_15px_rgba(16,185,129,0.15)] ring-1 ring-[#10b981]/40'
                      : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <StockLogo symbol={ticker.symbol} name={ticker.name} logoUrl={(ticker as any).logoUrl} size="sm" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-extrabold text-xs text-[#00FFA3] group-hover:underline transition truncate">
                          {formatDisplaySymbol(ticker.symbol)}
                        </span>
                        <span className="text-[9px] px-1.5 py-0.2 bg-white/10 text-white/60 rounded uppercase font-bold flex-shrink-0">
                          {ticker.assetClass}
                        </span>
                      </div>
                      <div className="text-[11px] text-white/80 font-bold truncate max-w-[170px]">
                        {formatDisplayName(ticker)}
                      </div>
                    </div>
                  </div>

                  <div className="text-right flex-shrink-0 ml-2">
                    <div className="text-xs font-bold text-white">
                      {info.formattedCurrentPrice}
                    </div>
                    {info.isAvailable ? (
                      <div className={`text-[10px] font-bold flex items-center justify-end gap-1 ${info.colorClass}`}>
                        <span>{info.formattedChangeText}</span>
                        <span>({info.formattedChangePctText})</span>
                      </div>
                    ) : (
                      <div className="text-[10px] font-bold text-amber-400/80">CHANGE: N/A</div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-white/10 bg-black/40 flex items-center justify-between text-[11px] text-white/40">
          <span className="flex items-center gap-1">
            <Globe className="w-3.5 h-3.5 text-[#00FFA3]" />
            Supporting Stocks, Forex, Commodities, Cryptos & Indices from 50+ Global Exchanges
          </span>
          <span>Press ESC or click Outside to Close</span>
        </div>
      </div>
    </div>
  );
};
