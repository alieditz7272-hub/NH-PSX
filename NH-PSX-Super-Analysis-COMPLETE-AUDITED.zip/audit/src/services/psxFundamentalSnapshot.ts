export interface FundamentalSnapshot {
  symbol: string; companyName: string; currentEps: number|null; expectedEps: number|null; peRatio: number|null; sectorMedianPe: number|null;
  faceValue:number|null; currentBookValue:number|null; expectedBookValue:number|null; currentEnterpriseValue:number|null; expectedEnterpriseValue:number|null;
  latestCashDividend:number|null; expectedCashDividend:number|null; latestCashDividendExDate:string|null; currentYearProfitLoss:number|null; previousYearProfitLoss:number|null;
  source:string; fetchedAt:number;
}
const n=(v:any)=>{const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null};
let cache: Record<string, any>|null=null;
export async function fetchFundamentalSnapshot(symbol:string):Promise<FundamentalSnapshot>{
  const clean=symbol.replace(/\.PSX$|\.KA$/i,'').toUpperCase();
  if(!cache){
    const r=await fetch(`./data/fundamentals.json?ts=${Date.now()}`,{cache:'no-store'});
    if(!r.ok) throw new Error('PSX fundamentals unavailable');
    const p=await r.json(); cache=p?.data||{};
  }
  const row=cache[clean];
  if(!row) throw new Error(`${clean} fundamentals unavailable`);
  return {
    symbol:clean, companyName:row.companyName||clean, currentEps:n(row.currentEps), expectedEps:n(row.expectedEps),
    peRatio:n(row.peRatio), sectorMedianPe:n(row.sectorMedianPe), faceValue:n(row.faceValue), currentBookValue:n(row.currentBookValue), expectedBookValue:n(row.expectedBookValue),
    currentEnterpriseValue:n(row.currentEnterpriseValue), expectedEnterpriseValue:n(row.expectedEnterpriseValue), latestCashDividend:n(row.latestCashDividend),
    expectedCashDividend:n(row.expectedCashDividend), latestCashDividendExDate:row.latestCashDividendExDate||null, currentYearProfitLoss:n(row.currentYearProfitLoss),
    previousYearProfitLoss:n(row.previousYearProfitLoss), source:row.source||'PSX Data Portal', fetchedAt:n(row.fetchedAt)||Date.now()
  };
}
