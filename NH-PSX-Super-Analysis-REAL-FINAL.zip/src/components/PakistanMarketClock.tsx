import React, { useState, useEffect } from 'react';
import { Clock, ShieldAlert, Wifi, Sparkles, RefreshCw, Zap, RotateCcw, CheckCircle2 } from 'lucide-react';
import { getPakistanTimeInfo, getPSXMarketStatus, PakistanTimeInfo, PSXMarketStatus } from '../utils/psxMarketCalendar';

interface PakistanMarketClockProps {
  psxDataStatus?: string;
  lastSourceTimestamp?: string;
  compact?: boolean;
  onTriggerAISync?: () => Promise<void>;
  onTriggerHardRefresh?: () => Promise<void>;
  isHardRefreshing?: boolean;
}

export const PakistanMarketClock: React.FC<PakistanMarketClockProps> = ({
  psxDataStatus,
  lastSourceTimestamp,
  compact = false,
  onTriggerAISync,
  onTriggerHardRefresh,
  isHardRefreshing = false,
}) => {
  const [timeInfo, setTimeInfo] = useState<PakistanTimeInfo>(getPakistanTimeInfo());
  const [marketStatus, setMarketStatus] = useState<PSXMarketStatus>(getPSXMarketStatus());
  const [isAiSyncing, setIsAiSyncing] = useState<boolean>(false);
  const [localHardRefreshing, setLocalHardRefreshing] = useState<boolean>(false);
  const [showSuccessToast, setShowSuccessToast] = useState<boolean>(false);

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setTimeInfo(getPakistanTimeInfo(now));
      setMarketStatus(getPSXMarketStatus(now));
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleAISync = async () => {
    if (isAiSyncing) return;
    setIsAiSyncing(true);
    try {
      if (onTriggerAISync) {
        await onTriggerAISync();
      } else {
        window.dispatchEvent(new Event('nh-psx-data-refresh'));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setTimeout(() => setIsAiSyncing(false), 1200);
    }
  };

  const handleHardRefresh = async () => {
    if (localHardRefreshing || isHardRefreshing) return;
    setLocalHardRefreshing(true);
    setShowSuccessToast(false);
    try {
      if (onTriggerHardRefresh) {
        await onTriggerHardRefresh();
      } else {
        await fetch('./data/market.json?refresh=' + Date.now(), { cache: 'no-store' });
      }
      setShowSuccessToast(true);
      setTimeout(() => setShowSuccessToast(false), 4000);
    } catch (e) {
      console.error(e);
    } finally {
      setTimeout(() => setLocalHardRefreshing(false), 1200);
    }
  };

  const activeRefreshing = isHardRefreshing || localHardRefreshing;

  return (
    <div className="w-full flex flex-col gap-2 font-mono text-xs">
      <div className="w-full grid grid-cols-1 xs:grid-cols-2 sm:flex sm:flex-wrap items-stretch sm:items-center gap-2">
        {/* 1. Pakistan Time & Date Widget */}
        <div className="flex items-center gap-2.5 px-3 py-2 bg-slate-950/80 border border-white/10 rounded-xl shadow-inner min-h-[46px]">
          <div className="p-1.5 bg-[#00FFA3]/10 border border-[#00FFA3]/30 rounded-lg text-[#00FFA3] shrink-0">
            <Clock className="w-3.5 h-3.5" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] text-white/50 uppercase font-bold tracking-wider">
                PAKISTAN TIME
              </span>
              <span className="text-[9px] text-[#00FFA3] font-extrabold bg-[#00FFA3]/10 px-1 py-0.2 rounded border border-[#00FFA3]/30">
                PKT
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-white font-extrabold text-xs sm:text-sm tracking-tight text-shadow-sm">
                {timeInfo.timeString}
              </span>
              <span className="text-[10px] text-white/60 font-medium">
                {timeInfo.dateString}
              </span>
            </div>
          </div>
        </div>

        {/* 2. PSX Market Status Box (Simple OPEN or CLOSED with Blinking Animation) */}
        <div className={`flex items-center justify-between xs:justify-center px-3 py-2 rounded-xl border shadow-sm transition-all duration-300 animate-pulse min-h-[46px] ${marketStatus.badgeColorClass}`}>
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5 items-center justify-center shrink-0">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-80 ${marketStatus.dotColorClass}`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${marketStatus.dotColorClass}`}></span>
            </span>
            <span className="font-extrabold text-xs tracking-tight uppercase">
              MARKET {marketStatus.state === 'OPEN' ? 'OPEN' : 'CLOSED'}
            </span>
          </div>
        </div>

        {/* 3. Last PSX Data Update Time */}
        <div className="flex flex-col justify-center px-3 py-2 bg-slate-950/80 border border-white/10 rounded-xl shadow-sm min-h-[46px]">
          <div className="text-[9px] text-white/50 uppercase font-bold tracking-wider">
            LATEST PSX UPDATE
          </div>
          <div className="text-xs font-bold text-amber-300 mt-0.5 font-mono truncate">
            {lastSourceTimestamp && lastSourceTimestamp !== 'N/A' && !lastSourceTimestamp.includes('unavailable')
              ? lastSourceTimestamp
              : 'Waiting for official PSX snapshot...'}
          </div>
        </div>
      </div>
    </div>
  );
};
