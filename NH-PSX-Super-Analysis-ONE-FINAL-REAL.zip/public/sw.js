// NH Stock Trading Pro Terminal - High Performance PWA Service Worker
const CACHE_NAME = 'nh-psx-super-analysis-v9';
const BASE = self.registration.scope;
const STATIC_ASSETS = [
  BASE,
  new URL('index.html', BASE).href,
  new URL('manifest.json', BASE).href,
  new URL('pwa-192x192.png', BASE).href,
  new URL('pwa-512x512.png', BASE).href,
  new URL('pwa-maskable-512x512.png', BASE).href,
  new URL('apple-touch-icon.png', BASE).href
];

// Install: precache static shell assets
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn('[SW] Precache asset error (non-fatal):', err);
      });
    })
  );
});

// Activate: clean up old caches and claim clients immediately
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch: Strategy for PSX EOD analysis app
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // 1. NEVER cache API endpoints or non-GET requests; EOD data must always come from the server
  if (
    event.request.method !== 'GET' ||
    url.pathname.startsWith('/api/') ||
    url.pathname.startsWith('/socket.io') ||
    url.pathname.includes('/sse') ||
    url.pathname === '/sw.js' ||
    url.pathname.endsWith('/data/market.json') ||
    url.pathname.endsWith('/data/fundamentals.json') ||
    url.pathname.endsWith('/sw.js') ||
    url.pathname === '/manifest.json'
  ) {
    return; // Pass-through to network
  }

  // 2. Navigation requests: Network First, always fetching the newest published build
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return response;
        })
        .catch(() => {
          return caches.match(new URL('index.html', BASE).href).then((response) => {
            return response || caches.match(BASE);
          });
        })
    );
    return;
  }

  // 3. Static assets & Google Fonts: Stale While Revalidate / Cache First
  if (
    url.origin.includes('fonts.googleapis.com') ||
    url.origin.includes('fonts.gstatic.com') ||
    url.pathname.endsWith('.png') ||
    url.pathname.endsWith('.svg') ||
    url.pathname.endsWith('.woff2') ||
    url.pathname.endsWith('.css') ||
    url.pathname.endsWith('.js')
  ) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        const fetchPromise = fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
          return networkResponse;
        }).catch(() => cachedResponse);

        return cachedResponse || fetchPromise;
      })
    );
    return;
  }

  // Default: Network with Cache Fallback
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});
