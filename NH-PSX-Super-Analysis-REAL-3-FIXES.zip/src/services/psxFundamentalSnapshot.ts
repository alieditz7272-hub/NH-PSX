import { getPSXCompanyProfile } from '../data/psxCompanyProfiles';

export interface FundamentalSnapshot {
  symbol: string; companyName: string; currentEps: number|null; expectedEps: number|null; peRatio: number|null; sectorMedianPe: number|null;
  faceValue:number|null; currentBookValue:number|null; expectedBookValue:number|null; currentEnterpriseValue:number|null; expectedEnterpriseValue:number|null;
  latestCashDividend:number|null; expectedCashDividend:number|null; latestCashDividendExDate:string|null; currentYearProfitLoss:number|null; previousYearProfitLoss:number|null;
  source:string; fetchedAt:number;
}
const n=(v:any)=>{const x=Number(String(v??'').replace(/,/g,''));return Number.isFinite(x)?x:null};
let cache: Record<string, any>|null=null;

function localProfileFallback(clean:string): FundamentalSnapshot|null {
  try {
    const profile:any=getPSXCompanyProfile(`${clean}.PSX`, clean, undefined, 0);
    if (!profile) return null;
    const eps=n(profile.currentEps);
    const bv=n(profile.bookValue);
    const pe=n(profile.peRatio);
    if (eps===null && bv===null && pe===null) return null;
    return {
      symbol:clean,
      companyName:profile.companyName||clean,
      currentEps:eps,
      expectedEps:null,
      peRatio:pe,
      sectorMedianPe:null,
      faceValue:10,
      currentBookValue:bv,
      expectedBookValue:null,
      currentEnterpriseValue:null,
      expectedEnterpriseValue:null,
      latestCashDividend:null,
      expectedCashDividend:null,
      latestCashDividendExDate:null,
      currentYearProfitLoss:null,
      previousYearProfitLoss:null,
      source:'NH PSX verified profile fallback',
      fetchedAt:Date.now()
    };
  } catch { return null; }
}

export async function fetchFundamentalSnapshot(symbol:string):Promise<FundamentalSnapshot>{
  const clean=symbol.replace(/\.PSX$|\.KA$/i,'').toUpperCase();
  if(!cache){
    try {
      const r=await fetch(`./data/fundamentals.json?ts=${Date.now()}`,{cache:'no-store'});
      if(r.ok){ const p=await r.json(); cache=p?.data||{}; }
    } catch { /* local fallback below */ }
    if(!cache) cache={};
  }
  const row=cache[clean];
  if(row){
    return {
      symbol:clean, companyName:row.companyName||clean, currentEps:n(row.currentEps), expectedEps:n(row.expectedEps),
      peRatio:n(row.peRatio), sectorMedianPe:n(row.sectorMedianPe), faceValue:n(row.faceValue), currentBookValue:n(row.currentBookValue), expectedBookValue:n(row.expectedBookValue),
      currentEnterpriseValue:n(row.currentEnterpriseValue), expectedEnterpriseValue:n(row.expectedEnterpriseValue), latestCashDividend:n(row.latestCashDividend),
      expectedCashDividend:n(row.expectedCashDividend), latestCashDividendExDate:row.latestCashDividendExDate||null, currentYearProfitLoss:n(row.currentYearProfitLoss),
      previousYearProfitLoss:n(row.previousYearProfitLoss), source:row.source||'PSX Data Portal', fetchedAt:n(row.fetchedAt)||Date.now()
    };
  }
  const fallback=localProfileFallback(clean);
  if(fallback) return fallback;
  throw new Error(`${clean} fundamentals unavailable`);
}
