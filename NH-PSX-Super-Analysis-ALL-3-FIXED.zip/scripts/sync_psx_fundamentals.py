import concurrent.futures
import html as html_lib
import json
import re
import time
from datetime import datetime, timezone
from urllib.request import Request, urlopen

BASE='https://dps.psx.com.pk'
HEADERS={'User-Agent':'Mozilla/5.0 (compatible; NH-PSX-Super-Analysis/1.0)','Accept':'text/html,application/xhtml+xml,application/json'}
INDEXES={'KSE100','KSE100PR','ALLSHR','KSE30','KMI30','KMIALLSHR','PSXDIV20','BKTI','OGTI'}

def screener_symbols():
    # Use the already-synced official PSX market snapshot as the symbol universe.
    # This keeps the fundamentals job independent of an undocumented screener API.
    path='public/data/market.json'
    try:
        payload=json.load(open(path,encoding='utf-8'))
        rows=payload.get('data',[]) if isinstance(payload,dict) else []
        symbols=[]
        for row in rows:
            sym=str(row.get('symbol','')).replace('.PSX','').replace('.KA','').strip().upper()
            if re.fullmatch(r'[A-Z0-9&._-]{1,20}',sym) and sym not in INDEXES:
                symbols.append(sym)
        return list(dict.fromkeys(symbols))
    except Exception as exc:
        print('market universe unavailable:',exc)
        return []


def get(url, attempts=3):
    last=None
    for attempt in range(attempts):
        try:
            req=Request(url,headers=HEADERS)
            with urlopen(req,timeout=30) as r:
                return r.read().decode('utf-8','replace')
        except Exception as exc:
            last=exc
            time.sleep(1 + attempt)
    raise last


def clean(s):
    s=html_lib.unescape(s)
    s=re.sub(r'<script[\s\S]*?</script>|<style[\s\S]*?</style>',' ',s,flags=re.I)
    s=re.sub(r'<[^>]+>',' ',s)
    s=s.replace('\xa0',' ')
    return re.sub(r'\s+',' ',s).strip()


def num(v):
    if v is None:return None
    s=str(v).replace(',','').replace('%','').replace('Rs','').replace('(','-').replace(')','').strip()
    if s in ('','-','—','N/A','n/a'):return None
    try:return float(s)
    except:return None


def table_rows(source):
    out=[]
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>',source,re.I|re.S):
        cells=[]
        for c in re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>',tr,re.I|re.S):
            cells.append(clean(c))
        if cells: out.append(cells)
    return out


def row_values(rows, label):
    needle=label.lower()
    for row in rows:
        if not row: continue
        if needle in row[0].lower():
            return [num(x) for x in row[1:]]
    return []


def parse_symbol(sym):
    source=get(f'{BASE}/company/{sym}', attempts=3)
    rows=table_rows(source)
    text=clean(source)

    # Company name is published in the page heading/title.
    title=re.search(r'<title[^>]*>(.*?)</title>',source,re.I|re.S)
    company_name=clean(title.group(1)) if title else sym
    company_name=re.sub(r'\s*[-|]\s*(Stock quote|Pakistan Stock Exchange.*)$','',company_name,flags=re.I).strip() or sym

    eps=row_values(rows,'EPS')
    profits=row_values(rows,'Profit after Taxation')
    dividends=row_values(rows,'Cash Dividend') or row_values(rows,'Dividend')
    book_values=row_values(rows,'Book Value') or row_values(rows,'Book value per share')
    pe_values=row_values(rows,'P/E') or row_values(rows,'Price to Earnings')

    # Fallback against rendered text when PSX changes table markup.
    def text_series(label):
        m=re.search(re.escape(label)+r'\s+((?:[\d,.()\-]+\s+){1,8})',text,re.I)
        return [num(x) for x in re.findall(r'[\d,.]+|\([\d,.]+\)',m.group(1))] if m else []

    if not eps: eps=text_series('EPS')
    if not profits: profits=text_series('Profit after Taxation')
    if not book_values: book_values=text_series('Book Value')

    current_eps=next((x for x in eps if x is not None),None)
    prev_eps=next((x for x in eps[1:] if x is not None),None)
    current_profit=next((x for x in profits if x is not None),None)
    prev_profit=next((x for x in profits[1:] if x is not None),None)
    latest_div=next((x for x in dividends if x is not None),None)
    current_bv=next((x for x in book_values if x is not None),None)
    prev_bv=next((x for x in book_values[1:] if x is not None),None)
    pe=next((x for x in pe_values if x is not None),None)

    expected_eps=None
    if current_eps is not None and current_profit is not None and prev_profit not in (None,0):
        growth=max(-0.20,min(0.25,current_profit/prev_profit-1))
        expected_eps=round(current_eps*(1+growth),2)

    expected_bv=None
    if current_bv is not None and current_profit is not None and prev_profit not in (None,0):
        growth=max(-0.20,min(0.25,current_profit/prev_profit-1))
        expected_bv=round(current_bv*(1+growth),2)

    mf=re.search(r'(?:Face Value|Par Value)\s*(?:Rs\.?\s*)?([\d,.]+)',text,re.I)
    face=num(mf.group(1)) if mf else None

    # Never invent balance-sheet/EV figures. If PSX publishes them in a
    # future company-page revision, the parser can populate them here.
    return {
      'symbol':sym,'companyName':company_name,'currentEps':current_eps,'expectedEps':expected_eps,
      'currentBookValue':current_bv,'expectedBookValue':expected_bv,
      'currentEnterpriseValue':None,'expectedEnterpriseValue':None,
      'latestCashDividend':latest_div,'expectedCashDividend':latest_div,'latestCashDividendExDate':None,
      'currentYearProfitLoss':current_profit,'previousYearProfitLoss':prev_profit,'faceValue':face,
      'peRatio':pe,'source':'PSX Data Portal — official company financials','fetchedAt':int(time.time()*1000)
    }

syms=screener_symbols()
print('symbols',len(syms))
if len(syms)<50:
    raise RuntimeError(f'PSX screener parser returned only {len(syms)} symbols')

results={}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
    futures={ex.submit(parse_symbol,s):s for s in syms}
    for i,f in enumerate(concurrent.futures.as_completed(futures),1):
        s=futures[f]
        try:
            r=f.result()
            if r and any(r.get(k) is not None for k in ('currentEps','currentYearProfitLoss','latestCashDividend')):
                results[s]=r
        except Exception as exc:
            if i<=20: print('skip',s,exc)
        if i%50==0: print('processed',i,'with fundamentals',len(results))

payload={'fetchedAt':datetime.now(timezone.utc).isoformat(),'source':'PSX Data Portal — official company financials','data':results}
with open('public/data/fundamentals.json','w',encoding='utf-8') as f:
    json.dump(payload,f,separators=(',',':'))
print('wrote',len(results),'fundamental records')
if len(results)<20:
    raise RuntimeError(f'PSX fundamentals parser returned only {len(results)} companies')
