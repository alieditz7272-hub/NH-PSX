import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  BarChart2, 
  Search, 
  Activity, 
  Globe, 
  Layers,
  Plus,
  ChevronDown,
  LineChart,
  ListFilter,
  Briefcase,
  Building2,
  Sparkles,
  ChevronRight,
  Compass,
  CheckCircle2,
  Flame,
  Scale,
  GraduationCap,
  History,
  Clock,
  X,
  Trash2,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Lock,
  Download
} from 'lucide-react';
import { TickerQuote } from '../types';
import { createCustomTicker } from '../data/marketData';
import { formatPrice } from '../utils/currency';
import { formatDisplaySymbol, formatDisplayName, isPsxDefaulter, isPsxIndex } from '../utils/symbol';
import { StockThreeRangeBars } from './StockThreeRangeBars';
import { SuperAnalystView } from './SuperAnalystView';
import { GlobalAssetSelectorModal } from './GlobalAssetSelectorModal';
import { PakistanMarketClock } from './PakistanMarketClock';
import { StockLogo } from './StockLogo';
import { MarketStructureViewCard } from './MarketStructureViewCard';
import { Candle, TimeFrame } from '../types';

export type AppModule = 'TERMINAL';

const SEARCH_HISTORY_STORAGE_KEY = 'nh_stock_search_history_v1';

interface SearchHistoryEntry {
  symbol: string;
  name?: string;
  count: number;
  lastSearched: number;
}

const DEFAULT_FREQUENT_SYMBOLS: SearchHistoryEntry[] = [
  { symbol: 'KSE100.PSX', name: 'KSE 100 Index', count: 125, lastSearched: Date.now() - 1000 },
  { symbol: 'OGDC.PSX', name: 'Oil & Gas Dev Co', count: 98, lastSearched: Date.now() - 2000 },
  { symbol: 'SYS.PSX', name: 'Systems Limited', count: 85, lastSearched: Date.now() - 3000 },
  { symbol: 'AKBL.PSX', name: 'Askari Bank Ltd', count: 74, lastSearched: Date.now() - 4000 },
  { symbol: 'LUCK.PSX', name: 'Lucky Cement Ltd', count: 68, lastSearched: Date.now() - 5000 },
  { symbol: 'MARI.PSX', name: 'Mari Petroleum', count: 62, lastSearched: Date.now() - 6000 },
  { symbol: 'PRL.PSX', name: 'Pakistan Refinery', count: 57, lastSearched: Date.now() - 7000 },
  { symbol: 'HUBC.PSX', name: 'Hub Power Company', count: 53, lastSearched: Date.now() - 8000 },
  { symbol: 'MEBL.PSX', name: 'Meezan Bank Ltd', count: 48, lastSearched: Date.now() - 9000 },
];

interface HeaderProps {
  tickers: TickerQuote[];
  selectedTicker: TickerQuote;
  setSelectedTicker: (ticker: TickerQuote) => void;
  isLiveFeed: boolean;
  setIsLiveFeed: (live: boolean) => void;
  psxDataStatus?: string;
  lastSourceTimestamp?: string;
  activeModule: AppModule;
  setActiveModule: (mod: AppModule) => void;
  onTriggerAISync?: () => Promise<void>;
  onTriggerHardRefresh?: () => Promise<void>;
  isHardRefreshing?: boolean;
  candles?: Candle[];
  timeframe?: TimeFrame;
  setTimeframe?: (tf: TimeFrame) => void;
  isLoadingChart?: boolean;
  onRefreshChart?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  tickers,
  selectedTicker,
  setSelectedTicker,
  isLiveFeed,
  setIsLiveFeed,
  psxDataStatus,
  lastSourceTimestamp,
  activeModule,
  setActiveModule,
  onTriggerAISync,
  onTriggerHardRefresh,
  isHardRefreshing = false,
  candles = [],
  timeframe = '1D',
  setTimeframe,
  isLoadingChart = false,
  onRefreshChart,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [deferredInstallPrompt, setDeferredInstallPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [selectedAssetFilter, setSelectedAssetFilter] = useState<string>('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchHistory, setSearchHistory] = useState<SearchHistoryEntry[]>(() => {
    try {
      const saved = localStorage.getItem(SEARCH_HISTORY_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignore
    }
    return DEFAULT_FREQUENT_SYMBOLS;
  });

  const searchInputRef = React.useRef<HTMLInputElement>(null);

  // Sync search history changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(SEARCH_HISTORY_STORAGE_KEY, JSON.stringify(searchHistory));
    } catch {
      // Ignore
    }
  }, [searchHistory]);

  const recordSearch = (ticker: TickerQuote) => {
    if (!ticker || !ticker.symbol) return;
    const sym = ticker.symbol;
    setSearchHistory((prev) => {
      const existing = prev.find((entry) => entry.symbol.toUpperCase() === sym.toUpperCase());
      let updated: SearchHistoryEntry[];
      if (existing) {
        updated = prev.map((entry) =>
          entry.symbol.toUpperCase() === sym.toUpperCase()
            ? { ...entry, count: entry.count + 1, lastSearched: Date.now(), name: ticker.name || entry.name }
            : entry
        );
      } else {
        const newEntry: SearchHistoryEntry = {
          symbol: sym,
          name: ticker.name || sym,
          count: 1,
          lastSearched: Date.now(),
        };
        updated = [newEntry, ...prev];
      }
      // Sort by frequency (count) and recency
      return updated.sort((a, b) => b.count - a.count || b.lastSearched - a.lastSearched).slice(0, 30);
    });
  };

  const removeHistoryItem = (sym: string, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setSearchHistory((prev) => prev.filter((item) => item.symbol.toUpperCase() !== sym.toUpperCase()));
  };

  const clearAllHistory = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setSearchHistory([]);
    try {
      localStorage.removeItem(SEARCH_HISTORY_STORAGE_KEY);
    } catch {
      // Ignore
    }
  };

  const dismissKeyboard = () => {
    if (searchInputRef.current) {
      searchInputRef.current.blur();
    }
    if (typeof document !== 'undefined' && document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
  };

  const handleSelectTicker = (ticker: TickerQuote) => {
    recordSearch(ticker);
    setSelectedTicker(ticker);
    setSearchQuery('');
    setIsSearchOpen(false);
    dismissKeyboard();
  };

  // Find quotes for history items
  const frequentTickers: TickerQuote[] = searchHistory
    .map((hist) => {
      const match = tickers.find(
        (t) => t.symbol.toUpperCase() === hist.symbol.toUpperCase() ||
               t.symbol.replace('.PSX', '').toUpperCase() === hist.symbol.replace('.PSX', '').toUpperCase()
      );
      if (match) return match;
      return createCustomTicker(hist.symbol);
    })
    .filter(Boolean);

  const filteredTickers = tickers
    .filter((t) => {
      const query = searchQuery.toLowerCase().trim();
      const symbolClean = t.symbol.toLowerCase();
      const symbolBase = t.symbol.split('.')[0].toLowerCase();
      const nameClean = t.name.toLowerCase();
      const sectorClean = t.sector.toLowerCase();
      const exchangeClean = (t.exchange || '').toLowerCase();

      const matchesQuery =
        !query ||
        symbolClean.includes(query) ||
        symbolBase === query ||
        nameClean.includes(query) ||
        sectorClean.includes(query) ||
        exchangeClean.includes(query) ||
        (query === 'psx' && (symbolClean.endsWith('.psx') || exchangeClean.includes('psx')));

      if (!matchesQuery) return false;
      if (selectedAssetFilter === 'ALL') return true;
      if (selectedAssetFilter === 'PSX_TOP') return (t.volume || 0) > 3000000 || t.aiScore >= 85;
      if (selectedAssetFilter === 'TECH') return sectorClean.includes('it') || sectorClean.includes('telecom') || sectorClean.includes('software');
      if (selectedAssetFilter === 'OIL_GAS') return sectorClean.includes('oil') || sectorClean.includes('gas');
      if (selectedAssetFilter === 'BANKS') return sectorClean.includes('bank') || sectorClean.includes('finance');
      if (selectedAssetFilter === 'CEMENT') return sectorClean.includes('cement') || sectorClean.includes('steel') || sectorClean.includes('construction');
      if (selectedAssetFilter === 'INDEX') return t.assetClass === 'Index' || symbolClean.includes('kse');
      return true;
    })
    .sort((a, b) => {
      const query = searchQuery.toLowerCase().trim();
      if (!query) return 0;

      const aBase = a.symbol.split('.')[0].toLowerCase();
      const bBase = b.symbol.split('.')[0].toLowerCase();
      const aExact = aBase === query || a.symbol.toLowerCase() === query;
      const bExact = bBase === query || b.symbol.toLowerCase() === query;

      if (aExact && !bExact) return -1;
      if (!aExact && bExact) return 1;

      const aStartsWith = a.symbol.toLowerCase().startsWith(query);
      const bStartsWith = b.symbol.toLowerCase().startsWith(query);
      if (aStartsWith && !bStartsWith) return -1;
      if (!aStartsWith && bStartsWith) return 1;

      return 0;
    });

  const exactMatchExists = tickers.some((t) => {
    const q = searchQuery.trim().toLowerCase();
    return t.symbol.toLowerCase() === q || t.symbol.split('.')[0].toLowerCase() === q;
  });

  useEffect(() => {
    const standalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true;
    setIsStandalone(Boolean(standalone));
    const onBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredInstallPrompt(e);
    };
    const onInstalled = () => {
      setIsStandalone(true);
      setDeferredInstallPrompt(null);
    };
    window.addEventListener('beforeinstallprompt', onBeforeInstall);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstall);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  const handlePwaInstall = async () => {
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      try { await deferredInstallPrompt.userChoice; } catch {}
      setDeferredInstallPrompt(null);
      return;
    }
    alert('Android Chrome: browser menu ⋮ → Install app / Add to Home screen.');
  };

  return (
    <header className="bg-black/40 backdrop-blur-md border-b border-white/5 text-[#E0E0E0] relative z-30 shadow-2xl">
      <GlobalAssetSelectorModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        tickers={tickers}
        selectedTicker={selectedTicker}
        onSelectTicker={setSelectedTicker}
      />

      {/* Main Header Rows - Clock, Status & Search */}
      <div className="max-w-[1920px] w-full mx-auto px-2 sm:px-4 md:px-6 lg:px-8 py-2.5 flex flex-col gap-2.5">
        {!isStandalone && (
          <button
            type="button"
            onClick={handlePwaInstall}
            className="w-full sm:w-auto self-end flex items-center justify-center gap-2 px-4 py-2 rounded-xl border border-[#00FFA3]/40 bg-[#00FFA3]/10 text-[#00FFA3] font-extrabold text-xs shadow-lg active:scale-95 transition"
            aria-label="Install NH PSX Super Analysis" title="Install NH PSX Super Analysis"
          >
            <Download className="w-4 h-4" />
            INSTALL PWA
          </button>
        )}

        {/* Row 1: Market Clock & Status */}
        <div className="w-full border-b border-white/5 pb-2">
          <PakistanMarketClock 
            psxDataStatus={psxDataStatus} 
            lastSourceTimestamp={lastSourceTimestamp} 
            onTriggerAISync={onTriggerAISync}
            onTriggerHardRefresh={onTriggerHardRefresh}
            isHardRefreshing={isHardRefreshing}
          />
        </div>

        {/* Row 2: Stock Search Box & Selected Active Stock/Index Up-Down Live Status Display */}
        <div id="section-stock-search-box" className="flex flex-col lg:flex-row items-stretch justify-between gap-3 w-full scroll-mt-28">
          <div className="relative w-full flex-1">
            {/* 🚨 PSX Defaulter Counter Alert Box (Directly above search box, equal width to search box, styled like search box) */}
            {selectedTicker && isPsxDefaulter(selectedTicker.symbol, selectedTicker) && (
              <div
                id="psx-defaulter-counter-banner"
                className="w-full mb-2.5 bg-[#180505] hover:bg-[#220707] border-2 border-red-500 rounded-2xl px-4 py-3 sm:py-3.5 flex items-center justify-center gap-2.5 text-sm sm:text-base font-black text-red-100 font-mono shadow-[0_0_20px_rgba(239,68,68,0.45)] transition"
              >
                <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 animate-pulse" />
                <span className="tracking-wider uppercase">PSX Defaulter Counter</span>
              </div>
            )}
            <div className="relative flex items-center gap-2 w-full">
              <div className="relative flex-1 group w-full">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center pointer-events-none">
                  <Search className="w-5 h-5 text-[#00FFA3] group-focus-within:scale-110 transition-transform" />
                </div>
                <input
                  id="main-psx-stock-search-input"
                  ref={searchInputRef}
                  type="text"
                  placeholder="Search Any PSX Stock or Index"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setIsSearchOpen(true);
                  }}
                  onFocus={() => setIsSearchOpen(true)}
                  onBlur={() => setTimeout(() => setIsSearchOpen(false), 250)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && searchQuery.trim().length > 0) {
                      const custom = createCustomTicker(searchQuery);
                      handleSelectTicker(custom);
                    }
                  }}
                  className="w-full bg-[#050e18] hover:bg-[#081525] border-2 border-[#00FFA3] focus:border-[#00FFA3] rounded-2xl pl-11 pr-4 py-3 sm:py-3.5 text-sm sm:text-base font-bold text-white placeholder-slate-400 focus:outline-none ring-1 ring-[#00FFA3]/50 focus:ring-2 focus:ring-[#00FFA3] shadow-[0_0_15px_rgba(0,255,163,0.25)] transition font-mono"
                />
              </div>
            </div>
            {/* Search Dropdown with Google-like Frequently / Recently Searched Stocks */}
            {isSearchOpen && (
              <div className="absolute top-full left-0 right-0 mt-1.5 bg-slate-950/98 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-2xl z-50 overflow-hidden font-mono divide-y divide-white/10">
                {/* Category Filter Pills */}
                <div className="p-2 bg-black/50 border-b border-white/10 flex items-center gap-1.5 overflow-x-auto text-[10px] scrollbar-none">
                  {['ALL', 'PSX_TOP', 'TECH', 'OIL_GAS', 'BANKS', 'CEMENT', 'INDEX'].map((cat) => (
                    <button
                      key={cat}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        setSelectedAssetFilter(cat);
                      }}
                      className={`px-2.5 py-1 rounded-lg font-bold uppercase transition whitespace-nowrap shrink-0 ${
                        selectedAssetFilter === cat
                          ? 'bg-[#00FFA3]/20 text-[#00FFA3] border border-[#00FFA3]/40 shadow-sm'
                          : 'text-white/50 hover:text-white bg-white/5'
                      }`}
                    >
                      {cat === 'ALL' ? '🇵🇰 All PSX' : cat === 'PSX_TOP' ? '🔥 Volume Leaders' : cat === 'TECH' ? '💻 IT & Telecom' : cat === 'OIL_GAS' ? '🛢️ Oil & Gas' : cat === 'BANKS' ? '🏦 Banks' : cat === 'CEMENT' ? '🏗️ Cement' : '📊 Indices'}
                    </button>
                  ))}
                </div>

                {/* 🌟 GOOGLE-LIKE FREQUENTLY SEARCHED / RECENT SEARCHES PANEL (Displays when input is empty or query is small) */}
                {searchQuery.trim().length === 0 && searchHistory.length > 0 && (
                  <div className="p-3 bg-gradient-to-b from-[#00FFA3]/5 to-transparent border-b border-white/10">
                    <div className="flex items-center justify-between pb-2 mb-1.5 border-b border-white/10 text-xs">
                      <div className="flex items-center gap-1.5 font-bold text-[#00FFA3]">
                        <History className="w-3.5 h-3.5 text-[#00FFA3]" />
                        <span className="text-[11px] uppercase tracking-wider">Frequently & Recently Searched Stocks</span>
                        <span className="text-[10px] px-1.5 py-0.2 bg-[#00FFA3]/20 text-[#00FFA3] rounded-full border border-[#00FFA3]/30">
                          {searchHistory.length}
                        </span>
                      </div>
                      <button
                        onMouseDown={clearAllHistory}
                        title="Clear all search history"
                        className="text-[10px] text-white/50 hover:text-red-400 flex items-center gap-1 transition px-1.5 py-0.5 rounded hover:bg-white/5"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Clear All</span>
                      </button>
                    </div>

                    {/* Quick Horizontal Chip Suggestions */}
                    <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none">
                      {frequentTickers.slice(0, 8).map((t) => (
                        <button
                          key={`chip-${t.symbol}`}
                          onMouseDown={(e) => {
                            e.preventDefault();
                            handleSelectTicker(t);
                          }}
                          className="px-2.5 py-1 bg-white/10 hover:bg-[#00FFA3]/20 border border-white/15 hover:border-[#00FFA3]/50 rounded-lg text-xs font-bold text-white hover:text-[#00FFA3] flex items-center gap-1.5 transition shrink-0 group active:scale-95"
                        >
                          <Clock className="w-3 h-3 text-[#00FFA3] group-hover:scale-110 transition-transform" />
                          <span>{formatDisplaySymbol(t.symbol)}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="max-h-80 overflow-y-auto divide-y divide-white/5">
                  {searchQuery.trim().length > 0 && !exactMatchExists && (
                    <button
                      onMouseDown={(e) => {
                        e.preventDefault();
                        const custom = createCustomTicker(searchQuery);
                        handleSelectTicker(custom);
                      }}
                      className="w-full px-4 py-3 text-left bg-[#00FFA3]/10 hover:bg-[#00FFA3]/20 border-b border-[#00FFA3]/20 flex items-center justify-between text-xs text-[#00FFA3] font-bold transition group"
                    >
                      <div className="flex items-center gap-2">
                        <Plus className="w-4 h-4 text-[#00FFA3]" />
                        <span>Analyze Custom PSX Symbol: <strong className="underline uppercase">{searchQuery.trim().toUpperCase()}</strong></span>
                      </div>
                      <span className="text-[10px] bg-[#00FFA3]/20 border border-[#00FFA3]/40 text-[#00FFA3] px-2 py-0.5 rounded uppercase">
                        PSX EOD
                      </span>
                    </button>
                  )}

                  {/* If user hasn't typed anything, show the full frequently searched list with hit counter and instant click selection */}
                  {searchQuery.trim().length === 0 && (
                    <div className="divide-y divide-white/5">
                      <div className="px-3.5 py-1.5 bg-black/40 text-[10px] font-bold text-white/50 uppercase tracking-wider flex items-center justify-between">
                        <span>Top Searched Stocks & Indices (Click to Select)</span>
                        <span className="text-[9px] text-[#00FFA3]">Auto-Saved</span>
                      </div>
                      {frequentTickers.map((ticker) => {
                        const histEntry = searchHistory.find(
                          (h) => h.symbol.toUpperCase() === ticker.symbol.toUpperCase()
                        );
                        return (
                          <div
                            key={`hist-${ticker.symbol}`}
                            onMouseDown={(e) => {
                              e.preventDefault();
                              handleSelectTicker(ticker);
                            }}
                            className="w-full px-3.5 py-2.5 hover:bg-white/10 flex items-center justify-between transition group cursor-pointer"
                          >
                            <div className="flex items-center gap-2.5">
                              <div className="p-1 rounded bg-[#00FFA3]/10 text-[#00FFA3] border border-[#00FFA3]/20">
                                <History className="w-3.5 h-3.5" />
                              </div>
                              <StockLogo symbol={ticker.symbol} name={ticker.name} logoUrl={(ticker as any).logoUrl} size="sm" />
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-extrabold font-mono text-xs text-[#00FFA3] group-hover:underline">
                                    {formatDisplaySymbol(ticker.symbol)}
                                  </span>
                                  <span className="text-[10px] text-white/80 font-bold truncate max-w-[140px] sm:max-w-[280px]">
                                    - {formatDisplayName(ticker)}
                                  </span>
                                </div>
                                <div className="flex items-center gap-1.5 mt-0.5 text-[9px] text-white/40">
                                  <span className="px-1 py-0.2 bg-white/5 rounded border border-white/10 uppercase font-bold text-white/50">
                                    {ticker.assetClass}
                                  </span>
                                  {histEntry && (
                                    <span className="text-[#00FFA3]/80 font-bold">
                                      • Searched {histEntry.count} time{histEntry.count > 1 ? 's' : ''}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-3">
                              <div className="text-right font-mono text-xs">
                                <div className="text-white font-bold">
                                  {formatPrice(ticker.price, ticker)}
                                </div>
                              </div>
                              <button
                                onMouseDown={(e) => removeHistoryItem(ticker.symbol, e)}
                                title="Remove from search history"
                                className="p-1 text-white/30 hover:text-red-400 hover:bg-white/10 rounded transition"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Standard Search Results matching typed query */}
                  {searchQuery.trim().length > 0 && filteredTickers.length === 0 && exactMatchExists && (
                    <div className="p-4 text-xs text-white/40 text-center font-mono">
                      No matching assets in this category filter
                    </div>
                  )}

                  {searchQuery.trim().length > 0 && filteredTickers.map((ticker) => (
                    <button
                      key={ticker.symbol}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        handleSelectTicker(ticker);
                      }}
                      className="w-full px-3.5 py-2.5 text-left hover:bg-white/10 flex items-center justify-between transition group"
                    >
                      <div className="flex items-center gap-2.5">
                        <StockLogo symbol={ticker.symbol} name={ticker.name} logoUrl={(ticker as any).logoUrl} size="sm" />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold font-mono text-xs text-[#00FFA3] group-hover:underline">
                              {formatDisplaySymbol(ticker.symbol)}
                            </span>
                            <span className="text-[10px] text-white/80 font-bold truncate max-w-[150px] sm:max-w-[300px]">
                              - {formatDisplayName(ticker)}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 mt-0.5 text-[9px] text-white/40">
                            <span className="px-1 py-0.2 bg-white/5 rounded border border-white/10 uppercase font-bold text-white/50">
                              {ticker.assetClass}
                            </span>
                            {ticker.exchange && (
                              <span>• {ticker.exchange}</span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="text-right font-mono text-xs">
                        <div className="text-white font-bold">
                          {formatPrice(ticker.price, ticker)}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 🌟 SELECTED STOCK / INDEX LIVE UP / DOWN STATUS & 52W / EVER HIGHS-LOWS DISPLAY */}
          {selectedTicker && (() => {
            const isIndex = isPsxIndex(selectedTicker);
            const cleanSym = formatDisplaySymbol(selectedTicker.symbol);

            return (
              <div className="w-full lg:w-auto flex flex-col items-stretch lg:items-end gap-2">
                {/* Main Selected Stock Summary Pill */}
                <div className="w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-black/90 via-[#071322] to-black/90 border border-white/20 rounded-2xl shadow-xl font-mono">
                  <StockLogo symbol={selectedTicker.symbol} name={selectedTicker.name} logoUrl={(selectedTicker as any).logoUrl} size="md" />
                  <div className="flex flex-col flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm sm:text-base font-black text-white">
                        {formatDisplaySymbol(selectedTicker.symbol)}
                      </span>
                      <span className="text-[11px] text-white/70 font-semibold truncate max-w-[140px] sm:max-w-[200px]">
                        {formatDisplayName(selectedTicker)}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[9.5px] font-extrabold uppercase bg-white/5 border border-white/15 text-[#00FFA3]">
                        {selectedTicker.assetClass === 'Index' ? 'PSX INDEX' : 'PSX REGULAR CASH (READY)'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className="text-sm sm:text-base font-black text-white">
                        {formatPrice(selectedTicker.price, selectedTicker)}
                      </span>
                      
                      {/* Real-time UP / DOWN badge */}
                      {(() => {
                        const chg = typeof selectedTicker.change === 'number' ? selectedTicker.change : 0;
                        const chgPct = typeof selectedTicker.changePercent === 'number' ? selectedTicker.changePercent : 0;
                        const isUp = chg > 0;
                        const isDown = chg < 0;
                        const absChg = isIndex ? Math.round(Math.abs(chg)).toString() : Math.abs(chg).toFixed(Math.abs(chg) < 0.1 ? 4 : 2);

                        if (isUp) {
                          return (
                            <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/40 text-[#00FFA3] text-[11px] font-extrabold shadow-sm">
                              <span>▲ UP:</span>
                              <span>+{absChg}</span>
                              <span>(+{chgPct.toFixed(2)}%)</span>
                            </div>
                          );
                        } else if (isDown) {
                          return (
                            <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-red-500/15 border border-red-500/40 text-red-400 text-[11px] font-extrabold shadow-sm">
                              <span>▼ DOWN:</span>
                              <span>-{absChg}</span>
                              <span>({chgPct.toFixed(2)}%)</span>
                            </div>
                          );
                        } else {
                          return (
                            <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-white/10 border border-white/20 text-slate-300 text-[11px] font-bold">
                              <span>UNCHANGED: {isIndex ? '0' : '0.00'} (0.00%)</span>
                            </div>
                          );
                        }
                      })()}
                    </div>
                  </div>
                </div>

                {/* 🌟 SUPER BRAIN ANALYSIS REPORT (DIRECTLY BELOW SELECTED SYMBOL) */}
                <SuperAnalystView selectedTicker={selectedTicker} candles={candles} />

                {/* 🌟 3 RANGE BARS: CURRENT DAY RANGE • 52-WEEK RANGE • EVER (ALL-TIME) RANGE */}
                <StockThreeRangeBars selectedTicker={selectedTicker} candles={candles} />

                {/* 🧭 BASIC STRUCTURE: Pure Price Action & Swing Structure */}
                <MarketStructureViewCard
                  selectedTicker={selectedTicker}
                  candles={candles}
                  allTickers={tickers}
                />
              </div>
            );
          })()}
        </div>
      </div>
    </header>
  );
};

