const ALLOWED_HOSTS = new Set([
  'dps.psx.com.pk',
  'psxdata-api.fastapicloud.dev',
]);

exports.handler = async (event) => {
  try {
    const rawUrl = event.queryStringParameters?.url;
    if (!rawUrl) return { statusCode: 400, body: 'Missing url' };

    const target = new URL(rawUrl);
    if (!ALLOWED_HOSTS.has(target.hostname)) {
      return { statusCode: 403, body: 'Host not allowed' };
    }

    const response = await fetch(target.toString(), {
      headers: { Accept: 'application/json, text/plain, text/html, */*' },
    });
    const body = await response.text();

    return {
      statusCode: response.status,
      headers: {
        'content-type': response.headers.get('content-type') || 'text/plain; charset=utf-8',
        'cache-control': 'no-store, max-age=0',
      },
      body,
    };
  } catch (error) {
    return { statusCode: 502, body: JSON.stringify({ error: String(error?.message || error) }) };
  }
};
