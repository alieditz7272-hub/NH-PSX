export interface FundamentalSnapshot {
  symbol: string;
  companyName: string;
  currentEps: number | null;
  expectedEps: number | null;
  peRatio: number | null;
  sectorMedianPe: number | null;
  faceValue: number | null;
  currentBookValue: number | null;
  expectedBookValue: number | null;
  currentEnterpriseValue: number | null;
  expectedEnterpriseValue: number | null;
  latestCashDividend: number | null;
  expectedCashDividend: number | null;
  latestCashDividendExDate: string | null;
  currentYearProfitLoss: number | null;
  previousYearProfitLoss: number | null;
  source: string;
  fetchedAt: number;
}

const API = 'https://psxdata-api.fastapicloud.dev';
const psxProxy = (url: string) => `/api/psx?url=${encodeURIComponent(url)}`;
const clean = (v: string) => v.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
const n = (v: any) => {
  if (v === null || v === undefined || v === '') return null;
  const x = Number(String(v).replace(/,/g, '').replace(/%/g, '').trim());
  return Number.isFinite(x) ? x : null;
};
const first = (obj: any, keys: string[]) => {
  for (const key of keys) {
    if (obj && obj[key] !== undefined && obj[key] !== null && obj[key] !== '') return obj[key];
  }
  return null;
};

const normKey = (key: string) => key.toLowerCase().replace(/[^a-z0-9]/g, '');
const firstLoose = (obj: any, keys: string[]) => {
  if (!obj || typeof obj !== 'object') return null;
  const map = new Map(Object.keys(obj).map(k => [normKey(k), obj[k]]));
  for (const key of keys) {
    const v = map.get(normKey(key));
    if (v !== undefined && v !== null && v !== '') return v;
  }
  return null;
};
const cleanSymbol = (symbol: string) => symbol.replace(/\.PSX$|\.KA$/i, '').replace(/[^A-Z0-9&._-]/gi, '').toUpperCase();
const median = (values: number[]) => {
  if (!values.length) return null;
  const a = [...values].sort((x, y) => x - y);
  return a[Math.floor(a.length / 2)];
};

function parseCompanyPage(html: string) {
  if (typeof DOMParser === 'undefined') return {
    faceValue: null, bookValue: null, enterpriseValue: null, eps: null,
    profit: null, previousProfit: null, dividend: null, exDate: null,
  };

  const doc = new DOMParser().parseFromString(html, 'text/html');
  const bodyText = (doc.body?.innerText || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const labelled = (labels: string[]) => {
    for (const label of labels) {
      const re = new RegExp(`${label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*[:|]?\\s*([-+]?\\d[\\d,]*(?:\\.\\d+)?)`, 'i');
      const m = re.exec(bodyText);
      if (m) return n(m[1]);
    }
    return null;
  };
  const dateAfter = (labels: string[]) => {
    for (const label of labels) {
      const re = new RegExp(`${label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*[:|]?\\s*(\\d{1,2}[-/]\\d{1,2}[-/]20\\d{2}|20\\d{2}[-/]\\d{1,2}[-/]\\d{1,2})`, 'i');
      const m = re.exec(bodyText);
      if (m) return m[1];
    }
    return null;
  };

  // PSX publishes Financials in HTML tables. Read the latest annual/quarterly
  // row instead of assuming a literal "EPS: 12.3" label exists.
  let latestEps: number | null = null;
  let latestProfit: number | null = null;
  let previousProfit: number | null = null;
  for (const table of Array.from(doc.querySelectorAll('table'))) {
    const rows = Array.from(table.querySelectorAll('tr'));
    if (!rows.length) continue;
    const headers = Array.from(rows[0].querySelectorAll('th,td')).map(c => clean(c.textContent || '').toLowerCase());
    const epsIndex = headers.findIndex(h => /(^|\b)eps(\b|$)/i.test(h));
    const patIndex = headers.findIndex(h => /profit after taxation|profit after tax|profit \/ loss|profit loss/i.test(h));
    if (epsIndex < 0 && patIndex < 0) continue;

    const values: string[][] = rows.slice(1).map(r => Array.from(r.querySelectorAll('td,th')).map(c => clean(c.textContent || ''))).filter(r => r.length);
    if (!values.length) continue;
    const firstRow = values[0];
    const secondRow = values[1];
    if (epsIndex >= 0 && firstRow[epsIndex]) latestEps = latestEps ?? n(firstRow[epsIndex]);
    if (patIndex >= 0 && firstRow[patIndex]) latestProfit = latestProfit ?? n(firstRow[patIndex]);
    if (patIndex >= 0 && secondRow?.[patIndex]) previousProfit = previousProfit ?? n(secondRow[patIndex]);
  }

  // Screener/company pages can expose these values as key/value text in some layouts.
  const faceValue = labelled(['Face Value', 'Face Value Per Share']);
  const bookValue = labelled(['Book Value Per Share', 'Book Value', 'BVPS']);
  const enterpriseValue = labelled(['Enterprise Value', 'EV']);
  const dividend = labelled(['Latest Cash Dividend', 'Latest Dividend', 'Cash Dividend']);

  return {
    faceValue,
    bookValue,
    enterpriseValue,
    eps: latestEps ?? labelled(['EPS', 'Earnings Per Share']),
    profit: latestProfit ?? labelled(['Profit After Taxation', 'Profit After Tax', 'Profit / Loss', 'Profit Loss']),
    previousProfit: previousProfit ?? labelled(['Previous Year Profit', 'Previous Profit']),
    dividend,
    exDate: dateAfter(['Ex Date', 'Ex-Date', 'Dividend Ex Date']),
  };
}

let screenerCache: { rows: any[]; fetchedAt: number } | null = null;
async function fetchScreener(): Promise<{ rows: any[]; fetchedAt: number }> {
  if (screenerCache && Date.now() - screenerCache.fetchedAt < 60_000 && screenerCache.rows.length > 100) return screenerCache;
  const res = await fetch(`${API}/screener?ts=${Date.now()}`, { cache: 'no-store' });
  if (!res.ok) throw new Error(`PSX screener HTTP ${res.status}`);
  const payload = await res.json();
  const rows = Array.isArray(payload) ? payload : payload?.data;
  if (!Array.isArray(rows) || rows.length < 100) throw new Error('PSX screener returned an incomplete universe');
  screenerCache = { rows, fetchedAt: Date.now() };
  return screenerCache;
}

export async function fetchFundamentalSnapshot(symbol: string): Promise<FundamentalSnapshot> {
  const clean = cleanSymbol(symbol);
  const { rows, fetchedAt } = await fetchScreener();
  const row = rows.find((r: any) => String(firstLoose(r, ['symbol', 'ticker', 'scrip', 'code']) ?? '').replace(/\.PSX$/i, '').toUpperCase() === clean);
  if (!row) throw new Error(`${clean} not found in the current PSX screener universe`);

  const price = n(firstLoose(row, ['price', 'current', 'close']));
  const pe = n(firstLoose(row, ['peRatio', 'pe', 'p/e', 'p/e ratio', 'pe ratio']));
  const directEps = n(firstLoose(row, ['eps', 'ttmEps', 'earningsPerShare', 'earnings per share']));
  const pb = n(firstLoose(row, ['pbRatio', 'priceToBook', 'priceBook', 'p/b', 'pb ratio', 'price to book']));
  const directBook = n(firstLoose(row, ['bookValue', 'bookValuePerShare', 'book value', 'bvps', 'book value per share']));
  const marketCap = n(firstLoose(row, ['marketCap', 'market cap', 'market_cap']));
  const sector = String(firstLoose(row, ['sector']) ?? '');
  const sectorPes = rows
    .filter((r: any) => String(firstLoose(r, ['sector']) ?? '') === sector)
    .map((r: any) => n(firstLoose(r, ['peRatio', 'pe', 'p/e ratio', 'pe ratio'])))
    .filter((v: number | null): v is number => v !== null && v > 0 && v < 100);

  let company = { faceValue: null as number|null, bookValue: null as number|null, enterpriseValue: null as number|null, eps: null as number|null, profit: null as number|null, previousProfit: null as number|null, dividend: null as number|null, exDate: null as string|null };
  let quote: any = null;
  try {
    const quoteRes = await fetch(`${API}/stocks/${encodeURIComponent(clean)}/quote?ts=${Date.now()}`, { cache: 'no-store' });
    if (quoteRes.ok) { const payload = await quoteRes.json(); quote = payload?.data ?? payload; }
  } catch {}
  try {
    const companyUrl = `https://dps.psx.com.pk/company/${encodeURIComponent(clean)}?ts=${Date.now()}`;
    const res = await fetch(psxProxy(companyUrl), { cache: 'no-store' });
    if (res.ok) company = parseCompanyPage(await res.text());
  } catch {
    // Browser CORS/network can block the official profile; screener-derived fields remain usable.
  }

  const currentEps = company.eps ?? directEps ?? n(firstLoose(quote, ['eps', 'ttmEps', 'earningsPerShare'])) ?? (price && pe && pe > 0 ? Number((price / pe).toFixed(4)) : null);
  const currentBookValue = company.bookValue ?? directBook ?? (price && pb && pb > 0 ? Number((price / pb).toFixed(4)) : null);
  const currentYearProfitLoss = company.profit ?? n(firstLoose(quote, ['profitAfterTax', 'profit', 'pat'])) ?? n(firstLoose(row, ['profitAfterTax', 'profit', 'pat', 'netProfit', 'profit after taxation']));
  const previousYearProfitLoss = company.previousProfit ?? n(firstLoose(row, ['previousProfit', 'previousYearProfit', 'priorYearProfit', 'previous profit']));

  const growth = currentYearProfitLoss !== null && previousYearProfitLoss !== null && previousYearProfitLoss !== 0
    ? (currentYearProfitLoss / previousYearProfitLoss) - 1 : null;
  const boundedGrowth = growth === null ? null : Math.max(-0.20, Math.min(0.25, growth));
  const expectedEps = currentEps !== null && boundedGrowth !== null ? Number((currentEps * (1 + boundedGrowth)).toFixed(2)) : null;
  const expectedBookValue = currentBookValue !== null && boundedGrowth !== null ? Number((currentBookValue * (1 + boundedGrowth)).toFixed(2)) : null;

  return {
    symbol: clean,
    companyName: String(firstLoose(row, ['name', 'companyName', 'company']) ?? clean),
    currentEps,
    expectedEps,
    peRatio: pe ?? n(firstLoose(quote, ['peRatio', 'pe', 'p/e'])),
    sectorMedianPe: median(sectorPes),
    faceValue: company.faceValue ?? n(firstLoose(row, ['faceValue', 'face value', 'par value'])),
    currentBookValue,
    expectedBookValue,
    currentEnterpriseValue: company.enterpriseValue ?? n(firstLoose(row, ['enterpriseValue', 'enterprise value', 'ev'])) ?? n(firstLoose(quote, ['enterpriseValue', 'enterprise value', 'ev'])),
    expectedEnterpriseValue: null,
    latestCashDividend: company.dividend ?? n(firstLoose(row, ['latestDividend', 'dividend', 'cashDividend', 'latest cash dividend'])) ?? n(firstLoose(quote, ['dividendAmount', 'dividend'])),
    expectedCashDividend: null,
    latestCashDividendExDate: company.exDate,
    currentYearProfitLoss,
    previousYearProfitLoss,
    source: company.faceValue || company.bookValue || company.enterpriseValue || company.dividend ? 'PSX Data Portal + PSX screener' : 'PSX screener (verified fields only)',
    fetchedAt,
  };
}
